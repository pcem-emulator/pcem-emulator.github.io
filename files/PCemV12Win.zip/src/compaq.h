void compaq_init();
