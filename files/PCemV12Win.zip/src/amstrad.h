void amstrad_init();

extern mouse_t mouse_amstrad;
