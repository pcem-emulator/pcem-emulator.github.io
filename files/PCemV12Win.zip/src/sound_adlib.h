extern device_t adlib_device;
