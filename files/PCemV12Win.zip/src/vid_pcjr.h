extern device_t pcjr_video_device;
extern device_t pcjr_device;
