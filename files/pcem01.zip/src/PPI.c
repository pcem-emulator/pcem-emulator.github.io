#include <allegro.h>
#include "ibm.h"

int keyboardtimer=0;
int output;
int keyboardresetcount;

unsigned char codeconvert[128]=
{
          0, 30, 48, 46, 32, 18, 33, 34, //0
         35, 23, 36, 37, 38, 50, 49, 24, //8
         25, 16, 19, 31, 20, 22, 47, 17, //16
         45, 21, 44, 11,  2,  3,  4,  5, //24
          6,  7,  8,  9, 10, 82, 79, 80, //32
         81, 75, 76, 77, 71, 72, 73, 59, //40
         60, 61, 62, 63, 64, 65, 66, 67, //48
         68, 87, 88,  1,  0, 12, 13, 14, //56
         15, 26, 27, 28, 39, 40, 43, 86, //64
         51, 52, 53, 57,  0,  0,  0,  0, //72
          0,  0, 75, 77, 72, 80,  0, 55, //80
         74, 78, 83,  0, 84,  0,  0,115, //88
        112,  0,  0,  0,  0,  0,  0, 42, //96
         54, 39,  0, 56,  0, 91, 92, 93, //104
         70, 69, 58, 42, 54, 29, 29, 56, //112
        121,  0,  0,  0,  0,  0,  0,  0, //120
};
/*Just to be difficult, the Tandy keyboard is slightly different*/
unsigned char codeconverttandy[128]=
{
          0, 30, 48, 46, 32, 18, 33, 34, //0
         35, 23, 36, 37, 38, 50, 49, 24, //8
         25, 16, 19, 31, 20, 22, 47, 17, //16
         45, 21, 44, 11,  2,  3,  4,  5, //24
          6,  7,  8,  9, 10, 82, 79, 80, //32
         81, 75, 76, 77, 71, 72, 73, 59, //40
         60, 61, 62, 63, 64, 65, 66, 67, //48
         68, 87, 88,  1,  0, 12, 13, 14, //56
         15, 26, 27, 28, 39, 40, 71, 71, //64
         51, 52, 53, 57,  0,  0,  0,  0, //72
          0,  0, 43, 78, 41, 74,  0, 55, //80
         74, 78, 83,  0, 84,  0,  0,115, //88
        112,  0,  0,  0,  0,  0,  0, 42, //96
         54, 39,  0, 56,  0, 91, 92, 93, //104
         70, 69, 58, 42, 54, 29, 29, 56, //112
        121,  0,  0,  0,  0,  0,  0,  0, //120
};
int oldkey[128];
unsigned char oldmb;

void checkkeys()
{
        int c;
        unsigned char d;
        if (pic.pend&pic.ins&2) return;
        if (keyboardtimer) return;
        for (c=0;c<128;c++)
        {
                if (key[c]!=oldkey[c])
                {
                        oldkey[c]=key[c];
                        if (TANDY) ppi.pa=codeconverttandy[c];
                        else       ppi.pa=codeconvert[c];
                        if (!oldkey[c]) ppi.pa|=0x80;
                        picint(2);
//                        printf("Sending key %02X\n",ppi.pa);
                        return;
                }
        }
        d=mouse_b;
        if (d!=oldmb)
        {
                if ((d^oldmb)&1)
                {
                        ppi.pa=0x7E;
                        if (!(d&1)) ppi.pa|=0x80;
                        picint(2);
                        oldmb=(oldmb&~1)|(d&1);
                        return;
                }
                if ((d^oldmb)&2)
                {
                        ppi.pa=0x7D;
                        if (!(d&1)) ppi.pa|=0x80;
                        picint(2);
                        oldmb=(oldmb&~2)|(d&2);
                        return;
                }
        }
}

void pressa()
{
        ppi.pa=codeconvert[KEY_A];
        picint(2);
}

void releasea()
{
        ppi.pa=codeconvert[KEY_A]|0x80;
        picint(2);
}

void resetppi()
{
        int c;
        ppi.pa=0xAA;//0x1D;
        for (c=0;c<128;c++) oldkey[c]=0;
        ppi.pb=0x40;
}

/*This makes the XT BIOS stop complaining of keyboard failure. I can't imagine
  why the keyboard would operate like this though, or what behaviour would make
  the XT BIOS expect this*/
/*It also makes the floppy drive stop working! Therefore disabled by default*/
void keyboardtimeout()
{
//        printf("Keyboard reset! %04X:%04X\n",cs>>4,pc);
/*        if (keyboardresetcount<2) */ppi.pa=0xAA;
//        else                      ppi.pa=0;
        keyboardresetcount++;
        picint(2);
}

unsigned char systemstat1,systemstat2;
void writeppi(unsigned short addr, unsigned char val)
{
//        printf("PPI write %04X %02X %04X:%04X %02X\n",addr,val,cs>>4,pc,BL);
//        output=1;
        switch (addr&7)
        {
                case 1:
/*                if (TANDY)
                {
                        if ((ppi.pb&0x80) && !(val&0x80))
                           keyboardtimer=500;
                }*/
                if (!(ppi.pb&0x40) && (val&0x40)) /*Reset keyboard*/
                        keyboardtimer=10000;
                if (AMSTRAD) ppi.s2=val&4;
                else         ppi.s2=val&8;
                ppi.pb=val;
                gated=((val&3)==3);
//                printf("Write PA %02X %i\n",val,gated);
                break;
                case 4:
                systemstat1=val;
                break;
                case 5:
                systemstat2=val;
                break;
        }
}

unsigned char readppi(unsigned short addr)
{
        unsigned char temp;
//        printf("PPI read %04X %04X:%04X\n",addr,cs>>4,pc);
        switch (addr&7)
        {
                case 0:
                if (ppi.pb&0x80 && AMSTRAD)
                {
//                        printf("Read PA with PB7 high %02X\n",systemstat1);
                        return (systemstat1|0xD)&0x7F;
                }
                if (ppi.pb&0x80 && romset==ROM_IBMPC)
                {
                        if (MDA) return 0x7D;
                        return 0x6D;
                }
//                printf("Reading PA %02X %04X:%04X\n",ppi.pa,cs>>4,pc);
/*                if (ppi.pa==0xEA)
                {
                        ppi.pa=0x65;
                        return 0xEA;
                }*/
//                output=1;
                return ppi.pa;
                case 1:
                return ppi.pb;
                case 2:
                if (AMSTRAD)
                {
                        if (ppi.s2) temp=systemstat2&0xF;
                        else        temp=systemstat2>>4;
                }
                else if (TANDY)
                {
                        if (ppi.s2)
                        {
                                if (MDA) temp=3|4|0x10;
                                else     temp=2|4|0x10;
                        }
                        else
                            temp=0xD|0x10;
                }
                else
                {
                        if (ppi.s2)
                        {
                                if (MDA) temp=3|4;
                                else     temp=2|4;
                        }
                        else
                            temp=0xD;
//                        temp|=(spkstat)?0x10:0;
                }
                temp|=((ppispeakon)?0x20:0);
//                printf("Read 62 %02X %02X\n",temp,systemstat2);
                return temp;
        }
        return 0xFF;
        printf("Bad PPI read %04X\n",addr);
        dumpregs();
        exit(-1);
}
