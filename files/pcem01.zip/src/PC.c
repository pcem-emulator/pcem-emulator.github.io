//3 6 and 9

#include <stdio.h>
#include <allegro.h>
#include <winalleg.h>
#include "ibm.h"

void loadconfig();
void saveconfig();
int infocus;
int mousecapture;
FILE *pclogf;
void pclog(const char *format, ...)
{
   char buf[256];
   return;
   if (!pclogf)
      pclogf=fopen("pclog.txt","wt");
//return;
   va_list ap;
   va_start(ap, format);
   vsprintf(buf, format, ap);
   va_end(ap);
   fputs(buf,pclogf);
   fflush(pclogf);
}
unsigned char cgastat;
int drawit=0;
void vsyncint()
{
        if (infocus || !drawit)
        {
                drawit++;
                wakeupmain();
        }
}

unsigned char mousex,mousey;

void writemouse(unsigned short addr, unsigned char val)
{
        if (addr==0x78) mousex=0;
        else            mousey=0;
}

unsigned char readmouse(unsigned short addr)
{
        unsigned char temp;
//        printf("Read mouse %04X:%04X\n",cs>>4,pc);
        if (addr==0x78)
        {
                temp=mousex;
                mousex=0;
                return temp;
        }
        temp=mousey;
        mousey=0;
        return temp;
}

void pollmouse()
{
        int x,y;
        get_mouse_mickeys(&x,&y);
        if (AMSTRAD)
        {
                mousex+=x;
                mousey-=y;
        }
//        else
//        {
                reportmouse(x,y,mouse_b);
//        }
        if (mousecapture) position_mouse(320,200);
}

/*PC1512 languages -
  7=English
  6=German
  5=French
  4=Spanish
  3=Danish
  2=Swedish
  1=Italian
        3,2,1 all cause the self test to fail for some reason
  */
void initpc()
{
        cpuspeed=1;
        romset=ROM_IBMXT;
        gfxcard=GFX_CGA;
        ADLIB=FASTDISC=GAMEBLASTER=0;
        allegro_init();
        install_keyboard();
        install_timer();
        install_mouse();
        loadconfig();
        initvideo();
        initmem();
        loadbios();
        resetx86();
        resetdma();
        resetpic();
        if (cpuspeed) setpitclock(8000000.0);
        else          setpitclock(4772728.0);
        resetpit();
        resetppi();
        resetserial();
        loaddisc(discfns[0]);
        loaddisc2(discfns[1]);
        loadfont();
        loadnvr();
        resetvideo();
        initsound();
        initpsg();
        install_int_ex(vsyncint,BPS_TO_TIMER(60));
}

void resetpc()
{
        resetx86();
        resetpit();
        resetppi();
        resetserial();
        resetdma();
        resetpic();
        resetvideo();
        resetfdc();
}

void resetpchard()
{
        resetpc();
        memset(ram,0,640*1024);
        memset(vram,0,256*1024);
}

char romsets[5][40]={"IBM PC","IBM XT","Tandy 1000","Amstrad PC1512","Sinclair PC200"};
int framecount=0;
int sndcount=0;
void runpc()
{
        char s[200];
        if (!drawit) waitmain();
        if (drawit)
        {
//                printf("Running!\n");
                drawit--;
                cgastat|=8;
                execx86((cpuspeed)?23333:13920);
                cgastat&=~8;
                execx86((cpuspeed)?110000:65625);
//                picint(0x20); /*IRQ 5 - vsync*/
                drawscreen();
                checkkeys();
                pollmouse();
                framecount++;
                if (framecount==60)
                {
                        framecount=0;
                        sprintf(s,"PCem - %s - %s - %s",romsets[romset],(cpuspeed)?"8mhz":"4.77mhz",(!mousecapture)?"Click to capture mouse":"Press CTRL-END to release mouse");
                        set_window_title(s);
                        intcount=pitcount=0;
                }
                pollad();
//                printf("Pollpsg!\n");
                pollpsg();
                pollcms();
//                printf("Pollpsgover!\n");
                sndcount++;
                if (sndcount==3)
                {
                        sndcount=0;
                        pollsound();
                }
//                printf("End of run!\n");
        }
}

void closepc()
{
        dumpregs();
        savenvr();
        savedisc2();
        savedisc();
        saveconfig();
        closevideo();
}

/*int main()
{
        initpc();
        while (!key[KEY_F11])
        {
                runpc();
        }
        closepc();
        return 0;
}

END_OF_MAIN();*/

void loadconfig()
{
        char *p;
        set_config_file("pcem.cfg");
        ADLIB=get_config_int(NULL,"adlib",1);
        GAMEBLASTER=get_config_int(NULL,"gameblaster",0);
        FASTDISC=get_config_int(NULL,"fast_disc",1);
        romset=get_config_int(NULL,"romset",-1);
        gfxcard=get_config_int(NULL,"gfxcard",0);
        cpuspeed=get_config_int(NULL,"cpu_speed",1);
        p=get_config_string(NULL,"disc_a","");
        if (p) strcpy(discfns[0],p);
        else   strcpy(discfns[0],"");
        p=get_config_string(NULL,"disc_b","");
        if (p) strcpy(discfns[1],p);
        else   strcpy(discfns[1],"");
}

void saveconfig()
{
        set_config_int(NULL,"adlib",ADLIB);
        set_config_int(NULL,"gameblaster",GAMEBLASTER);
        set_config_int(NULL,"fast_disc",FASTDISC);
        set_config_int(NULL,"romset",romset);
        set_config_int(NULL,"gfxcard",gfxcard);
        set_config_int(NULL,"cpu_speed",cpuspeed);
        set_config_string(NULL,"disc_a",discfns[0]);
        set_config_string(NULL,"disc_b",discfns[1]);
}
