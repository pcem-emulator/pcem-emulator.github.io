#include "ibm.h"

int pit0;
void resetpic()
{
        pic.icw=0;
        pic.mask=0xFF;
        pic.pend=pic.ins=0;
}

void writepic(unsigned short addr, unsigned char val)
{
        int c;
//        printf("Write PIC %04X %02X %i %04X:%04X\n",addr,val,pic.icw,cs>>4,pc);
        if (addr&1)
        {
                switch (pic.icw)
                {
                        case 0: /*OCW1*/
//                        printf("Write mask %02X\n",val);
                        pic.mask=val;
                        break;
                        case 1: /*ICW2*/
                        if (pic.icw1&2) pic.icw=3;
                        else            pic.icw=2;
                        break;
                        case 2: /*ICW3*/
                        if (pic.icw1&1) pic.icw=3;
                        else            pic.icw=0;
                        break;
                        case 3: /*ICW4*/
                        pic.icw=0;
                        break;
                }
        }
        else
        {
                if (val&16) /*ICW1*/
                {
                        pic.mask=0xFF;
                        pic.icw=1;
                        pic.icw1=val;
                }
                else if (!(val&8)) /*OCW2*/
                {
                        if ((val&0xE0)==0x60)
                        {
                                pic.ins&=(1<<(val&7));
                                pic.pend&=(1<<(val&7));
                        }
                        else
                        {
                                for (c=0;c<8;c++)
                                {
                                        if (pic.ins&(1<<c))
                                        {
                                                pic.ins&=~(1<<c);
                                                pic.pend&=~(1<<c);
                                                if (c==0) pit0=1;
                                                return;
                                        }
                                }
                        }
                }
                else               /*OCW3*/
                {
                }
        }
}

unsigned char readpic(unsigned short addr)
{
        if (addr&1) return pic.mask;
        return pic.ins;
}

void updatepicints()
{
        int c;
        unsigned char temp=pic.pend&~pic.mask;        
        for (c=0;c<8;c++)
        {
                if (temp&(1<<c))
                {
                        pic.pend&=~(1<<c);
                        pic.ins|=(1<<c);
//                        printf("Cause interrupt %02X\n",c+8);
//                        i86_Cause_Interrupt(c+8);
                        return;
                }
        }
//        i86_Clear_Pending_Interrupts();
}
        
void clearpic()
{
        pic.pend=pic.ins=0;
}

void picint(int num)
{
//        printf("PIC int %i %02X %i\n",num,pic.mask,flags&I_FLAG);
        pic.pend|=num;
}

unsigned char picinterrupt()
{
        unsigned char temp=pic.pend&~pic.mask;
        int c;
        for (c=0;c<8;c++)
        {
                if (temp&(1<<c))
                {
                        pic.pend&=~(1<<c);
                        pic.ins|=(1<<c);
//                        if (c==0) pic.ins&=~1;
                        return c+8;
                }
        }
        return 0xFF;
}

void picclear(int num)
{
        pic.pend&=~num;
        pic.ins&=~num;
        if (num==1) pit0=1;
}
