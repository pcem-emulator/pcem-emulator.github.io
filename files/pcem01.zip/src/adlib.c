#include "ibm.h"
#include "adlibemu.h"

/*Interfaces between PCem and the actual Adlib emulator*/

int adlibaddr;
unsigned char adlibstat;
unsigned char adlibt1,adlibt2;
unsigned short adlibbuf[5488];
int adlibpos=0;

void writeadlib(unsigned short a, unsigned char v)
{
        if (!(a&1)) adlibaddr=v;
        else
        {
                adlib0(adlibaddr,v);
                switch (adlibaddr)
                {
                        case 4: /*Timer control*/
                        if (v==0x80) adlibstat=0;
                        if (v&1) adlibstat|=0xC0;
                        if (v&2) adlibstat|=0xA0;
                        break;
                }
        }
}

unsigned char readadlib(unsigned short a)
{
        if (!(a&1)) return adlibstat;
        return 0;
}

void getadlib(unsigned short *buf, int size)
{
        int c;
        adlibgetsample(buf,size*2);
        for (c=0;c<size;c++)
            buf[c]^=0x8000;
        buf[c]>>=1;
}

void initadlib()
{
        adlibinit(44100,1,2);
}

void polladlib()
{
//        return;
//        printf("Poll adlib %i\n",adlibpos*686);
        getadlib(&adlibbuf[adlibpos*686],686);
        adlibpos++;
}
