#include "ibm.h"

unsigned char dmaregs[16];

void resetdma()
{
        int c;
        dma.wp=0;
        for (c=0;c<16;c++) dmaregs[c]=0;
        for (c=0;c<4;c++)
        {
                dma.mode[c]=0;
                dma.ac[c]=0;
                dma.cc[c]=0;
                dma.ab[c]=0;
                dma.cb[c]=0;
        }
        dma.m=0;
}

unsigned char readdma(unsigned short addr)
{
        unsigned char temp;
//        printf("Read DMA %04X %04X:%04X\n",addr,cs>>4,pc);
        switch (addr&0xF)
        {
                case 0:
                if (((dma.mode[0]>>2)&3)==2)
                {
                        dma.ac[0]++;
                        dma.cc[0]--;
                        if (dma.cc[0]<0)
                        {
                                dma.ac[0]=dma.ab[0];
                                dma.cc[0]=dma.cb[0];
                        }
                }
                case 2: case 4: case 6: /*Address registers*/
                dma.wp^=1;
                if (dma.wp) return dma.ac[(addr>>1)&3]&0xFF;
                return dma.ac[(addr>>1)&3]>>8;
                case 1: case 3: case 5: case 7: /*Count registers*/
                dma.wp^=1;
                if (dma.wp) temp=dma.cc[(addr>>1)&3]&0xFF;
                else        temp=dma.cc[(addr>>1)&3]>>8;
//                printf("%02X\n",temp);
                return temp;
                case 8: /*Status register*/
                temp=dma.stat;
                dma.stat=0;
                return temp|1;
        }
        return dmaregs[addr&0xF];
        printf("Bad DMA read %04X\n",addr);
        dumpregs();
        exit(-1);
}

void writedma(unsigned short addr, unsigned char val)
{
//        printf("Write DMA %04X %02X %04X:%04X\n",addr,val,cs>>4,pc);
        dmaregs[addr&0xF]=val;
        switch (addr&0xF)
        {
                case 0: case 2: case 4: case 6: /*Address registers*/
                dma.wp^=1;
                if (dma.wp) dma.ab[(addr>>1)&3]=(dma.ab[(addr>>1)&3]&0xFF00)|val;
                else        dma.ab[(addr>>1)&3]=(dma.ab[(addr>>1)&3]&0xFF)|(val<<8);
                dma.ac[(addr>>1)&3]=dma.ab[(addr>>1)&3];
//                printf("DMA addr %i now %04X\n",(addr>>1)&3,dma.ac[(addr>>1)&3]);
                return;
                case 1: case 3: case 5: case 7: /*Count registers*/
                dma.wp^=1;
                if (dma.wp) dma.cb[(addr>>1)&3]=(dma.cb[(addr>>1)&3]&0xFF00)|val;
                else        dma.cb[(addr>>1)&3]=(dma.cb[(addr>>1)&3]&0xFF)|(val<<8);
                dma.cc[(addr>>1)&3]=dma.cb[(addr>>1)&3];
//                printf("DMA count %i now %04X\n",(addr>>1)&3,dma.cc[(addr>>1)&3]);
                return;
                case 8: /*Control register*/
                return;
                case 0xA: /*Mask*/
                if (val&4) dma.m|=(1<<(val&3));
                else       dma.m&=~(1<<(val&3));
                return;
                case 0xB: /*Mode*/
                dma.mode[val&3]=val;
                return;
                case 0xC: /*Clear FF*/
                dma.wp=0;
                return;
                case 0xD: /*Master clear*/
                dma.wp=0;
                dma.m=0xF;
                return;
                case 0xF: /*Mask write*/
                dma.m=val&0xF;
                return;
        }
        printf("Bad DMA write %04X %02X\n",addr,val);
//        dumpregs();
//        exit(-1);
}

void writepage(unsigned short addr, unsigned char val)
{
        switch (addr&7)
        {
                case 1:
                dma.page[2]=val;
                break;
        }
//        printf("Page write %04X %02X\n",addr,val);
}

void writedma2(unsigned char val)
{
//        printf("Write to %05X %02X %i\n",(dma.page[2]<<16)+dma.ac[2],val,dma.m&4);
        if (!(dma.m&4))
        {
                writememb((dma.page[2]<<16)+dma.ac[2],val);
                dma.ac[2]++;
                dma.cc[2]--;
                if (dma.cc[2]==-1)
                {
                        dma.m|=4;
                        dma.stat|=4;
                }
        }
}

int readdma2()
{
        unsigned char temp=readmemb((dma.page[2]<<16)+dma.ac[2]);
        if (dma.m&4)
        {
                return -1;
        }
//        printf("Read DMA 2 - %02X %05X\n",temp,(dma.page[2]<<16)+dma.ac[2]);
        if (!(dma.m&4))
        {
                dma.ac[2]++;
                dma.cc[2]--;
                if (dma.cc[2]==-1)
                {
                        dma.m|=4;
                        dma.stat|=4;
                }
        }
        return temp;
}

void readdma0()
{
        if (AMSTRAD) return;
//        if (!(dma.m&1))
//        {
                dma.ac[0]+=2;
                dma.cc[0]--;
                if (dma.cc[0]==-1)
                {
                        dma.stat|=1;
                        dma.ac[0]=dma.ab[0];
                        dma.cc[0]=dma.cb[0];
                }
//        }
}

void dumpdma()
{
        printf("Address : %04X %04X %04X %04X\n",dma.ac[0],dma.ac[1],dma.ac[2],dma.ac[3]);
        printf("Count   : %04X %04X %04X %04X\n",dma.cc[0],dma.cc[1],dma.cc[2],dma.cc[3]);
        printf("Mask %02X Stat %02X\n",dma.m,dma.stat);
}
