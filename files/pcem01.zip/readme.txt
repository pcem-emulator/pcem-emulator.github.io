PCem v0.1
~~~~~~~~~

PCem emulates various old XT clones on Windows.

PCem is licensed under the GPL, see COPYING for more details.


PCem emulates the following machines:

IBM 5150 PC (1981) 
The original PC. This shipped in 1981 with a 4.77mhz 8088, 64k of RAM, and a cassette port.
Disc drives quickly became standard, along with more memory.

ROM files needed:

pc102782.bin
basicc11.f6
basicc11.f8
basicc11.fa
basicc11.fc


IBM 5160 XT (1983)
From a hardware perspective, this is a minor tweak of the original PC. It originally shipped
with 128k of RAM and a 10mb hard disc, both of which could be easily fitted to the 1981 machine.
However, this was targetted as businesses and was more successful than the original.

ROM files needed:

xt050986.0
xt050986.1


Tandy 1000 (1985)
This is a clone of the unsuccessful IBM PCjr, which added better graphics and sound to the XT,
but removed much expandability plus some other hardware (such as the DMA controller). The Tandy
puts back the DMA controller and ISA slots, making it a much more useful machine. Many games
from the late 80s support the Tandy.

ROM files needed:

tandy1t1.020


Amstrad PC1512 (1986)
This was Amstrad's first entry into the PC clone market (after the CPC and PCW machines), and
was the first cheap PC available in the UK, selling for only �500. It was a 'turbo' clone, 
having an 8mhz 8086, as opposed to an 8088, and had 512k RAM as standard. It also had a 
perculiar modification to its onboard CGA controller - the 640x200 mode had 16 colours instead
of the usual 2. This was put to good use by GEM, which shipped with the machine.

ROM files needed:

40043.v1
40044.v2


Sinclair PC200/Amstrad PC20 (1988)
This was Amstrad's entry to the 16-bit home computer market, intended to compete with the Atari
ST and Commodore Amiga. It's similar to the PC1512, but is based on Amstrad's portable PPC512
system. With stock CGA and PC speaker, it couldn't compare with the ST or Amiga.

ROM files needed:

pc20v2.0
pc20v2.1



PCem emulates the following graphics adapters :

MDA - The original PC adapter. This displays 80x25 text in monochrome.
Hercules - A clone of MDA, with the addition of a high-resolution 720x348 graphics mode.
CGA - The most common of the original adapters, supporting 40x25 and 80x25 text, and 
    320x200 in 4 colours, 640x200 in 2 colours, and a composite mode giving 160x200 in 16 colours.
PC1512 - This is a CGA clone with a new mode - 640x200 in 16 colours. To my knowledge, the
    new mode is only used by GEM.
Tandy - This adds all sorts of new modes to CGA - 160x200x16, 320x200x16, 640x200x4.


Pcem emulates the following sound devices :

PC speaker - The standard beeper on all PCs. Supports samples/RealSound.
Tandy PSG - The Texas Instruments chip in the PCjr and Tandy 1000. Supports 3 voices plus
    noise.
Gameblaster - The Creative Labs Gameblaster/Creative Music System, Creative's first sound card
    introduced in 1987. Has two Philips SAA1099, giving 12 voices of square waves plus 4 noise
    voices. In stereo!
Adlib - The one the Sound Blaster ripped off. Has a Yamaha YM3812, giving 9 voices of 2 op FM,
    or 6 voices plus a rubbish drum section. PCem uses Ken Silverman's emulator for this.


Other stuff emulated :

Serial mouse - A Mouse Systems compatible serial mouse on COM1. Compatible drivers are all over
    the place for this.
PC1512 mouse - The PC1512's perculiar quadrature mouse. You need Amstrad's actual driver for this
    one.


Options :

Fast disc access - this will bypass the BIOS and FDC for disc accesses, speeding them up 
    somewhat. Recommended for DOS, but most booter games need this turned off.


Notes :

- The original IBM PC BIOS only supports up to 256k RAM.

- Both the PC and XT fail part of their self test. This doesn't really affect anything, just puts
  an irritating message on the screen.

- The time on the PC1512 clock is wrong. The date is correct, though since the PC1512's bios isn't
  Y2k compliant, it thinks it's 1987.

- The PC200's video system isn't really emulated. The real machine has an NMI system to 'catch'
  unsupported video writes. Since this isn't there, the PC200 doesn't pass self test. It instead is
  run in diagnostic mode, where only 512k of RAM is available.

- The envelope system on the Gameblaster isn't emulated. The noise may not be right either.


Software tested:

Booter games :

Battlezone
Centipede
Commando
Defender
Digger (missing music)
Galaxian
Jumpman (needs fast disc access on)
King's Quest (Tandy)
King's Quest (CGA) (needs fast disc off to start with, then on after title screen)
King's Quest 2 (CGA)
Rollo and the Brush Brothers
Space Strike
Spider Bot
Zaxxon

Boulderdash (hangs)
Cosmic whatever (bombs out or hangs)


DOS stuff :

MS-DOS 3.30
PC-DOS 3.30
PC-DOS 5.02
MS-DOS 6.22

DR-DOS 6.0


Windows 3.0 (CGA, Hercules) (I can't find a way to make the mouse work)
GEM 2       (CGA, Hercules, PC1512)


Another World (Tandy)
Arkanoid (CGA, Tandy)
Batman (CGA, Tandy)
Block Out (CGA, Tandy)
Elite
Hoyle (CGA, Tandy)
Jill of the Jungle
King's Quest 3 (CGA, Composite, Tandy)
King's Quest 4 (Tandy)
Lands of Lore
Lemmings (CGA, Tandy)
Monopoly
Moonbugs
Outrun (CGA, Tandy)
Police Quest (CGA, Composite, Tandy)
Prince of Persia (CGA, Tandy)
Psion Chess (CGA, Hercules)
Road Runner
Secret of Monkey Island (Tandy)
Space Racer
Star Wars
Tetris
The Cycles
Xenon 2 (CGA, Tandy)
Zak McKraken (CGA, Tandy)


Tom Walker
tommowalker@yahoo.co.uk