extern device_t ati28800_device;
extern device_t ati28800k_device;
extern device_t ati28800k_spc4620p_device;
