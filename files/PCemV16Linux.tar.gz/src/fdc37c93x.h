extern void fdc37c932fr_init();
