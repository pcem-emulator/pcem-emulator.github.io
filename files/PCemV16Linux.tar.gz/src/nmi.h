void nmi_init();
void nmi_write(uint16_t port, uint8_t val, void *p);
extern int nmi_mask;


