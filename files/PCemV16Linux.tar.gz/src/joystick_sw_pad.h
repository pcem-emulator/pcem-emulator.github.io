extern joystick_if_t joystick_sw_pad;
