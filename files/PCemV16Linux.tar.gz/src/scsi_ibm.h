extern device_t scsi_ibm_device;
