extern device_t pc200_device;
extern device_t ppc512_device;

extern int pc200_is_mda;
