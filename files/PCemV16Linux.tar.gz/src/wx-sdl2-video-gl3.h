sdl_renderer_t* gl3_renderer_create();
void gl3_renderer_close(sdl_renderer_t* renderer);
int gl3_renderer_available(struct sdl_render_driver* driver);
