void acc2168_init();
