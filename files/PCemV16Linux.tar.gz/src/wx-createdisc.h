#ifndef SRC_WX_CREATEDISC_H_
#define SRC_WX_CREATEDISC_H_

extern "C" {
void creatediscimage_open(void *hwnd);
}

#endif /* SRC_WX_CREATEDISC_H_ */
