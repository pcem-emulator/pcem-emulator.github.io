extern device_t genius_device;
