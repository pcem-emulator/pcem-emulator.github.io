void acer386sx_init();
void acer386sx_set_oti067(void *oti067);
