void ali1429_init();
void ali1429_reset();
