extern void fdc37c665_init();
