extern device_t pas16_device;
