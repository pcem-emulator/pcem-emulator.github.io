void i430fx_init();
