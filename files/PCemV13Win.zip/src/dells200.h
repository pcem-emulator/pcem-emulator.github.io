void dells200_chipset_init();
