extern device_t mach64gx_device;
extern device_t mach64vt2_device;
