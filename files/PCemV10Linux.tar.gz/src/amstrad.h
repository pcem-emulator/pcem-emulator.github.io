void amstrad_init();

