void keyboard_olim24_init();
void keyboard_olim24_reset();
void keyboard_olim24_poll();
