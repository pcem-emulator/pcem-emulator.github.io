void ps1mb_init();
