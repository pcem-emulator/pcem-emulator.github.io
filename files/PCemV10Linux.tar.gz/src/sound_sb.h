extern device_t sb_1_device;
extern device_t sb_15_device;
extern device_t sb_2_device;
extern device_t sb_pro_v1_device;
extern device_t sb_pro_v2_device;
extern device_t sb_16_device;
extern device_t sb_awe32_device;
