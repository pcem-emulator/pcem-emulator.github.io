void allegro_video_init();
void allegro_video_close();
void allegro_video_update_size(int x, int y);
