extern device_t mach64gx_device;
