extern device_t s3_virge_device;
extern device_t s3_virge_375_device;
