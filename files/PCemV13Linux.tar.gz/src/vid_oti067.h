extern device_t oti067_device;
extern device_t oti067_acer386_device;

void oti067_enable_disable(void *p, int enable);
