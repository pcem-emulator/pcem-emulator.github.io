extern device_t et4000_device;
