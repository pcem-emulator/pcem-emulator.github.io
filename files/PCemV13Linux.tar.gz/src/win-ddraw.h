#ifdef __cplusplus
extern "C" {
#endif
        void ddraw_init(HWND h);
        void ddraw_close();
#ifdef __cplusplus
}
#endif

