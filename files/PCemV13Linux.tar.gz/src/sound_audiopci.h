extern device_t es1371_device;
