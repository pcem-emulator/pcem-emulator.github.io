sdl_renderer_t* sdl2_renderer_create();
void sdl2_renderer_close(sdl_renderer_t* renderer);
int sdl2_renderer_available(struct sdl_render_driver* driver);
