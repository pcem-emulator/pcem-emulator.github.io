extern device_t t3100e_device;

void t3100e_video_options_set(uint8_t options);
void t3100e_display_set(uint8_t internal);
