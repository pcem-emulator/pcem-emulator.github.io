extern device_t xtide_device;
extern device_t xtide_at_device;
extern device_t xtide_ps1_device;
