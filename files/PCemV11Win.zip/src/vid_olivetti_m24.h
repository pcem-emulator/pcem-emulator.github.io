extern device_t m24_device;
