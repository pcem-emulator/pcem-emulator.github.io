void i430vx_init();
