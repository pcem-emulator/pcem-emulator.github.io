extern device_t ati18800_device;
