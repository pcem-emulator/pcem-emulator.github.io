extern device_t gameport_device;
extern device_t gameport_201_device;
