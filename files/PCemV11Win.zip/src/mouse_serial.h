void mouse_serial_init();
