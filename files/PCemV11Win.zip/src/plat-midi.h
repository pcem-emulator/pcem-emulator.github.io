void midi_init();
void midi_close();
void midi_write(uint8_t val);
