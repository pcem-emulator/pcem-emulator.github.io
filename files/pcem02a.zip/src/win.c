#include <allegro.h>
#include <winalleg.h>
#include "ibm.h"
#include "resources.h"

int vgapresent;

void soundthread(LPVOID param);
void endsoundthread();
void silencesound();
void restoresound();
static HANDLE soundobject;
AUDIOSTREAM *as;

static HANDLE frameobject;

int romspresent[7];
int quited=0;

RECT oldclip,pcclip;
int mousecapture=0;
int drawit;
/*  Declare Windows procedure  */
LRESULT CALLBACK WindowProcedure (HWND, UINT, WPARAM, LPARAM);

/*  Make the class name into a global variable  */
char szClassName[ ] = "WindowsApp";

HWND ghwnd;
void updatewindowsize(int x, int y)
{
        RECT r;
        GetWindowRect(ghwnd,&r);
        MoveWindow(ghwnd,r.left,r.top,
                     x+(GetSystemMetrics(SM_CXFIXEDFRAME)*2),
                     y+(GetSystemMetrics(SM_CYFIXEDFRAME)*2)+GetSystemMetrics(SM_CYMENUSIZE)+GetSystemMetrics(SM_CYCAPTION)+1,
                     TRUE);
}

void releasemouse()
{
        if (mousecapture) ClipCursor(&oldclip);
}

static LARGE_INTEGER counter_base;
static LARGE_INTEGER counter_freq;
static LARGE_INTEGER counter_pos;
static LARGE_INTEGER counter_posold;

void setrefresh(int rate)
{
        counter_freq.QuadPart=counter_base.QuadPart/rate;
}

HINSTANCE hinstance;
int infocus=1;
int WINAPI WinMain (HINSTANCE hThisInstance,
                    HINSTANCE hPrevInstance,
                    LPSTR lpszArgument,
                    int nFunsterStil)

{
    HWND hwnd;               /* This is the handle for our window */
    MSG messages;            /* Here messages to the application are saved */
    WNDCLASSEX wincl;        /* Data structure for the windowclass */
    HANDLE soundthreadh;
    int c,d;
    FILE *f;

        hinstance=hThisInstance;
    /* The Window structure */
    wincl.hInstance = hThisInstance;
    wincl.lpszClassName = szClassName;
    wincl.lpfnWndProc = WindowProcedure;      /* This function is called by windows */
    wincl.style = CS_DBLCLKS;                 /* Catch double-clicks */
    wincl.cbSize = sizeof (WNDCLASSEX);

    /* Use default icon and mouse-pointer */
    wincl.hIcon = LoadIcon (NULL, IDI_APPLICATION);
    wincl.hIconSm = LoadIcon (NULL, IDI_APPLICATION);
    wincl.hCursor = LoadCursor (NULL, IDC_ARROW);
    wincl.lpszMenuName = NULL;                 /* No menu */
    wincl.cbClsExtra = 0;                      /* No extra bytes after the window class */
    wincl.cbWndExtra = 0;                      /* structure or the window instance */
    /* Use Windows's default color as the background of the window */
    wincl.hbrBackground = (HBRUSH) COLOR_BACKGROUND;

    /* Register the window class, and if it fails quit the program */
    if (!RegisterClassEx (&wincl))
        return 0;

    /* The class is registered, let's create the program*/
    hwnd = CreateWindowEx (
           0,                   /* Extended possibilites for variation */
           szClassName,         /* Classname */
           "PCem",       /* Title Text */
           WS_OVERLAPPEDWINDOW&~WS_SIZEBOX, /* default window */
           CW_USEDEFAULT,       /* Windows decides the position */
           CW_USEDEFAULT,       /* where the window ends up on the screen */
           640+(GetSystemMetrics(SM_CXFIXEDFRAME)*2),                 /* The programs width */
           400+(GetSystemMetrics(SM_CYFIXEDFRAME)*2)+GetSystemMetrics(SM_CYMENUSIZE)+GetSystemMetrics(SM_CYCAPTION)+1,                 /* and height in pixels */
           HWND_DESKTOP,        /* The window is a child-window to desktop */
           LoadMenu(hThisInstance,TEXT("MainMenu")),                /* No menu */
           hThisInstance,       /* Program Instance handler */
           NULL                 /* No Window Creation data */
           );

        /* Make the window visible on the screen */
        ShowWindow (hwnd, nFunsterStil);

        win_set_window(hwnd);
        
        ghwnd=hwnd;

        initpc();
        
        d=romset;
        for (c=0;c<7;c++)
        {
                romset=c;
                romspresent[c]=loadbios();
        }
        romset=d;
        c=loadbios();
        
        if (!romspresent[0] && !romspresent[1] && !romspresent[2] && !romspresent[3] && !romspresent[4] && !romspresent[5] && !romspresent[6])
        {
                MessageBox(hwnd,"No ROMs present!\nYou must have at least one romset to use PCem.","PCem fatal error",MB_OK);
                return 0;
        }
        if (!c)
        {
                if (romset!=-1) MessageBox(hwnd,"Configured romset not available.\nDefaulting to available romset.","PCemu error",MB_OK);
                for (c=0;c<7;c++)
                {
                        if (romspresent[c])
                        {
                                romset=c;
                                loadbios();
                                break;
                        }
                }
        }
        
        f=romfopen("roms/trident.bin","rb");
        if (f)
        {
                fclose(f);
                vgapresent=1;
        }
        else
        {
                vgapresent=0;
                if (gfxcard==GFX_SVGA) gfxcard=GFX_CGA;
        }
        timeBeginPeriod(1);
        soundobject=CreateEvent(NULL, FALSE, FALSE, NULL);
        soundthreadh=CreateThread(NULL,0,soundthread,NULL,NULL,NULL);
        //(HANDLE)_beginthread(soundthread,0,NULL);
        atexit(endsoundthread);
//        SetThreadPriority(soundthreadh,THREAD_PRIORITY_TIME_CRITICAL);
        
        frameobject=CreateEvent(NULL, FALSE, FALSE, NULL);

//        SetThreadPriority(GetCurrentThread(), THREAD_PRIORITY_HIGHEST);
        
        atexit(releasemouse);
        atexit(endsoundthread);
        drawit=0;
        QueryPerformanceFrequency(&counter_base);
        setrefresh(60);
        QueryPerformanceCounter(&counter_posold);
        /* Run the message loop. It will run until GetMessage() returns 0 */
        while (!quited)
        {
                if (infocus)
                {
                        for (c=0;c<2;c++)
                        {
                                runpc();
                                if ((key[KEY_LCONTROL] || key[KEY_RCONTROL]) && key[KEY_END] && mousecapture)
                                {
                                        ClipCursor(&oldclip);
                                        mousecapture=0;
                                }
                                QueryPerformanceCounter(&counter_pos);
                                while (counter_pos.QuadPart<(counter_posold.QuadPart+counter_freq.QuadPart))
                                {
                                        QueryPerformanceCounter(&counter_pos);
                                        sleep(0);
                                }
                                counter_posold.QuadPart+=counter_freq.QuadPart;
                        }
                }
                else
                   sleep(1);
                if (PeekMessage(&messages,NULL,0,0,PM_REMOVE))
                {
                        if (messages.message==WM_QUIT)
                           quited=1;
                        /* Translate virtual-key messages into character messages */
                        TranslateMessage(&messages);
                        /* Send message to WindowProcedure */
                        DispatchMessage(&messages);
                }
        }
        timeEndPeriod(1);
        endsoundthread();
        dumpregs();
        if (mousecapture) ClipCursor(&oldclip);
        closepc();
        return messages.wParam;
}

char openfilestring[260];
int getfile(HWND hwnd, char *f, char *fn)
{
        OPENFILENAME ofn;       // common dialog box structure
        char szFile[260];       // buffer for file name

        // Initialize OPENFILENAME
        ZeroMemory(&ofn, sizeof(ofn));
        ofn.lStructSize = sizeof(ofn);
        ofn.hwndOwner = hwnd;
        ofn.lpstrFile = openfilestring;
        //
        // Set lpstrFile[0] to '\0' so that GetOpenFileName does not
        // use the contents of szFile to initialize itself.
        //
//        ofn.lpstrFile[0] = '\0';
        strcpy(ofn.lpstrFile,fn);
        ofn.nMaxFile = sizeof(openfilestring);
        ofn.lpstrFilter = f;//"All\0*.*\0Text\0*.TXT\0";
        ofn.nFilterIndex = 1;
        ofn.lpstrFileTitle = NULL;
        ofn.nMaxFileTitle = 0;
        ofn.lpstrInitialDir = NULL;
        ofn.Flags = OFN_PATHMUSTEXIST | OFN_FILEMUSTEXIST;

        // Display the Open dialog box.

        if (GetOpenFileName(&ofn))
           return 0;
        return 1;
}

int romstolist[7],listtoroms[7];
BOOL CALLBACK configdlgproc(HWND hdlg, UINT message, WPARAM wParam, LPARAM lParam)
{
        HWND h;
        int c;
        int rom,gfx;
        switch (message)
        {
                case WM_INITDIALOG:
                h=GetDlgItem(hdlg,IDC_COMBO1);
                for (c=0;c<7;c++) romstolist[c]=0;
                c=0;
                if (romspresent[ROM_IBMPC])  { SendMessage(h,CB_ADDSTRING,0,(LPARAM)(LPCSTR)"IBM PC"); romstolist[ROM_IBMPC]=c; listtoroms[c]=ROM_IBMPC; c++; }
                if (romspresent[ROM_IBMXT])  { SendMessage(h,CB_ADDSTRING,0,(LPARAM)(LPCSTR)"IBM XT"); romstolist[ROM_IBMXT]=c; listtoroms[c]=ROM_IBMXT; c++; }
                if (romspresent[ROM_TANDY])  { SendMessage(h,CB_ADDSTRING,0,(LPARAM)(LPCSTR)"Tandy 1000"); romstolist[ROM_TANDY]=c; listtoroms[c]=ROM_TANDY; c++; }
                if (romspresent[ROM_PC1512]) { SendMessage(h,CB_ADDSTRING,0,(LPARAM)(LPCSTR)"Amstrad PC1512"); romstolist[ROM_PC1512]=c; listtoroms[c]=ROM_PC1512; c++; }
                if (romspresent[ROM_PC200])  { SendMessage(h,CB_ADDSTRING,0,(LPARAM)(LPCSTR)"Sinclair PC200"); romstolist[ROM_PC200]=c; listtoroms[c]=ROM_PC200; c++; }
                if (romspresent[ROM_PC1640]) { SendMessage(h,CB_ADDSTRING,0,(LPARAM)(LPCSTR)"Amstrad PC1640"); romstolist[ROM_PC1640]=c; listtoroms[c]=ROM_PC1640; c++; }
                if (romspresent[ROM_IBMAT])  { SendMessage(h,CB_ADDSTRING,0,(LPARAM)(LPCSTR)"IBM AT"); romstolist[ROM_IBMAT]=c; listtoroms[c]=ROM_IBMAT; c++; }
                SendMessage(h,CB_SETCURSEL,romstolist[romset],0);
                
                h=GetDlgItem(hdlg,IDC_COMBO2);
                SendMessage(h,CB_ADDSTRING,0,(LPARAM)(LPCSTR)"CGA");
                SendMessage(h,CB_ADDSTRING,0,(LPARAM)(LPCSTR)"MDA");
                SendMessage(h,CB_ADDSTRING,0,(LPARAM)(LPCSTR)"Hercules");
                if (vgapresent) SendMessage(h,CB_ADDSTRING,0,(LPARAM)(LPCSTR)"VGA");
                SendMessage(h,CB_SETCURSEL,gfxcard,0);
                if (romset>1 && romset<6) EnableWindow(h,FALSE);

                h=GetDlgItem(hdlg,IDC_COMBO3);
                SendMessage(h,CB_ADDSTRING,0,(LPARAM)(LPCSTR)"4.77mhz 8088");
                SendMessage(h,CB_ADDSTRING,0,(LPARAM)(LPCSTR)"8mhz 8086");
                SendMessage(h,CB_ADDSTRING,0,(LPARAM)(LPCSTR)"10mhz 8086");
                SendMessage(h,CB_ADDSTRING,0,(LPARAM)(LPCSTR)"12mhz 8086");
                SendMessage(h,CB_ADDSTRING,0,(LPARAM)(LPCSTR)"16mhz 8086");
                SendMessage(h,CB_SETCURSEL,cpuspeed,0);
                if (AT || romset>2) EnableWindow(h,FALSE);
                else                EnableWindow(h,TRUE);

                h=GetDlgItem(hdlg,IDC_COMBO4);
                SendMessage(h,CB_ADDSTRING,0,(LPARAM)(LPCSTR)"8mhz 80286");
                SendMessage(h,CB_ADDSTRING,0,(LPARAM)(LPCSTR)"12mhz 80286");
                SendMessage(h,CB_ADDSTRING,0,(LPARAM)(LPCSTR)"16mhz 80286");
                SendMessage(h,CB_ADDSTRING,0,(LPARAM)(LPCSTR)"20mhz 80286");
                SendMessage(h,CB_ADDSTRING,0,(LPARAM)(LPCSTR)"25mhz 80286");
                SendMessage(h,CB_SETCURSEL,cpuspeed,0);
                if (!AT) ShowWindow(h,SW_HIDE);
                else     ShowWindow(h,SW_SHOW);

                h=GetDlgItem(hdlg,IDC_COMBO5);
                SendMessage(h,CB_ADDSTRING,0,(LPARAM)(LPCSTR)"8mhz 8086");
                SendMessage(h,CB_ADDSTRING,0,(LPARAM)(LPCSTR)"10mhz 8086");
                SendMessage(h,CB_ADDSTRING,0,(LPARAM)(LPCSTR)"12mhz 8086");
                SendMessage(h,CB_ADDSTRING,0,(LPARAM)(LPCSTR)"16mhz 8086");
                if (cpuspeed) SendMessage(h,CB_SETCURSEL,cpuspeed-1,0);
                else          SendMessage(h,CB_SETCURSEL,0,0);
                if (!AT && romset>2) ShowWindow(h,SW_SHOW);
                else                 ShowWindow(h,SW_HIDE);

                h=GetDlgItem(hdlg,IDC_CHECK2);
                SendMessage(h,BM_SETCHECK,ADLIB,0);
                
                h=GetDlgItem(hdlg,IDC_CHECK3);
                SendMessage(h,BM_SETCHECK,GAMEBLASTER,0);
                
                h=GetDlgItem(hdlg,IDC_CHECK1);
                SendMessage(h,BM_SETCHECK,FASTDISC,0);

                return TRUE;
                case WM_COMMAND:
                switch (LOWORD(wParam))
                {
                        case IDOK:
                        h=GetDlgItem(hdlg,IDC_COMBO1);
                        rom=listtoroms[SendMessage(h,CB_GETCURSEL,0,0)];

                        h=GetDlgItem(hdlg,IDC_COMBO2);
                        gfx=SendMessage(h,CB_GETCURSEL,0,0);

                        if (rom!=romset || gfx!=gfxcard)
                        {
                                if (MessageBox(ghwnd,"This will reset PCem!\nOkay to continue?","PCem",MB_OKCANCEL)==IDOK)
                                {
                                        romset=rom;
                                        gfxcard=gfx;
                                        loadbios();
                                        resetpchard();
                                }
                                else
                                {
                                        EndDialog(hdlg,0);
                                        return TRUE;
                                }
                        }

                        h=GetDlgItem(hdlg,IDC_CHECK2);
                        ADLIB=SendMessage(h,BM_GETCHECK,0,0);

                        h=GetDlgItem(hdlg,IDC_CHECK3);
                        GAMEBLASTER=SendMessage(h,BM_GETCHECK,0,0);

                        h=GetDlgItem(hdlg,IDC_CHECK1);
                        FASTDISC=SendMessage(h,BM_GETCHECK,0,0);

                        if (AT)            h=GetDlgItem(hdlg,IDC_COMBO4);
                        else if (romset>2) h=GetDlgItem(hdlg,IDC_COMBO5);
                        else               h=GetDlgItem(hdlg,IDC_COMBO3);
                        cpuspeed=SendMessage(h,CB_GETCURSEL,0,0);
                        if (!AT && romset>2) cpuspeed++;

                        speedchanged();
//                        if (romset>2) cpuspeed=1;
//                        setpitclock(clocks[AT?1:0][cpuspeed][0]);
//                        if (cpuspeed) setpitclock(8000000.0);
//                        else          setpitclock(4772728.0);

                        case IDCANCEL:
                        EndDialog(hdlg,0);
                        return TRUE;
                        case IDC_COMBO1:
                        if (HIWORD(wParam)==CBN_SELCHANGE)
                        {
                                h=GetDlgItem(hdlg,IDC_COMBO1);
                                c=SendMessage(h,CB_GETCURSEL,0,0);
                                h=GetDlgItem(hdlg,IDC_COMBO2);
                                if (listtoroms[c]<2 || listtoroms[c]>=6) EnableWindow(h,TRUE);
                                else                                     EnableWindow(h,FALSE);
                                h=GetDlgItem(hdlg,IDC_COMBO3);
                                if (listtoroms[c]<3) EnableWindow(h,TRUE);
                                else                 EnableWindow(h,FALSE);
                                h=GetDlgItem(hdlg,IDC_COMBO4);
                                if (listtoroms[c]==ROM_IBMAT) ShowWindow(h,SW_SHOW);
                                else                          ShowWindow(h,SW_HIDE);
                                h=GetDlgItem(hdlg,IDC_COMBO5);
                                if (listtoroms[c]!=ROM_IBMAT && listtoroms[c]>2) ShowWindow(h,SW_SHOW);
                                else                                             ShowWindow(h,SW_HIDE);
                        }
                        break;
                }
                break;

        }
        return FALSE;
}

BOOL CALLBACK hdconfdlgproc(HWND hdlg, UINT message, WPARAM wParam, LPARAM lParam)
{
        char s[260];
        HWND h;
        int c;
        PcemHDC hd[2];
        int changeddrv=0;
        switch (message)
        {
                case WM_INITDIALOG:
                hd[0]=hdc[0];
                hd[1]=hdc[1];
                
                h=GetDlgItem(hdlg,IDC_EDIT1);
                sprintf(s,"%i",hdc[0].spt);
                SendMessage(h,WM_SETTEXT,0,(LPARAM)s);
                h=GetDlgItem(hdlg,IDC_EDIT2);
                sprintf(s,"%i",hdc[0].hpc);
                SendMessage(h,WM_SETTEXT,0,(LPARAM)s);
                h=GetDlgItem(hdlg,IDC_EDIT3);
                sprintf(s,"%i",hdc[0].tracks);
                SendMessage(h,WM_SETTEXT,0,(LPARAM)s);

                h=GetDlgItem(hdlg,IDC_EDIT4);
                sprintf(s,"%i",hdc[1].spt);
                SendMessage(h,WM_SETTEXT,0,(LPARAM)s);
                h=GetDlgItem(hdlg,IDC_EDIT5);
                sprintf(s,"%i",hdc[1].hpc);
                SendMessage(h,WM_SETTEXT,0,(LPARAM)s);
                h=GetDlgItem(hdlg,IDC_EDIT6);
                sprintf(s,"%i",hdc[1].tracks);
                SendMessage(h,WM_SETTEXT,0,(LPARAM)s);
                
                h=GetDlgItem(hdlg,IDC_TEXT1);
                sprintf(s,"Size : %imb",((((hd[0].tracks*hd[0].hpc)*hd[0].spt)*512)/1024)/1024);
                SendMessage(h,WM_SETTEXT,0,(LPARAM)s);

                h=GetDlgItem(hdlg,IDC_TEXT2);
                sprintf(s,"Size : %imb",((((hd[1].tracks*hd[1].hpc)*hd[1].spt)*512)/1024)/1024);
                SendMessage(h,WM_SETTEXT,0,(LPARAM)s);
                return TRUE;
                case WM_COMMAND:
                switch (LOWORD(wParam))
                {
                        case IDOK:
                        h=GetDlgItem(hdlg,IDC_EDIT1);
                        SendMessage(h,WM_GETTEXT,255,(LPARAM)s);
                        sscanf(s,"%i",&hd[0].spt);
                        h=GetDlgItem(hdlg,IDC_EDIT2);
                        SendMessage(h,WM_GETTEXT,255,(LPARAM)s);
                        sscanf(s,"%i",&hd[0].hpc);
                        h=GetDlgItem(hdlg,IDC_EDIT3);
                        SendMessage(h,WM_GETTEXT,255,(LPARAM)s);
                        sscanf(s,"%i",&hd[0].tracks);

                        h=GetDlgItem(hdlg,IDC_EDIT4);
                        SendMessage(h,WM_GETTEXT,255,(LPARAM)s);
                        sscanf(s,"%i",&hd[1].spt);
                        h=GetDlgItem(hdlg,IDC_EDIT5);
                        SendMessage(h,WM_GETTEXT,255,(LPARAM)s);
                        sscanf(s,"%i",&hd[1].hpc);
                        h=GetDlgItem(hdlg,IDC_EDIT6);
                        SendMessage(h,WM_GETTEXT,255,(LPARAM)s);
                        sscanf(s,"%i",&hd[1].tracks);

                        if ((hd[0].spt != hdc[0].spt) || (hd[0].hpc != hdc[0].hpc) || (hd[0].tracks != hd[0].tracks))
                        {
                                if (hd[0].spt>63)
                                {
                                        MessageBox(ghwnd,"Drive C: has too many sectors (maximum is 63)","PCem error",MB_OK);
                                        return TRUE;
                                }
                                if (hd[0].hpc>16)
                                {
                                        MessageBox(ghwnd,"Drive C: has too many heads (maximum is 16","PCem error",MB_OK);
                                        return TRUE;
                                }
                                if (hd[0].tracks>1023)
                                {
                                        MessageBox(ghwnd,"Drive C: has too many cylinders (maximum is 1023)","PCem error",MB_OK);
                                        return TRUE;
                                }
                                if (MessageBox(ghwnd,"This will wipe everything on the emulated drive C:!\nIt will also reset PCem\nOkay to continue?","PCem",MB_OKCANCEL)==IDOK)
                                {
                                        hdc[0].spt=hd[0].spt;
                                        hdc[0].hpc=hd[0].hpc;
                                        hdc[0].tracks=hd[0].tracks;
                                        resizedrive(0);
                                        resetpchard();
                                        changeddrv=1;
                                }
                        }
                        if ((hd[1].spt != hdc[1].spt) || (hd[1].hpc != hdc[1].hpc) || (hd[1].tracks != hd[1].tracks))
                        {
                                if (hd[1].spt>63)
                                {
                                        MessageBox(ghwnd,"Drive D: has too many sectors (maximum is 63)","PCem error",MB_OK);
                                        return TRUE;
                                }
                                if (hd[1].hpc>16)
                                {
                                        MessageBox(ghwnd,"Drive D: has too many heads (maximum is 16","PCem error",MB_OK);
                                        return TRUE;
                                }
                                if (hd[1].tracks>1023)
                                {
                                        MessageBox(ghwnd,"Drive D: has too many cylinders (maximum is 1023)","PCem error",MB_OK);
                                        return TRUE;
                                }
                                if (MessageBox(ghwnd,"This will wipe everything on the emulated drive D:!\nIt will also reset PCem\nOkay to continue?","PCem",MB_OKCANCEL)==IDOK)
                                {
                                        hdc[1].spt=hd[1].spt;
                                        hdc[1].hpc=hd[1].hpc;
                                        hdc[1].tracks=hd[1].tracks;
                                        resizedrive(1);
                                        resetpchard();
                                        changeddrv=1;
                                }
                        }
                        if (changeddrv)
                           MessageBox(ghwnd,"Remember to partition and format the new drive(s)","PCem",MB_OK);
                        case IDCANCEL:
                        EndDialog(hdlg,0);
                        return TRUE;
                        
                        case IDC_EDIT1: case IDC_EDIT2: case IDC_EDIT3:
                        h=GetDlgItem(hdlg,IDC_EDIT1);
                        SendMessage(h,WM_GETTEXT,255,(LPARAM)s);
                        sscanf(s,"%i",&hd[0].spt);
                        h=GetDlgItem(hdlg,IDC_EDIT2);
                        SendMessage(h,WM_GETTEXT,255,(LPARAM)s);
                        sscanf(s,"%i",&hd[0].hpc);
                        h=GetDlgItem(hdlg,IDC_EDIT3);
                        SendMessage(h,WM_GETTEXT,255,(LPARAM)s);
                        sscanf(s,"%i",&hd[0].tracks);

                        h=GetDlgItem(hdlg,IDC_TEXT1);
                        sprintf(s,"Size : %imb",((((hd[0].tracks*hd[0].hpc)*hd[0].spt)*512)/1024)/1024);
                        SendMessage(h,WM_SETTEXT,0,(LPARAM)s);
                        return TRUE;

                        case IDC_EDIT4: case IDC_EDIT5: case IDC_EDIT6:
                        h=GetDlgItem(hdlg,IDC_EDIT4);
                        SendMessage(h,WM_GETTEXT,255,(LPARAM)s);
                        sscanf(s,"%i",&hd[1].spt);
                        h=GetDlgItem(hdlg,IDC_EDIT5);
                        SendMessage(h,WM_GETTEXT,255,(LPARAM)s);
                        sscanf(s,"%i",&hd[1].hpc);
                        h=GetDlgItem(hdlg,IDC_EDIT6);
                        SendMessage(h,WM_GETTEXT,255,(LPARAM)s);
                        sscanf(s,"%i",&hd[1].tracks);

                        h=GetDlgItem(hdlg,IDC_TEXT2);
                        sprintf(s,"Size : %imb",((((hd[1].tracks*hd[1].hpc)*hd[1].spt)*512)/1024)/1024);
                        SendMessage(h,WM_SETTEXT,0,(LPARAM)s);
                        return TRUE;
                }
                break;

        }
        return FALSE;
}

LRESULT CALLBACK WindowProcedure (HWND hwnd, UINT message, WPARAM wParam, LPARAM lParam)
{
        HMENU hmenu;
        switch (message)
        {
                case WM_COMMAND:
                hmenu=GetMenu(hwnd);
                switch (LOWORD(wParam))
                {
                        case IDM_FILE_RESET:
                        resetpc();
                        drawit=1;
                        break;
                        case IDM_FILE_HRESET:
                        resetpchard();
                        drawit=1;
                        break;
                        case IDM_FILE_EXIT:
                        PostQuitMessage (0);       /* send a WM_QUIT to the message queue */
                        break;
                        case IDM_DISC_A:
                        if (!getfile(hwnd,"Disc image (*.IMG;*.IMA)\0*.IMG;*.IMA\0All files (*.*)\0*.*\0",discfns[0]))
                        {
                                savedisc();
                                loaddisc(openfilestring);
                        }
                        break;
                        case IDM_DISC_B:
                        if (!getfile(hwnd,"Disc image (*.IMG;*.IMA)\0*.IMG;*.IMA\0All files (*.*)\0*.*\0",discfns[1]))
                        {
                                savedisc2();
                                loaddisc2(openfilestring);
                        }
                        break;
                        case IDM_EJECT_A:
                        ejectdisc();
                        break;
                        case IDM_EJECT_B:
                        ejectdisc2();
                        break;
                        case IDM_HDCONF:
                        DialogBox(hinstance,TEXT("HdConfDlg"),ghwnd,hdconfdlgproc);
                        break;
                        case IDM_CONFIG:
                        DialogBox(hinstance,TEXT("ConfigureDlg"),ghwnd,configdlgproc);
                        break;
                }
                return 0;
                
                case WM_SETFOCUS:
                infocus=1;
                drawit=0;
                QueryPerformanceCounter(&counter_posold);
//                restoresound();
//                printf("Set focus!\n");
                break;
                case WM_KILLFOCUS:
                infocus=0;
                if (mousecapture)
                {
                        ClipCursor(&oldclip);
                        mousecapture=0;
                }
//                silencesound();
//                printf("Lost focus!\n");
                break;

                case WM_LBUTTONUP:
                if (!mousecapture)
                {
                        GetClipCursor(&oldclip);
                        GetWindowRect(hwnd,&pcclip);
                        pcclip.left+=GetSystemMetrics(SM_CXFIXEDFRAME)+10;
                        pcclip.right-=GetSystemMetrics(SM_CXFIXEDFRAME)+10;
                        pcclip.top+=GetSystemMetrics(SM_CXFIXEDFRAME)+GetSystemMetrics(SM_CYMENUSIZE)+GetSystemMetrics(SM_CYCAPTION)+10;
                        pcclip.bottom-=GetSystemMetrics(SM_CXFIXEDFRAME)+10;
                        ClipCursor(&pcclip);
                        mousecapture=1;
                }
                break;
                case WM_DESTROY:
                PostQuitMessage (0);       /* send a WM_QUIT to the message queue */
                break;
                default:
//                        printf("Def %08X %i\n",message,message);
                return DefWindowProc (hwnd, message, wParam, lParam);
        }
        return 0;
}


/*Windows sound handling*/
signed short buffers[4][(SOUNDBUFLEN)*2];
int readbuf,writebuf,bufs;
int soundthreadon=1;

void soundthread(LPVOID param)
{
        signed short *p;
        readbuf=writebuf=bufs=0;
        while (!quited)
        {
                while (!bufs && !quited && infocus) //WaitForSingleObject(soundobject,INFINITE);
                {
                        sleep(1);
                }
                if (!infocus) sleep(10);
                while (bufs && !quited)
                {
                        p=NULL;
                        while (!p && !quited && infocus) { p=get_audio_stream_buffer(as); sleep(0); }
                        if (!p) break;
                        if (quited || !infocus) break;
                        memcpy(p,buffers[readbuf],(SOUNDBUFLEN)*2*2);
                        free_audio_stream_buffer(as);
                        readbuf=(readbuf+1)&3;
                        bufs--;
                }
        }
        if (quited && p) free_audio_stream_buffer(as);
        soundthreadon=0;
        ExitThread(0);
}

void outputsoundbuffer(signed short *p)
{
/*        if (!p)
        {
                memset(buffers,0,4*SOUNDBUFLEN*2*2);
                readbuf=writebuf=0;
                bufs=4;
                return;
        }*/
        if (bufs==4) { writebuf=(writebuf-1)&3; bufs--; }
        memcpy(buffers[writebuf],p,(SOUNDBUFLEN)*2*2);
        writebuf=(writebuf+1)&3;
        bufs++;
        SetEvent(soundobject);
}

void silencesound()
{
//        outputsoundbuffer(NULL);
//        set_volume(0,-1);
//        printf("Sound silence!\n");
}

void restoresound()
{
//        set_volume(255,-1);
//        printf("Sound restore!\n");
}

void endsoundthread()
{
//        return;
        if (!soundthreadon) return;
        quited=1;
        bufs=0;
        while (soundthreadon)
        {
//                SetEvent(soundobject);
                sleep(1);
        }
}

/*Frame handling*/
void wakeupmain()
{
        SetEvent(frameobject);
}

void waitmain()
{
//        printf("Wait!\n");
        WaitForSingleObject(frameobject,100);
}
