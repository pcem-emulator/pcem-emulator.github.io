#include <stdio.h>
#include <allegro.h>
#include "ibm.h"

unsigned char cgamode=1,cgastat,cgacol=7,ocgamode;
int frames=0;
int output;
unsigned char *vram,*ram;

unsigned char crtc[32],crtcreg;

void writecrtc(unsigned short addr, unsigned char val)
{
        if (!(addr&1)) crtcreg=val&31;
        else
        {
                crtc[crtcreg]=val;
//                printf("Write CRTC %i %02X %02X %04X:%04X\n",crtcreg,val,cgastat,cs>>4,pc);
        }
}

unsigned char readcrtc(unsigned short addr)
{
        if (!(addr&1)) return crtcreg;
        else           return crtc[crtcreg];
}

unsigned char crtcm[32],crtcmreg;

void writecrtcm(unsigned short addr, unsigned char val)
{
        if (!(addr&1)) crtcmreg=val&31;
        else           crtcm[crtcmreg]=val;
}

unsigned char readcrtcm(unsigned short addr)
{
        if (!(addr&1)) return crtcmreg;
        else           return crtcm[crtcmreg];
}

unsigned char mdactrl,hercctrl;
int hercgfx=0;
void writemda(unsigned short addr, unsigned char val)
{
        if (addr==0x3BF) hercctrl=val;
        if (addr==0x3B8) mdactrl=val;
        hercgfx=(hercctrl&1)&&(mdactrl&2);
}

/*Amstrad PC1512*/
unsigned char amswrite=0xF,amsread=0;
void writevram(unsigned short addr, unsigned char val)
{
//        printf("Write VRAM %04X %02X %i %04X:%04X %04X:%04X %04X:%04X\n",addr,val,cgamode&2,cs>>4,pc,ds>>4,SI,es>>4,DI);
        if ((cgamode&0x12)==0x12)
        {
                if (amswrite&1) vram[addr]=val;
                if (amswrite&2) vram[addr|0x10000]=val;
                if (amswrite&4) vram[addr|0x20000]=val;
                if (amswrite&8) vram[addr|0x30000]=val;
        }
        else
           vram[addr]=val;
}

unsigned char readvram(unsigned short addr)
{
        if ((cgamode&0x12)==0x12) return vram[addr|(amsread<<16)];
        return vram[addr];
}

void writeams(unsigned short addr, unsigned char val)
{
//        printf("Amstrad write %04X %02X\n",addr,val);
        if (addr==0x3DD) amswrite=val;
        if (addr==0x3DE) amsread=val&3;
}

/*PCjr/Tandy stuff*/
unsigned char array[32];
int arrayreg;
void writearray(unsigned short addr, unsigned char val)
{
//        printf("Write addr %04X %02X\n",addr,val);
        if (addr&4)
        {
                array[arrayreg&31]=val;
//                printf("Register %i now %02X\n",arrayreg,val);
        }
        else
           arrayreg=val&31;
}

unsigned char *tandyvram,*tandyb8000;
int tandymemctrl=-1;
unsigned long tandybase=0;
void recalctandyaddress()
{
        if ((tandymemctrl&0xC0)==0xC0)
        {
                tandyvram=&ram[((tandymemctrl&0x6)<<14)+tandybase];
                tandyb8000=&ram[((tandymemctrl&0x30)<<11)+tandybase];
//                printf("VRAM at %05X B8000 at %05X\n",((tandymemctrl&0x6)<<14)+tandybase,((tandymemctrl&0x30)<<11)+tandybase);
        }
        else
        {
                tandyvram=&ram[((tandymemctrl&0x7)<<14)+tandybase];
                tandyb8000=&ram[((tandymemctrl&0x38)<<11)+tandybase];
//                printf("VRAM at %05X B8000 at %05X\n",((tandymemctrl&0x7)<<14)+tandybase,((tandymemctrl&0x38)<<11)+tandybase);
        }
}

void writetandy(unsigned short addr, unsigned char val)
{
        if (addr==0x3DA || addr==0x3DE) writearray(addr,val);
//        printf("Write Tandy %03X %02X\n",addr,val);
        if (addr==0x3DF)
        {
                tandymemctrl=val;
                recalctandyaddress();
        }
        if (addr==0xA0)
        {
                tandybase=((val>>1)&7)*128*1024;
                recalctandyaddress();
        }
}

void writetandyvram(unsigned short addr, unsigned char val)
{
//        if (tandybase==0xA0000) return;
        if (tandymemctrl==-1) return;
        if (addr&0x8000) tandyb8000[addr&0x7FFF]=val;
//        printf("Write tandy vram %04X,%02X %04X:%04X %04X %05X\n",addr,val,cs>>4,pc,ds>>4,((tandymemctrl&0x38)<<11)+0x80000+(addr&0x7FFF));
        //        if (addr==0xBE84) output=1;
}

unsigned char readtandyvram(unsigned short addr)
{
        if (tandymemctrl==-1) return 0xFF;
//        printf("Read tandy vram %04X %02X\n",addr&0x7FFF,tandyb8000[addr&0x7FFF]);
        if (addr&0x8000) return tandyb8000[addr&0x7FFF];
         return 0xFF;
}

void drawscr()
{
//        printf("Mode %i\n",array[3]);
}

PALETTE cgapal=
{
        {0,0,0},{0,42,0},{42,0,0},{42,21,0},
        {0,0,0},{0,42,42},{42,0,42},{42,42,42},
        {0,0,0},{21,63,21},{63,21,21},{63,63,21},
        {0,0,0},{21,63,63},{63,21,63},{63,63,63},

        {0,0,0},{0,0,42},{0,42,0},{0,42,42},
        {42,0,0},{42,0,42},{42,21,00},{42,42,42},
        {21,21,21},{21,21,63},{21,63,21},{21,63,63},
        {63,21,21},{63,21,63},{63,63,21},{63,63,63},

        {0,0,0},{0,21,0},{0,0,42},{0,42,42},
        {42,0,21},{21,10,21},{42,0,42},{42,0,63},
        {21,21,21},{21,63,21},{42,21,42},{21,63,63},
        {63,0,0},{42,42,0},{63,21,42},{41,41,41},
        
        {0,0,0},{0,42,42},{42,0,0},{42,42,42},
        {0,0,0},{0,42,42},{42,0,0},{42,42,42},
        {0,0,0},{0,63,63},{63,0,0},{63,63,63},
        {0,0,0},{0,63,63},{63,0,0},{63,63,63},
};
BITMAP *buffer,*vbuf;//,*vbuf2;
int speshul=0;

unsigned char fontdat[256][8];
unsigned char fontdatm[256][16];

void loadfont()
{
        FILE *f=fopen("mda.rom","rb");
        int c,d;
        for (c=0;c<256;c++)
        {
                for (d=0;d<8;d++)
                {
                        fontdatm[c][d]=getc(f);
                }
        }
        for (c=0;c<256;c++)
        {
                for (d=0;d<8;d++)
                {
                        fontdatm[c][d+8]=getc(f);
                }
        }
        fseek(f,4096+2048,SEEK_SET);
        for (c=0;c<256;c++)
        {
                for (d=0;d<8;d++)
                {
                        fontdat[c][d]=getc(f);
                }
        }
        fclose(f);
}

void charout(BITMAP *b, int x, int y, int c, unsigned char attr, int scanhigh)
{
        int xx,yy;
        unsigned char temp;
        int fg=attr&0xF,bg=attr>>4;
        c&=0xFF;
        for (yy=0;yy<scanhigh;yy++)
        {
                temp=fontdat[c][yy];
                for (xx=0;xx<8;xx++)
                {
                        if (temp&0x80) b->line[y+yy][x+xx]=fg+16;
                        else           b->line[y+yy][x+xx]=bg+16;
                        temp<<=1;
                }
        }
}

void charout14(BITMAP *b, int x, int y, int c, unsigned char attr, int scanhigh)
{
        int xx,yy;
        unsigned char temp;
        int fg=7,bg=0;
        if (attr==0x70 || attr==0x78 || attr==0xF0 || attr==0xF8)
        {
                fg=0;
                bg=7;
        }
        else if (attr&8) fg=15;
        for (yy=0;yy<14;yy++)
        {
                temp=fontdatm[c][yy];
                for (xx=0;xx<9;xx++)
                {
                        if (temp&0x80) b->line[y+yy][x+xx]=fg+16;
                        else           b->line[y+yy][x+xx]=bg+16;
                        temp<<=1;
                }
                if ((c&0xE0)==0xC0)
                {
                        if (fontdatm[c][yy]&1) b->line[y+yy][x+8]=fg+16;
                        else                   b->line[y+yy][x+8]=bg+16;
                }
        }
}

void drawscreencga(char *vram)
{
        int c,d,e,f;
        unsigned char dat;
        char s[2]={0,0};
        int col;
        int scanhigh=crtc[9]+1;
        int cursoraddr=((crtc[15]|(crtc[14]<<8))<<1)&0xFFE;
        int base=((crtc[13]|(crtc[12]<<8))<<1)&0xFFE;
        int yy,x;
        int cgacols[4];
//        #ifdef CGA
        if (scanhigh==9) scanhigh=8;
        if (cgacol&32) col=4;
        else           col=0;
        if (cgacol&16) col|=8;
        if (cgamode&4) col|=0x30;
        cgacols[0]=(cgacol&15)|16;
        cgacols[1]=col|1;
        cgacols[2]=col|2;
        cgacols[3]=col|3;
//        printf("Base %04X\n",base);
//        printf("CRTC 10 %02X 11 %02X\n",crtc[10],crtc[11]);
//        printf("Draw %i ",cgamode);
        drawscr();
//        printf("CGAmode %02X\n",cgamode);
//        _farsetsel(_dos_ds);
//        if ((cgamode&1) && !(ocgamode&1)) { set_gfx_mode(GFX_AUTODETECT_WINDOWED,640,200,0,0); set_palette(cgapal); }
//        if ((ocgamode&1) && !(cgamode&1)) { set_gfx_mode(GFX_AUTODETECT_WINDOWED,320,200,0,0); set_palette(cgapal); }
        if (speshul) /*Olivetti 640x400 mode - used by Psion Chess*/
        {
                for (e=0;e<4;e++)
                {
                        f=(e*0x2000)+0x0000;
                        for (d=0;d<400;d+=4)
                        {
                                for (c=0;c<640;c+=8)
                                {
                                        dat=vram[f++];
                                        buffer->line[d+e][c]=((dat>>7)&1)?15:0;
                                        buffer->line[d+e][c+1]=((dat>>6)&1)?15:0;
                                        buffer->line[d+e][c+2]=((dat>>5)&1)?15:0;
                                        buffer->line[d+e][c+3]=((dat>>4)&1)?15:0;
                                        buffer->line[d+e][c+4]=((dat>>3)&1)?15:0;
                                        buffer->line[d+e][c+5]=((dat>>2)&1)?15:0;
                                        buffer->line[d+e][c+6]=((dat>>1)&1)?15:0;
                                        buffer->line[d+e][c+7]=(dat&1)?15:0;
                                }
                        }
                }
        }
        else if (cgamode&2)
        {
                if (cgamode&0x10)
                {
                        if (cgamode&4 || AMSTRAD)
                        {
                                if (AMSTRAD)
                                {
//                                        printf("CGACOL %02X\n",cgacol);
                                        for (e=0;e<2;e++)
                                        {
                                                f=(e*0x2000)+0x0000;
                                                for (d=0;d<200;d+=2)
                                                {
                                                        for (c=0;c<640;c+=8)
                                                        {
                                                                for (col=0;col<8;col++) buffer->line[d+e][c+col]=16;
                                                                if (cgacol&1)
                                                                {
                                                                        dat=vram[f];
                                                                        buffer->line[d+e][c]|=((dat>>7)&1)?1:0;
                                                                        buffer->line[d+e][c+1]|=((dat>>6)&1)?1:0;
                                                                        buffer->line[d+e][c+2]|=((dat>>5)&1)?1:0;
                                                                        buffer->line[d+e][c+3]|=((dat>>4)&1)?1:0;
                                                                        buffer->line[d+e][c+4]|=((dat>>3)&1)?1:0;
                                                                        buffer->line[d+e][c+5]|=((dat>>2)&1)?1:0;
                                                                        buffer->line[d+e][c+6]|=((dat>>1)&1)?1:0;
                                                                        buffer->line[d+e][c+7]|=(dat&1)?1:0;
                                                                }
                                                                if (cgacol&2)
                                                                {
                                                                        dat=vram[f|0x10000];
                                                                        buffer->line[d+e][c]|=((dat>>7)&1)?2:0;
                                                                        buffer->line[d+e][c+1]|=((dat>>6)&1)?2:0;
                                                                        buffer->line[d+e][c+2]|=((dat>>5)&1)?2:0;
                                                                        buffer->line[d+e][c+3]|=((dat>>4)&1)?2:0;
                                                                        buffer->line[d+e][c+4]|=((dat>>3)&1)?2:0;
                                                                        buffer->line[d+e][c+5]|=((dat>>2)&1)?2:0;
                                                                        buffer->line[d+e][c+6]|=((dat>>1)&1)?2:0;
                                                                        buffer->line[d+e][c+7]|=(dat&1)?2:0;
                                                                }
                                                                if (cgacol&4)
                                                                {
                                                                        dat=vram[f|0x20000];
                                                                        buffer->line[d+e][c]|=((dat>>7)&1)?4:0;
                                                                        buffer->line[d+e][c+1]|=((dat>>6)&1)?4:0;
                                                                        buffer->line[d+e][c+2]|=((dat>>5)&1)?4:0;
                                                                        buffer->line[d+e][c+3]|=((dat>>4)&1)?4:0;
                                                                        buffer->line[d+e][c+4]|=((dat>>3)&1)?4:0;
                                                                        buffer->line[d+e][c+5]|=((dat>>2)&1)?4:0;
                                                                        buffer->line[d+e][c+6]|=((dat>>1)&1)?4:0;
                                                                        buffer->line[d+e][c+7]|=(dat&1)?4:0;
                                                                }
                                                                if (cgacol&8)
                                                                {
                                                                        dat=vram[f|0x30000];
                                                                        buffer->line[d+e][c]|=((dat>>7)&1)?8:0;
                                                                        buffer->line[d+e][c+1]|=((dat>>6)&1)?8:0;
                                                                        buffer->line[d+e][c+2]|=((dat>>5)&1)?8:0;
                                                                        buffer->line[d+e][c+3]|=((dat>>4)&1)?8:0;
                                                                        buffer->line[d+e][c+4]|=((dat>>3)&1)?8:0;
                                                                        buffer->line[d+e][c+5]|=((dat>>2)&1)?8:0;
                                                                        buffer->line[d+e][c+6]|=((dat>>1)&1)?8:0;
                                                                        buffer->line[d+e][c+7]|=(dat&1)?8:0;
                                                                }
                                                                f++;
                                                        }
                                                }
                                        }
                                }
                                else
                                {
                                        col=(cgacol&15)+16;
                                        for (e=0;e<2;e++)
                                        {
                                                f=(e*0x2000)+0x0000;
                                                for (d=0;d<200;d+=2)
                                                {
                                                        for (c=0;c<640;c+=8)
                                                        {
                                                                dat=vram[f++];
                                                                buffer->line[d+e][c]=((dat>>7)&1)?col:0;
                                                                buffer->line[d+e][c+1]=((dat>>6)&1)?col:0;
                                                                buffer->line[d+e][c+2]=((dat>>5)&1)?col:0;
                                                                buffer->line[d+e][c+3]=((dat>>4)&1)?col:0;
                                                                buffer->line[d+e][c+4]=((dat>>3)&1)?col:0;
                                                                buffer->line[d+e][c+5]=((dat>>2)&1)?col:0;
                                                                buffer->line[d+e][c+6]=((dat>>1)&1)?col:0;
                                                                buffer->line[d+e][c+7]=(dat&1)?col:0;
                                                        }
                                                }
                                        }
                                }
                        }
                        else
                        {
                                for (e=0;e<2;e++)
                                {
                                        f=(e*0x2000)+0x0000;
                                        for (d=0;d<200;d+=2)
                                        {
                                                for (c=0;c<160;c+=2)
                                                {
                                                        dat=vram[f++];
                                                        buffer->line[d+e][c]=(dat>>4)+32;
//                                                        buffer->line[d+e][c+1]=(dat>>4)+32;
//                                                        buffer->line[d+e][c+2]=(dat>>4)+32;
//                                                        buffer->line[d+e][c+3]=(dat>>4)+32;
                                                        buffer->line[d+e][c+1]=(dat&0xF)+32;
//                                                        buffer->line[d+e][c+5]=(dat&0xF)+32;
//                                                        buffer->line[d+e][c+6]=(dat&0xF)+32;
//                                                        buffer->line[d+e][c+7]=(dat&0xF)+32;
                                                }
                                        }
                                }
                        }
                }
                else
                {
                        for (e=0;e<2;e++)
                        {
                                f=(e*0x2000)+0x0000;
                                for (d=0;d<200;d+=2)
                                {
                                        for (c=0;c<320;c+=4)
                                        {
                                                dat=vram[f++];
                                                buffer->line[d+e][c]=cgacols[(dat>>6)&3];
                                                buffer->line[d+e][c+1]=cgacols[(dat>>4)&3];
                                                buffer->line[d+e][c+2]=cgacols[(dat>>2)&3];
                                                buffer->line[d+e][c+3]=cgacols[dat&3];
                                        }
                                }
                        }
                }
        }
        else
        {
//                printf("Drawing CGA text?\n");
                e=base;
                if (cgamode&1)
                {
                        for (d=0;d<200;d+=scanhigh)
                        {
                                for (c=0;c<80;c++)
                                {
                                        charout(buffer,c<<3,d,vram[e+0x0000],vram[e+0x0001],scanhigh);
                                        if (e==cursoraddr && (frames&16))
                                        {
                                                for (yy=crtc[10];yy<=crtc[11];yy++)
                                                {
                                                        for (x=0;x<8;x++)
                                                        {
                                                                buffer->line[d+yy][(c*8)+x]^=7;
                                                        }
                                                }
                                        }
                                        e+=2;
//                                        textout(buffer,font,s,c<<3,d<<3,7);
                                }
                        }
                }
                else
                {
                        for (d=0;d<200;d+=scanhigh)
                        {
                                for (c=0;c<40;c++)
                                {
                                        charout(buffer,c<<3,d,vram[e+0x0000],vram[e+0x0001],scanhigh);
                                        if (e==cursoraddr && (frames&16))
                                        {
                                                for (yy=crtc[10];yy<=crtc[11];yy++)
                                                {
                                                        for (x=0;x<8;x++)
                                                        {
                                                                buffer->line[d+yy][(c*8)+x]^=7;
                                                        }
                                                }
                                        }
                                        e+=2;
                                }
                        }
                }
        }
//        textprintf(buffer,font,304,0,7,"%02i",fdc.track);
        if (speshul)
        {
                blit(buffer,screen,0,0,0,0,640,400);
        }
        else if ((cgamode&3)==1 || (cgamode&0x12)==0x12)
        {
                if (!(cgamode&4) && (cgamode&0x10) && !AMSTRAD)
                {
                        blit(buffer,vbuf,0,0,0,0,160,200);
                        stretch_blit(vbuf,screen,0,0,160,200,0,0,640,400);
                }
                else
                {
                        blit(buffer,vbuf,0,0,0,0,640,200);
                        stretch_blit(vbuf,screen,0,0,640,200,0,0,640,400);
                }
        }
        else
        {
                blit(buffer,vbuf,0,0,0,0,320,200);
                stretch_blit(vbuf,screen,0,0,320,200,0,0,640,400);
        }
        ocgamode=cgamode;
        if (readflash) rectfill(screen,600,8,632,14,0xFFFFFFFF);
        readflash=0;
//        printf("R9 - %i\n",crtc[9]);
//        #endif
}

void drawscreenmda()
{
        int c,d,e=0,yy,x;
        int cursoraddr=((crtcm[15]|(crtcm[14]<<8))<<1)&0xFFE;
        unsigned char temp;
//        printf("DRAWMDA!\n");
        drawscr();
        if (hercgfx && HERCULES)
        {
                for (yy=0;yy<4;yy++)
                {
                        e=yy*0x2000;
                        if (mdactrl&0x80) e+=0x8000;
                        for (d=0;d<348;d+=4)
                        {
                                for (c=0;c<720;c+=8)
                                {
                                        temp=vram[e++];
                                        buffer->line[d+yy][c]=(temp&0x80)?31:0;
                                        buffer->line[d+yy][c+1]=(temp&0x40)?31:0;
                                        buffer->line[d+yy][c+2]=(temp&0x20)?31:0;
                                        buffer->line[d+yy][c+3]=(temp&0x10)?31:0;
                                        buffer->line[d+yy][c+4]=(temp&0x8)?31:0;
                                        buffer->line[d+yy][c+5]=(temp&0x4)?31:0;
                                        buffer->line[d+yy][c+6]=(temp&0x2)?31:0;
                                        buffer->line[d+yy][c+7]=(temp&0x1)?31:0;
                                }
                        }
                }
        }
        else
        {
//                printf("Drawing MDA text\n");
                for (d=0;d<350;d+=14)
                {
                        for (c=0;c<80;c++)
                        {
                                charout14(buffer,c*9,d,vram[e+0x0000],vram[e+0x0001],14);
                                if (e==cursoraddr && (frames&16))
                                {
                                        for (yy=crtcm[10];yy<=crtcm[11];yy++)
                                        {
                                                for (x=0;x<8;x++)
                                                {
                                                        buffer->line[d+yy][(c*9)+x]^=7;
                                                }
                                        }
                                }
                                e+=2;
                        }
                }
        }
        blit(buffer,screen,0,0,0,0,720,350);
        if (readflash) rectfill(screen,680,8,712,14,0xFFFFFFFF);
        readflash=0;
//        printf("Hercgfx %i\n",hercgfx);
}

void drawscreentandy(unsigned char *vram)
{
        int yy,y;
        unsigned short addr;
        unsigned char temp,temp2;
        int x,xx;
        if ((cgamode&1) && (array[3]&0x10) && !(cgamode&0x10) && cgamode&2) /*320x200x16*/
        {
                for (yy=0;yy<4;yy++)
                {
                        addr=yy*0x2000;
                        for (y=0;y<200;y+=4)
                        {
                                for (x=0;x<320;x+=2)
                                {
                                        buffer->line[y+yy][x]=array[(vram[addr]>>4)|0x10]|0x10;
                                        buffer->line[y+yy][x+1]=array[(vram[addr]&0xF)|0x10]|0x10;
                                        addr++;
                                }
                        }
                }
                blit(buffer,vbuf,0,0,0,0,320,200);
                stretch_blit(vbuf,screen,0,0,320,200,0,0,640,400);
        }
        else if ((cgamode&1) && (array[3]&0x08) && (cgamode&0x10) && cgamode&2) /*640x200x4*/
        {
                for (yy=0;yy<4;yy++)
                {
                        addr=yy*0x2000;
                        for (y=0;y<200;y+=4)
                        {
                                for (x=0;x<640;x+=8)
                                {
                                        temp=vram[addr];
                                        temp2=vram[addr+1];
                                        for (xx=0;xx<8;xx++)
                                        {
                                                buffer->line[(y+yy)&511][(x+xx)&1023]=(temp&0x80)?2:0;
                                                if (temp2&0x80) buffer->line[(y+yy)&511][(x+xx)&1023]|=1;
                                                temp<<=1;
                                                temp2<<=1;
                                        }
                                        addr+=2;
                                }
                        }
                }
                blit(buffer,vbuf,0,0,0,0,640,200);
                stretch_blit(vbuf,screen,0,0,640,200,0,0,640,400);
        }
        else if ((array[3]&0x10) && !(cgamode&0x10) && cgamode&2) /*160x200x16*/
        {
                for (yy=0;yy<2;yy++)
                {
                        addr=yy*0x2000;
                        for (y=0;y<200;y+=2)
                        {
                                for (x=0;x<160;x+=2)
                                {
                                        temp=vram[addr++];
                                        buffer->line[y+yy][x]=array[(temp>>4)|0x10]|0x10;
                                        buffer->line[y+yy][x+1]=array[(temp&0xF)|0x10]|0x10;
//                                        addr++;
                                }
                        }
                }
                blit(buffer,vbuf,0,0,0,0,160,200);
                stretch_blit(vbuf,screen,0,0,160,200,0,0,640,400);
        }
//        printf("Bad TGA mode! %02X %02X\n",cgamode,array[3]);
        if (readflash) rectfill(screen,600,8,632,14,0xFFFFFFFF);
        readflash=0;
}

void drawscreen()
{
//        printf("Drawscreen %i %i\n",gfxcard,MDA);
        if (EGA) drawscreenega(buffer,vbuf);
        else if (MDA) drawscreenmda();
        else if (TANDY)
        {
                if ((cgamode&3)==3 || array[3]&0x10) drawscreentandy(tandyvram);
                else                drawscreencga(tandyvram);
        }
        else            drawscreencga(&vram[0x8000]);
        frames++;
}

void initvideo()
{
        int c,d;
        set_color_depth(desktop_color_depth());
        set_gfx_mode(GFX_AUTODETECT_WINDOWED,720,480,0,0);
        vbuf=create_system_bitmap(720,480);
//        vbuf2=create_video_bitmap(160,200);
        set_color_depth(8);
        buffer=create_bitmap(1024,512);
        for (c=0;c<64;c++)
        {
                cgapal[c+64].r=(((c&4)?2:0)|((c&0x10)?1:0))*21;
                cgapal[c+64].g=(((c&2)?2:0)|((c&0x10)?1:0))*21;
                cgapal[c+64].b=(((c&1)?2:0)|((c&0x10)?1:0))*21;
                if ((c&0x17)==6) cgapal[c+64].g>>=1;
        }
        for (c=0;c<64;c++)
        {
                cgapal[c+128].r=(((c&4)?2:0)|((c&0x20)?1:0))*21;
                cgapal[c+128].g=(((c&2)?2:0)|((c&0x10)?1:0))*21;
                cgapal[c+128].b=(((c&1)?2:0)|((c&0x08)?1:0))*21;
        }
        set_palette(cgapal);
        if (MDA && !TANDY && !AMSTRAD && romset!=ROM_PC200) updatewindowsize(720,350);
        else                                                updatewindowsize(640,400);
}

void resetvideo()
{
        tandybase=0x80000;
        tandymemctrl=0x3F;
        recalctandyaddress();
        tandymemctrl=-1;
        if (MDA && !TANDY && !AMSTRAD && romset!=ROM_PC200) updatewindowsize(720,350);
        else                                                updatewindowsize(640,400);
        cgastat=0;
//        tandyvram=&ram[0x9C000];
//        printf("Tandy VRAM %08X\n",tandyvram);
//        tandyb8000=&ram[0x9C000];
}

void closevideo()
{
        destroy_bitmap(buffer);
        destroy_bitmap(vbuf);
}
