#include <stdio.h>
#include <allegro.h>
#include <winalleg.h>
#include "ibm.h"

int notpresent=0;
int output;
void pmodeint(int num, int soft);
/*NOT PRESENT is INT 0B
  GPF is INT 0D*/

FILE *pclogf;
void x86abort(const char *format, ...)
{
   char buf[256];
//   return;
   if (!pclogf)
      pclogf=fopen("pclog.txt","wt");
//return;
   va_list ap;
   va_start(ap, format);
   vsprintf(buf, format, ap);
   va_end(ap);
   fputs(buf,pclogf);
   fflush(pclogf);
   dumpregs();
   exit(-1);
}

void x86gpf(char *s, unsigned short error)
{
//        printf("GPF! - error %04X\n",error);
        pmodeint(0x0D,0);
        writememw(ss,((SP-2)&0xFFFF),error);
        SP-=2;
        dumpregs();
        exit(-1);
}
int ins;
unsigned short nperror;
void x86np()
{
//        printf("Not present! %04X  ",nperror);
        pmodeint(0x0B,0);
        writememw(ss,((SP-2)&0xFFFF),nperror);
        SP-=2;
//        printf("%04X:%04X %i\n",CS,pc,ins);
/*        if (output)
        {
                dumpregs();
                exit(-1);
        }*/
        if (!nperror) output=1;
//        output=1;
}
/*void x86abort(char *s)
{
        printf("ABORT : %s\n",s);
        dumpregs();
        exit(-1);
}*/

void loadseg(unsigned short seg, x86seg *s)
{
        unsigned short segdat[3];
        unsigned long addr;
        int dpl;
        if (msw&1)
        {
                if (!(seg&~3))
                {
                        if (s==&_ss)
                        {
                                printf("SS selector = NULL!\n");
                                dumpregs();
                                exit(-1);
                        }
                        s->seg=0;
                        s->base=-1;
//                        printf("NULL selector\n");
                        return;
                }
//                if (s==&_ss) printf("Load SS %04X\n",seg);
//                printf("Protected mode seg load!\n");
                addr=seg&~7;
                if (seg&4)
                {
                        if (addr>=ldt.limit) x86abort("Bigger than LDT limit\n");
                        addr+=ldt.base;
                }
                else
                {
                        if (addr>=gdt.limit) x86abort("Bigger than GDT limit\n");
                        addr+=gdt.base;
                }
                segdat[0]=readmemw(0,addr);
                segdat[1]=readmemw(0,addr+2);
                segdat[2]=readmemw(0,addr+4);
//                printf("Data seg - %04X\n",segdat[2]);
                dpl=(segdat[2]>>13)&3;
                if (!(segdat[2]&0x800) || !(segdat[2]&0x400))
                {
                        if ((seg&3)>dpl || (CS&3)>dpl)
                        {
//                                printf("Data seg fail - %04X %04X %i\n",CS,seg,dpl);
                                x86gpf("Data segment load - level too low!\n",seg&0xFFFC);
                                return;
                        }
                }
//                if (!(segdat[2]&0x8000)) x86abort("Data segment not present!\n");
                        if (!(segdat[2]&0x8000))
                        {
                                notpresent=1;
                                nperror=seg&0xFFFC;
                                return;
                        }
                        s->seg=seg;
                        s->limit=segdat[0];
                        s->base=segdat[1];
                        s->base|=((segdat[2]&0xFF)<<16);
                        s->access=segdat[2]>>8;
//                printf("base=%06X limit=%04X access=%02X  %06X  %04X %04X %04X  %04X\n",s->base,s->limit,s->access,addr,segdat[0],segdat[1],segdat[2],seg);
//                dumpregs();
//                exit(-1);
        }
        else
        {
                s->base=seg<<4;
                s->limit=0xFFFF;
                s->seg=seg;
/*                if (s==&_ds)
                {
                        printf("DS! %04X %06X %04X:%04X\n",DS,ds,CS,pc);
                }*/
        }
}

void loadcs(unsigned short seg)
{
        unsigned short segdat[3];
        unsigned long addr;
        int count;
        if (msw&1)
        {
//                printf("Load CS %04X\n",seg);
                if (!(seg&~3))
                {
                        printf("Trying to load CS with NULL selector!\n");
                        dumpregs();
                        exit(-1);
                }
//                printf("Protected mode CS load! %04X\n",seg);
                addr=seg&~7;
                if (seg&4)
                {
                        if (addr>=ldt.limit) x86abort("Bigger than LDT limit\n");
                        addr+=ldt.base;
                }
                else
                {
                        if (addr>=gdt.limit) x86abort("Bigger than GDT limit\n");
                        addr+=gdt.base;
                }
                segdat[0]=readmemw(0,addr);
                segdat[1]=readmemw(0,addr+2);
                segdat[2]=readmemw(0,addr+4);
//                printf("Code seg - %04X - %04X %04X %04X\n",seg,segdat[0],segdat[1],segdat[2]);
//                if (!(segdat[2]&0x8000)) x86abort("Code segment not present!\n");
                if (segdat[2]&0x1000)
                {
                        CS=seg;
                        _cs.limit=segdat[0];
                        _cs.base=segdat[1];
                        _cs.base|=((segdat[2]&0xFF)<<16);
                        _cs.access=segdat[2]>>8;
//                        CS=(CS&0xFFFC)|((_cs.access>>5)&3);
                        if (!(segdat[2]&0x8000))
                        {
                                notpresent=1;
                                nperror=seg&0xFFFC;
                                return;
                        }
                }
                else
                {
                        if (!(segdat[2]&0x8000))
                        {
                                notpresent=1;
                                nperror=seg&0xFFFC;
                                return;
                        }
                        switch (segdat[2]&0xF00)
                        {
                                case 0x400: /*Call gate*/
                                count=segdat[2]&31;
                                printf("Call gate - copy %i words\n",count);
                                dumpregs();
                                exit(-1);
                                default:
                                printf("Bad special descriptor %03X %04X\n",segdat[2]&0xF00,seg);
                                dumpregs();
                                exit(-1);
                        }
                }
//                printf("CS = %04X base=%06X limit=%04X access=%02X  %04X\n",CS,cs,_cs.limit,_cs.access,addr);
//                dumpregs();
//                exit(-1);
        }
        else
        {
                _cs.base=seg<<4;
                _cs.limit=0xFFFF;
                CS=seg;
        }
}


void loadcscall(unsigned short seg)
{
        unsigned short segdat[3];
        unsigned long addr;
        int count;
        unsigned short oldcs=CPL;
        unsigned short oldss,oldsp;
        if (msw&1)
        {
//                printf("Protected mode CS load! %04X\n",seg);
                if (!(seg&~3))
                {
                        printf("Trying to load CS with NULL selector!\n");
                        dumpregs();
                        exit(-1);
                }
                addr=seg&~7;
                if (seg&4)
                {
                        if (addr>=ldt.limit) x86abort("Bigger than LDT limit\n");
                        addr+=ldt.base;
                }
                else
                {
                        if (addr>=gdt.limit) x86abort("Bigger than GDT limit\n");
                        addr+=gdt.base;
                }
                segdat[0]=readmemw(0,addr);
                segdat[1]=readmemw(0,addr+2);
                segdat[2]=readmemw(0,addr+4);
//                printf("Code seg call - %04X - %04X %04X %04X\n",seg,segdat[0],segdat[1],segdat[2]);
                if (segdat[2]&0x1000)
                {
                        CS=seg;
                        _cs.limit=segdat[0];
                        _cs.base=segdat[1];
                        _cs.base|=((segdat[2]&0xFF)<<16);
                        _cs.access=segdat[2]>>8;
                        if (!(segdat[2]&0x8000))
                        {
                                notpresent=1;
                                nperror=seg&0xFFFC;
                                return;
                        }
                }
                else
                {
                        switch (segdat[2]&0xF00)
                        {
                                case 0x400: /*Call gate*/
                                if (!(segdat[2]&0x8000))
                                {
                                        notpresent=1;
                                        nperror=seg&0xFFFC;
//                                        printf("Call gate not present!\n");
                                        return;
                                }
//                                output=1;
//                                printf("Call gate! %04X:%04X\n",SS,SP);
//                                if (output) { dumpregs(); exit(-1); }
//                                if (SP==0x28F0) output=1;
                                CS&=~3;
                                loadseg(segdat[1],&_cs);
                                if (CPL<oldcs)
                                {
                                        count=segdat[2]&31;
                                        if (count&31)
                                        {
                                                printf("Call gate - copy %i words\n",count);
                                                dumpregs();
                                                exit(-1);
                                        }
                                        oldss=SS;
                                        oldsp=SP;
                                        
                                        addr=2+((CS&3)<<2)+tr.base;
//                                        printf("Loading SS - %04X %04X %04X\n",readmemw(0,addr+2),readmemw(0,addr),CS);
                                        loadseg(readmemw(0,addr+2),&_ss);
                                        SP=readmemw(0,addr);
                                        
                                        writememw(ss,((SP-2)&0xFFFF),oldss);
                                        writememw(ss,((SP-4)&0xFFFF),oldsp);
                                        SP-=4;
                                }
                                pc=segdat[0];
//                                printf("Now %04X:%04X\n",CS,pc);
                                break;
                                
                                default:
                                printf("Bad special descriptor %03X\n",segdat[2]&0xF00);
                                dumpregs();
                                exit(-1);
                        }
                }
//                printf("CS = %04X base=%06X limit=%04X access=%02X  %04X\n",CS,cs,_cs.limit,_cs.access,addr);
//                dumpregs();
//                exit(-1);
        }
        else
        {
                _cs.base=seg<<4;
                _cs.limit=0xFFFF;
                CS=seg;
        }
}

void pmodeint(int num, int soft)
{
        unsigned short segdat[3];
        unsigned long addr;
        unsigned short temp[3];
        unsigned short oldcs=CPL;
        unsigned short oldss,oldsp;
//        printf("PMODE INT %02X %i %04X:%04X\n",num,soft,CS,pc);
        addr=(num<<3);
        if (addr>=idt.limit)
        {
                if (num==8)
                {
                        /*Triple fault - reset!*/
//                        printf("Triple fault!\n");
                        resetx86();
                }
                else
                {
//                        printf("Double fault!\n");
                        pmodeint(8,0);
                }
//                printf("IDT out of limit - reset?\n");
                return;
//                dumpregs();
//                exit(-1);
        }
        addr+=idt.base;
        segdat[0]=readmemw(0,addr);
        segdat[1]=readmemw(2,addr);
        segdat[2]=readmemw(4,addr);
        switch (segdat[2]&0xF00)
        {
                case 0x600: /*Interrupt gate*/
                temp[0]=flags; temp[1]=CS; temp[2]=pc;
                flags&=~I_FLAG;
                CS=0;
                loadseg(segdat[1],&_cs);
                pc=segdat[0];
                if (!(_cs.access&4) && (CPL<oldcs))
                {
                        oldss=SS;
                        oldsp=SP;
                        
                        addr=2+((CS&3)<<2)+tr.base;
//                        if (!readmemw(0,addr+2)) printf("SP NULL when INT\n");
                        loadseg(readmemw(0,addr+2),&_ss);
                        SP=readmemw(0,addr);

                        writememw(ss,((SP-2)&0xFFFF),oldss);
                        writememw(ss,((SP-4)&0xFFFF),oldsp);
                        SP-=4;
                        
//                        printf("Interrupt to inner level! %04X %04X\n",temp[1],CS);
//                        dumpregs();
//                        exit(-1);
                }
                writememw(ss,((SP-2)&0xFFFF),temp[0]);
                writememw(ss,((SP-4)&0xFFFF),temp[1]);
                writememw(ss,((SP-6)&0xFFFF),temp[2]);
                SP-=6;
//                printf("Interrupt to %04X(%06X):%04X\n",CS,cs,pc);
                return;
//                dumpregs();
//                exit(-1);
                default:
                printf("Bad int gate %03X  %04X %04X %04X\n",segdat[2]&0xF00,segdat[0],segdat[1],segdat[2]);
                dumpregs();
                exit(-1);
        }
        printf("PMODEINT - how did we get here?\n");
        dumpregs();
        exit(-1);
}
int inint;
void pmodeiret()
{
        unsigned short nss,nsp;
        unsigned short oldcs=CPL;
//        printf("Pmode IRET %04X:%04X ",CS,pc);
        if (flags&NT_FLAG)
        {
                printf("Nested task return!\n");
                dumpregs();
                exit(-1);
        }
        inint=0;
        pc=readmemw(ss,SP);
        loadcs(readmemw(ss,((SP+2)&0xFFFF)));
        flags=readmemw(ss,((SP+4)&0xFFFF))&0xFFF;
        SP+=6;
        if (CPL>oldcs) /*Return to outer level*/
        {
//                printf("IRET to outer level! %04X\n",oldcs);
                nsp=readmemw(ss,SP);
                nss=readmemw(ss,((SP+2)&0xFFFF));
//                if (!nss) printf("SP NULL when IRET\n");
//                printf("SS %04X SP %04X\n",nss,nsp);
                loadseg(nss,&_ss);
                SP=nsp;
                if (CPL>((_ds.access>>5)&3))
                {
                        _ds.seg=0;
                        _ds.base=-1;
                }
                if (CPL>((_es.access>>5)&3))
                {
                        _es.seg=0;
                        _es.base=-1;
                }
//                dumpregs();
//                exit(-1);
        }
//        printf("%04X:%04X %04X\n",CS,pc,flags);
}
