#include "ibm.h"

float PITCONST;
float cpuclock;

void setpitclock(float clock)
{
//        printf("PIT clock %f\n",clock);
        cpuclock=clock;
        PITCONST=clock/1193182.0;
        SPKCONST=clock/48000.0;
        setsbclock(clock);
        SOUNDCONST=clock/60.0;
}

//#define PITCONST (8000000.0/1193000.0)
//#define PITCONST (cpuclock/1193000.0)
int pit0;
void resetpit()
{
        memset(&pit,0,sizeof(PIT));
        pit.l[0]=0xFFFF; pit.c[0]=0xFFFF*PITCONST;
        pit.l[1]=0xFFFF; pit.c[1]=0xFFFF*PITCONST;
        pit.l[2]=0xFFFF; pit.c[2]=0xFFFF*PITCONST;
        pit.m[0]=pit.m[1]=pit.m[2]=0;
        pit.ctrls[0]=pit.ctrls[1]=pit.ctrls[2]=0;
        pit.thit[0]=1;
        spkstat=0;
        pit.delay[2]=0;
}

void clearpit()
{
        pit.c[0]=(pit.l[0]<<2);
}

void writepit(unsigned short addr, unsigned char val)
{
        int t;
        pit0=1;
//        if (CS<0xA000) printf("Write PIT %04X %02X %04X:%04X\n",addr,val,cs>>4,pc);
        switch (addr&3)
        {
                case 3: /*CTRL*/
                pit.ctrls[val>>6]=pit.ctrl=val;
                if ((val>>7)==3)
                {
                        printf("Bad PIT reg select\n");
                        return;
//                        dumpregs();
//                        exit(-1);
                }
//                printf("CTRL write %02X\n",val);
                if (!(pit.ctrl&0x30))
                   pit.rl[val>>6]=pit.c[val>>6]/PITCONST;
                else
                {
                        if ((val&0xC0)==0xC0)
                        {
                                if (!(val&0x20))
                                {
                                        if (val&2) pit.rl[0]=pit.c[0]/PITCONST;
                                        if (val&4) pit.rl[1]=pit.c[1]/PITCONST;
                                        if (val&8) pit.rl[2]=pit.c[2]/PITCONST;
                                }
                        }
                        else
                        {
                                pit.rm[val>>6]=(pit.ctrl>>4)&3;
                                pit.m[val>>6]=(val>>1)&7;
                                if (pit.m[val>>6]>5)
                                   pit.m[val>>6]&=3;
                                if (!(pit.rm[val>>6]))
                                {
                                        pit.rereadlatch[val>>6]=1;
//                                        printf("Latching timer!\n");
                                        pit.rl[val>>6]=pit.c[val>>6]/PITCONST;
                                }
//                                if (!(val>>6)) printf("PIT 0 mode %i\n",pit.m[val>>6]);
                        }
//                        printf("PIT timer %i mode %i\n",val>>6,(val>>1)&7);
                }
//                else
//                   pit.rm[val>>6]=(pit.ctrl>>4)&3;
//                printf("RM=%02X\n",pit.rm);
                pit.wp=0;
                pit.thit[pit.ctrl>>6]=0;
//                printf("PIT ctrl now %02X %02X\n",pit.ctrl,val);
                break;
                case 0: case 1: case 2: /*Timers*/
                t=addr&3;
                if (t==2) ppispeakon=speakon=0;
//                pit.delay[(pit.ctrl>>4)&3]=100;
                if (!t) picclear(1);
                switch ((pit.ctrl>>4)&3)
                {
                        case 1:
                        pit.l[t]=val;
//                        printf("PIT %i now %04X %04X:%04X\n",pit.ctrl>>6,val,cs>>4,pc);
                        pit.thit[t]=0;
                        pit.c[t]=pit.l[t]*PITCONST;
                        if (t==1) pit.delay[1]=0;
//                        printf("1PIT %i %04X %f\n",pit.ctrl>>6,pit.l[pit.ctrl>>6],pit.c[pit.ctrl>>6]);
                        break;
                        case 2:
                        pit.l[t]=(val<<8);
//                        printf("PIT %i now %04X\n",pit.ctrl>>6,val<<8);
                        pit.thit[t]=0;
                        pit.c[t]=pit.l[t]*PITCONST;
                        if (t==1) pit.delay[1]=0;
//                        printf("2PIT %i %04X %f\n",pit.ctrl>>6,pit.l[pit.ctrl>>6],pit.c[pit.ctrl>>6]);
                        break;
                        case 3:
                        if (pit.wp)
                        {
                                pit.l[t]&=0xFF;
                                pit.l[t]|=(val<<8);
//                                printf("PIT %i now %04X %04X:%04X\n",pit.ctrl>>6,pit.l[pit.ctrl>>6],cs>>4,pc);
                                pit.thit[t]=0;
                        }
                        else
                        {
                                pit.l[t]&=0xFF00;
                                pit.l[t]|=val;
//                                printf("PIT %i now %04X %04X:%04X\n",pit.ctrl>>6,pit.l[pit.ctrl>>6],cs>>4,pc);
                        }
                        pit.c[t]=pit.l[t]*PITCONST;
//                        printf("3PIT %i %04X %f\n",pit.ctrl>>6,pit.l[pit.ctrl>>6],pit.c[pit.ctrl>>6]);
                        pit.rl[t]=pit.l[t];
                        pit.wp^=1;
                        if (t==1) pit.delay[1]=0;
                        break;
                }
                speakval=(((float)pit.l[2]/(float)pit.l[0])*0x4000)-0x2000;
//                if (speakval>0x2000)
//                   printf("Speaker overflow - %i %i %04X %04X\n",pit.l[0],pit.l[2],pit.l[0],pit.l[2]);
                if (speakval>0x2000) speakval=0x2000;
                if (!pit.l[t])
                {
                        pit.l[t]|=0x10000;
                        pit.c[t]=pit.l[t]*PITCONST;
//                        printf("-PIT %i now %05X %05X\n",pit.ctrl>>6,pit.l[pit.ctrl>>6],pit.c[pit.ctrl>>6]);
                }
//                printf("PIT %i now %05X %f %i %i %02X %i\n",t,pit.l[t],pit.c[t],pit.delay[t],(pit.ctrl>>4)&3,pit.ctrl,pit.m[t]);
                break;
        }
}

unsigned char readpit(unsigned short addr)
{
        unsigned char temp;
//        if (CS<0xA000) printf("Read PIT %04X ",addr);
        switch (addr&3)
        {
                case 0: case 1: case 2: /*Timers*/
/*                switch (pit.rm)
                {
                        case 0:
                        printf("Shouldn't have got here\n");
                        dumpregs();
                        exit(-1);
                        case 1:
                        temp=(pit.rl)&0xFF;
                        break;
                        case 2:
                        temp=(pit.rl)>>8;
                        break;
                        case 3:
                        pit.wp^=1;
                        if (pit.wp) temp=(pit.rl)&0xFF;
                        else        temp=(pit.rl)>>8;
                        break;
                }*/
                if (pit.rereadlatch[addr&3])
                {
                        pit.rereadlatch[addr&3]=0;
                        pit.rl[addr&3]=pit.c[addr&3]/PITCONST;
                }
                switch (pit.rm[addr&3])
                {
                        case 0:
                        temp=pit.rl[addr&3]>>8;
                        pit.rl[addr&3]=pit.c[addr&3]/PITCONST;
                        pit.rm[addr&3]=3;
//                        printf("Reading latch %02X\n",temp);
                        break;
//                      printf("Shouldn't have got here\n");
//                      dumpregs();
//                      exit(-1);
                        case 1:
                        temp=(pit.rl[addr&3])&0xFF;
                        pit.rereadlatch[addr&3]=1;
                        break;
                        case 2:
                        temp=(pit.rl[addr&3])>>8;
                        pit.rereadlatch[addr&3]=1;
                        break;
                        case 3:
                        temp=(pit.rl[addr&3])&0xFF;
                        if (pit.m[addr&3]&0x80) pit.m[addr&3]&=7;
                        else pit.rm[addr&3]=0;
//                        printf("Reading latch %02X\n",temp);
                        break;
                }
                break;
                case 3: /*Control*/
                temp=pit.ctrl;
        }
//        if (CS<0xA000) printf("%02X %i %i %04X:%04X\n",temp,pit.rm,pit.wp,cs>>4,pc);
        return temp;
}

void pollpit()
{
//        printf("Poll pit %f %f %f\n",pit.c[0],pit.c[1],pit.c[2]);
        if (pit.c[0]<1)
        {
                if (pit.m[0]==0 || pit.m[0]==4)
                {
//                        pit.c[0]&=0xFFFF;
                        pit.c[0]+=(0x10000*PITCONST);
                }
                else if (pit.m[0]==3 || pit.m[0]==2)
                {
                        if (pit.l[0]) pit.c[0]+=(int)((float)(pit.l[0]*PITCONST));
                        else          pit.c[0]+=(int)((float)(0x10000*PITCONST));
                }
//                pit.c[0]+=(pit.l[0]*PITCONST);
//                printf("PIT over! %f %i\n",pit.c[0],pit.m[0]);
                if (!pit.thit[0] && (pit.l[0]>0x14))
                {
//                        printf("PIT int!\n");
///                        printf("%05X %05X %02X\n",pit.c[0],pit.l[0],pit.ctrls[0]);
                        picint(1);
                }
                if (!pit.m[0] || pit.m[0]==4) pit.thit[0]=1;
//                if ((pit.ctrls[0]&0xE)==2) pit.thit[0]=1;
                pit0=0;
                pitcount++;
        }
        if (pit.c[1]<1)
        {
//                printf("PIT1 over %02X\n",pit.ctrls[0]&0xE);
                if (!(pit.ctrls[0]&0xE))
                {
                        pit.c[1]=0xFFFF*PITCONST;
                        pit.delay[1]=1;
                }
                else
                {
                        pit.c[1]+=(pit.l[1]*PITCONST);
                }
                readdma0();
        }
        if (pit.c[2]<1)
        {
//                printf("PIT 2 over %i\n",pit.m[2]);
                if (!pit.m[2] || pit.m[2]==4)
                {
                        pit.c[2]+=(0x10000*PITCONST);
                        speakon^=1;
                        ppispeakon^=1;
                }
                else
                {
                        pit.c[2]+=((pit.l[2]*PITCONST)/2);
                        if (pit.l[2]>0x30) /*Some games use very high frequencies as 'speaker off'. This stops them from generating noise*/
                           speakon^=1;
                        ppispeakon^=1;
//                        printf("Speakon %i %04X %i\n",speakon,pit.l[2],pit.c[2]);
                }
//                if (pit.ctrls[2]&0xE) pit.c[2]+=(pit.l[2]*PITCONST);
//                spkstat^=0x20;
        }
}
