#include <allegro.h>
#include <stdio.h>
#include "ibm.h"

int soundon=1;
AUDIOSTREAM *as;
unsigned short *adbuffer;
unsigned short *psgbuffer;
unsigned short *cmsbuffer;
signed short *spkbuffer;
signed short *outbuffer;

void initsound()
{
        install_sound(DIGI_AUTODETECT,MIDI_NONE,0);
        as=play_audio_stream(SOUNDBUFLEN,16,1,48000,255,128);
        initadlib();
        adbuffer=malloc((SOUNDBUFLEN)*2);
        psgbuffer=malloc((SOUNDBUFLEN)*2);
        cmsbuffer=malloc((SOUNDBUFLEN)*2*2);
        spkbuffer=malloc(((SOUNDBUFLEN)*2)+32);
        outbuffer=malloc((SOUNDBUFLEN)*2*2);
}

int adpoll=0;
void pollad()
{
        if (adpoll>=3) return;
        getadlib(adbuffer+(adpoll*(48000/60)),48000/60);
        adpoll++;
//        printf("ADPOLL %i\n",adpoll);
}

int psgpoll=0;
void pollpsg()
{
        if (psgpoll>=3) return;
        getpsg(psgbuffer+(psgpoll*(48000/60)),48000/60);
        psgpoll++;
}

int cmspoll=0;
void pollcms()
{
        if (cmspoll>=3) return;
        getcms(cmsbuffer+(cmspoll*(48000/60)*2),48000/60);
        cmspoll++;
}

int spkpos=0;
void pollspk()
{
        if (spkpos>=SOUNDBUFLEN) return;
        if (gated)
        {
                if (!pit.m[2] || pit.m[2]==4)
                   spkbuffer[spkpos]=speakval;
                else 
                   spkbuffer[spkpos]=(speakon)?0x1400:0;
        }
        else
           spkbuffer[spkpos]=0;
        spkpos++;
}

FILE *soundf;
void pollsound()
{
        int c;
        if (soundon)
        {
                for (c=0;c<(SOUNDBUFLEN);c++)
                    outbuffer[c<<1]=outbuffer[(c<<1)+1]=(signed short)adbuffer[c];
//                memcpy(outbuffer,adbuffer,(SOUNDBUFLEN)*2);
                for (c=0;c<spkpos;c++)
                {
                        outbuffer[c<<1]+=(spkbuffer[c]/2);
                        outbuffer[(c<<1)+1]+=(spkbuffer[c]/2);
                }
                for (c=spkpos;c<(SOUNDBUFLEN);c++)
                {
                        outbuffer[c<<1]+=(spkbuffer[spkpos-1]/2);
                        outbuffer[(c<<1)+1]+=(spkbuffer[spkpos-1]/2);
                }
                for (c=0;c<(SOUNDBUFLEN);c++)
                {
                        outbuffer[c<<1]+=(psgbuffer[c]/2);
                        outbuffer[(c<<1)+1]+=(psgbuffer[c]/2);
                }
                for (c=0;c<((SOUNDBUFLEN)*2);c++)
                    outbuffer[c]+=(cmsbuffer[c]/2);
                addsb(outbuffer);
//                getpsgbuffer(outbuffer,SOUNDBUFLEN);
                outputsoundbuffer(outbuffer);
                for (c=0;c<((SOUNDBUFLEN)*2);c++) outbuffer[c]^=0x8000;
//                if (!soundf) soundf=fopen("sound.pcm","wb");
//                fwrite(outbuffer,(SOUNDBUFLEN)*2*2,1,soundf);
        }
        addsb(outbuffer);
        adpoll=0;
        psgpoll=0;
        cmspoll=0;
        spkpos=0;
}

int sndcount;
void pollsound60hz()
{
                pollad();
                pollpsg();
                pollcms();
                sndcount++;
                if (sndcount==3)
                {
                        sndcount=0;
                        pollsound();
                }
}
