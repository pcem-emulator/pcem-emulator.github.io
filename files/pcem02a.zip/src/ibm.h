#include <stdio.h>
#define printf pclog

#define AX regs[0].w
#define CX regs[1].w
#define DX regs[2].w
#define BX regs[3].w
#define SP regs[4].w
#define BP regs[5].w
#define SI regs[6].w
#define DI regs[7].w
#define AL regs[0].b.l
#define AH regs[0].b.h
#define CL regs[1].b.l
#define CH regs[1].b.h
#define DL regs[2].b.l
#define DH regs[2].b.h
#define BL regs[3].b.l
#define BH regs[3].b.h

typedef union
{
        unsigned short w;
        struct
        {
                unsigned char l,h;
        } b;
} x86reg;

x86reg regs[8];
unsigned short pc,flags;
unsigned long /*cs,ds,es,ss,*/oldds,oldss;
unsigned short msw;

typedef struct
{
        unsigned long base;
        unsigned short limit;
        unsigned char access;
        unsigned short seg;
} x86seg;

x86seg gdt,ldt,idt,tr;
x86seg _cs,_ds,_es,_ss;
/*Segments -
  _cs,_ds,_es,_ss are the segment structures
  CS,DS,ES,SS is the 16-bit data
  cs,ds,es,ss are defines to the bases*/
//unsigned short CS,DS,ES,SS;
#define CS _cs.seg
#define DS _ds.seg
#define ES _es.seg
#define SS _ss.seg
#define cs _cs.base
#define ds _ds.base
#define es _es.base
#define ss _ss.base

#define CPL ((_cs.access>>5)&3)

void loadseg(unsigned short seg, x86seg *s);
void loadcs(unsigned short seg);
unsigned long rammask;

#define C_FLAG  0x0001
#define P_FLAG  0x0004
#define A_FLAG  0x0010
#define Z_FLAG  0x0040
#define N_FLAG  0x0080
#define I_FLAG  0x0200
#define D_FLAG  0x0400
#define V_FLAG  0x0800
#define NT_FLAG 0x4000

typedef struct PIT
{
        unsigned long l[3];
        float c[3];
        unsigned char m[3];
        unsigned char ctrl,ctrls[2];
        int wp,rm[3];
        unsigned short rl[3];
        int thit[3];
        int delay[3];
        int rereadlatch[3];
} PIT;

PIT pit;
void setpitclock(float clock);

typedef struct DMA
{
        unsigned short ab[4],ac[4];
        unsigned short cb[4];
        int cc[4];
        int wp;
        unsigned char m,mode[4];
        unsigned char page[4];
        unsigned char stat;
} DMA;

DMA dma,dma16;

typedef struct PPI
{
        int s2;
        unsigned char pa,pb;
} PPI;

PPI ppi;

typedef struct PIC
{
        unsigned char icw1,mask,ins,pend;
        int icw;
        unsigned char vector;
} PIC;

PIC pic,pic2;

typedef struct FDC
{
        unsigned char dor,stat,command,dat,st0;
        int head,track[2],sector,drive,lastdrive;
        int pos;
        unsigned char params[8];
        unsigned char res[8];
        int pnum,ptot;
} FDC;

FDC fdc;
int disctime;

#define MDA ((gfxcard==GFX_MDA || gfxcard==GFX_HERCULES) && (romset<2 || romset>=6))
#define HERCULES (gfxcard==GFX_HERCULES && (romset<2 || romset>=6))
#define AMSTRAD (romset==ROM_PC1512 || romset==ROM_PC1640)
#define TANDY (romset==ROM_TANDY/* || romset==ROM_IBMPCJR*/)
#define EGA (romset==ROM_PC1640 || VGA)
#define VGA (gfxcard==GFX_SVGA && romset!=ROM_PC1640 && romset!=ROM_PC1512 && romset!=ROM_TANDY && romset!=ROM_PC200)
#define AT (romset==ROM_IBMAT)

int FASTDISC;
int ADLIB;
int GAMEBLASTER;

char discfns[2][256];

int intcount,pitcount;

#define ROM_IBMPC   0 /*301 keyboard error, 131 cassette (!!!) error*/
#define ROM_IBMXT   1 /*301 keyboard error*/
#define ROM_TANDY   2 /*Works fine*/
#define ROM_PC1512  3 /*Works fine*/
#define ROM_PC200   4 /*Video controller not emulated, so has to run in diagnostic mode*/
#define ROM_PC1640  5 /*Works fine*/
#define ROM_IBMAT   6
//#define ROM_IBMPCJR 5 /*Not working! ROMs are corrupt*/

int romset;

#define GFX_CGA 0
#define GFX_MDA 1
#define GFX_HERCULES 2
#define GFX_SVGA 3     /*Using Trident BIOS*/

int gfxcard;

unsigned char spkstat;

float spktime,soundtime;
int ppispeakon;
//#define SPKCONST (8000000.0/44100.0)
float SPKCONST;
float SOUNDCONST;
int gated,speakval,speakon;

int readflash;

/*0=4.77mhz 8088
  1=8mhz 8086*/
int cpuspeed;

unsigned char *ram,*vram;
unsigned char hercctrl;

int mousedelay;

int driveempty[2];

#define SOUNDBUFLEN (48000/20)

/*Sound Blaster*/
int sbenable,sblatch,sbcount;
unsigned char sbdat;
void setsbclock(float clock);

int clocks[2][5][4];
int at70hz;

char pcempath[512];

FILE *romfopen(char *fn, char *mode);

typedef struct
{
        FILE *f;
        int spt,hpc; /*Sectors per track, heads per cylinder*/
        int tracks;
} PcemHDC;

PcemHDC hdc[2];

