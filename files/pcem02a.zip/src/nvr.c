#include <stdio.h>
#include <windows.h>
#include "ibm.h"

unsigned char nvrram[64];
int nvraddr;

SYSTEMTIME systemtime;

void getnvrtime()
{
        int c,d;
        unsigned char baknvr[10];
        memcpy(baknvr,nvrram,10);
        GetLocalTime(&systemtime);
        d=systemtime.wSecond%10;
        c=systemtime.wSecond/10;
        nvrram[0]=d|(c<<4);
        d=systemtime.wMinute%10;
        c=systemtime.wMinute/10;
        nvrram[2]=d|(c<<4);
        d=systemtime.wHour%10;
        c=systemtime.wHour/10;
        nvrram[4]=d|(c<<4);
        d=systemtime.wDayOfWeek%10;
        c=systemtime.wDayOfWeek/10;
        nvrram[6]=d|(c<<4);
        d=systemtime.wDay%10;
        c=systemtime.wDay/10;
        nvrram[7]=d|(c<<4);
        d=systemtime.wMonth%10;
        c=systemtime.wMonth/10;
        nvrram[8]=d|(c<<4);
        d=systemtime.wYear%10;
        c=systemtime.wYear/10;
        nvrram[9]=d|(c<<4);
        if (baknvr[0]!=nvrram[0] ||
            baknvr[2]!=nvrram[2] ||
            baknvr[4]!=nvrram[4] ||
            baknvr[6]!=nvrram[6] ||
            baknvr[7]!=nvrram[7] ||
            baknvr[8]!=nvrram[8] ||
            baknvr[9]!=nvrram[9]) nvrram[0xA]|=0x80;
}

void writenvr(unsigned short addr, unsigned char val)
{
        if (addr&1) nvrram[nvraddr]=val;
        else        nvraddr=val&63;
}

unsigned char readnvr(unsigned short addr)
{
        unsigned char temp;
//        printf("Read NVR %03X %02X %02X %04X:%04X\n",addr,nvraddr,nvrram[nvraddr],cs>>4,pc);
        if (addr&1)
        {
                if (nvraddr<=0xA) getnvrtime();
                if (nvraddr==0xD) nvrram[0xD]|=0x80;
                if (nvraddr==0xA)
                {
                        temp=nvrram[0xA];
                        nvrram[0xA]&=~0x80;
                        return temp;
                }
//                if (nvraddr==0xA) nvrram[0xA]^=0x80;
                return nvrram[nvraddr];
        }
        return nvraddr;
}

void loadnvr()
{
        FILE *f;
        switch (romset)
        {
                case ROM_PC1512: f=romfopen("pc1512.nvr","rb"); break;
                case ROM_PC1640: f=romfopen("pc1640.nvr","rb"); break;
                case ROM_IBMAT:  f=romfopen("at.nvr"    ,"rb"); break;
                default: return;
        }
        fread(nvrram,64,1,f);
        fclose(f);
}
void savenvr()
{
        FILE *f;
        switch (romset)
        {
                case ROM_PC1512: f=romfopen("pc1512.nvr","wb"); break;
                case ROM_PC1640: f=romfopen("pc1640.nvr","wb"); break;
                case ROM_IBMAT:  f=romfopen("at.nvr"    ,"wb"); break;
                default: return;
        }
        fwrite(nvrram,64,1,f);
        fclose(f);
}
