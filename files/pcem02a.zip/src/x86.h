unsigned long old8,old82,old83;
unsigned short oldpc,oldcs;
int oldcpl;

int tempc;
int cycles,output;
int ssegs;
int firstrepcycle;

unsigned long easeg,eaaddr;
int rm,reg,mod,rmdat;

int skipnextprint;
int inhlt;

unsigned char opcode;
int ins,noint,notpresent;
int inint;

unsigned short lastcs,lastpc;
int lldt;
int timetolive,keyboardtimer;

#define setznp168 setznp16

#define getr8(r)   ((r&4)?regs[r&3].b.h:regs[r&3].b.l)

#define setr8(r,v) if (r&4) regs[r&3].b.h=v; \
                   else     regs[r&3].b.l=v;

