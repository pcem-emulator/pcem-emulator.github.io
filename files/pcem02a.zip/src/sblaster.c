#include <stdio.h>
#include "ibm.h"

int sbtype=0; /*0=SB2, 1=SB pro*/

unsigned char sbdatl,sbdatr;

int sbleftright=0;
int sbinput=0;
int sbreadstat,sbwritestat;
int sbreset;
unsigned char sbreaddat;
unsigned char sbcommand,sbdata;
int sbcommandnext=1;
unsigned char sbtest;
int sbtime;
int sblength;
int sbcommandstat;
int sbhalted;
int adpcmstat=0;
int sbautolen;
int sbautoinit=0;
unsigned char sbcurcommand,sbdmacommand;
unsigned char sbe2;
int sbe2count;
float SBCONST;

void setsbclock(float clock)
{
        SBCONST=clock/1000000.0f;
        printf("SBCONST %f %f\n",SBCONST,clock);
        sblatch=SBCONST*(256-sbtime);
}

int sbstereo=0;

int sbe2dat[4][9] = {
  {  0x01, -0x02, -0x04,  0x08, -0x10,  0x20,  0x40, -0x80, -106 },
  { -0x01,  0x02, -0x04,  0x08,  0x10, -0x20,  0x40, -0x80,  165 },
  { -0x01,  0x02,  0x04, -0x08,  0x10, -0x20, -0x40,  0x80, -151 },
  {  0x01, -0x02,  0x04, -0x08, -0x10,  0x20, -0x40,  0x80,   90 }
};


void initsb()
{
        sbreset=0;
        sbenable=sblatch=sbcount=0;
        sbhalted=0;
        sbe2=0xaa;
        sbe2count=0;
        sbdmacommand=0;
}

void outmidi(unsigned char v)
{
        printf("Write MIDI %02X\n",v);
}

unsigned char mixerindex;

void writesb(unsigned short a, unsigned char v)
{
        int temp;
        int c;
        printf("Write soundblaster %04X %02X %04X:%04X %02X\n",a,v,cs>>4,pc,sbcommand);
        switch (a&0xF)
        {
                case 0: case 1: case 2: case 3: writeadlib(a,v); return; /*OPL*/
                case 4: mixerindex=v; return;
                case 5: if (mixerindex==0xE) sbstereo=(v&2); return;
                case 6: /*Reset*/
                if (!(v&1) && (sbreset&1))
                {
                        sbreaddat=0xAA;
                        sbreadstat=0x80;
                        sbe2=0xaa;
                        sbe2count=0;
                        sbenable=0;
                        sbcommand=0;
                        picintc(0x80);
//                        printf("Sound blaster reset\n");
                }
                sbreset=v;
                return;
                case 8: case 9: writeadlib(a,v); return; /*OPL*/
                case 0xC: /*Command/data write*/
                if (sbcommandnext)
                {
                        printf("New command %02X\n",v);
                        sbcommand=v;
                        switch (v)
                        {
                                case 0x10: /*Direct DAC*/
                                sbcommandnext=0;
                                break;
                                case 0x20: /*8-bit ADC direct*/
                                sbreaddat=0;
                                sbreadstat=0x80;
                                sbcommand=0;
                                break;
                                case 0x14: /*8-bit DMA transfer*/
                                sblength=0;
                                sbcommandnext=0;
                                sbcommandstat=0;
                                sbcurcommand=sbcommand;
                                sbinput=0;
                                sbleftright=0;
                                break;
                                case 0x1C: /*8-bit Auto-init DMA*/
                                case 0x90: /*8-bit Auto-init high-speed DMA transfer*/
                                case 0x91: /*8-bit high-speed DMA transfer*/
                                sbenable=1;
                                sbautoinit=(v==0x91)?0:1;
                                sblength=sbautolen;
                                sbdmacommand=0x1C;
                                sbinput=0;
                                sbleftright=0;
//                                printf("Started DMA\n");
                                break;
                                case 0xDA:
                                sbenable=0;
                                sblength=sbautolen;
                                break;
                                case 0x24: /*8-bit DMA ADC transfer*/
                                sblength=0;
                                sbcommandnext=0;
                                sbcommandstat=0;
                                sbcurcommand=sbcommand;
//                                printf("ADC transfer %02X %02X\n",sbcommand,sbcurcommand);
//                                sbinput=0;
                                break;
                                case 0x40: /*Set time constant*/
                                sbcommandnext=0;
                                break;
                                case 0x17: /*2-bit ADPCM transfer with reference*/
                                case 0x75: /*4-bit ADPCM transfer with reference*/
                                case 0x77: /*2.6-bit ADPCM transfer with reference*/
                                sbdat=readdma1();
                                case 0x16: /*2-bit ADPCM transfer*/
                                case 0x74: /*4-bit ADPCM transfer*/
                                case 0x76: /*2.6-bit ADPCM transfer*/
                                case 0x80: /*Silence DAC*/
                                sblength=0;
                                sbcommandnext=0;
                                sbcommandstat=0;
                                adpcmstat=0;
                                sbcurcommand=sbcommand;
                                sbinput=0;
                                sbautoinit=0;
                                sbleftright=0;
                                break;
                                case 0x48: /*Set DMA length*/
                                sbcommandnext=0;
                                sbcommandstat=0;
                                sbcurcommand=sbcommand;
//                                printf("Set DMA length! %04X:%04X\n",CS,pc);
                                break;
                                case 0xD0: /*Halt DMA*/
//                                printf("Halt DMA\n");
                                sbhalted=1;
                                sbenable=0;
                                break;
                                case 0xD1: /*Enable speaker*/
                                case 0xD3: /*Disable speaker*/
                                break;
                                case 0xD4: /*Continue DMA*/
//                                printf("Continue DMA\n");
                                if (sbhalted)
                                {
                                        sbhalted=0;
                                        sbenable=1;
                                }
                                break;
                                case 0xE0: /*Identify*/
                                sbcommandnext=0;
                                break;
                                case 0xE1: /*DSP version*/
                                sbreaddat=(sbtype)?3:2;//1;
                                sbreadstat=0x80;
                                break;
                                case 0xE2: /*Identify DMA*/
                                sbcommandnext=0;
                                break;
                                case 0xE4: /*Write test byte*/
                                sbcommandnext=0;
                                break;
                                case 0xE8: /*Read test byte*/
                                sbreaddat=sbtest;
                                sbreadstat=0x80;
                                break;
                                case 0xF2: /*Interrupt request*/
                                picint(0x80);
//                                printf("Interrupt request\n");
                                break;
                                case 0xFF: case 0xFA: case 0x00: case 7:
                                        break;
                                default:
                                printf("Bad soundblaster command %02X\n",v);
                                dumpregs();
                                exit(-1);
                        }
                }
                else
                {
                        sbdata=v;
                        sbcommandnext=1;
                        switch (sbcommand)
                        {
                                case 0x10:
                                sbdat=v;
                                break;
                                case 0x14:
                                case 0x91:
                                case 0x16:
                                case 0x17:
                                case 0x74:
                                case 0x75:
                                case 0x76:
                                case 0x77:
                                case 0x80:
                                        case 0x24:
                                if (sbcommandstat)
                                {
                                        sblength=((sblength&0xFF)|(v<<8));
//                                        printf("SB start - %02X %02X length %04X addr %01X%04X\n",sbcommand,sbcurcommand,sblength,dmaseg[1],dmabase[1]);
                                        sbenable=1;
                                        if (sbcurcommand==0x24) sbinput=1;
                                        sbdmacommand=sbcurcommand;
                                }
                                else
                                {
                                        sblength=(sblength&0xFF00)|v;
                                        sbcommandnext=0;
                                }
                                sbcommandstat++;
                                break;
                                case 0x48: /*Set DMA length*/
//                                printf("Set DMA length %02X %i\n",v,sbcommandstat);
                                if (sbcommandstat)
                                {
                                        sbautolen=((sbautolen&0xFF)|(v<<8));
                                }
                                else
                                {
                                        sbautolen=(sbautolen&0xFF00)|v;
                                        sbcommandnext=0;
                                }
//                                printf("Now %04X\n",sbautolen);
                                sbcommandstat++;
                                break;
                                case 0x40: /*Set time constant*/
                                sbtime=sbdata;
                                temp=256-sbdata;
                                temp=1000000/temp;
//                                printf("Sample rate - %ihz\n",temp);
                                sblatch=SBCONST*(256-sbdata);
//                                printf("SB latch %i cycles\n",sblatch);
                                break;
                                case 0xE0: /*Identify*/
                                sbreaddat=~sbdata;
                                sbreadstat=0x80;
                                break;
                                case 0xE2:
                                for (c=0;c<8;c++)
                                    if (v&(1<<c)) sbe2+=sbe2dat[sbe2count&3][c];
                                sbe2+=sbe2dat[sbe2count&3][8];
                                sbe2count++;
//                                printf("WriteDMA1 %02X\n",sbe2);
                                writedma1(sbe2);
                                break;
                                case 0xE4:
                                sbtest=sbdata;
                                break;
                                default:
                                printf("Bad soundblaster command2 %02X %02X\n",sbcommand,v);
                                dumpregs();
                                exit(-1);
                        }
                }
                break;
        }
}

unsigned char readsb(unsigned short a)
{
        unsigned char temp;
//        if (a==0x224) output=1;
//        if (a!=0x22A) printf("Read soundblaster %04X %04X:%04X\n",a,cs>>4,pc);
        switch (a&0xF)
        {
                case 5: if (mixerindex==0xE) return (sbstereo)?2:0; pclog("Read mixer %02X!\n",mixerindex); return 0;
                case 8: case 9: return readadlib(a); /*OPL*/
                case 0xA: /*Read data*/
                sbreadstat=0;
                temp=sbreaddat;
                switch (sbcommand)
                {
                        case 0xE1: /*DSP version*/
                        sbcommand=0;
                        sbreaddat=(sbtype)?0:1;//5;
                        sbreadstat=0x80;
                        break;
                }
                return temp;
                case 0xE: /*Read data ready*/
                return sbreadstat;
        }
        return 0;
}

//FILE *sbfile;
int sbshift4[8]={-2,-1,0,0,1,1,1,1};
void pollsb()
{
        unsigned char temp;
//        printf("Poll SB %i %02X\n",sbinput,sbdmacommand);
        if (sbinput)
        {
                writedma1(0);
        }
        else
        {
//        if (!sbfile) sbfile=fopen("sound.pcm","wb");
                if (sbdmacommand==0x14 || sbdmacommand==0x1C || sbdmacommand==0x91)
                   sbdat=readdma1();
                else
                   sbdat=0;
        }
        if (sbstereo)
        {
                if (sbleftright) sbdatr=sbdat;
                else             sbdatl=sbdat;
                sbleftright^=1;
        }
        else
           sbdatl=sbdatr=sbdat;
//        putc(sbdat,sbfile);
//        printf("SB %02X %i\n",sbdat,sblength);
        sblength--;
        if (sblength<0)
        {
//                printf("SB over - IRQ!\n");
                if (sbautoinit)
                {
                        sblength=sbautolen;
                        picint(0x80);
//                        printf("Soundblaster over - %i  %i %02X\n",sblength,sbinput,sbdmacommand);
                }
                else
                {
                        sbenable=0;
//                        printf("End of transfer\n");
                        picint(0x80);
                }
        }
}

short sbbuffer[SOUNDBUFLEN+20];
int sbbufferpos=0;
void getsbsamp()
{
        sbbuffer[sbbufferpos++]=(((int)(unsigned int)sbdat)-0x80)*0x60;
}

void addsb(signed short *p)
{
        int c;
        if (sbbufferpos>SOUNDBUFLEN) sbbufferpos=SOUNDBUFLEN;
//        printf("Addsb - %i\n",sbbufferpos);
        for (c=0;c<sbbufferpos;c++)
        {
                p[c<<1]+=(sbbuffer[c]);
                p[(c<<1)+1]+=(sbbuffer[c]);
        }
        for (;c<SOUNDBUFLEN;c++)
        {
                p[c<<1]+=(sbbuffer[sbbufferpos-1]);
                p[(c<<1)+1]+=(sbbuffer[sbbufferpos-1]);
        }
        sbbufferpos=0;
}
