#include <allegro.h>
#include "ibm.h"

int frames;
int incga=1;
int hsync;
unsigned char cgastat;

unsigned char crtc[32];
unsigned char gdcreg[16];
int gdcaddr;
unsigned char attrregs[32];
int attraddr,attrff=0;

unsigned char rotatevga[8][256];
unsigned char writemask,charset;
int writemode,readmode,readplane,chain4;
unsigned char colourcompare,colournocare;
unsigned char la,lb,lc,ld;

unsigned char *vram;

int egares;

unsigned char seqregs[16];
int seqaddr;

/*3C2 controls default mode on EGA. On VGA, it determines monitor type (mono or colour)*/
int egaswitchread,egaswitches=9; /*7=CGA mode (200 lines), 9=EGA mode (350 lines)*/
/*For VGA non-interlace colour, ID bits should be 1 1 0 or 6*/

PALETTE vgapal;
int dacread,dacwrite,dacpos=0;
int palchange=1;

void outega(unsigned short addr, unsigned char val)
{
        switch (addr)
        {
                case 0x3C0:
//                printf("Write 3C0 %i %02X %02X %02X  %02X %04X:%04X\n",attrff,val,attraddr,attrregs[0x10],cgastat,cs>>4,pc);
                if (!attrff) attraddr=val;
                else
                {
                        attrregs[attraddr&31]=val;
//                        if (attraddr<16) printf("ATTR %02X = %02X\n",attraddr,val);
                }
                attrff^=1;
                break;
                case 0x3C2: egaswitchread=val&0xC; at70hz=((val&0xC0)!=0xC0); break;
                case 0x3C4: seqaddr=val; break;
                case 0x3C5:
                seqregs[seqaddr&0xF]=val;
//                        printf("Sequencer write %02X %02X\n",val,seqaddr);
                switch (seqaddr&0xF)
                {
                        case 1: egares=val&8; break;
                        case 2: writemask=val&0xF; break;
                        case 3: charset=val&0xF; break;
                        case 4: chain4=val&8; break;
                }
                break;
                case 0x3C7: dacread=val; dacpos=0; break;
                case 0x3C8: dacwrite=val; dacpos=0; break;
                case 0x3C9:
                palchange=1;
                switch (dacpos)
                {
                        case 0: vgapal[dacwrite].r=val&63; dacpos++; break;
                        case 1: vgapal[dacwrite].g=val&63; dacpos++; break;
                        case 2: vgapal[dacwrite].b=val&63; dacpos=0; dacwrite=(dacwrite+1)&255; break;
                }
                break;
                case 0x3CE: gdcaddr=val; break;
                case 0x3CF:
                gdcreg[gdcaddr&15]=val;
                switch (gdcaddr&15)
                {
                        case 2: colourcompare=val; break;
                        case 4: readplane=val&3; break;
                        case 5: writemode=val&3; readmode=val&8; break;
                        case 7: colournocare=val; break;
                }
                break;
                case 0x3DB: incga=val&0x40; break;
        }
}

unsigned char inega(unsigned short addr)
{
        switch (addr)
        {
                case 0x3C2:
//                printf("Read egaswitch %02X\n",egaswitchread);
                if (VGA) return 0x10;
                switch (egaswitchread)
                {
                        case 0xC: return (egaswitches&1)?0x10:0;
                        case 0x8: return (egaswitches&2)?0x10:0;
                        case 0x4: return (egaswitches&4)?0x10:0;
                        case 0x0: return (egaswitches&8)?0x10:0;
                }
                break;
                case 0x3C5:
                return seqregs[seqaddr&0xF];
                case 0x3C9:
                palchange=1;
                switch (dacpos)
                {
                        case 0: dacpos++; return vgapal[dacread].r;
                        case 1: dacpos++; return vgapal[dacread].g;
                        case 2: dacpos=0; dacread=(dacread+1)&255; return vgapal[(dacread-1)&255].b;
                }
                break;
                case 0x3CF:
                return gdcreg[gdcaddr&0xF];
                case 0x3DA:
                attrff=0;
                hsync++;
                hsync&=31;
//                cgastat^=1;
//                printf("Read 3DA %02X\n",(cgastat&8)?(cgastat|1):(cgastat|(hsync)>>4));
                if (cgastat&8) return cgastat|1;
                return cgastat|(hsync>>4);
//                return cgastat;
        }
//        printf("Bad EGA read %04X %04X:%04X\n",addr,cs>>4,pc);
        return 0xFF;
}

void writeega(unsigned short addr, unsigned char val)
{
        int x,y;
        char s[2]={0,0};
        unsigned char vala,valb,valc,vald,wm=writemask;
        if (chain4)
        {
                writemask=1<<(addr&3);
                addr=addr>>2;
        }
//        printf("Write VRAM %04X %02X %04X:%04X\n",addr,val,cs>>4,pc);
        switch (writemode)
                {
                        case 1:
                        if (writemask&1) vram[addr]=la;
                        if (writemask&2) vram[addr|0x10000]=lb;
                        if (writemask&4) vram[addr|0x20000]=lc;
                        if (writemask&8) vram[addr|0x30000]=ld;
                        break;
                        case 0:
                        if (gdcreg[3]&7) val=rotatevga[gdcreg[3]&7][val];
                        if (gdcreg[8]==0xFF && !(gdcreg[3]&0x18) && !gdcreg[1])
                        {
                                if (writemask&1) vram[addr]=val;
                                if (writemask&2) vram[addr|0x10000]=val;
                                if (writemask&4) vram[addr|0x20000]=val;
                                if (writemask&8) vram[addr|0x30000]=val;
                        }
                        else
                        {
                                if (gdcreg[1]&1) vala=(gdcreg[0]&1)?0xFF:0;
                                else             vala=val;
                                if (gdcreg[1]&2) valb=(gdcreg[0]&2)?0xFF:0;
                                else             valb=val;
                                if (gdcreg[1]&4) valc=(gdcreg[0]&4)?0xFF:0;
                                else             valc=val;
                                if (gdcreg[1]&8) vald=(gdcreg[0]&8)?0xFF:0;
                                else             vald=val;
                                switch (gdcreg[3]&0x18)
                                {
                                        case 0: /*Set*/
                                        if (writemask&1) vram[addr]=(vala&gdcreg[8])|(la&~gdcreg[8]);
                                        if (writemask&2) vram[addr|0x10000]=(valb&gdcreg[8])|(lb&~gdcreg[8]);
                                        if (writemask&4) vram[addr|0x20000]=(valc&gdcreg[8])|(lc&~gdcreg[8]);
                                        if (writemask&8) vram[addr|0x30000]=(vald&gdcreg[8])|(ld&~gdcreg[8]);
                                        break;
                                        case 8: /*AND*/
                                        if (writemask&1) vram[addr]=(vala|~gdcreg[8])&la;
                                        if (writemask&2) vram[addr|0x10000]=(valb|~gdcreg[8])&lb;
                                        if (writemask&4) vram[addr|0x20000]=(valc|~gdcreg[8])&lc;
                                        if (writemask&8) vram[addr|0x30000]=(vald|~gdcreg[8])&ld;
                                        break;
                                        case 0x10: /*OR*/
                                        if (writemask&1) vram[addr]=(vala&gdcreg[8])|la;
                                        if (writemask&2) vram[addr|0x10000]=(valb&gdcreg[8])|lb;
                                        if (writemask&4) vram[addr|0x20000]=(valc&gdcreg[8])|lc;
                                        if (writemask&8) vram[addr|0x30000]=(vald&gdcreg[8])|ld;
                                        break;
                                        case 0x18: /*XOR*/
                                        if (writemask&1) vram[addr]=(vala&gdcreg[8])^la;
                                        if (writemask&2) vram[addr|0x10000]=(valb&gdcreg[8])^lb;
                                        if (writemask&4) vram[addr|0x20000]=(valc&gdcreg[8])^lc;
                                        if (writemask&8) vram[addr|0x30000]=(vald&gdcreg[8])^ld;
                                        break;
                                }
                        }
                        break;
                        case 2:
                        if (!(gdcreg[3]&0x18) && !gdcreg[1])
                        {
                                if (writemask&1) vram[addr]=(((val&1)?0xFF:0)&gdcreg[8])|(la&~gdcreg[8]);
                                if (writemask&2) vram[addr|0x10000]=(((val&2)?0xFF:0)&gdcreg[8])|(lb&~gdcreg[8]);
                                if (writemask&4) vram[addr|0x20000]=(((val&4)?0xFF:0)&gdcreg[8])|(lc&~gdcreg[8]);
                                if (writemask&8) vram[addr|0x30000]=(((val&8)?0xFF:0)&gdcreg[8])|(ld&~gdcreg[8]);
                        }
                        else
                        {
                                vala=((val&1)?0xFF:0);
                                valb=((val&2)?0xFF:0);
                                valc=((val&4)?0xFF:0);
                                vald=((val&8)?0xFF:0);
                                switch (gdcreg[3]&0x18)
                                {
                                        case 0: /*Set*/
                                        if (writemask&1) vram[addr]=(vala&gdcreg[8])|(la&~gdcreg[8]);
                                        if (writemask&2) vram[addr|0x10000]=(valb&gdcreg[8])|(lb&~gdcreg[8]);
                                        if (writemask&4) vram[addr|0x20000]=(valc&gdcreg[8])|(lc&~gdcreg[8]);
                                        if (writemask&8) vram[addr|0x30000]=(vald&gdcreg[8])|(ld&~gdcreg[8]);
                                        break;
                                        case 8: /*AND*/
                                        if (writemask&1) vram[addr]=(vala|~gdcreg[8])&la;
                                        if (writemask&2) vram[addr|0x10000]=(valb|~gdcreg[8])&lb;
                                        if (writemask&4) vram[addr|0x20000]=(valc|~gdcreg[8])&lc;
                                        if (writemask&8) vram[addr|0x30000]=(vald|~gdcreg[8])&ld;
                                        break;
                                        case 0x10: /*OR*/
                                        if (writemask&1) vram[addr]=(vala&gdcreg[8])|la;
                                        if (writemask&2) vram[addr|0x10000]=(valb&gdcreg[8])|lb;
                                        if (writemask&4) vram[addr|0x20000]=(valc&gdcreg[8])|lc;
                                        if (writemask&8) vram[addr|0x30000]=(vald&gdcreg[8])|ld;
                                        break;
                                        case 0x18: /*XOR*/
                                        if (writemask&1) vram[addr]=(vala&gdcreg[8])^la;
                                        if (writemask&2) vram[addr|0x10000]=(valb&gdcreg[8])^lb;
                                        if (writemask&4) vram[addr|0x20000]=(valc&gdcreg[8])^lc;
                                        if (writemask&8) vram[addr|0x30000]=(vald&gdcreg[8])^ld;
                                        break;
                                }
                        }
                        break;
                        case 3:
//                        printf("Writemode 3! %02X %02X %02X %04X:%04X\n",gdcreg[3]&0x18,val,gdcreg[0],cs>>4,pc);
                        if (gdcreg[3]&7) val=rotatevga[gdcreg[3]&7][val];
                        wm=gdcreg[8];
                        gdcreg[8]&=val;
//                        printf("Write mask %02X %02X %02X\n",gdcreg[8],val,wm);
//                        printf("Latches %02X %02X %02X %02X\n",la,lb,lc,ld);
/*                        if (!(gdcreg[3]&0x18) && !gdcreg[1])
                        {
                                if (writemask&1) vram[addr]=(((val&1)?0xFF:0)&gdcreg[8])|(la&~gdcreg[8]);
                                if (writemask&2) vram[addr|0x10000]=(((val&2)?0xFF:0)&gdcreg[8])|(lb&~gdcreg[8]);
                                if (writemask&4) vram[addr|0x20000]=(((val&4)?0xFF:0)&gdcreg[8])|(lc&~gdcreg[8]);
                                if (writemask&8) vram[addr|0x30000]=(((val&8)?0xFF:0)&gdcreg[8])|(ld&~gdcreg[8]);
                        }
                        else
                        {*/
                                vala=(gdcreg[0]&1)?0xFF:0;
                                valb=(gdcreg[0]&2)?0xFF:0;
                                valc=(gdcreg[0]&4)?0xFF:0;
                                vald=(gdcreg[0]&8)?0xFF:0;
                                switch (gdcreg[3]&0x18)
                                {
                                        case 0: /*Set*/
                                        if (writemask&1) vram[addr]=(vala&gdcreg[8])|(la&~gdcreg[8]);
                                        if (writemask&2) vram[addr|0x10000]=(valb&gdcreg[8])|(lb&~gdcreg[8]);
                                        if (writemask&4) vram[addr|0x20000]=(valc&gdcreg[8])|(lc&~gdcreg[8]);
                                        if (writemask&8) vram[addr|0x30000]=(vald&gdcreg[8])|(ld&~gdcreg[8]);
                                        break;
                                        case 8: /*AND*/
                                        if (writemask&1) vram[addr]=(vala|~gdcreg[8])&la;
                                        if (writemask&2) vram[addr|0x10000]=(valb|~gdcreg[8])&lb;
                                        if (writemask&4) vram[addr|0x20000]=(valc|~gdcreg[8])&lc;
                                        if (writemask&8) vram[addr|0x30000]=(vald|~gdcreg[8])&ld;
                                        break;
                                        case 0x10: /*OR*/
                                        if (writemask&1) vram[addr]=(vala&gdcreg[8])|la;
                                        if (writemask&2) vram[addr|0x10000]=(valb&gdcreg[8])|lb;
                                        if (writemask&4) vram[addr|0x20000]=(valc&gdcreg[8])|lc;
                                        if (writemask&8) vram[addr|0x30000]=(vald&gdcreg[8])|ld;
                                        break;
                                        case 0x18: /*XOR*/
                                        if (writemask&1) vram[addr]=(vala&gdcreg[8])^la;
                                        if (writemask&2) vram[addr|0x10000]=(valb&gdcreg[8])^lb;
                                        if (writemask&4) vram[addr|0x20000]=(valc&gdcreg[8])^lc;
                                        if (writemask&8) vram[addr|0x30000]=(vald&gdcreg[8])^ld;
                                        break;
                                }
//                        }
                        gdcreg[8]=wm;
                        break;
//                        dumpregs();
//                        exit(-1);
                }
}

unsigned char readega(unsigned short addr)
{
        unsigned char temp,temp2,temp3,temp4;
        unsigned long addr2;
        if (chain4)
        {
                addr2=addr;
                addr2=(addr2>>2)|((addr2&3)<<16);
                return vram[addr2];
        }
                la=vram[addr];
                lb=vram[addr|0x10000];
                lc=vram[addr|0x20000];
                ld=vram[addr|0x30000];
//                printf("Loaded latches from %04X - %02X %02X %02X %02X  %04X:%04X\n",addr,la,lb,lc,ld,cs>>4,pc);
                if (readmode)
                {
                        temp= (colournocare&1) ?0xFF:0;
                        temp&=la;
                        temp^=(colourcompare&1)?0xFF:0;
                        temp2= (colournocare&2) ?0xFF:0;
                        temp2&=lb;
                        temp2^=(colourcompare&2)?0xFF:0;
                        temp3= (colournocare&4) ?0xFF:0;
                        temp3&=lc;
                        temp3^=(colourcompare&4)?0xFF:0;
                        temp4= (colournocare&8) ?0xFF:0;
                        temp4&=ld;
                        temp4^=(colourcompare&8)?0xFF:0;
                        return ~(temp|temp2|temp3|temp4);
                }
                return vram[addr|(readplane<<16)];
}

unsigned char edatlookup[4][4];
void initega()
{
        int c,d,e;
        for (c=0;c<256;c++)
        {
                e=c;
                for (d=0;d<8;d++)
                {
                        rotatevga[d][c]=e;
                        e=(e>>1)|((e&1)?0x80:0);
                }
        }
        crtc[0xC]=crtc[0xD]=0;
        if (romset==ROM_PC1640) incga=1;
        else                    incga=0;
        for (c=0;c<4;c++)
        {
                for (d=0;d<4;d++)
                {
                        edatlookup[c][d]=0;
                        if (c&1) edatlookup[c][d]|=1;
                        if (d&1) edatlookup[c][d]|=2;
                        if (c&2) edatlookup[c][d]|=0x10;
                        if (d&2) edatlookup[c][d]|=0x20;
//                        printf("Edat %i,%i now %02X\n",c,d,edatlookup[c][d]);
                }
        }
}
unsigned short egabase,egaoffset;

void cacheega()
{
        egabase=(crtc[0xC]<<8)|crtc[0xD];
//        egaoffset=8-((attrregs[0x13])&7);
//        printf("Cache base!\n");
}
void cacheega2()
{
//        egabase=(crtc[0xC]<<8)|crtc[0xD];
        if (gdcreg[5]&0x40) egaoffset=8-(((attrregs[0x13])&7)>>1);
        else                egaoffset=8-((attrregs[0x13])&7);
//        printf("Cache offset!\n");
}

int olddisplines;
void drawscreenega(BITMAP *b, BITMAP *vbuf)
{
        int charseta=((charset>>2)*0x4000)+0x20000;
        int charsetb=((charset&3) *0x4000)+0x20000;
        int x,y,xx,yy;
        int addr=0x8000,addrback;
        unsigned char chr,attr;
        int charaddr;
        unsigned char dat,edat[4];
        int fg,bg;
        int offset;
        int vtotal=crtc[6];
        int coffset;
        int displines=crtc[0x12];
        int scans=(crtc[9]&31)+1;
        int split=crtc[0x18];
        int cursoraddr=((crtc[15]|(crtc[14]<<8))<<1)&0xFFE;
        int htotal=crtc[1]+1;
//        htotal=(htotal<=40)?1:0;
        if (crtc[7]&1)    vtotal|=0x100;
        if (crtc[7]&2)    displines|=0x100;
        if (crtc[7]&0x10) split|=0x100;
        if (incga)
        {
                drawscreencga(&vram[0x8000]);
                return;
        }
        displines++;
//        printf("Displines %i\n",displines);
        if (displines!=olddisplines)
        {
                olddisplines=displines;
                if (displines>240) updatewindowsize(640,displines);
                else               updatewindowsize(640,displines<<1);
        }
        if (VGA && palchange)
        {
                palchange=0;
                set_palette(vgapal);
        }
//        printf("Vtotal %i\n",vtotal);
        if (!(seqregs[4]&1))//attrregs[0x10]&1)
        {
                offset=egaoffset;
                addr=egabase;
//                printf("%i ",displines);
                displines/=scans;
                if (crtc[9]&0x80) displines/=2;
                if (!(crtc[0x17]&1)) displines*=2;
//                printf("EGABASE %04X %04X %02X %02X %i\n",addr,crtc[0x13],crtc[0x14],crtc[0x17],displines);
//                printf("Displines %i %i\n",displines,split);
                split/=scans;
                if (crtc[9]&0x80) split/=2;
//                if (crtc[0x17]&4) displines/=2;
                coffset=(displines>200)?128:64;
                if (VGA) coffset=0;
//                printf("DRAW! htotal %i colmode %02X egares %i %i vtotal %i R17 %02X\n",htotal,gdcreg[5]&0x60,egares,scans,displines,crtc[0x17]);
                for (y=0;y<displines;y++)
                {
                        if (y==(split+1) && (crtc[0x17]&1)) /*This triggers on line 128 of every single CGA game I've tried*/
                        {
                                addr=0;
                                if (VGA && attrregs[0x10]&0x20) offset=8; /*This, bizarrely, isn't supported by EGA!*/
                        }
                        addrback=addr;
                        if (!(crtc[0x17]&1) && (y&1)) addr|=0x2000;
//                        printf("Line %i addr %04X\n",y,addr);
                        switch (gdcreg[5]&0x60)
                        {
                                case 0x00: /*16 colour EGA*/
                                for (x=0;x<((egares)?328:648);x+=8)
                                {
                                        edat[0]=vram[addr];
                                        edat[1]=vram[addr|0x10000];
                                        edat[2]=vram[addr|0x20000];
                                        edat[3]=vram[addr|0x30000];
                                        dat=edatlookup[edat[0]&3][edat[1]&3]|(edatlookup[edat[2]&3][edat[3]&3]<<2);
                                        b->line[y&511][(x+7+offset)&1023]=attrregs[dat&0xF]+coffset;
                                        b->line[y&511][(x+6+offset)&1023]=attrregs[dat>>4]+coffset;
                                        dat=edatlookup[(edat[0]>>2)&3][(edat[1]>>2)&3]|(edatlookup[(edat[2]>>2)&3][(edat[3]>>2)&3]<<2);
                                        b->line[y&511][(x+5+offset)&1023]=attrregs[dat&0xF]+coffset;
                                        b->line[y&511][(x+4+offset)&1023]=attrregs[dat>>4]+coffset;
                                        dat=edatlookup[(edat[0]>>4)&3][(edat[1]>>4)&3]|(edatlookup[(edat[2]>>4)&3][(edat[3]>>4)&3]<<2);
                                        b->line[y&511][(x+3+offset)&1023]=attrregs[dat&0xF]+coffset;
                                        b->line[y&511][(x+2+offset)&1023]=attrregs[dat>>4]+coffset;
                                        dat=edatlookup[edat[0]>>6][edat[1]>>6]|(edatlookup[edat[2]>>6][edat[3]>>6]<<2);
                                        b->line[y&511][(x+1+offset)&1023]=attrregs[dat&0xF]+coffset;
                                        b->line[y&511][(x+offset)&1023]=attrregs[dat>>4]+coffset;
                                        addr++;
                                        addr&=0xFFFF;
                                }
                                break;
                                case 0x20: /*4 colour CGA*/
                                for (x=0;x<((egares)?324:644);x+=4)
                                {
                                        dat=vram[addr+0x8000];
                                        b->line[y&511][(x+8)&1023]=attrregs[dat>>6];
                                        b->line[y&511][(x+9)&1023]=attrregs[(dat>>4)&3];
                                        b->line[y&511][(x+10)&1023]=attrregs[(dat>>2)&3];
                                        b->line[y&511][(x+11)&1023]=attrregs[dat&3];
                                        addr++;
                                        addr&=0xFFFF;
                                }
                                break;
                                case 0x40: case 0x60: /*256 colour VGA*/
                                for (x=0;x<324;x+=4)
                                {
                                        b->line[y&511][(x+offset)&1023] =vram[addr];
                                        b->line[y&511][(x+offset+1)&1023] =vram[addr|0x10000];
                                        b->line[y&511][(x+offset+2)&1023]=vram[addr|0x20000];
                                        b->line[y&511][(x+offset+3)&1023]=vram[addr|0x30000];
                                        addr++;
                                        addr&=0xFFFF;
                                }
                                break;
                        }
                        if (!(crtc[0x17]&1) && !(y&1))
                           addr=addrback;
                        else
                        {
                                if (crtc[0x14]&0x40)      addr=addrback+(crtc[0x13]<<1);
                                else if (crtc[0x17]&0x40) addr=addrback+(crtc[0x13]<<1);
                                else                      addr=addrback+(crtc[0x13]<<2);
                                addr&=0xFFFF;
                        }
                }
                if (egares || gdcreg[5]&0x40)
                {
                        if (displines>240)
                        {
                                blit(b,vbuf,8,0,0,0,320,displines);
                                stretch_blit(vbuf,screen,0,0,320,displines,0,0,640,displines);
                        }
                        else
                        {
                                blit(b,vbuf,8,0,0,0,320,displines);
                                stretch_blit(vbuf,screen,0,0,320,displines,0,0,640,displines<<1);
                        }
                }
                else
                {
                        if (displines>240)
                        {
                                blit(b,vbuf,8,0,0,0,640,displines);
                                blit(vbuf,screen,0,0,0,0,640,displines);
                        }
                        else
                        {
                                blit(b,vbuf,8,0,0,0,640,displines);
                                stretch_blit(vbuf,screen,0,0,640,displines,0,0,640,displines<<1);
                        }
                }
        }
        else
        {
                if (VGA) coffset=0;
                else     coffset=64;
                if (crtc[9]&0x80) displines/=2;
                addr=0x8000+((egabase<<1)&0x7FFF);
//                printf("EGABASE %08X\n",egabase);
//                printf("Displines %i scans %i\n",displines,scans);
//                displines*=scans;
                for (y=0;y<displines;y+=scans)
                {
                        for (x=0;x<htotal;x++)
                        {
                                chr=vram[addr];
                                attr=vram[addr+1];
                                if (attr&8) charaddr=charsetb+(chr*32);
                                else        charaddr=charseta+(chr*32);
                                fg=attrregs[attr&15]+coffset;
                                bg=attrregs[attr>>4]+coffset;
                                for (yy=0;yy<scans;yy++)
                                {
                                        dat=vram[charaddr++];
                                        for (xx=0;xx<8;xx++)
                                        {
                                                b->line[(yy+y)&511][(xx+(x<<3))&1023]=(dat&0x80)?fg:bg;
                                                dat<<=1;
                                        }
                                }
                                if ((addr&0xFFE)==cursoraddr && frames&8 && !(crtc[0xA]&0x20))
                                {
                                        if (attr&8) charaddr=charsetb+(chr*32);
                                        else        charaddr=charseta+(chr*32);
                                        fg=attrregs[attr>>4]+coffset;
                                        bg=attrregs[attr&15]+coffset;
                                        charaddr+=(crtc[0xA]&31);
                                        for (yy=(crtc[0xA]&31);yy<(crtc[0xB]&31);yy++)
                                        {
                                                dat=vram[charaddr++];
                                                for (xx=0;xx<8;xx++)
                                                {
                                                        b->line[(y+yy)&511][((x*8)+xx)&1023]=(dat&0x80)?fg:bg;
                                                        dat<<=1;
                                                }
                                        }
                                }
                                addr+=2;
                        }
                }
                if (displines>240)
                {
                        if (htotal<=40)
                        {
                                blit(b,vbuf,0,0,0,0,320,displines);
                                stretch_blit(vbuf,screen,0,0,320,displines,0,0,640,displines);
                        }
                        else
                        {
                                blit(b,vbuf,0,0,0,0,640,displines);
                                blit(vbuf,screen,0,0,0,0,640,displines);
                        }
                }
                else
                {
                        if (htotal<=40)
                        {
                                blit(b,vbuf,0,0,0,0,320,displines);
                                stretch_blit(vbuf,screen,0,0,320,200,0,0,640,displines*2);
                        }
                        else
                        {
                                blit(b,vbuf,0,0,0,0,640,displines);
                                stretch_blit(vbuf,screen,0,0,640,200,0,0,640,displines*2);
                        }
                }
        }
        if (readflash) rectfill(screen,600,8,632,14,0xFFFFFFFF);
        readflash=0;
}
