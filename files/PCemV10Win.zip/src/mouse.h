extern void (*mouse_poll)(int x, int y, int b);

extern int mousepos;
extern int mousedelay;

