extern device_t oti067_device;
extern device_t oti067_acer386_device;
