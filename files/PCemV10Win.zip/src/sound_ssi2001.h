extern device_t ssi2001_device;
