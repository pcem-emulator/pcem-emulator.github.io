extern void um8669f_init();
