extern device_t gameport_device;
