void olivetti_m24_init();
