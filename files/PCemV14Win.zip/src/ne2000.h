extern device_t ne2000_device;
extern device_t rtl8029as_device;
