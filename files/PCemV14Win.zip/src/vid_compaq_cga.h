extern device_t compaq_cga_device;
