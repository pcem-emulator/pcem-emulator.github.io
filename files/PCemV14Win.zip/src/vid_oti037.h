extern device_t oti037_device;
