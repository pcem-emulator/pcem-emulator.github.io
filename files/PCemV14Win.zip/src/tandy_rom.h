extern device_t tandy_rom_device;
