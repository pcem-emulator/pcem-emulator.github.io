device_t tandy_eeprom_device;
int tandy_eeprom_read();
