#ifdef __cplusplus
extern "C" {
#endif
        void ddraw_fs_init(HWND h);
        void ddraw_fs_close();
#ifdef __cplusplus
}
#endif
