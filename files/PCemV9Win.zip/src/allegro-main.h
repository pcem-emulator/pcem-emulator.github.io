#define getr8 allegro_getr8
#define setr8 allegro_setr8
#define get_filename allegro_get_filename
#define append_filename allegro_append_filename
#define put_backslash allegro_put_backslash
#define GFX_VGA allegro_GFX_VGA

#include <allegro.h>

#undef GFX_VGA
#undef getr8
#undef setr8
#undef get_filename
#undef append_filename
#undef put_backslash
