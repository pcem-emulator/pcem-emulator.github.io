extern LPDIRECTINPUT lpdi;
