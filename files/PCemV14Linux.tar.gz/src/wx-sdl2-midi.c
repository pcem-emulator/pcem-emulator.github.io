#include <inttypes.h>
#include "plat-midi.h"

void midi_init()
{
}

void midi_close()
{
}

void midi_write(uint8_t val)
{
}

int midi_get_num_devs()
{
        return 0;
}

void midi_get_dev_name(int num, char *s)
{
}
