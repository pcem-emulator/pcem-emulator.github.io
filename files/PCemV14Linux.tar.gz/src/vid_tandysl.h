extern device_t tandysl_device;
