extern device_t ati28800_device;
extern device_t ati28800k_device;
