extern device_t et4000w32p_device;
