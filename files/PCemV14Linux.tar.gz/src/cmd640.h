void cmd640b_init(int card);
