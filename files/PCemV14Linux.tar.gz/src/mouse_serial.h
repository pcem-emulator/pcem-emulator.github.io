extern mouse_t mouse_serial_microsoft;
