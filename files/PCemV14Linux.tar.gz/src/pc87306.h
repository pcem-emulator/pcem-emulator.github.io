void pc87306_init(uint16_t addr);
