extern device_t cms_device;
