void piix_init(int card, int pci_a, int pci_b, int pci_c, int pci_d, void (*nb_reset)());
