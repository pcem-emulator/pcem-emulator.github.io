void voodoo_init();
