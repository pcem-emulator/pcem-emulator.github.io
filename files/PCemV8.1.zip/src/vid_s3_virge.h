extern device_t s3_virge_device;
