#include "ibm.h"
#include "video.h"


void dumpegaregs()
{
/*        int c;
        printf("CRTC :");
        for (c=0;c<0x20;c++) printf(" %02X",crtc[c]);
        printf("\n");
        printf(" EXT :");
        for (c=0;c<0x20;c++) printf(" %02X",crtc[c+32]);
        printf("\n");
        printf(" EXT2:");
        for (c=0;c<0x20;c++) printf(" %02X",crtc[c+64]);
        printf("\n");
        printf("SEQ  :");
        for (c=0;c<0x10;c++) printf(" %02X",seqregs[c]);
        printf("\n");
        printf(" EXT :");
        for (c=0;c<0x10;c++) printf(" %02X",seqregs[c + 0x10]);
        printf("\n");
        printf("ATTR :");
        for (c=0;c<0x20;c++) printf(" %02X",attrregs[c]);
        printf("\n");
        printf("GDC  :");
        for (c=0;c<0x10;c++) printf(" %02X",gdcreg[c]);
        printf("\n");
//        printf("OLD CTRL2 = %02X  NEW CTRL2 = %02X  DAC = %02X  3C2 = %02X\n",tridentoldctrl2,tridentnewctrl2,tridentdac,ega3c2);
        printf("BPP = %02X\n",bpp);*/
}

