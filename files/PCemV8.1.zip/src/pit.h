extern double PITCONST;
void pit_init();
void pit_reset();
void pit_set_gate(int channel, int gate);
