device_t s3_bahamas64_device;
device_t s3_9fx_device;
