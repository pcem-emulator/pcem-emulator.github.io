FILE *romfopen(char *fn, char *mode);
int rom_present(char *fn);
