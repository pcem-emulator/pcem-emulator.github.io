void midi_init();
void midi_close();
void midi_out(uint8_t val);
