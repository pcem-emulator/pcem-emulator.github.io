int BPS_TO_TIMER(int a)
{
        return a;
}

void install_int_ex(void (*rout)(), int a)
{
}
