extern device_t vga_device;
