void speaker_init();
