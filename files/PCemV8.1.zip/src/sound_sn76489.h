extern device_t sn76489_device;
