extern device_t oti067_device;
