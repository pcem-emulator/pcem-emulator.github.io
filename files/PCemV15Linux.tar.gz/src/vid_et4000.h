extern device_t et4000_device;
extern device_t et4000k_device;
