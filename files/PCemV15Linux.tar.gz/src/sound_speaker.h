void speaker_init();

extern int speaker_mute;

extern int speaker_gated;
extern int speaker_enable, was_speaker_enable;

void speaker_update();
