extern device_t gd5429_device;
extern device_t gd5430_device;
extern device_t gd5430_pb570_device;
extern device_t gd5434_device;
extern device_t gd5434_pb520r_device;
