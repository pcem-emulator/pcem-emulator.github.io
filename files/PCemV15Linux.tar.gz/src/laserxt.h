void laserxt_init();
