extern device_t sigma_device;

