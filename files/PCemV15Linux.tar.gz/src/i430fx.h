void i430fx_init();
void i430fx_reset();
