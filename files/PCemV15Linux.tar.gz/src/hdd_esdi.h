extern device_t hdd_esdi_device;
