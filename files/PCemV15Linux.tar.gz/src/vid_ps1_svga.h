extern device_t ps1_m2121_svga_device;
