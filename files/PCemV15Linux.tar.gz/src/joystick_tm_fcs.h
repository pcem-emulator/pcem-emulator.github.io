extern joystick_if_t joystick_tm_fcs;
