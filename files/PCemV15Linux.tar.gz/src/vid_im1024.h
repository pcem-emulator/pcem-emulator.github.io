extern device_t im1024_device;
