void i430lx_init();
