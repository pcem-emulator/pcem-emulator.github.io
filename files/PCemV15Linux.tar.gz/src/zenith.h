device_t zenith_scratchpad_device;
