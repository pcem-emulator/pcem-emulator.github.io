device_t s3_bahamas64_device;
device_t s3_9fx_device;
device_t s3_phoenix_trio32_device;
device_t s3_phoenix_trio64_device;
