void nvr_init();

extern int enable_sync;

extern int nvr_dosave;

void time_get(char *nvrram);

