extern device_t vga_device;
extern device_t ps1vga_device;
