void opti495_init();
