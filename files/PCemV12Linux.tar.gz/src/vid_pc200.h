extern device_t pc200_device;
