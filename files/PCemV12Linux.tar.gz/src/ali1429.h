void ali1429_init();
