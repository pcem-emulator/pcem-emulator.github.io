void nvr_init();

extern int nvr_dosave;

void time_get(char *nvrram);

