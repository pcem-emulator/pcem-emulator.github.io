extern device_t tandy_device;
