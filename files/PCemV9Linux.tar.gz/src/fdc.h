void fdc_init();
void fdc_add();
void fdc_add_pcjr();
void fdc_remove();
void fdc_reset();
void fdc_poll();
void fdc_abort();
