void keyboard_pcjr_init();
void keyboard_pcjr_reset();
void keyboard_pcjr_poll();
