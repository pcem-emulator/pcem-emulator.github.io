#include <stdio.h>
#include "ibm.h"

FILE *adpcmlog,*adpcmlog2;

/*These tables were 'borrowed' from DOSBox*/
	signed char scaleMap4[64] = {
		0,  1,  2,  3,  4,  5,  6,  7,  0,  -1,  -2,  -3,  -4,  -5,  -6,  -7,
		1,  3,  5,  7,  9, 11, 13, 15, -1,  -3,  -5,  -7,  -9, -11, -13, -15,
		2,  6, 10, 14, 18, 22, 26, 30, -2,  -6, -10, -14, -18, -22, -26, -30,
		4, 12, 20, 28, 36, 44, 52, 60, -4, -12, -20, -28, -36, -44, -52, -60
	};
	unsigned char adjustMap4[64] = {
		  0, 0, 0, 0, 0, 16, 16, 16,
		  0, 0, 0, 0, 0, 16, 16, 16,
		240, 0, 0, 0, 0, 16, 16, 16,
		240, 0, 0, 0, 0, 16, 16, 16,
		240, 0, 0, 0, 0, 16, 16, 16,
		240, 0, 0, 0, 0, 16, 16, 16,
		240, 0, 0, 0, 0,  0,  0,  0,
		240, 0, 0, 0, 0,  0,  0,  0
	};

	signed char scaleMap26[40] = {
		0,  1,  2,  3,  0,  -1,  -2,  -3,
		1,  3,  5,  7, -1,  -3,  -5,  -7,
		2,  6, 10, 14, -2,  -6, -10, -14,
		4, 12, 20, 28, -4, -12, -20, -28,
		5, 15, 25, 35, -5, -15, -25, -35
	};
	unsigned char adjustMap26[40] = {
		  0, 0, 0, 8,   0, 0, 0, 8,
		248, 0, 0, 8, 248, 0, 0, 8,
		248, 0, 0, 8, 248, 0, 0, 8,
		248, 0, 0, 8, 248, 0, 0, 8,
		248, 0, 0, 0, 248, 0, 0, 0
	};

	signed char scaleMap2[24] = {
		0,  1,  0,  -1, 1,  3,  -1,  -3,
		2,  6, -2,  -6, 4, 12,  -4, -12,
		8, 24, -8, -24, 6, 48, -16, -48
	};
	unsigned char adjustMap2[24] = {
		  0, 4,   0, 4,
		252, 4, 252, 4, 252, 4, 252, 4,
		252, 4, 252, 4, 252, 4, 252, 4,
		252, 0, 252, 0
	};

#define ADPCM_2  1
#define ADPCM_4  2
#define ADPCM_26 3

int sbtype=0;

int writebusy=0; /*Needed for Amnesia*/

unsigned char sbdatl=0x80,sbdatr=0x80;

unsigned char sbdat=0x80;
unsigned char sbref;
int sbdacmode,sbdacpos,sbdat2;
signed char sbstep;
int sbleftright=0;
int sbinput=0;
int sbreadstat,sbwritestat;
int sbreset;
unsigned char sbreaddat;
unsigned char sbcommand,sbdata;
int sbcommandnext=1;
unsigned char sbtest;
int sbtime;
int sblength;
int sbcommandstat;
int sbhalted;
int adpcmstat=0;
int sbautolen;
int sbautoinit=0;
unsigned char sbcurcommand,sbdmacommand;
unsigned char sbe2;
int sbe2count;
float SBCONST;
int sbstereo=0;

void setsbclock(float clock)
{
        SBCONST=clock/1000000.0f;
        printf("SBCONST %f %f\n",SBCONST,clock);
        sblatch=SBCONST*(256-sbtime);
}

void setsbtype(int type)
{
        sbtype=type;
        sbstereo=0;
}

int sbe2dat[4][9] = {
  {  0x01, -0x02, -0x04,  0x08, -0x10,  0x20,  0x40, -0x80, -106 },
  { -0x01,  0x02, -0x04,  0x08,  0x10, -0x20,  0x40, -0x80,  165 },
  { -0x01,  0x02,  0x04, -0x08,  0x10, -0x20, -0x40,  0x80, -151 },
  {  0x01, -0x02,  0x04, -0x08, -0x10,  0x20, -0x40,  0x80,   90 }
};

void initsb()
{
        sbreset=0;
        sbenable=sblatch=sbcount=0;
        sbhalted=0;
        sbe2=0xaa;
        sbe2count=0;
        sbdmacommand=0;
        sbstereo=0;
        sbpmixer.vocl=sbpmixer.vocr=15;
        sbpmixer.masl=sbpmixer.masr=15;
        sbpmixer.midl=sbpmixer.midr=15;
        sbpmixer.voc=255;
        sbpmixer.mas=255;
        sbpmixer.mid=255;
}

void outmidi(unsigned char v)
{
        printf("Write MIDI %02X\n",v);
}

unsigned char mixerindex;

void writesb(unsigned short a, unsigned char v)
{
        int temp;
        int c;
//        printf("Write soundblaster %04X %02X %04X:%04X %02X\n",a,v,cs>>4,pc,sbcommand);
        switch (a&0xF)
        {
                case 0: case 1: case 2: case 3: writeadlib(a,v); return; /*OPL*/
                case 4: mixerindex=v; return;
                case 5:
                switch (mixerindex)
                {
                        case 0x4: sbpmixer.vocl=v>>4; sbpmixer.vocr=v&0xF; sbpmixer.voc=v; return;
                        case 0xE: sbstereo=(v&2); return;
                        case 0x22: sbpmixer.masl=v>>4; sbpmixer.masr=v&0xF; sbpmixer.mas=v; return;
                        case 0x26: sbpmixer.midl=v>>4; sbpmixer.midr=v&0xF; sbpmixer.mid=v; return;
                }
                return;
                case 6: /*Reset*/
                if (!(v&1) && (sbreset&1))
                {
                        sbreaddat=0xAA;
                        sbreadstat=0x80;
                        sbe2=0xaa;
                        sbe2count=0;
                        sbenable=0;
                        sbcommand=0;
                        picintc(0x80);
//                        printf("Sound blaster reset\n");
                }
                sbreset=v;
                return;
                case 8: case 9: writeadlib(a,v); return; /*OPL*/
                case 0xC: /*Command/data write*/
                if (sbcommandnext)
                {
                        sbdacmode=0;
//                        printf("New command %02X\n",v);
                        sbcommand=v;
                        switch (v)
                        {
                                case 0x10: /*Direct DAC*/
                                sbcommandnext=0;
                                break;
                                case 0x20: /*8-bit ADC direct*/
                                sbreaddat=0;
                                sbreadstat=0x80;
                                sbcommand=0;
                                break;
                                case 0x14: /*8-bit DMA transfer*/
                                sblength=0;
                                sbcommandnext=0;
                                sbcommandstat=0;
                                sbcurcommand=sbcommand;
                                sbinput=0;
                                sbleftright=0;
                                break;
                                case 0x1C: /*8-bit Auto-init DMA*/
                                case 0x90: /*8-bit Auto-init high-speed DMA transfer*/
                                case 0x91: /*8-bit high-speed DMA transfer*/
                                sbenable=1;
                                sbautoinit=(v==0x91)?0:1;
                                sblength=sbautolen;
                                sbdmacommand=0x1C;
                                sbinput=0;
                                sbleftright=0;
//                                printf("Started DMA\n");
                                break;
                                case 0xDA:
                                sbenable=0;
                                sblength=sbautolen;
                                break;
                                case 0x24: /*8-bit DMA ADC transfer*/
                                sblength=0;
                                sbcommandnext=0;
                                sbcommandstat=0;
                                sbcurcommand=sbcommand;
//                                printf("ADC transfer %02X %02X\n",sbcommand,sbcurcommand);
//                                sbinput=0;
                                break;
                                case 0x40: /*Set time constant*/
                                sbcommandnext=0;
                                break;
                                case 0x17: /*2-bit ADPCM transfer with reference*/
                                case 0x75: /*4-bit ADPCM transfer with reference*/
                                case 0x77: /*2.6-bit ADPCM transfer with reference*/
                                sbref=readdma1();
                                sbstep=0;
                                case 0x16: /*2-bit ADPCM transfer*/
                                case 0x74: /*4-bit ADPCM transfer*/
                                case 0x76: /*2.6-bit ADPCM transfer*/
                                if ((v&~1)==0x16) sbdacmode=ADPCM_2;
                                if ((v&~1)==0x74) sbdacmode=ADPCM_4;
                                if ((v&~1)==0x76) sbdacmode=ADPCM_26;
//                                pclog("SBADPCM %i\n",sbdacmode);
                                sbdacpos=0;
                                sbdat2=readdma1();
                                case 0x80: /*Silence DAC*/
                                sblength=0;
                                sbcommandnext=0;
                                sbcommandstat=0;
                                adpcmstat=0;
                                sbcurcommand=sbcommand;
                                sbinput=0;
                                sbautoinit=0;
                                sbleftright=0;
                                break;
                                case 0x48: /*Set DMA length*/
                                sbcommandnext=0;
                                sbcommandstat=0;
                                sbcurcommand=sbcommand;
//                                printf("Set DMA length! %04X:%04X\n",CS,pc);
                                break;
                                case 0xD0: /*Halt DMA*/
//                                printf("Halt DMA\n");
                                sbhalted=1;
                                sbenable=0;
                                break;
                                case 0xD1: /*Enable speaker*/
                                case 0xD3: /*Disable speaker*/
                                sbdat=sbdatl=sbdatr=0x80;
                                break;
                                case 0xD4: /*Continue DMA*/
//                                printf("Continue DMA\n");
                                if (sbhalted)
                                {
                                        sbhalted=0;
                                        sbenable=1;
                                }
                                break;
                                case 0xE0: /*Identify*/
                                sbcommandnext=0;
                                break;
                                case 0xE1: /*DSP version*/
                                sbreaddat=sbtype-1;
                                sbreadstat=0x80;
                                break;
                                case 0xE2: /*Identify DMA*/
                                sbcommandnext=0;
                                break;
                                case 0xE4: /*Write test byte*/
                                sbcommandnext=0;
                                break;
                                case 0xE8: /*Read test byte*/
                                sbreaddat=sbtest;
                                sbreadstat=0x80;
                                break;
                                case 0xF2: /*Interrupt request*/
                                picint(0x80);
//                                printf("Interrupt request\n");
                                break;
                                case 0xFF: case 0xFA: case 0x00: case 7: case 0xE7:
                                        break;
                                default:
                                printf("Bad soundblaster command %02X\n",v);
                                dumpregs();
                                exit(-1);
                        }
                }
                else
                {
                        sbdata=v;
                        sbcommandnext=1;
                        switch (sbcommand)
                        {
                                case 0x00: break;
                                case 0x10:
                                sbdat=v;
                                break;
                                case 0x14:
                                case 0x91:
                                case 0x16:
                                case 0x17:
                                case 0x74:
                                case 0x75:
                                case 0x76:
                                case 0x77:
                                case 0x80:
                                        case 0x24:
//                                                printf("SB command stat %i\n",sbcommandstat);
                                if (sbcommandstat)
                                {
                                        sblength=((sblength&0xFF)|(v<<8));
//                                        printf("SB start - %02X %02X length %04X addr\n",sbcommand,sbcurcommand,sblength);
                                        sbenable=1;
                                        if (sbcurcommand==0x24) sbinput=1;
                                        sbdmacommand=sbcurcommand;
                                }
                                else
                                {
                                        sblength=(sblength&0xFF00)|v;
                                        sbcommandnext=0;
                                }
                                sbcommandstat++;
                                break;
                                case 0x48: /*Set DMA length*/
//                                printf("Set DMA length %02X %i\n",v,sbcommandstat);
                                if (sbcommandstat)
                                {
                                        sbautolen=((sbautolen&0xFF)|(v<<8));
                                }
                                else
                                {
                                        sbautolen=(sbautolen&0xFF00)|v;
                                        sbcommandnext=0;
                                }
//                                printf("Now %04X\n",sbautolen);
                                sbcommandstat++;
                                break;
                                case 0x40: /*Set time constant*/
                                sbtime=sbdata;
                                temp=256-sbdata;
                                temp=1000000/temp;
//                                printf("Sample rate - %ihz\n",temp);
                                sblatch=SBCONST*(256-sbdata);
//                                printf("SB latch %i cycles\n",sblatch);
                                break;
                                case 0xE0: /*Identify*/
                                sbreaddat=~sbdata;
                                sbreadstat=0x80;
                                break;
                                case 0xE2:
                                for (c=0;c<8;c++)
                                    if (v&(1<<c)) sbe2+=sbe2dat[sbe2count&3][c];
                                sbe2+=sbe2dat[sbe2count&3][8];
                                sbe2count++;
//                                printf("WriteDMA1 %02X\n",sbe2);
                                writedma1(sbe2);
                                break;
                                case 0xE4:
                                sbtest=sbdata;
                                break;
                                default:
                                printf("Bad soundblaster command2 %02X %02X\n",sbcommand,v);
                                dumpregs();
                                exit(-1);
                        }
                }
                break;
        }
}

unsigned char readsb(unsigned short a)
{
        unsigned char temp;
//        if (a==0x224) output=1;
//        if (a!=0x22A) printf("Read soundblaster %04X %04X:%04X\n",a,cs>>4,pc);
        switch (a&0xF)
        {
                case 5:
                if (sbtype!=SBPRO) return 0;
                switch (mixerindex)
                {
                        case 0x4: return sbpmixer.voc;
                        case 0xE: return (sbstereo)?2:0;
                        case 0x22: return sbpmixer.mas;
                        case 0x26: return sbpmixer.mid;
                }
                return 0;
                case 8: case 9: return readadlib(a); /*OPL*/
                case 0xA: /*Read data*/
                sbreadstat=0;
                temp=sbreaddat;
                switch (sbcommand)
                {
                        case 0xE1: /*DSP version*/
                        sbcommand=0;
                        sbreaddat=(sbtype!=SB2)?0:1;//5;
                        sbreadstat=0x80;
                        break;
                }
                return temp;
                case 0xC: /*Write data ready*/
                writebusy++;
                if (writebusy&8) return 0xFF;
                return 0x7F;
                case 0xE: /*Read data ready*/
                return sbreadstat;
        }
        return 0;
}

//FILE *sbfile;
int sbshift4[8]={-2,-1,0,0,1,1,1,1};
void pollsb()
{
        unsigned char temp;
        int tempi,ref;
//        printf("Poll SB %i %02X %i\n",sbinput,sbdmacommand,sbdacmode);
        if (sbinput)
        {
                writedma1(0);
        }
        else
        {
//        if (!sbfile) sbfile=fopen("sound.pcm","wb");
                if (sbdmacommand==0x14 || sbdmacommand==0x1C || sbdmacommand==0x91)
                   sbdat=readdma1();
                else switch (sbdacmode)
                {
                        case ADPCM_4:
                        if (sbdacpos) tempi=(sbdat2&0xF)+sbstep;
                        else          tempi=(sbdat2>>4)+sbstep;
                        if (tempi<0) tempi=0;
                        if (tempi>63) tempi=63;

                	ref = sbref + scaleMap4[tempi];
                	if (ref > 0xff) sbref = 0xff;
                	else if (ref < 0x00) sbref = 0x00;
                	else sbref = ref;
//                	if (!adpcmlog) adpcmlog=fopen("adpcm.pcm","wb");
//                	putc(ref,adpcmlog);
//                	putc((ref>>8),adpcmlog);
                	sbstep = (sbstep + adjustMap4[tempi]) & 0xff;
                	
                        sbdat=sbref;
                        
//                        pclog("SBDAT %02X SBREF %02X REF %02X\n",sbdat,sbref,ref);

                        sbdacpos++;
                        if (sbdacpos>=2)
                        {
                                sbdacpos=0;
                                sbdat2=readdma1();
                        }
                        else sblength++;
                        break;
                        case ADPCM_26:
                        if (!sbdacpos)        tempi=(sbdat2>>5)+sbstep;
                        else if (sbdacpos==1) tempi=((sbdat2>>2)&7)+sbstep;
                        else                  tempi=((sbdat2<<1)&7)+sbstep;
//                        tempi=((sbdat2>>((3-sbdacpos)*2))&3)+sbstep;
                        if (tempi<0) tempi=0;
                        if (tempi>39) tempi=39;

                	ref = sbref + scaleMap26[tempi];
                	if (ref > 0xff) sbref = 0xff;
                	else if (ref < 0x00) sbref = 0x00;
                	else sbref = ref;
                	sbstep = (sbstep + adjustMap26[tempi]) & 0xff;

                        sbdat=sbref;

                        sbdacpos++;
                        if (sbdacpos>=3)
                        {
                                sbdacpos=0;
                                sbdat2=readdma1();
                        }
                        else sblength++;
                        break;
                        case ADPCM_2:
                        tempi=((sbdat2>>((3-sbdacpos)*2))&3)+sbstep;
                        if (tempi<0) tempi=0;
                        if (tempi>23) tempi=23;

                	ref = sbref + scaleMap2[tempi];
                	if (ref > 0xff) sbref = 0xff;
                	else if (ref < 0x00) sbref = 0x00;
                	else sbref = ref;
                	sbstep = (sbstep + adjustMap2[tempi]) & 0xff;

                        sbdat=sbref;

                        sbdacpos++;
                        if (sbdacpos>=4)
                        {
                                sbdacpos=0;
                                sbdat2=readdma1();
                        }
                        else sblength++;
                        break;
                        default:
                        sbdat=0;
                        break;
                }
        }
        if (sbstereo)
        {
                if (sbleftright) sbdatr=sbdat;
                else             sbdatl=sbdat;
                sbleftright^=1;
        }
        else
           sbdatl=sbdatr=sbdat;
//        putc(sbdat,sbfile);
//        printf("SB %02X %i\n",sbdat,sblength);
        sblength--;
        if (sblength<0)
        {
//                printf("SB over - IRQ! %i %04X\n",sblength,dma.ac[1]+(dma.page[1]<<16));
                if (sbautoinit)
                {
                        sblength=sbautolen;
                        picint(0x80);
//                        printf("Soundblaster over - %i  %i %02X\n",sblength,sbinput,sbdmacommand);
                }
                else
                {
                        sbenable=0;
//                        printf("End of transfer\n");
                        picint(0x80);
                }
        }
}

signed short sbbuffer[2][SOUNDBUFLEN+20];
int sbbufferpos=0;
int _sampcnt=0;
void getsbsamp()
{
        int vocl=sbpmixer.vocl*sbpmixer.masl;
        int vocr=sbpmixer.vocr*sbpmixer.masr;
        if (sbbufferpos>=(SOUNDBUFLEN+20)) return;
/*        _sampcnt++;
        if (_sampcnt==48000)
        {
                _sampcnt=0;
                printf("Vols : %i,%i %i,%i %i,%i %i\n",vocl,vocr,sbpmixer.vocl,sbpmixer.vocr,sbpmixer.masl,sbpmixer.masr);
        }*/
        if (sbtype==SBPRO)
        {
                if (sbstereo)
                {
                        sbbuffer[0][sbbufferpos]=((((int)(unsigned int)sbdatl)-0x80)*0x40*225)/vocl;
                        sbbuffer[1][sbbufferpos++]=((((int)(unsigned int)sbdatr)-0x80)*0x40*225)/vocr;
                }
                else
                {
                        sbbuffer[0][sbbufferpos]=((((int)(unsigned int)sbdat)-0x80)*0x40*225)/vocl;
                        sbbuffer[1][sbbufferpos++]=((((int)(unsigned int)sbdat)-0x80)*0x40*225)/vocr;
                }
        }
        else
        {
                sbbuffer[0][sbbufferpos]=(((int)(unsigned int)sbdat)-0x80)*0x40*3;
                sbbuffer[1][sbbufferpos++]=(((int)(unsigned int)sbdat)-0x80)*0x40*3;
        }
}

void addsb(signed short *p)
{
        int c;
        if (sbbufferpos>SOUNDBUFLEN) sbbufferpos=SOUNDBUFLEN;
//        printf("Addsb - %i\n",sbbufferpos);
        for (c=0;c<sbbufferpos;c++)
        {
                p[c<<1]+=(sbbuffer[0][c]);
                p[(c<<1)+1]+=(sbbuffer[1][c]);
        }
        for (;c<SOUNDBUFLEN;c++)
        {
                p[c<<1]+=(sbbuffer[0][sbbufferpos-1]);
                p[(c<<1)+1]+=(sbbuffer[1][sbbufferpos-1]);
        }
        sbbufferpos=0;
}
