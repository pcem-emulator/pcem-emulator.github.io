#include <stdio.h>
#include <stdint.h>
#include "ibm.h"
#include "x86.h"

int is486;
int cgate32;
unsigned char opcode2;
int incga;
int enters=0;
int ec;

FILE *ttyoutf;
void ttyout(unsigned char c)
{
        if (!ttyoutf) ttyoutf=fopen("ttyout.txt","wb");
        putc(c,ttyoutf);
}

unsigned long ten3688;
int oldv86=0,oldpmode=0,itson=0;
unsigned char old22;
#undef readmemb
#undef writememb

#define readmemb(s,a) ((readlookup2[((s)+(a))>>12]==0xFFFFFFFF || (s)==0xFFFFFFFF)?readmemb386l(s,a):ram[readlookup2[((s)+(a))>>12]+(((s)+(a))&0xFFF)])
#define writememb(s,a,v) if (writelookup2[((s)+(a))>>12]==0xFFFFFFFF || (s)==0xFFFFFFFF) writememb386l(s,a,v); else ram[writelookup2[((s)+(a))>>12]+(((s)+(a))&0xFFF)]=v

//#define readmemb(s,a)    readmemb((s)+(a))
//#define writememb(s,a,v) writememb((s)+(a),v)
unsigned long mmucache[0x100000];

#define mmutranslate(addr,rw) mmutranslatereal(addr,rw)
//((mmucache[addr>>12]!=0xFFFFFFFF)?(mmucache[addr>>12]+(addr&0xFFF)):mmutranslatereal(addr,rw))
unsigned char romext[32768];
unsigned char *ram,*rom,*vram,*vrom;
unsigned short biosmask;

unsigned short getwordx()
{
        pc+=2;
        return readmemw(cs,(pc-2));
}

#define getword() getwordx()

unsigned char readmemb386l(unsigned long seg, unsigned long addr)
{
        unsigned long addr2=addr+seg;
        if (seg==-1)
        {
                printf("NULL segment!\n");
                x86gpf(NULL,0);
                return -1;
                printf("NULL segment!\n");
                dumpregs();
                exit(-1);
        }
        if (cr0>>31)
        {
                addr2=mmutranslate(addr2,0);
                if (addr2==0xFFFFFFFF) return 0xFF;
        }
//        if ((addr2&0xFF0000)!=0xF0000) printf("Checking - %08X %08X %i\n",addr2&rammask,(addr2&rammask)>>16,isram[(addr2&rammask)>>16]);
        if (isram[(addr2&rammask)>>16])
        {
                addreadlookup(seg+addr,addr2&rammask);
                return ram[addr2&rammask];
        }
        addr=addr2&rammask;
        switch ((addr>>16)&0xFF)
        {
                case 0: case 1: case 2: case 3: case 4:
                case 5: case 6: case 7: case 8: case 9:
                return ram[addr];
                case 10: if (EGA) return readega(addr);
                if (slowega) cycles-=egacycles;
                return 0xFF;
                case 11:
                if (slowega && EGA) cycles-=egacycles;
                if (addr&0x8000 && MDA)
                {
                        if (!HERCULES) return 0xFF;
                        if (!(hercctrl&2)) return 0xFF;
                }
                if (AMSTRAD && incga) return readvram(addr);
                if (AMSTRAD || EGA) return readega(addr&0x7FFF);
                if (TANDY) return readtandyvram(addr);
                return vram[addr&0xFFFF];
                case 12: if (addr&0x8000)
                {
//                        printf("Read extrom %04X:%04X %04X %02X %02X\n",CS,pc,addr,romext[addr&0x7FFF],AL);
//output=2;
                        return romext[addr&0x7FFF];
                }
//                return 0x63;
                return vrom[addr&0x7FFF];
                case 14: if (shadowbios) { /*printf("Read shadow RAM %08X %02X\n",addr,ram[addr]);*/ return ram[addr]; }
                case 15: if (!shadowbios)
                {
                        if (AMIBIOS && (addr&0xFFFF)==0x8281)
                        {
//                                printf("Read magic addr %04X(%06X):%04X\n",CS,cs,pc);
//                                if (pc==0x547D) output=3;
                                return 0x40;
                        }
                        return rom[addr&biosmask];
                }
//                printf("Read shadow RAM %08X %02X\n",addr,ram[addr]);
                return ram[addr];
                case 0x10: case 0x11: case 0x12: case 0x13:
                case 0x14: case 0x15: case 0x16: case 0x17:
                case 0x18: case 0x19: case 0x1A: case 0x1B:
                case 0x1C: case 0x1D: case 0x1E: case 0x1F:
                case 0x20: case 0x21: case 0x22: case 0x23:
                case 0x24: case 0x25: case 0x26: case 0x27:
                case 0x28: case 0x29: case 0x2A: case 0x2B:
                case 0x2C: case 0x2D: case 0x2E: case 0x2F:
                case 0x30: case 0x31: case 0x32: case 0x33:
                case 0x34: case 0x35: case 0x36: case 0x37:
                case 0x38: case 0x39: case 0x3A: case 0x3B:
                case 0x3C: case 0x3D: case 0x3E: case 0x3F:
                case 0x40: case 0x41: case 0x42: case 0x43:
                case 0x44: case 0x45: case 0x46: case 0x47:
                case 0x48: case 0x49: case 0x4A: case 0x4B:
                case 0x4C: case 0x4D: case 0x4E: case 0x4F:
                case 0x50: case 0x51: case 0x52: case 0x53:
                case 0x54: case 0x55: case 0x56: case 0x57:
                case 0x58: case 0x59: case 0x5A: case 0x5B:
                case 0x5C: case 0x5D: case 0x5E: case 0x5F:
                case 0x60: case 0x61: case 0x62: case 0x63:
                case 0x64: case 0x65: case 0x66: case 0x67:
                case 0x68: case 0x69: case 0x6A: case 0x6B:
                case 0x6C: case 0x6D: case 0x6E: case 0x6F:
                case 0x70: case 0x71: case 0x72: case 0x73:
                case 0x74: case 0x75: case 0x76: case 0x77:
                case 0x78: case 0x79: case 0x7A: case 0x7B:
                case 0x7C: case 0x7D: case 0x7E: case 0x7F:
//                if (cs!=0xF0000) printf("Read high mem %06X %04X:%04X\n",addr,CS,pc);
                return ram[addr];
                case 0xFF: return rom[addr&biosmask];
        }
        if (addr>0x800000)
        {
                printf("Read from bad address %08X!\n",addr);
                dumpregs();
                exit(-1);
        }
        return 0xFF;
}

void writememb386l(unsigned long seg, unsigned long addr, unsigned char val)
{
        unsigned long addr2=addr+seg;
//        if (addr==0x126030+0x0000DF34) printf("Writememb386l 126030:0000DF34 %02X %04X:%08X\n",val,CS,pc);
//        if (addr==0xC01D59E8) printf("Write C01D59E8 %08X %04X:%08X\n",val,CS,pc);
        if (seg==-1)
        {
                printf("NULL segment!\n");
                dumpregs();
                exit(-1);
        }
//        printf("Writemem %08X %02X\n",addr,val);
//        if (addr==(0xA4BE)+0x100) printf("Write A4BE %02X %04X(%06X):%04X\n",val,CS,cs,pc);
//        if (addr==0x2A60+0x8C2 || addr==0x2A60+0x8C3) printf("Writememb %05X %02X %04X(%06X):%04X\n",addr,val,cs,CS,pc);
//        if (addr==0x12DC58) printf("Writememb %05X %02X %04X(%06X):%04X\n",addr,val,cs,CS,pc);
        if (cr0>>31)
        {
                addr2=mmutranslate(addr2,1);
                if (addr2==0xFFFFFFFF) return;
        }
//        if (addr2==0x158138) printf("Writemembl %02X %08X %i\n",val,addr2,cr0>>31);
        if (isram[(addr2&rammask)>>16])
        {
                addwritelookup(addr+seg,addr2&rammask);
        }
        addr=addr2&rammask;
        switch ((addr>>16)&0xFF)
        {
                case 0: case 1: case 2: case 3: case 4:
                case 5: case 6: case 7: case 8: case 9:
//                        printf("Writemem %05X %02X %04X:%04X\n",addr,val,cs>>4,pc);
                ram[addr]=val;
                return;
                case 10: if (EGA) writeega(addr,val);
                if (slowega) cycles-=egacycles;
//                printf("VRAM write %05X %02X %04X:%04X %c\n",addr,val,cs>>4,pc,val);
                return;
                case 11:
                if (slowega && EGA) cycles-=egacycles;
//                printf("VRAM write %05X %02X %04X:%04X %c %i %i %02X\n",addr,val,cs>>4,pc,val,AMSTRAD,EGA,gdcreg[6]&0xC);
                if (AMSTRAD && incga) writevram(addr,val);
                else if ((AMSTRAD || EGA) && ((gdcreg[6]&0xC)==0xC)) writeega(addr&0x7FFF,val);
                else if (TANDY) writetandyvram(addr,val);
                else            writevramgen(addr,val);//vram[addr&0xFFFF]=val;
                return;
                case 15: /*printf("BIOS write %08X %02X\n",addr,val); */if (shadowbios) return;
                case 14: //printf("Write %08X %02X\n",addr,val); //ram[addr]=val;
                case 0x10: case 0x11: case 0x12: case 0x13:
                case 0x14: case 0x15: case 0x16: case 0x17:
                case 0x18: case 0x19: case 0x1A: case 0x1B:
                case 0x1C: case 0x1D: case 0x1E: case 0x1F:
                case 0x20: case 0x21: case 0x22: case 0x23:
                case 0x24: case 0x25: case 0x26: case 0x27:
                case 0x28: case 0x29: case 0x2A: case 0x2B:
                case 0x2C: case 0x2D: case 0x2E: case 0x2F:
                case 0x30: case 0x31: case 0x32: case 0x33:
                case 0x34: case 0x35: case 0x36: case 0x37:
                case 0x38: case 0x39: case 0x3A: case 0x3B:
                case 0x3C: case 0x3D: case 0x3E: case 0x3F:
                case 0x40: case 0x41: case 0x42: case 0x43:
                case 0x44: case 0x45: case 0x46: case 0x47:
                case 0x48: case 0x49: case 0x4A: case 0x4B:
                case 0x4C: case 0x4D: case 0x4E: case 0x4F:
                case 0x50: case 0x51: case 0x52: case 0x53:
                case 0x54: case 0x55: case 0x56: case 0x57:
                case 0x58: case 0x59: case 0x5A: case 0x5B:
                case 0x5C: case 0x5D: case 0x5E: case 0x5F:
                case 0x60: case 0x61: case 0x62: case 0x63:
                case 0x64: case 0x65: case 0x66: case 0x67:
                case 0x68: case 0x69: case 0x6A: case 0x6B:
                case 0x6C: case 0x6D: case 0x6E: case 0x6F:
                case 0x70: case 0x71: case 0x72: case 0x73:
                case 0x74: case 0x75: case 0x76: case 0x77:
                case 0x78: case 0x79: case 0x7A: case 0x7B:
                case 0x7C: case 0x7D: case 0x7E: case 0x7F:
//                if (cs!=0xF0000) printf("Write high mem %06X %04X:%04X\n",addr,CS,pc);
                ram[addr]=val;
                return;
        }
/*        if (addr>0x800000 && addr<0xFC0000)
        {
                printf("Write to bad address %08X %08X!\n",addr,val);
                dumpregs();
                exit(-1);
        }*/
//        printf("Bad write addr %05X %02X\n",addr,val);
}

//#define readmemb(s,a) readmemb386(s,a)
//#define writememb(s,a,v) writememb386(s,a,v)

unsigned long fetchdat;
unsigned long rmdat32;
#define rmdat rmdat32
unsigned long backupregs[16];
int oddeven=0;
int inttype,abrt;
void writeerror(unsigned long error)
{
        if (inttype)
        {
                if (stack32) { writememl(ss,(ESP-4),error);        ESP-=4; }
                else         { writememl(ss,((SP-4)&0xFFFF),error); SP-=4; }
        }
        else
        {
                if (stack32) { writememw(ss,(ESP-2),error);        ESP-=2; }
                else         { writememw(ss,((SP-2)&0xFFFF),error); SP-=2; }
        }
}

unsigned long oldcs2;
unsigned long oldecx;
unsigned short op32,oldflags;

inline unsigned long fastreadl(unsigned long a)
{
//        return readmeml(0,a);
        if ((a&0xFFF)>0xFFC) return readmeml(0,a);
        if ((a>>12)==pccache) return *((unsigned long *)&pccache2[a]);
        pccache2=getpccache(a);
        pccache=a>>12;
//        if (a>0xFFFFF) printf("LOG : %08X %08X %08X\n",a,pccache2,ram);
        return *((unsigned long *)&pccache2[a]);
}

unsigned long getlong()
{
        pc+=4;
        return readmeml(cs,(pc-4));
}


void fetcheal32nosib()
{
        if (rm==5) easeg=ss;
        if (mod==1) { eaaddr+=((unsigned long)(signed char)(rmdat>>8)); pc++; }
        else        { eaaddr+=getlong(); }
}

void fetcheal32sib()
{
        unsigned char sib;
        sib=rmdat>>8; pc++; //readmemb(cs+pc); pc++;
        switch (mod)
        {
                case 0: eaaddr=regs[sib&7].l; break;
                case 1: eaaddr=((unsigned long)(signed char)(rmdat>>16))+regs[sib&7].l; pc++; break;
                case 2: eaaddr=getlong()+regs[sib&7].l; break;
        }
        /*SIB byte present*/
        if ((sib&7)==5 && !mod) eaaddr=getlong();
        else if ((sib&6)==4) easeg=ss;
        if (((sib>>3)&7)!=4) eaaddr+=regs[(sib>>3)&7].l<<(sib>>6);
}

unsigned short *mod1add[2][8];
unsigned long *mod1seg[8];

void fetchea32()
{
        if (op32&0x200)
        {
                /*rmdat=readmemw(cs,pc); */pc++;
                reg=(rmdat>>3)&7;
                mod=(rmdat>>6)&3;
                rm=rmdat&7;
                if (mod!=3)
                {
                        easeg=ds;
                        if (rm==4) fetcheal32sib();
                        else
                        {
                                eaaddr=regs[rm].l;
                                if (mod) fetcheal32nosib();
                                else if (rm==5) eaaddr=getlong();
                        }
                }
//                rmdat&=0xFF;
        }
        else
        {
                rmdat=readmemb(cs,pc); pc++;
                reg=(rmdat>>3)&7;
                mod=rmdat>>6;
                rm=rmdat&7;
                if (mod!=3)
                {
                        if (!mod && rm==6) { eaaddr=getword(); easeg=ds; }
                        else
                        {
                                switch (mod)
                                {
                                        case 0:
                                        eaaddr=0;
                                        break;
                                        case 1:
                                        eaaddr=(unsigned short)(signed char)readmemb(cs,pc); pc++;
                                        break;
                                        case 2:
                                        eaaddr=getword();
                                        break;
                                }
                                eaaddr+=(*mod1add[0][rm])+(*mod1add[1][rm]);
                                easeg=*mod1seg[rm];
                                eaaddr&=0xFFFF;
                        }
                }
        }
}

#undef fetchea
#define fetchea() if (op32&0x200) { rmdat=fetchdat>>8; } fetchea32()
#define fetchea2() if (op32&0x200) { rmdat=readmeml(cs,pc); } fetchea32()

void setznp32(unsigned long val)
{
        flags&=~0xC4;
        flags|=((val&0x80000000)?N_FLAG:((!val)?Z_FLAG:0));
        flags|=znptable8[val&0xFF]&P_FLAG;
}

void setadd32(unsigned long a, unsigned long b)
{
        unsigned long c=(unsigned long)a+(unsigned long)b;
        flags&=~0x8D5;
        flags|=((c&0x80000000)?N_FLAG:((!c)?Z_FLAG:0));
        flags|=(znptable8[c&0xFF]&P_FLAG);
        if (c<a) flags|=C_FLAG;
        if (!((a^b)&0x80000000)&&((a^c)&0x80000000)) flags|=V_FLAG;
        if (((a&0xF)+(b&0xF))&0x10)      flags|=A_FLAG;
}
void setadd32nc(unsigned long a, unsigned long b)
{
        unsigned long c=(unsigned long)a+(unsigned long)b;
        flags&=~0x8D4;
        flags|=((c&0x80000000)?N_FLAG:((!c)?Z_FLAG:0));
        flags|=(znptable8[c&0xFF]&P_FLAG);
        if (!((a^b)&0x80000000)&&((a^c)&0x80000000)) flags|=V_FLAG;
        if (((a&0xF)+(b&0xF))&0x10)      flags|=A_FLAG;
}
void setadc32(unsigned long a, unsigned long b)
{
        unsigned long c=(unsigned long)a+(unsigned long)b+tempc;
        flags&=~0x8D5;
        flags|=((c&0x80000000)?N_FLAG:((!c)?Z_FLAG:0));
        flags|=(znptable8[c&0xFF]&P_FLAG);
        if ((c<a) || (c==a && tempc)) flags|=C_FLAG;
        if (!((a^b)&0x80000000)&&((a^c)&0x80000000)) flags|=V_FLAG;
        if (((a&0xF)+(b&0xF)+tempc)&0x10)      flags|=A_FLAG;
}
void setsub32(unsigned long a, unsigned long b)
{
        unsigned long c=(unsigned long)a-(unsigned long)b;
        flags&=~0x8D5;
        flags|=((c&0x80000000)?N_FLAG:((!c)?Z_FLAG:0));
        flags|=(znptable8[c&0xFF]&P_FLAG);
        if (c>a) flags|=C_FLAG;
        if ((a^b)&(a^c)&0x80000000) flags|=V_FLAG;
        if (((a&0xF)-(b&0xF))&0x10) flags|=A_FLAG;
}
void setsub32nc(unsigned long a, unsigned long b)
{
        unsigned long c=(unsigned long)a-(unsigned long)b;
        flags&=~0x8D4;
        flags|=((c&0x80000000)?N_FLAG:((!c)?Z_FLAG:0));
        flags|=(znptable8[c&0xFF]&P_FLAG);
        if ((a^b)&(a^c)&0x80000000) flags|=V_FLAG;
        if (((a&0xF)-(b&0xF))&0x10)      flags|=A_FLAG;
}
void setsbc32(unsigned long a, unsigned long b)
{
        unsigned long c=(unsigned long)a-(((unsigned long)b)+tempc);
        flags&=~0x8D5;
        flags|=((c&0x80000000)?N_FLAG:((!c)?Z_FLAG:0));
        flags|=(znptable8[c&0xFF]&P_FLAG);
        if ((c>a) || (c==a && tempc)) flags|=C_FLAG;
        if ((a^b)&(a^c)&0x80000000) flags|=V_FLAG;
        if (((a&0xF)-((b&0xF)+tempc))&0x10)      flags|=A_FLAG;
}

/*void setadc32(unsigned long a, unsigned long b)
{
        unsigned long c=(unsigned long)a+(unsigned long)b+tempc;
        flags&=~0x8D5;
        flags|=((c&0x80000000)?N_FLAG:((!c)?Z_FLAG:0));
        flags|=(znptable8[c&0xFF]&P_FLAG);
        if ((c<a) || (c==a && tempc)) flags|=C_FLAG;
        if (!((a^b)&0x80000000)&&((a^c)&0x80000000)) flags|=V_FLAG;
        if (((a&0xF)+(b&0xF)+tempc)&0x10)      flags|=A_FLAG;
}
void setadd32(unsigned long a, unsigned long b)
{
        unsigned long c=(unsigned long)a+(unsigned long)b;
        flags&=~0x8D5;
        flags|=((c&0x80000000)?N_FLAG:((!c)?Z_FLAG:0));
        flags|=(znptable8[c&0xFF]&P_FLAG);
        if (c<a) flags|=C_FLAG;
        if (!((a^b)&0x80000000)&&((a^c)&0x80000000)) flags|=V_FLAG;
        if (((a&0xF)+(b&0xF))&0x10)      flags|=A_FLAG;
}
void setadd32nc(unsigned long a, unsigned long b)
{
        unsigned long c=(unsigned long)a+(unsigned long)b;
        flags&=~0x8D4;
        flags|=((c&0x80000000)?N_FLAG:((!c)?Z_FLAG:0));
        flags|=(znptable8[c&0xFF]&P_FLAG);
        if (!((a^b)&0x80000000)&&((a^c)&0x80000000)) flags|=V_FLAG;
        if (((a&0xF)+(b&0xF))&0x10)      flags|=A_FLAG;
}
void setsbc32(unsigned long a, unsigned long b)
{
        unsigned long c=(unsigned long)a-(((unsigned long)b)+tempc);
        flags&=~0x8D5;
        flags|=((c&0x80000000)?N_FLAG:((!c)?Z_FLAG:0));
        flags|=(znptable8[c&0xFF]&P_FLAG);
        if ((c>a) || (c==a && tempc)) flags|=C_FLAG;
        if ((a^b)&(a^c)&0x80000000) flags|=V_FLAG;
        if (((a&0xF)-((b&0xF)+tempc))&0x10)      flags|=A_FLAG;
}
void setsub32(unsigned long a, unsigned long b)
{
        unsigned long c=(unsigned long)a-(unsigned long)b;
        flags&=~0x8D5;
        flags|=((c&0x80000000)?N_FLAG:((!c)?Z_FLAG:0));
        flags|=(znptable8[c&0xFF]&P_FLAG);
        if (c>a) flags|=C_FLAG;
        if ((a^b)&(a^c)&0x80000000) flags|=V_FLAG;
        if (((a&0xF)-(b&0xF))&0x10)      flags|=A_FLAG;
}
void setsub32nc(unsigned long a, unsigned long b)
{
        unsigned long c=(unsigned long)a-(unsigned long)b;
        flags&=~0x8D4;
        flags|=((c&0x80000000)?N_FLAG:((!c)?Z_FLAG:0));
        flags|=(znptable8[c&0xFF]&P_FLAG);
        if ((a^b)&(a^c)&0x80000000) flags|=V_FLAG;
        if (((a&0xF)-(b&0xF))&0x10)      flags|=A_FLAG;
}*/

inline unsigned long geteal()
{
        if (mod==3)
           return regs[rm].l;
//        cycles-=(is486)?1:3;
//        if (output==3) printf("EA %04X:%08X\n",easeg,eaaddr);
        return readmeml(easeg,eaaddr);
}
inline void seteal(unsigned long val)
{
        if (mod==3)
           regs[rm].l=val;
        else
        {
//                cycles-=(is486)?1:2;
                writememl(easeg,eaaddr,val);
        }
}

void int6()
{
        uint32_t addr;
                                pc=oldpc;
                                if (msw&1)
                                {
                                        pmodeint(6,0);
                                }
                                else
                                {
                                        if (ssegs) ss=oldss;
                                        if (stack32)
                                        {
                                                writememw(ss,ESP-2,flags);
                                                writememw(ss,ESP-4,CS);
                                                writememw(ss,ESP-6,pc);
                                                ESP-=6;
                                        }
                                        else
                                        {
                                                writememw(ss,((SP-2)&0xFFFF),flags);
                                                writememw(ss,((SP-4)&0xFFFF),CS);
                                                writememw(ss,((SP-6)&0xFFFF),pc);
                                                SP-=6;
                                        }
                                        addr=6<<2;
//                                        flags&=~I_FLAG;
                                        oxpc=pc;
                                        pc=readmemw(0,addr);
                                        loadcs(readmemw(0,addr+2));
                                        if (!pc && !cs)
                                        {
                                                printf("Bad int 06 %04X:%04X\n",oldcs,oldpc);
                                                dumpregs();
                                                exit(-1);
                                        }
                                }
                                cycles-=70;
}

void rep386(int fv)
{
        unsigned char temp;
        unsigned long c;//=CX;
        unsigned char temp2;
        unsigned short tempw,tempw2,tempw3;
        unsigned long ipc=oldpc;//pc-1;
        int changeds=0;
        unsigned long oldds;
        unsigned short rep32=op32;
        unsigned long templ,templ2;
//        if (output) printf("REP32 %04X %04X  ",use32,rep32);
        startrep:
        temp=opcode2=readmemb(cs,pc); pc++;
//        if (firstrepcycle && temp==0xA5) printf("REP MOVSW %06X:%04X %06X:%04X\n",ds,SI,es,DI);
//        if (output) printf("REP %02X %04X\n",temp,ipc);
        c=(rep32&0x200)?ECX:CX;
/*        if (rep32 && (msw&1))
        {
                if (temp!=0x67 && temp!=0x66 && (rep32|temp)!=0x1AB && (rep32|temp)!=0x3AB) printf("32-bit REP %03X %08X %04X:%06X\n",temp|rep32,c,CS,pc);
        }*/
        switch (temp|rep32)
        {
                case 0xC3: case 0x1C3: case 0x2C3: case 0x3C3:
                pc--;
                break;
                case 0x08:
                pc=ipc+1;
                break;
                case 0x26: case 0x126: case 0x226: case 0x326: /*ES:*/
                oldds=ds;
                ds=es;
                changeds=1;
                goto startrep;
                break;
                case 0x2E: case 0x12E: case 0x22E: case 0x32E: /*CS:*/
                oldds=ds;
                ds=cs;
                changeds=1;
                goto startrep;
                break;
                case 0x36: case 0x136: case 0x236: case 0x336: /*SS:*/
                oldds=ds;
                ds=ss;
                changeds=1;
                goto startrep;
                break;
                case 0x3E: case 0x13E: case 0x23E: case 0x33E: /*DS:*/
                oldds=ds;
                ds=ds;
                changeds=1;
                goto startrep;
                break;
                case 0x64: case 0x164: case 0x264: case 0x364: /*FS:*/
                oldds=ds;
                ds=fs;
                changeds=1;
                goto startrep;
                case 0x65: case 0x165: case 0x265: case 0x365: /*GS:*/
                oldds=ds;
                ds=gs;
                changeds=1;
                goto startrep;
                case 0x66: case 0x166: case 0x266: case 0x366: /*Data size prefix*/
                rep32^=0x100;
                goto startrep;
                case 0x67: case 0x167: case 0x267: case 0x367:  /*Address size prefix*/
                rep32^=0x200;
                goto startrep;
                case 0x6C: case 0x16C: /*REP INSB*/
                if (c>0)
                {
                        temp2=inb(DX);
                        writememb(ds,DI,temp2);
                        if (flags&D_FLAG) DI--;
                        else              DI++;
                        c--;
                        cycles-=15;
                }
                if (c>0) { firstrepcycle=0; pc=ipc; if (ssegs) ssegs++; }
                else firstrepcycle=1;
                break;
                case 0x26C: case 0x36C: /*REP INSB*/
                if (c>0)
                {
                        temp2=inb(DX);
                        writememb(ds,EDI,temp2);
                        if (flags&D_FLAG) EDI--;
                        else              EDI++;
                        c--;
                        cycles-=15;
                }
                if (c>0) { firstrepcycle=0; pc=ipc; if (ssegs) ssegs++; }
                else firstrepcycle=1;
                break;
                case 0x6E: case 0x16E: /*REP OUTSB*/
                if (c>0)
                {
                        temp2=readmemb(ds,SI);
                        outb(DX,temp2);
                        if (flags&D_FLAG) SI--;
                        else              SI++;
                        c--;
                        cycles-=14;
                }
                if (c>0) { firstrepcycle=0; pc=ipc; if (ssegs) ssegs++; }
                else firstrepcycle=1;
                break;
                case 0x26E: case 0x36E: /*REP OUTSB*/
                if (c>0)
                {
                        temp2=readmemb(ds,ESI);
                        outb(DX,temp2);
                        if (flags&D_FLAG) ESI--;
                        else              ESI++;
                        c--;
                        cycles-=14;
                }
                if (c>0) { firstrepcycle=0; pc=ipc; if (ssegs) ssegs++; }
                else firstrepcycle=1;
                break;
                case 0x26F: /*REP OUTSW*/
                if (c>0)
                {
                        tempw=readmemw(ds,ESI);
                        outb(DX,tempw);
                        outb(DX+1,tempw>>8);
                        if (flags&D_FLAG) ESI-=2;
                        else              ESI+=2;
                        c--;
                        cycles-=14;
                }
                if (c>0) { firstrepcycle=0; pc=ipc; if (ssegs) ssegs++; }
                else firstrepcycle=1;
                break;
                case 0xA4: case 0x1A4: /*REP MOVSB*/
                if (c>0)
                {
                        temp2=readmemb(ds,SI);
                        writememb(es,DI,temp2);
                        if (flags&D_FLAG) { DI--; SI--; }
                        else              { DI++; SI++; }
                        c--;
                        cycles-=(is486)?3:4;
                }
                if (c>0) { firstrepcycle=0; pc=ipc; if (ssegs) ssegs++; }
                else firstrepcycle=1;
                break;
                case 0x2A4: case 0x3A4: /*REP MOVSB*/
                if (c>0)
                {
                        temp2=readmemb(ds,ESI);
                        writememb(es,EDI,temp2);
                        if (flags&D_FLAG) { EDI--; ESI--; }
                        else              { EDI++; ESI++; }
                        c--;
                        cycles-=(is486)?3:4;
                }
                if (c>0) { firstrepcycle=0; pc=ipc; if (ssegs) ssegs++; }
                else firstrepcycle=1;
                break;
                case 0xA5: /*REP MOVSW*/
                if (c>0)
                {
                        tempw=readmemw(ds,SI);
                        writememw(es,DI,tempw);
                        if (flags&D_FLAG) { DI-=2; SI-=2; }
                        else              { DI+=2; SI+=2; }
                        c--;
                        cycles-=(is486)?3:4;
                }
                if (c>0) { firstrepcycle=0; pc=ipc; if (ssegs) ssegs++; }
                else firstrepcycle=1;
                break;
                case 0x1A5: /*REP MOVSL*/
                if (c>0)
                {
                        templ=readmeml(ds,SI);
                        writememl(es,DI,templ);
                        if (flags&D_FLAG) { DI-=4; SI-=4; }
                        else              { DI+=4; SI+=4; }
                        c--;
                        cycles-=(is486)?3:4;
                }
                if (c>0) { firstrepcycle=0; pc=ipc; if (ssegs) ssegs++; }
                else firstrepcycle=1;
                break;
                case 0x2A5: /*REP MOVSW*/
                if (c>0)
                {
                        tempw=readmemw(ds,ESI);
                        writememw(es,EDI,tempw);
//                        if (output) printf("Written %04X from %08X to %08X %i  %08X %04X %08X %04X\n",tempw,ds+ESI,es+EDI,c,ds,ES,es,ES);
                        if (flags&D_FLAG) { EDI-=2; ESI-=2; }
                        else              { EDI+=2; ESI+=2; }
                        c--;
                        cycles-=(is486)?3:4;
                }
                if (c>0) { firstrepcycle=0; pc=ipc; if (ssegs) ssegs++; }
                else firstrepcycle=1;
                break;
                case 0x3A5: /*REP MOVSL*/
                if (c>0)
                {
                        templ=readmeml(ds,ESI);
//                        if ((EDI&0xFFFF0000)==0xA0000) cycles-=12;
                        writememl(es,EDI,templ);
//                        if (output) printf("Load %08X from %08X to %08X  %04X %08X  %04X %08X\n",templ,ESI,EDI,DS,ds,ES,es);
                        if (flags&D_FLAG) { EDI-=4; ESI-=4; }
                        else              { EDI+=4; ESI+=4; }
                        c--;
                        cycles-=(is486)?3:4;
                }
                if (c>0) { firstrepcycle=0; pc=ipc; if (ssegs) ssegs++; }
                else firstrepcycle=1;
                break;
                case 0xA6: case 0x1A6: /*REP CMPSB*/
                if (fv) flags|=Z_FLAG;
                else    flags&=~Z_FLAG;
                if ((c>0) && (fv==((flags&Z_FLAG)?1:0)))
                {
                        temp=readmemb(ds,SI);
                        temp2=readmemb(es,DI);
                        if (flags&D_FLAG) { DI--; SI--; }
                        else              { DI++; SI++; }
                        c--;
                        cycles-=(is486)?7:9;
                        setsub8(temp,temp2);
                }
                if ((c>0) && (fv==((flags&Z_FLAG)?1:0))) { pc=ipc; firstrepcycle=0; if (ssegs) ssegs++; }
                else firstrepcycle=1;
                break;
                case 0x2A6: case 0x3A6: /*REP CMPSB*/
                if (fv) flags|=Z_FLAG;
                else    flags&=~Z_FLAG;
                if ((c>0) && (fv==((flags&Z_FLAG)?1:0)))
                {
                        temp=readmemb(ds,ESI);
                        temp2=readmemb(es,EDI);
                        if (flags&D_FLAG) { EDI--; ESI--; }
                        else              { EDI++; ESI++; }
                        c--;
                        cycles-=(is486)?7:9;
                        setsub8(temp,temp2);
                }
                if ((c>0) && (fv==((flags&Z_FLAG)?1:0))) { pc=ipc; firstrepcycle=0; if (ssegs) ssegs++; }
                else firstrepcycle=1;
                break;
                case 0xA7: /*REP CMPSW*/
                if (fv) flags|=Z_FLAG;
                else    flags&=~Z_FLAG;
                if ((c>0) && (fv==((flags&Z_FLAG)?1:0)))
                {
                        tempw=readmemw(ds,SI);
                        tempw2=readmemw(es,DI);
                        if (flags&D_FLAG) { DI-=2; SI-=2; }
                        else              { DI+=2; SI+=2; }
                        c--;
                        cycles-=(is486)?7:9;
                        setsub16(tempw,tempw2);
                }
                if ((c>0) && (fv==((flags&Z_FLAG)?1:0))) { pc=ipc; firstrepcycle=0; if (ssegs) ssegs++; }
                else firstrepcycle=1;
                break;
                case 0x1A7: /*REP CMPSL*/
                if (fv) flags|=Z_FLAG;
                else    flags&=~Z_FLAG;
                if ((c>0) && (fv==((flags&Z_FLAG)?1:0)))
                {
                        templ=readmeml(ds,SI);
                        templ2=readmeml(es,DI);
                        if (flags&D_FLAG) { DI-=4; SI-=4; }
                        else              { DI+=4; SI+=4; }
                        c--;
                        cycles-=(is486)?7:9;
                        setsub32(templ,templ2);
                }
                if ((c>0) && (fv==((flags&Z_FLAG)?1:0))) { pc=ipc; firstrepcycle=0; if (ssegs) ssegs++; }
                else firstrepcycle=1;
                break;
                case 0x2A7: /*REP CMPSW*/
                if (fv) flags|=Z_FLAG;
                else    flags&=~Z_FLAG;
                if ((c>0) && (fv==((flags&Z_FLAG)?1:0)))
                {
                        tempw=readmemw(ds,ESI);
                        tempw2=readmemw(es,EDI);
                        if (flags&D_FLAG) { EDI-=2; ESI-=2; }
                        else              { EDI+=2; ESI+=2; }
                        c--;
                        cycles-=(is486)?7:9;
                        setsub16(tempw,tempw2);
                }
                if ((c>0) && (fv==((flags&Z_FLAG)?1:0))) { pc=ipc; firstrepcycle=0; if (ssegs) ssegs++; }
                else firstrepcycle=1;
                break;
                case 0x3A7: /*REP CMPSL*/
                if (fv) flags|=Z_FLAG;
                else    flags&=~Z_FLAG;
                if ((c>0) && (fv==((flags&Z_FLAG)?1:0)))
                {
                        templ=readmeml(ds,ESI);
                        templ2=readmeml(es,EDI);
                        if (flags&D_FLAG) { EDI-=4; ESI-=4; }
                        else              { EDI+=4; ESI+=4; }
                        c--;
                        cycles-=(is486)?7:9;
                        setsub32(templ,templ2);
                }
                if ((c>0) && (fv==((flags&Z_FLAG)?1:0))) { pc=ipc; firstrepcycle=0; if (ssegs) ssegs++; }
                else firstrepcycle=1;
                break;

                case 0xAA: case 0x1AA: /*REP STOSB*/
                if (c>0)
                {
                        writememb(es,DI,AL);
                        if (flags&D_FLAG) DI--;
                        else              DI++;
                        c--;
                        cycles-=(is486)?4:5;
                }
                if (c>0) { firstrepcycle=0; pc=ipc; if (ssegs) ssegs++; }
                else firstrepcycle=1;
                break;
                case 0x2AA: case 0x3AA: /*REP STOSB*/
                if (c>0)
                {
                        writememb(es,EDI,AL);
                        if (flags&D_FLAG) EDI--;
                        else              EDI++;
                        c--;
                        cycles-=(is486)?4:5;
                }
                if (c>0) { firstrepcycle=0; pc=ipc; if (ssegs) ssegs++; }
                else firstrepcycle=1;
                break;
                case 0xAB: /*REP STOSW*/
                if (c>0)
                {
                        writememw(es,DI,AX);
                        if (flags&D_FLAG) DI-=2;
                        else              DI+=2;
                        c--;
                        cycles-=(is486)?4:5;
                }
                if (c>0) { firstrepcycle=0; pc=ipc; if (ssegs) ssegs++; }
                else firstrepcycle=1;
                break;
                case 0x2AB: /*REP STOSW*/
                if (c>0)
                {
                        writememw(es,EDI,AX);
                        if (flags&D_FLAG) EDI-=2;
                        else              EDI+=2;
                        c--;
                        cycles-=(is486)?4:5;
                }
                if (c>0) { firstrepcycle=0; pc=ipc; if (ssegs) ssegs++; }
                else firstrepcycle=1;
                break;
                case 0x1AB: /*REP STOSL*/
                if (c>0)
                {
                        writememl(es,DI,EAX);
                        if (flags&D_FLAG) DI-=4;
                        else              DI+=4;
                        c--;
                        cycles-=(is486)?4:5;
                }
                if (c>0) { firstrepcycle=0; pc=ipc; if (ssegs) ssegs++; }
                else firstrepcycle=1;
                break;
                case 0x3AB: /*REP STOSL*/
                if (c>0)
                {
                        writememl(es,EDI,EAX);
                        if (flags&D_FLAG) EDI-=4;
                        else              EDI+=4;
                        c--;
                        cycles-=(is486)?4:5;
                }
                if (c>0) { firstrepcycle=0; pc=ipc; if (ssegs) ssegs++; }
                else firstrepcycle=1;
                break;
                case 0xAC: case 0x1AC: /*REP LODSB*/
//                if (ds==0xFFFFFFFF) printf("Null selector REP LODSB %04X(%06X):%06X\n",CS,cs,pc);
                if (c>0)
                {
                        AL=readmemb(ds,SI);
                        if (flags&D_FLAG) SI--;
                        else              SI++;
                        c--;
                        cycles-=5;
                }
                if (c>0) { firstrepcycle=0; pc=ipc; if (ssegs) ssegs++; }
                else firstrepcycle=1;
                break;
                case 0x2AC: case 0x3AC: /*REP LODSB*/
//                if (ds==0xFFFFFFFF) printf("Null selector REP LODSB %04X(%06X):%06X\n",CS,cs,pc);
                if (c>0)
                {
                        AL=readmemb(ds,ESI);
                        if (flags&D_FLAG) ESI--;
                        else              ESI++;
                        c--;
                        cycles-=5;
                }
                if (c>0) { firstrepcycle=0; pc=ipc; if (ssegs) ssegs++; }
                else firstrepcycle=1;
                break;
                case 0xAD: /*REP LODSW*/
//                if (ds==0xFFFFFFFF) printf("Null selector REP LODSW %04X(%06X):%06X\n",CS,cs,pc);
                if (c>0)
                {
                        AX=readmemw(ds,SI);
                        if (flags&D_FLAG) SI-=2;
                        else              SI+=2;
                        c--;
                        cycles-=5;
                }
                if (c>0) { firstrepcycle=0; pc=ipc; if (ssegs) ssegs++; }
                else firstrepcycle=1;
                break;
                case 0x1AD: /*REP LODSL*/
//                if (ds==0xFFFFFFFF) printf("Null selector REP LODSL %04X(%06X):%06X\n",CS,cs,pc);
                if (c>0)
                {
                        EAX=readmeml(ds,SI);
                        if (flags&D_FLAG) SI-=4;
                        else              SI+=4;
                        c--;
                        cycles-=5;
                }
                if (c>0) { firstrepcycle=0; pc=ipc; if (ssegs) ssegs++; }
                else firstrepcycle=1;
                break;
                case 0x2AD: /*REP LODSW*/
//                if (ds==0xFFFFFFFF) printf("Null selector REP LODSW %04X(%06X):%06X\n",CS,cs,pc);
                if (c>0)
                {
                        AX=readmemw(ds,ESI);
                        if (flags&D_FLAG) ESI-=2;
                        else              ESI+=2;
                        c--;
                        cycles-=5;
                }
                if (c>0) { firstrepcycle=0; pc=ipc; if (ssegs) ssegs++; }
                else firstrepcycle=1;
                break;
                case 0x3AD: /*REP LODSL*/
//                if (ds==0xFFFFFFFF) printf("Null selector REP LODSL %04X(%06X):%06X\n",CS,cs,pc);
                if (c>0)
                {
                        EAX=readmeml(ds,ESI);
                        if (flags&D_FLAG) ESI-=4;
                        else              ESI+=4;
                        c--;
                        cycles-=5;
                }
                if (c>0) { firstrepcycle=0; pc=ipc; if (ssegs) ssegs++; }
                else firstrepcycle=1;
                break;
                case 0xAE: case 0x1AE: /*REP SCASB*/
//                if (es==0xFFFFFFFF) printf("Null selector REP SCASB %04X(%06X):%06X\n",CS,cs,pc);
                if (fv) flags|=Z_FLAG;
                else    flags&=~Z_FLAG;
                if ((c>0) && (fv==((flags&Z_FLAG)?1:0)))
                {
                        temp2=readmemb(es,DI);
                        setsub8(AL,temp2);
                        if (flags&D_FLAG) DI--;
                        else              DI++;
                        c--;
                        cycles-=(is486)?5:8;
                }
                if ((c>0) && (fv==((flags&Z_FLAG)?1:0)))  { pc=ipc; firstrepcycle=0; if (ssegs) ssegs++; }
                else firstrepcycle=1;
                break;
                case 0x2AE: case 0x3AE: /*REP SCASB*/
//                if (es==0xFFFFFFFF) printf("Null selector REP SCASB %04X(%06X):%06X\n",CS,cs,pc);
                if (fv) flags|=Z_FLAG;
                else    flags&=~Z_FLAG;
//                if (output) printf("REP SCASB - %i %04X %i\n",fv,flags&Z_FLAG,c);
                if ((c>0) && (fv==((flags&Z_FLAG)?1:0)))
                {
                        temp2=readmemb(es,EDI);
//                        if (output) printf("Compare %02X,%02X\n",temp2,AL);
                        setsub8(AL,temp2);
                        if (flags&D_FLAG) EDI--;
                        else              EDI++;
                        c--;
                        cycles-=(is486)?5:8;
                }
                if ((c>0) && (fv==((flags&Z_FLAG)?1:0)))  { pc=ipc; firstrepcycle=0; if (ssegs) ssegs++; }
                else firstrepcycle=1;
                break;
                case 0xAF: /*REP SCASW*/
//                if (es==0xFFFFFFFF) printf("Null selector REP SCASW %04X(%06X):%06X\n",CS,cs,pc);
                if (fv) flags|=Z_FLAG;
                else    flags&=~Z_FLAG;
                if ((c>0) && (fv==((flags&Z_FLAG)?1:0)))
                {
                        tempw=readmemw(es,DI);
                        setsub16(AX,tempw);
                        if (flags&D_FLAG) DI-=2;
                        else              DI+=2;
                        c--;
                        cycles-=(is486)?5:8;
                }
                if ((c>0) && (fv==((flags&Z_FLAG)?1:0)))  { pc=ipc; firstrepcycle=0; if (ssegs) ssegs++; }
                else firstrepcycle=1;
                break;
                case 0x1AF: /*REP SCASL*/
//                if (es==0xFFFFFFFF) printf("Null selector REP SCASL %04X(%06X):%06X\n",CS,cs,pc);
                if (fv) flags|=Z_FLAG;
                else    flags&=~Z_FLAG;
                if ((c>0) && (fv==((flags&Z_FLAG)?1:0)))
                {
                        templ=readmeml(es,DI);
                        setsub32(EAX,templ);
                        if (flags&D_FLAG) DI-=4;
                        else              DI+=4;
                        c--;
                        cycles-=(is486)?5:8;
                }
                if ((c>0) && (fv==((flags&Z_FLAG)?1:0)))  { pc=ipc; firstrepcycle=0; if (ssegs) ssegs++; }
                else firstrepcycle=1;
                break;
                case 0x2AF: /*REP SCASW*/
//                if (es==0xFFFFFFFF) printf("Null selector REP SCASW %04X(%06X):%06X\n",CS,cs,pc);
                if (fv) flags|=Z_FLAG;
                else    flags&=~Z_FLAG;
                if ((c>0) && (fv==((flags&Z_FLAG)?1:0)))
                {
                        tempw=readmemw(es,EDI);
                        setsub16(AX,tempw);
                        if (flags&D_FLAG) EDI-=2;
                        else              EDI+=2;
                        c--;
                        cycles-=(is486)?5:8;
                }
                if ((c>0) && (fv==((flags&Z_FLAG)?1:0)))  { pc=ipc; firstrepcycle=0; if (ssegs) ssegs++; }
                else firstrepcycle=1;
                break;
                case 0x3AF: /*REP SCASL*/
//                if (es==0xFFFFFFFF) printf("Null selector REP SCASL %04X(%06X):%06X\n",CS,cs,pc);
                if (fv) flags|=Z_FLAG;
                else    flags&=~Z_FLAG;
                if ((c>0) && (fv==((flags&Z_FLAG)?1:0)))
                {
                        templ=readmeml(es,EDI);
                        setsub32(EAX,templ);
                        if (flags&D_FLAG) EDI-=4;
                        else              EDI+=4;
                        c--;
                        cycles-=(is486)?5:8;
                }
                if ((c>0) && (fv==((flags&Z_FLAG)?1:0)))  { pc=ipc; firstrepcycle=0; if (ssegs) ssegs++; }
                else firstrepcycle=1;
                break;


                default:
                        pc=ipc;
                        cycles-=20;
                printf("Bad REP %02X %i\n",temp,rep32>>8);
                dumpregs();
                exit(-1);
        }
        if (rep32&0x200) ECX=c;
        else             CX=c;
        if (changeds) ds=oldds;
//        if (output) printf("%03X %03X\n",rep32,use32);
}

int checkio(int port)
{
        unsigned short t=readmemw(tr.base,66);
        unsigned char d;
        if ((t+(port>>3))>tr.limit) return 1;
        d=readmemb(tr.base,t+(port>>3));
        return d&(1<<(port&7));
}

int xout=0;

static inline unsigned char geteab()
{
        if (mod==3)
           return (rm&4)?regs[rm&3].b.h:regs[rm&3].b.l;
        cycles-=3;
        return readmemb(easeg,eaaddr);
}

static inline unsigned short geteaw()
{
        if (mod==3)
           return regs[rm].w;
        cycles-=3;
//        if (output==3) printf("GETEAW %04X:%08X\n",easeg,eaaddr);
        return readmemw(easeg,eaaddr);
}

static inline unsigned short geteaw2()
{
        if (mod==3)
           return regs[rm].w;
        cycles-=2;
//        printf("Getting addr from %04X:%04X %05X\n",easeg,eaaddr+2,easeg+eaaddr+2);
        return readmemw(easeg,(eaaddr+2)&0xFFFF);
}

static inline void seteab(unsigned char val)
{
        if (mod==3)
        {
                if (rm&4) regs[rm&3].b.h=val;
                else      regs[rm&3].b.l=val;
        }
        else
        {
                cycles-=2;
                writememb(easeg,eaaddr,val);
        }
}

static inline void seteaw(unsigned short val)
{
        if (mod==3)
           regs[rm].w=val;
        else
        {
                cycles-=2;
                writememw(easeg,eaaddr,val);
//                writememb(easeg+eaaddr+1,val>>8);
        }
}

void exec386(int cycs)
{
        uint64_t temp64;
        int64_t temp64i;
        unsigned char temp,temp2;
        unsigned short tempw,tempw2,tempw3,tempw4;
        signed char offset;
        int tempws;
        unsigned long templ,templ2,addr;
        int c,cycdiff,oldcyc;
        int tempi;
        FILE *f;
        cycles+=cycs;
//        output=3;
        while (cycles>0)
        {
                cycdiff=0;
                oldcyc=cycles;
                while (cycdiff<100)
                {
/*                old83=old82;
                old82=old8;
                old8=oldpc+cs;
                oldcs2=cs;*/
                oldcs=CS;
                oldpc=pc;
                oldcpl=CPL;
                op32=use32;
                
                optype=0;

/*8 x86regs, CS,DS,ES,FS,GS,SS, flags,eflags*/
/*                backupregs[0]=EAX; backupregs[1]=EBX; backupregs[2]=ECX; backupregs[3]=EDX;
                backupregs[4]=ESI; backupregs[5]=EDI; backupregs[6]=EBP; backupregs[7]=ESP;
                backupregs[8]=CS;  backupregs[9]=DS;  backupregs[10]=ES; backupregs[11]=FS;
                backupregs[12]=GS; backupregs[13]=SS; backupregs[14]=flags; backupregs[15]=eflags;*/

                opcodestart:
                fetchdat=fastreadl(cs+pc);
//                fetchdat=readmeml(cs,pc);
                opcode=fetchdat&0xFF;
//                opcode=readmemb(cs+pc);
                tempc=flags&C_FLAG;


/*                if (op32 && (msw&1))
                {
                        tempw=op32|opcode;
                        if (tempw!=0x153 && tempw!=0x181 && tempw!=0x183 && tempw!=0x133 && tempw!=0x13B && tempw!=0x189 && tempw!=0x18B && tempw!=0x125 && tempw!=0x12B && tempw!=0x266 && tempw!=0x267 && tempw!=0x2AC && ((tempw&0x3F0)!=0x150) && ((tempw&0x3F0)!=0x140) && tempw!=0x109 && tempw!=0x123 && tempw!=0x20A && tempw!=0x38B)
                           printf("Pmode 386 op %03X %04X:%04X %02X %02X\n",op32|opcode,CS,pc,readmemb(cs+pc+1),(readmemb(cs+pc+1)&0x38));
                }*/
                #if 0
                if ((output==3 /*&& (pc<0xB37F || pc>0xB386)*/ && (CS!=0x88)) /*|| (pc>=0x3502 && pc<0x3578)*//* || ((cr0&1)|(eflags&VM_FLAG))*//* && (SP&0xFF00)==0x6E00*/)//&& /*cs<0xF0000 && */!ssegs)//opcode!=0x26 && opcode!=0x36 && opcode!=0x2E && opcode!=0x3E)
                {
                        if ((opcode!=0xF2 && opcode!=0xF3) || firstrepcycle)
                        {
                                if (!skipnextprint) printf("%04X(%06X):%04X : %08X %08X %08X %08X %04X %04X %04X %04X %08X %08X %08X %08X %02X %04X %i %08X %08X %08X\n",CS,cs,pc,EAX,EBX,ECX,EDX,CS,DS,ES,SS,EDI,ESI,EBP,ESP,opcode,flags,ins,readmeml(0,0x1BC90+0x50),ram[0xAB],readmemb(0x400,0xE2));
                                abrt=0;
                                if (ins==75000)
                                {
//                                        output=0;
//                                        dumpregs();
//                                        exit(-1);
                                }
//                                if (!skipnextprint) printf("%08X - from %08X:%08X\n",readmeml(ss,0xF6C),ss,0xF6C);
                                skipnextprint=0;
//                                ins++;
/*                                if (ins==50000)
                                {
                                        dumpregs();
                                        exit(-1);
                                }*/
/*                                if (ins==500000)
                                {
                                        dumpregs();
                                        exit(-1);
                                }*/
                        }
                }
                #endif
                pc++;
                inhlt=0;
//                if (ins==500000) { dumpregs(); exit(0); }*/
/*                if (!xout && op32)
                {
                        xout=1;
                        ins=0;
//                        output=3;
                }*/
                /*C01C87C2*/
//                if (xout && ins>38000000) output=3;
//if (xout && pc>0xC0000000) output=3;
                switch (opcode|op32)
                {
                        case 0x00: case 0x100: case 0x200: case 0x300: /*ADD 8,reg*/
                        fetchea();
/*                        if (!rmdat) pc--;
                        if (!rmdat)
                        {
                                printf("Crashed\n");
//                                clear_keybuf();
//                                readkey();
                                dumpregs();
                                exit(-1);
                        }*/
                        temp=geteab();
                        setadd8(temp,getr8(reg));
                        temp+=getr8(reg);
                        seteab(temp);
                        if (is486) cycles-=((mod==3)?1:3);
                        else       cycles-=((mod==3)?2:7);
                        break;
                        case 0x01: case 0x201: /*ADD 16,reg*/
                        fetchea();
                        tempw=geteaw();
                        setadd16(tempw,regs[reg].w);
                        tempw+=regs[reg].w;
                        seteaw(tempw);
                        if (is486) cycles-=((mod==3)?1:3);
                        else       cycles-=((mod==3)?2:7);
                        break;
                        case 0x101: case 0x301: /*ADD 32,reg*/
                        fetchea();
                        templ=geteal();
                        setadd32(templ,regs[reg].l);
                        templ+=regs[reg].l;
                        seteal(templ);
                        if (is486) cycles-=((mod==3)?1:3);
                        else       cycles-=((mod==3)?2:7);
                        break;
                        case 0x02: case 0x102: case 0x202: case 0x302: /*ADD reg,8*/
                        fetchea();
                        temp=geteab();
                        setadd8(getr8(reg),temp);
                        setr8(reg,getr8(reg)+temp);
                        if (is486) cycles-=((mod==3)?1:2);
                        else       cycles-=((mod==3)?2:6);
                        break;
                        case 0x03: case 0x203: /*ADD reg,16*/
                        fetchea();
                        tempw=geteaw();
                        setadd16(regs[reg].w,tempw);
                        regs[reg].w+=tempw;
                        if (is486) cycles-=((mod==3)?1:2);
                        else       cycles-=((mod==3)?2:6);
                        break;
                        case 0x103: case 0x303: /*ADD reg,32*/
                        fetchea();
                        templ=geteal();
                        setadd32(regs[reg].l,templ);
                        regs[reg].l+=templ;
                        if (is486) cycles-=((mod==3)?1:2);
                        else       cycles-=((mod==3)?2:6);
                        break;
                        case 0x04: case 0x104: case 0x204: case 0x304: /*ADD AL,#8*/
                        temp=fetchdat>>8; pc++;
                        setadd8(AL,temp);
                        AL+=temp;
                        cycles-=(is486)?1:2;
                        break;
                        case 0x05: case 0x205: /*ADD AX,#16*/
                        tempw=fetchdat>>8; pc+=2;
                        setadd16(AX,tempw);
                        AX+=tempw;
                        cycles-=(is486)?1:2;
                        break;
                        case 0x105: case 0x305: /*ADD EAX,#32*/
                        templ=getlong();
                        setadd32(EAX,templ);
                        EAX+=templ;
                        cycles-=(is486)?1:2;
                        break;

                        case 0x06: case 0x206: /*PUSH ES*/
                        if (ssegs) ss=oldss;
                        if (stack32)
                        {
                                writememw(ss,ESP-2,ES);
                                ESP-=2;
                        }
                        else
                        {
                                writememw(ss,((SP-2)&0xFFFF),ES);
                                SP-=2;
                        }
                        cycles-=2;
                        break;
                        case 0x106: case 0x306: /*PUSH ES*/
                        if (ssegs) ss=oldss;
                        if (stack32)
                        {
                                writememl(ss,ESP-4,ES);
                                ESP-=4;
                        }
                        else
                        {
                                writememl(ss,((SP-4)&0xFFFF),ES);
                                SP-=4;
                        }
                        cycles-=2;
                        break;
                        case 0x07: case 0x207: /*POP ES*/
                        if (ssegs) ss=oldss;
                        if (stack32)
                        {
                                tempw=readmemw(ss,ESP);
                                ESP+=2;
                        }
                        else
                        {
                                tempw=readmemw(ss,SP);
                                SP+=2;
                        }
                        loadseg(tempw,&_es);
                        cycles-=(is486)?3:7;
                        break;
                        case 0x107: case 0x307: /*POP ES*/
                        if (ssegs) ss=oldss;
                        if (stack32)
                        {
                                tempw=readmemw(ss,ESP);
                                ESP+=4;
                        }
                        else
                        {
                                tempw=readmemw(ss,SP);
                                SP+=4;
                        }
                        loadseg(tempw,&_es);
                        cycles-=(is486)?3:7;
                        break;

                        case 0x08: case 0x108: case 0x208: case 0x308: /*OR 8,reg*/
                        fetchea();
                        temp=geteab();
                        temp|=getr8(reg);
                        setznp8(temp);
                        flags&=~(C_FLAG|V_FLAG|A_FLAG);
                        seteab(temp);
                        if (is486) cycles-=((mod==3)?1:3);
                        else       cycles-=((mod==3)?2:7);
                        break;
                        case 0x09: case 0x209: /*OR 16,reg*/
                        fetchea();
                        tempw=geteaw();
                        tempw|=regs[reg].w;
                        setznp16(tempw);
                        flags&=~(C_FLAG|V_FLAG|A_FLAG);
                        seteaw(tempw);
                        if (is486) cycles-=((mod==3)?1:3);
                        else       cycles-=((mod==3)?2:7);
                        break;
                        case 0x109: case 0x309: /*OR 32,reg*/
                        fetchea();
                        templ=geteal();
                        templ|=regs[reg].l;
                        setznp32(templ);
                        flags&=~(C_FLAG|V_FLAG|A_FLAG);
                        seteal(templ);
                        if (is486) cycles-=((mod==3)?1:3);
                        else       cycles-=((mod==3)?2:7);
                        break;
                        case 0x0A: case 0x10A: case 0x20A: case 0x30A: /*OR reg,8*/
                        fetchea();
                        temp=geteab();
                        temp|=getr8(reg);
                        setznp8(temp);
                        flags&=~(C_FLAG|V_FLAG|A_FLAG);
                        setr8(reg,temp);
                        if (is486) cycles-=((mod==3)?1:2);
                        else       cycles-=((mod==3)?2:6);
                        break;
                        case 0x0B: case 0x20B: /*OR reg,16*/
                        fetchea();
                        tempw=geteaw();
                        tempw|=regs[reg].w;
                        setznp16(tempw);
                        flags&=~(C_FLAG|V_FLAG|A_FLAG);
                        regs[reg].w=tempw;
                        if (is486) cycles-=((mod==3)?1:2);
                        else       cycles-=((mod==3)?2:6);
                        break;
                        case 0x10B: case 0x30B: /*OR reg,32*/
                        fetchea();
                        templ=geteal();
                        templ|=regs[reg].l;
                        setznp32(templ);
                        flags&=~(C_FLAG|V_FLAG|A_FLAG);
                        regs[reg].l=templ;
                        if (is486) cycles-=((mod==3)?1:2);
                        else       cycles-=((mod==3)?2:6);
                        break;
                        case 0x0C: case 0x10C: case 0x20C: case 0x30C: /*OR AL,#8*/
                        AL|=readmemb(cs,pc); pc++;
                        setznp8(AL);
                        flags&=~(C_FLAG|V_FLAG|A_FLAG);
                        cycles-=(is486)?1:2;
                        break;
                        case 0x0D: case 0x20D: /*OR AX,#16*/
                        AX|=getword();
                        setznp16(AX);
                        flags&=~(C_FLAG|V_FLAG|A_FLAG);
                        cycles-=(is486)?1:2;
                        break;
                        case 0x10D: case 0x30D: /*OR AX,#32*/
                        EAX|=getlong();
                        setznp32(EAX);
                        flags&=~(C_FLAG|V_FLAG|A_FLAG);
                        cycles-=(is486)?1:2;
                        break;

                        case 0x0E: case 0x20E: /*PUSH CS*/
                        if (ssegs) ss=oldss;
                        if (stack32)
                        {
                                writememw(ss,ESP-2,CS);
                                ESP-=2;
                        }
                        else
                        {
                                writememw(ss,((SP-2)&0xFFFF),CS);
                                SP-=2;
                        }
                        cycles-=2;
                        break;
                        case 0x10E: case 0x30E: /*PUSH CS*/
                        if (ssegs) ss=oldss;
                        if (stack32)
                        {
                                writememl(ss,ESP-4,CS);
                                ESP-=4;
                        }
                        else
                        {
                                writememl(ss,((SP-4)&0xFFFF),CS);
                                SP-=4;
                        }
                        cycles-=2;
                        break;

                        case 0x0F: case 0x20F:
                        temp=fetchdat>>8/*readmemb(cs+pc)*/; pc++;
                        opcode2=temp;
//                        if (temp>5 && temp!=0x82 && temp!=0x85 && temp!=0x84 && temp!=0x87 && temp!=0x8D && temp!=0x8F && temp!=0x8C && temp!=0x20 && temp!=0x22) printf("Using magic 386 0F instruction %02X!\n",temp);
                        switch (temp)
                        {
                                case 0:
                                if (!(cr0&1) || (eflags&VM_FLAG)) goto inv16;
                                fetchea2();
                                switch (rmdat&0x38)
                                {
                                        case 0x00: /*SLDT*/
                                        seteaw(ldt.seg);
                                        cycles-=4;
                                        break;
                                        case 0x08: /*STR*/
                                        seteaw(tr.seg);
                                        cycles-=4;
                                        break;
                                        case 0x10: /*LLDT*/
                                        if (!lldt)
                                        {
                                                lldt=1;
                                                ins=0;
//                                                output=1;
                                        }
                                        ldt.seg=geteaw();
//                                        printf("Load LDT %04X ",ldt.seg);
                                        templ=(ldt.seg&~7)+gdt.base;
//                                        printf("%06X ",gdt.base);
                                        ldt.limit=readmemw(0,templ);
                                        ldt.base=(readmemw(0,templ+2))|(readmemb(0,templ+4)<<16)|(readmemb(0,templ+7)<<24);
//                                        printf("%08X %08X %06X\n",readmeml(0,templ),readmeml(0,templ+4),ldt.base);
                                        cycles-=20;
                                        break;
                                        case 0x18: /*LTR*/
                                        tr.seg=geteaw();
                                        templ=(tr.seg&~7)+gdt.base;
                                        tr.limit=readmemw(0,templ);
                                        tr.base=(readmemw(0,templ+2))|(readmemb(0,templ+4)<<16)|(readmemb(0,templ+7)<<24);
                                        tr.access=readmemb(0,templ+5);
                                        cycles-=20;
                                        break;
                                        case 0x20: /*VERR*/
                                        tempw=geteaw();
                                        flags&=~Z_FLAG;
                                        if (!(tempw&0xFFFC)) break; /*Null selector*/
                                        tempi=(tempw&~7)<((tempw&4)?ldt.limit:gdt.limit);
                                        tempw2=readmemw(0,((tempw&4)?ldt.base:gdt.base)+(tempw&~7)+4);
                                        if (!(tempw2&0x1000)) tempi=0;
                                        if ((tempw2&0xC00)!=0xC00) /*Exclude conforming code segments*/
                                        {
                                                tempw3=(tempw2>>13)&3; /*Check permissions*/
                                                if (tempw3<CPL || tempw3<(tempw&3)) tempi=0;
                                        }
                                        if ((tempw2&0x0800) && !(tempw2&0x0200)) tempi=0; /*Non-readable code*/
                                        if (tempi) flags|=Z_FLAG;
                                        cycles-=20;
                                        break;
                                        case 0x28: /*VERW*/
//                                        printf("VERW at %04X(%06X):%04X\n",CS,cs,pc);
                                        tempw=geteaw();
                                        flags&=~Z_FLAG;
                                        if (!(tempw&0xFFFC)) break; /*Null selector*/
                                        tempi=(tempw&~7)<((tempw&4)?ldt.limit:gdt.limit);
                                        tempw2=readmemw(0,((tempw&4)?ldt.base:gdt.base)+(tempw&~7)+4);
                                        if (!(tempw2&0x1000)) tempi=0;
//                                        printf("SEGDAT2 %04X %i\n",tempw2,tempi);
                                        tempw3=(tempw2>>13)&3; /*Check permissions*/
                                        if (tempw3<CPL || tempw3<(tempw&3)) tempi=0;
//                                        printf("Permissions %i\n",tempi);
                                        if (tempw2&0x0800) tempi=0; /*Code*/
                                        else if (!(tempw2&0x0200)) tempi=0; /*Read-only data*/
//                                        printf("Final %i\n",tempi);
                                        if (tempi) flags|=Z_FLAG;
                                        cycles-=20;
                                        break;


                                        default:
                                        printf("Bad 0F 00 opcode %02X\n",rmdat&0x38);
                                        pc-=3;
                                        dumpregs();
                                        exit(-1);
                                }
                                break;
                                case 1:
//                                        printf("FETCHEA2!\n");
                                fetchea2();
                                switch (rmdat&0x38)
                                {
                                        case 0x00: /*SGDT*/
                                        seteaw(gdt.limit);
                                        writememw(easeg,eaaddr+2,gdt.base);
                                        writememb(easeg,eaaddr+4,gdt.base>>16);
                                        cycles-=7; //less seteaw time
//                                        if (msw&1) writememb(easeg+eaaddr+5,gdt.access);
                                        /*else*/       writememb(easeg,eaaddr+5,0xFF);
                                        break;
                                        case 0x08: /*SIDT*/
                                        seteaw(idt.limit);
                                        writememw(easeg,eaaddr+2,idt.base);
                                        writememb(easeg,eaaddr+4,idt.base>>16);
                                        if (msw&1) { writememb(easeg,eaaddr+5,idt.access); }
                                        else       { writememb(easeg,eaaddr+5,0xFF); }
                                        cycles-=7;
                                        break;
                                        case 0x10: /*LGDT*/
//                                        printf("LGDT %08X:%08X %04X:%08X\n",easeg,eaaddr,CS,pc);
                                        if ((CPL || eflags&VM_FLAG) && (cr0&1))
                                        {
                                                printf("Invalid LGDT!\n");
                                                dumpregs();
                                                exit(-1);
                                        }
                                        gdt.limit=geteaw();
                                        gdt.base=readmeml(0,easeg+eaaddr+2)&0xFFFFFF;
//                                        printf("LGDT24 %08X %08X\n",gdt.base,readmeml(0,easeg+eaaddr+2));
//                                        gdt.access=readmemb(easeg+eaaddr+5);
                                        cycles-=11;
                                        break;
                                        case 0x18: /*LIDT*/
                                        if ((CPL || eflags&VM_FLAG) && (cr0&1))
                                        {
                                                printf("Invalid LIDT!\n");
                                                dumpregs();
                                                exit(-1);
                                        }
                                        idt.limit=geteaw();
                                        idt.base=readmeml(0,easeg+eaaddr+2)&0xFFFFFF;
//                                        printf("LIDT24 %08X %08X\n",idt.base,readmeml(0,easeg+eaaddr+2));
//                                        idt.access=readmemb(easeg+eaaddr+5);
                                        cycles-=11;
                                        break;

                                        case 0x20: /*SMSW*/
                                        if (is486) seteaw(msw);
                                        else       seteaw(msw|0xFF00);
                                        cycles-=2;
                                        break;
                                        case 0x30: /*LMSW*/
                                        if ((CPL || eflags&VM_FLAG) && (msw&1))
                                        {
                                                printf("LMSW - ring not zero!\n");
                                                dumpregs();
                                                exit(-1);
                                        }
                                        tempw=geteaw();
                                        if (msw&1) tempw|=1;
//                                        if ((tempw&1) && !(msw&1)) printf("Entering protected mode at %04X:%04X\n",CS,pc);
/*                                        if (!(tempw&1) && (msw&1))
                                        {
                                                printf("Can't leave protected mode on 286!\n");
                                                dumpregs();
                                                exit(-1);
                                        }*/
                                        msw=tempw;
                                        break;

                                        default:
                                        printf("Bad 0F 01 opcode %02X\n",rmdat&0x38);
                                        pc-=3;
                                        dumpregs();
                                        exit(-1);
                                }
                                break;

                                case 2: /*LAR*/
                                fetchea2();
                                tempw=geteaw();
                                flags&=~Z_FLAG;
                                if (!(tempw&0xFFFC)) break; /*Null selector*/
                                tempi=(tempw&~7)<((tempw&4)?ldt.limit:gdt.limit);
                                tempw2=readmemw(0,((tempw&4)?ldt.base:gdt.base)+(tempw&~7)+4);
                                if ((tempw2&0xE00)==0x600) tempi=0; /*Interrupt or trap gate*/
                                if ((tempw2&0xC00)!=0xC00) /*Exclude conforming code segments*/
                                {
                                        tempw3=(tempw2>>13)&3;
                                        if (tempw3<CPL || tempw3<(tempw&3)) tempi=0;
                                }
                                if (tempi)
                                {
                                        flags|=Z_FLAG;
                                        regs[reg].w=readmemb(0,((tempw&4)?ldt.base:gdt.base)+(tempw&~7)+5)<<8;
                                }
                                cycles-=11;
                                break;

                                case 3: /*LSL*/
                                fetchea2();
                                tempw=geteaw();
                                flags&=~Z_FLAG;
                                if (!(tempw&0xFFFC)) break; /*Null selector*/
                                tempi=(tempw&~7)<((tempw&4)?ldt.limit:gdt.limit);
                                tempw2=readmemw(0,((tempw&4)?ldt.base:gdt.base)+(tempw&~7)+4);
                                if ((tempw2&0xE00)==0x600) tempi=0; /*Interrupt or trap gate*/
                                if ((tempw2&0xC00)!=0xC00) /*Exclude conforming code segments*/
                                {
                                        tempw3=(tempw2>>13)&3;
                                        if (tempw3<CPL || tempw3<(tempw&3)) tempi=0;
                                }
                                if (tempi)
                                {
                                        flags|=Z_FLAG;
                                        regs[reg].w=readmemw(0,((tempw&4)?ldt.base:gdt.base)+(tempw&~7));
                                }
                                cycles-=10;
                                break;

                                case 5: /*LOADALL*/
//                                printf("At %04X:%04X  ",CS,pc);
                                flags=readmemw(0,0x818);
                                pc=readmemw(0,0x81A);
                                DS=readmemw(0,0x81E);
                                SS=readmemw(0,0x820);
                                CS=readmemw(0,0x822);
                                ES=readmemw(0,0x824);
                                DI=readmemw(0,0x826);
                                SI=readmemw(0,0x828);
                                BP=readmemw(0,0x82A);
                                SP=readmemw(0,0x82C);
                                BX=readmemw(0,0x82E);
                                DX=readmemw(0,0x830);
                                CX=readmemw(0,0x832);
                                AX=readmemw(0,0x834);
                                if (readmemw(0,0x806))
                                {
                                        printf("Something in LOADALL!\n");
                                        dumpregs();
                                        exit(-1);
                                }
                                es=readmemw(0,0x836)|(readmemb(0,0x838)<<16);
                                cs=readmemw(0,0x83C)|(readmemb(0,0x83E)<<16);
                                ss=readmemw(0,0x842)|(readmemb(0,0x844)<<16);
                                ds=readmemw(0,0x848)|(readmemb(0,0x84A)<<16);
                                cycles-=195;
//                                printf("LOADALL - %06X:%04X %06X:%04X %04X\n",ds,SI,es,DI,DX);
                                break;
                                
                                case 6: /*CLTS*/
                                cr0&=~8;
                                cycles-=5;
                                break;
                                
                                case 9: /*WBINVD*/
                                cycles-=10000;
                                break;

                                case 0x20: /*MOV reg32,CRx*/
                                if ((CPL || (eflags&VM_FLAG)) && (cr0&1))
                                {
                                        printf("Can't load from CRx\n");
                                        x86gpf(NULL,0);
                                        break;
                                }
                                fetchea2();
                                switch (reg)
                                {
                                        case 0:
                                        regs[rm].l=cr0;
                                        if (is486) regs[rm].l|=0x10; /*ET hardwired on 486*/
                                        break;
                                        case 2:
                                        regs[rm].l=cr2;
                                        break;
                                        case 3:
                                        regs[rm].l=cr3;
                                        break;
                                        default:
                                        printf("Bad read of CR%i %i\n",rmdat&7,reg);
                                        dumpregs();
                                        exit(-1);
                                }
                                cycles-=6;
                                break;
                                case 0x21: /*MOV reg32,DRx*/
                                if ((CPL || (eflags&VM_FLAG)) && (cr0&1))
                                {
                                        printf("Can't load from DRx\n");
                                        x86gpf(NULL,0);
                                        break;
                                }
                                fetchea2();
                                regs[rm].l=0;
                                cycles-=6;
                                break;
                                case 0x22: /*MOV CRx,reg32*/
                                if ((CPL || (eflags&VM_FLAG)) && (cr0&1))
                                {
                                        printf("Can't load CRx\n");
                                        x86gpf(NULL,0);
                                        break;
                                }
                                fetchea2();
                                switch (reg)
                                {
                                        case 0:
                                        if ((cr0^regs[rm].l)>>31) flushmmucache();
                                        cr0=regs[rm].l;
                                        if (cr0&0x80000000)
                                        {
//                                                printf("Paging on!!!\n");
//                                                output=3;
//                                                dumpregs();
//                                                exit(-1);
                                        }
                                        break;
                                        case 2:
                                        cr2=regs[rm].l;
                                        break;
                                        case 3:
                                        cr3=regs[rm].l&~0xFFF;
                                        printf("Loading CR3 with %08X at %08X:%08X\n",cr3,cs,pc);
                                        flushmmucache();
                                        break;
                                        default:
                                        printf("Bad load CR%i\n",reg);
                                        dumpregs();
                                        exit(-1);
                                }
                                cycles-=10;
                                break;
                                case 0x23: /*MOV DRx,reg32*/
                                if ((CPL || (eflags&VM_FLAG)) && (cr0&1))
                                {
                                        printf("Can't load DRx\n");
                                        x86gpf(NULL,0);
                                        break;
                                }
                                fetchea2();
                                cycles-=6;
                                break;

                                case 0x82: /*JB*/
                                tempw=getword();
                                if (flags&C_FLAG) { pc+=(signed short)tempw; cycles-=((is486)?2:4); }
                                cycles-=((is486)?1:3);
                                break;
                                case 0x83: /*JNB*/
                                tempw=getword();
                                if (!(flags&C_FLAG)) { pc+=(signed short)tempw; cycles-=((is486)?2:4); }
                                cycles-=((is486)?1:3);
                                break;
                                case 0x84: /*JE*/
                                tempw=getword();
                                if (flags&Z_FLAG) pc+=(signed short)tempw;
                                cycles-=4;
                                break;
                                case 0x85: /*JNE*/
                                tempw=getword();
                                if (!(flags&Z_FLAG)) pc+=(signed short)tempw;
                                cycles-=4;
                                break;
                                case 0x86: /*JBE*/
                                tempw=getword();
                                if (flags&(C_FLAG|Z_FLAG)) { pc+=(signed short)tempw; cycles-=((is486)?2:4); }
                                cycles-=((is486)?1:3);
                                break;
                                case 0x87: /*JNBE*/
                                tempw=getword();
                                if (!(flags&(C_FLAG|Z_FLAG))) { pc+=(signed short)tempw; cycles-=((is486)?2:4); }
                                cycles-=((is486)?1:3);
                                break;
                                case 0x88: /*JS*/
                                tempw=getword();
                                if (flags&N_FLAG) pc+=(signed short)tempw;
                                cycles-=4;
                                break;
                                case 0x89: /*JNS*/
                                tempw=getword();
                                if (!(flags&N_FLAG)) pc+=(signed short)tempw;
                                cycles-=4;
                                break;
                                case 0x8A: /*JP*/
                                tempw=getword();
                                if (flags&P_FLAG) { pc+=(signed short)tempw; cycles-=((is486)?2:4); }
                                cycles-=((is486)?1:3);
                                break;
                                case 0x8B: /*JNP*/
                                tempw=getword();
                                if (!(flags&P_FLAG)) { pc+=(signed short)tempw; cycles-=((is486)?2:4); }
                                cycles-=((is486)?1:3);
                                break;
                                case 0x8C: /*JL*/
                                tempw=getword();
                                temp=(flags&N_FLAG)?1:0;
                                temp2=(flags&V_FLAG)?1:0;
                                if (temp!=temp2)  { pc+=(signed short)tempw; cycles-=((is486)?2:4); }
                                cycles-=((is486)?1:3);
                                break;
                                case 0x8D: /*JNL*/
                                tempw=getword();
                                temp=(flags&N_FLAG)?1:0;
                                temp2=(flags&V_FLAG)?1:0;
                                if (temp==temp2)  { pc+=(signed short)tempw; cycles-=((is486)?2:4); }
                                cycles-=((is486)?1:3);
                                break;
                                case 0x8E: /*JLE*/
                                tempw=getword();
                                temp=(flags&N_FLAG)?1:0;
                                temp2=(flags&V_FLAG)?1:0;
                                if ((flags&Z_FLAG) || (temp!=temp2))  { pc+=(signed short)tempw; cycles-=((is486)?2:4); }
                                cycles-=((is486)?1:3);
                                break;
                                case 0x8F: /*JNLE*/
                                tempw=getword();
                                temp=(flags&N_FLAG)?1:0;
                                temp2=(flags&V_FLAG)?1:0;
                                if (!((flags&Z_FLAG) || (temp!=temp2)))  { pc+=(signed short)tempw; cycles-=((is486)?2:4); }
                                cycles-=((is486)?1:3);
                                break;

                                case 0x92: /*SETC*/
                                fetchea2();
                                seteab((flags&C_FLAG)?1:0);
                                cycles-=4;
                                break;
                                case 0x93: /*SETAE*/
                                fetchea2();
                                seteab((flags&C_FLAG)?0:1);
                                cycles-=4;
                                break;
                                case 0x94: /*SETZ*/
                                fetchea2();
                                seteab((flags&Z_FLAG)?1:0);
                                cycles-=4;
                                break;
                                case 0x95: /*SETNZ*/
                                fetchea2();
                                seteab((flags&Z_FLAG)?0:1);
                                cycles-=4;
                                break;
                                case 0x96: /*SETBE*/
                                fetchea2();
                                seteab((flags&(C_FLAG|Z_FLAG))?1:0);
                                cycles-=4;
                                break;
                                case 0x97: /*SETNBE*/
                                fetchea2();
                                seteab((flags&(C_FLAG|Z_FLAG))?0:1);
                                cycles-=4;
                                break;
                                case 0x98: /*SETS*/
                                fetchea2();
                                seteab((flags&N_FLAG)?1:0);
                                cycles-=4;
                                break;

                                case 0xA0: /*PUSH FS*/
                                if (ssegs) ss=oldss;
                                if (stack32)
                                {
                                        writememw(ss,ESP-2,FS);
                                        ESP-=2;
                                }
                                else
                                {
                                        writememw(ss,((SP-2)&0xFFFF),FS);
                                        SP-=2;
                                }
                                cycles-=2;
                                break;
                                case 0xA1: /*POP FS*/
                                if (ssegs) ss=oldss;
                                if (stack32)
                                {
                                        tempw=readmemw(ss,ESP);
                                        ESP+=2;
                                }
                                else
                                {
                                        tempw=readmemw(ss,SP);
                                        SP+=2;
                                }
                                loadseg(tempw,&_fs);
                                cycles-=(is486)?3:7;
                                break;
                                #if 0
                                case 0xA2: /*CPUID - I know this isn't supported on the 386...*/
                                if (!EAX)
                                {
                                        EAX=0x00000001;
                                        EBX=0x756e6547;
                                        EDX=0x49656e69;
                                        ECX=0x6c65746e;
                                }
                                else if (EAX==1)
                                {
                                        EAX=0x435; /*486*/
                                        EBX=ECX=0;
                                        EDX=;
                                }
                                break;
                                #endif
                                case 0xA3: /*BT r16*/
                                fetchea2();
                                eaaddr+=((regs[reg].w/16)*2);
                                tempw=geteaw();
                                if (tempw&(1<<(regs[reg].w&15))) flags|=C_FLAG;
                                else                             flags&=~C_FLAG;
                                cycles-=3;
                                break;
                                case 0xA4: /*SHLD imm*/
                                fetchea2();
                                temp=readmemb(cs,pc)&31; pc++;
                                if (temp)
                                {
                                        tempw=geteaw();
                                        if ((tempw<<(temp-1))&0x8000) flags|=C_FLAG;
                                        else                          flags&=~C_FLAG;
                                        templ=(tempw<<16)|regs[reg].w;
                                        if (temp<=16) tempw=templ>>(16-temp);
                                        else          tempw=(templ<<temp)>>16;
//                                        tempw=(tempw<<temp)|(regs[reg].w>>(16-temp));
                                        seteaw(tempw);
                                        setznp16(tempw);
                                }
                                cycles-=3;
                                break;
                                case 0xA5: /*SHLD CL*/
                                fetchea2();
                                temp=CL&31;
                                if (temp)
                                {
                                        tempw=geteaw();
                                        if ((tempw<<(temp-1))&0x8000) flags|=C_FLAG;
                                        else                          flags&=~C_FLAG;
                                        templ=(tempw<<16)|regs[reg].w;
                                        if (temp<=16) tempw=templ>>(16-temp);
                                        else          tempw=(templ<<temp)>>16;
//                                        if (temp>15) tempw=(tempw<<temp)|(regs[reg].w>>(16-temp));
//                                        else         tempw=(tempw<<temp)|(regs[reg].w>>(16-temp));
                                        seteaw(tempw);
                                        setznp16(tempw);
                                }
                                cycles-=3;
                                break;
                                case 0xA8: /*PUSH GS*/
                                if (ssegs) ss=oldss;
                                if (stack32)
                                {
                                        writememw(ss,ESP-2,GS);
                                        ESP-=2;
                                }
                                else
                                {
                                        writememw(ss,((SP-2)&0xFFFF),GS);
                                        SP-=2;
                                }
                                cycles-=2;
                                break;
                                case 0xA9: /*POP GS*/
                                if (ssegs) ss=oldss;
                                if (stack32)
                                {
                                        tempw=readmemw(ss,ESP);
                                        ESP+=2;
                                }
                                else
                                {
                                        tempw=readmemw(ss,SP);
                                        SP+=2;
                                }
                                loadseg(tempw,&_gs);
                                cycles-=(is486)?3:7;
                                break;
                                case 0xAB: /*BTS r16*/
                                fetchea2();
                                eaaddr+=((regs[reg].w/16)*2);
                                tempw=geteaw();
                                if (tempw&(1<<(regs[reg].w&15))) flags|=C_FLAG;
                                else                             flags&=~C_FLAG;
                                tempw|=(1<<(regs[reg].w&15));
                                seteaw(tempw);
                                cycles-=6;
                                break;
                                case 0xAC: /*SHRD imm*/
                                fetchea2();
                                temp=readmemb(cs,pc)&31; pc++;
                                if (temp)
                                {
                                        tempw=geteaw();
                                        if ((tempw>>(temp-1))&1) flags|=C_FLAG;
                                        else                     flags&=~C_FLAG;
                                        templ=tempw|(regs[reg].w<<16);
                                        tempw=templ>>temp;
//                                        tempw=(tempw>>temp)|(regs[reg].w<<(16-temp));
                                        seteaw(tempw);
                                        setznp16(tempw);
                                }
                                cycles-=3;
                                break;
                                case 0xAD: /*SHRD CL*/
                                fetchea2();
                                temp=CL&31;
                                if (temp)
                                {
                                        tempw=geteaw();
                                        if ((tempw>>(temp-1))&1) flags|=C_FLAG;
                                        else                     flags&=~C_FLAG;
                                        templ=tempw|(regs[reg].w<<16);
                                        tempw=templ>>temp;
//                                        tempw=(tempw>>temp)|(regs[reg].w<<(16-temp));
                                        seteaw(tempw);
                                        setznp16(tempw);
                                }
                                cycles-=3;
                                break;

                                case 0xAF: /*IMUL reg16,rm16*/
                                fetchea2();
                                temp64i=(int64_t)(signed short)regs[reg].w*(int64_t)(signed short)geteaw();
                                regs[reg].w=temp64i&0xFFFF;
                                if ((temp64i>>16) && (temp64i>>16)!=-1) flags|=C_FLAG|V_FLAG;
                                else                                    flags&=~(C_FLAG|V_FLAG);
                                cycles-=18;
                                break;

                                case 0xB3: /*BTR r16*/
                                fetchea2();
                                eaaddr+=((regs[reg].w/16)*2);
                                tempw=geteaw();
                                if (tempw&(1<<(regs[reg].w&15))) flags|=C_FLAG;
                                else                             flags&=~C_FLAG;
                                tempw&=~(1<<(regs[reg].w&15));
                                seteaw(tempw);
                                cycles-=6;
                                break;

                                case 0xB2: /*LSS*/
//                                output=1;
                                fetchea2();
                                regs[reg].w=readmemw(easeg,eaaddr); //geteaw();
                                tempw=readmemw(easeg,(eaaddr+2)); //geteaw2();
                                printf("LSS16 from %04X:%04X  %04X:%04X\n",easeg,eaaddr,tempw,regs[reg].w);
                                loadseg(tempw,&_ss);
                                oldss=ss;
                                if (!AT) cycles-=24;
                                else     cycles-=7;
                                break;
                                case 0xB4: /*LFS*/
                                fetchea2();
                                regs[reg].w=readmemw(easeg,eaaddr); //geteaw();
                                tempw=readmemw(easeg,(eaaddr+2)); //geteaw2();
                                loadseg(tempw,&_fs);
                                if (!AT) cycles-=24;
                                else     cycles-=7;
                                break;
                                case 0xB5: /*LGS*/
                                fetchea2();
                                regs[reg].w=readmemw(easeg,eaaddr); //geteaw();
                                tempw=readmemw(easeg,(eaaddr+2)); //geteaw2();
                                loadseg(tempw,&_gs);
                                if (!AT) cycles-=24;
                                else     cycles-=7;
                                break;

                                case 0xB6: /*MOVZX b*/
                                fetchea2();
                                regs[reg].w=geteab();
                                cycles-=3;
                                break;
                                case 0xB7: /*MOVZX w*/
                                fetchea2(); /*Slightly pointless?*/
                                regs[reg].w=geteaw();
                                cycles-=3;
                                break;
                                case 0xBE: /*MOVSX b*/
                                fetchea2();
                                regs[reg].w=geteab();
                                if (regs[reg].w&0x80) regs[reg].w|=0xFF00;
                                cycles-=3;
                                break;

                                case 0xBA: /*MORE?!?!?!*/
                                fetchea2();
                                switch (rmdat&0x38)
                                {
                                        case 0x20: /*BT w,imm*/
                                        tempw=geteaw();
                                        temp=readmemb(cs,pc); pc++;
                                        if (tempw&(1<<temp)) flags|=C_FLAG;
                                        else                 flags&=~C_FLAG;
                                        cycles-=6;
                                        break;
                                        case 0x28: /*BTS w,imm*/
                                        tempw=geteaw();
                                        temp=readmemb(cs,pc); pc++;
                                        if (tempw&(1<<temp)) flags|=C_FLAG;
                                        else                 flags&=~C_FLAG;
                                        tempw|=(1<<temp);
                                        seteaw(tempw);
                                        cycles-=6;
                                        break;
                                        case 0x30: /*BTR w,imm*/
                                        tempw=geteaw();
                                        temp=readmemb(cs,pc); pc++;
                                        if (tempw&(1<<temp)) flags|=C_FLAG;
                                        else                 flags&=~C_FLAG;
                                        tempw&=~(1<<temp);
                                        seteaw(tempw);
                                        cycles-=6;
                                        break;
                                        case 0x38: /*BTC w,imm*/
                                        tempw=geteaw();
                                        temp=readmemb(cs,pc); pc++;
                                        if (tempw&(1<<temp)) flags|=C_FLAG;
                                        else                 flags&=~C_FLAG;
                                        tempw^=(1<<temp);
                                        seteaw(tempw);
                                        cycles-=6;
                                        break;

                                        default:
                                        printf("Bad 0F BA opcode %02X\n",rmdat&0x38);
                                        dumpregs();
                                        exit(-1);
                                }
                                break;

                                case 0xBC: /*BSF w*/
                                fetchea2();
                                tempw=geteaw();
                                if (!tempw)
                                {
//                                        regs[reg].w=0;
                                        flags|=Z_FLAG;
                                }
                                else
                                {
                                        for (tempi=0;tempi<16;tempi++)
                                        {
                                                cycles-=(is486)?2:3;
                                                if (tempw&(1<<tempi))
                                                {
                                                        flags&=~Z_FLAG;
                                                        regs[reg].w=tempi;
                                                        break;
                                                }
                                        }
                                }
                                cycles-=(is486)?6:10;
                                break;
                                case 0xBD: /*BSR w*/
                                fetchea2();
                                tempw=geteaw();
                                if (!tempw)
                                {
//                                        regs[reg].w=0;
                                        flags|=Z_FLAG;
                                }
                                else
                                {
                                        for (tempi=15;tempi>=0;tempi--)
                                        {
                                                cycles-=(is486)?6:3;
                                                if (tempw&(1<<tempi))
                                                {
                                                        flags&=~Z_FLAG;
                                                        regs[reg].w=tempi;
                                                        break;
                                                }
                                        }
                                }
                                cycles-=(is486)?6:10;
                                break;

                                case 0xA6: /*XBTS/CMPXCHG486*/
//                                output=1;
                                case 0xFF: /*Invalid - Windows 3.1 syscall trap?*/
                                inv16:
                                pc-=2;
                                if (msw&1)
                                {
                                        pmodeint(6,0);
                                }
                                else
                                {
                                        if (ssegs) ss=oldss;
                                        if (stack32)
                                        {
                                                writememw(ss,ESP-2,flags);
                                                writememw(ss,ESP-4,CS);
                                                writememw(ss,ESP-6,pc);
                                                ESP-=6;
                                        }
                                        else
                                        {
                                                writememw(ss,((SP-2)&0xFFFF),flags);
                                                writememw(ss,((SP-4)&0xFFFF),CS);
                                                writememw(ss,((SP-6)&0xFFFF),pc);
                                                SP-=6;
                                        }
                                        addr=6<<2;
//                                        flags&=~I_FLAG;
                                        oxpc=pc;
                                        pc=readmemw(0,addr);
                                        loadcs(readmemw(0,addr+2));
                                        if (!pc && !cs)
                                        {
                                                printf("Bad int %02X %04X:%04X\n",temp,oldcs,oldpc);
                                                dumpregs();
                                                exit(-1);
                                        }
                                }
                                cycles-=70;
                                break;

                                default:
                                printf("Bad 16-bit 0F opcode %02X 386\n",temp);
                                pc-=2;
                                dumpregs();
                                exit(-1);
                        }
                        break;

                        case 0x10F: case 0x30F:
                        temp=fetchdat>>8/*readmemb(cs+pc)*/; pc++;
                        opcode2=temp;
                        switch (temp)
                        {
                                case 0:
                                if (!(cr0&1) || (eflags&VM_FLAG)) goto inv32;
                                fetchea2();
//                                printf("32-bit op %02X\n",rmdat&0x38);
                                switch (rmdat&0x38)
                                {
                                        case 0x00: /*SLDT*/
                                        seteal(ldt.seg);
                                        cycles-=4;
                                        break;
                                        case 0x08: /*STR*/
                                        seteal(tr.seg);
                                        cycles-=4;
                                        break;
                                        case 0x10: /*LLDT*/
                                        if (!lldt)
                                        {
                                                lldt=1;
                                                ins=0;
//                                                output=1;
                                        }
                                        printf("Load 32 LDT %04X ",ldt.seg);
                                        templ=(ldt.seg&~7)+gdt.base;
                                        printf("%06X ",gdt.base);
                                        ldt.limit=readmemw(0,templ);
                                        ldt.base=(readmemw(0,templ+2))|(readmemb(0,templ+4)<<16)|(readmemb(0,templ+7)<<24);
                                        printf("%08X %08X %06X\n",readmeml(0,templ),readmeml(0,templ+4),ldt.base);
                                        cycles-=20;
                                        break;
                                        case 0x18: /*LTR*/
                                        tr.seg=geteaw();
                                        templ=(tr.seg&~7)+gdt.base;
                                        tr.limit=readmemw(0,templ);
                                        tr.base=(readmemw(0,templ+2))|(readmemb(0,templ+4)<<16)|(readmemb(0,templ+7)<<24);
                                        tr.access=readmemb(0,templ+5);
                                        cycles-=20;
//                                        output=1;
                                        break;
                                        #if 0
                                        case 0x20: /*VERR*/
                                        tempw=geteaw();
                                        flags&=~Z_FLAG;
                                        if (!(tempw&0xFFFC)) break; /*Null selector*/
                                        tempi=(tempw&~7)<((tempw&4)?ldt.limit:gdt.limit);
                                        tempw2=readmemw(0,((tempw&4)?ldt.base:gdt.base)+(tempw&~7)+4);
                                        if (!(tempw2&0x1000)) tempi=0;
                                        if ((tempw2&0xC00)!=0xC00) /*Exclude conforming code segments*/
                                        {
                                                tempw3=(tempw2>>13)&3; /*Check permissions*/
                                                if (tempw3<CPL || tempw3<(tempw&3)) tempi=0;
                                        }
                                        if ((tempw2&0x0800) && !(tempw2&0x0200)) tempi=0; /*Non-readable code*/
                                        if (tempi) flags|=Z_FLAG;
                                        cycles-=20;
                                        break;
                                        case 0x28: /*VERW*/
//                                        printf("VERW at %04X(%06X):%04X\n",CS,cs,pc);
                                        tempw=geteaw();
                                        flags&=~Z_FLAG;
                                        if (!(tempw&0xFFFC)) break; /*Null selector*/
                                        tempi=(tempw&~7)<((tempw&4)?ldt.limit:gdt.limit);
                                        tempw2=readmemw(0,((tempw&4)?ldt.base:gdt.base)+(tempw&~7)+4);
                                        if (!(tempw2&0x1000)) tempi=0;
//                                        printf("SEGDAT2 %04X %i\n",tempw2,tempi);
                                        tempw3=(tempw2>>13)&3; /*Check permissions*/
                                        if (tempw3<CPL || tempw3<(tempw&3)) tempi=0;
//                                        printf("Permissions %i\n",tempi);
                                        if (tempw2&0x0800) tempi=0; /*Code*/
                                        else if (!(tempw2&0x0200)) tempi=0; /*Read-only data*/
//                                        printf("Final %i\n",tempi);
                                        if (tempi) flags|=Z_FLAG;
                                        cycles-=20;
                                        break;
                                        #endif


                                        default:
                                        printf("Bad 0F 00 opcode %02X\n",rmdat&0x38);
                                        pc-=3;
                                        dumpregs();
                                        exit(-1);
                                }
                                break;
                                case 1:
                                fetchea2();
                                switch (rmdat&0x38)
                                {
                                        case 0x00: /*SGDT*/
                                        seteaw(gdt.limit);
                                        writememl(easeg,eaaddr+2,gdt.base);
                                        cycles-=7;
                                        break;
                                        case 0x08: /*SIDT*/
                                        seteaw(idt.limit);
                                        writememl(easeg,eaaddr+2,idt.base);
                                        cycles-=7;
                                        break;
                                        case 0x10: /*LGDT*/
                                        if ((CPL || eflags&VM_FLAG) && (cr0&1))
                                        {
                                                printf("Invalid LGDT32!\n");
                                                dumpregs();
                                                exit(-1);
                                        }
                                        gdt.limit=geteaw();
                                        gdt.base=readmeml(easeg,eaaddr+2);
                                        break;
                                        case 0x18: /*LIDT*/
                                        if ((CPL || eflags&VM_FLAG) && (cr0&1))
                                        {
                                                printf("Invalid LIDT32!\n");
                                                dumpregs();
                                                exit(-1);
                                        }
                                        idt.limit=geteaw();
                                        idt.base=readmeml(easeg,eaaddr+2);
//                                        printf("LIDT32 %08X %08X\n",idt.base,readmeml(0,easeg+eaaddr+2));
                                        cycles-=11;
                                        break;
                                        case 0x20: /*SMSW*/
                                        seteal(cr0); /*Apparently this is the case!*/
                                        cycles-=2;
                                        break;


                                        default:
                                        printf("Bad 0F 01 opcode %02X\n",rmdat&0x38);
                                        pc-=3;
                                        dumpregs();
                                        exit(-1);
                                }
                                break;

                                case 2: /*LAR*/
                                fetchea2();
                                tempw=geteaw();
                                flags&=~Z_FLAG;
                                if (!(tempw&0xFFFC)) break; /*Null selector*/
                                tempi=(tempw&~7)<((tempw&4)?ldt.limit:gdt.limit);
                                tempw2=readmemw(0,((tempw&4)?ldt.base:gdt.base)+(tempw&~7)+4);
                                if ((tempw2&0xE00)==0x600) tempi=0; /*Interrupt or trap gate*/
                                if ((tempw2&0xC00)!=0xC00) /*Exclude conforming code segments*/
                                {
                                        tempw3=(tempw2>>13)&3;
                                        if (tempw3<CPL || tempw3<(tempw&3)) tempi=0;
                                }
                                if (tempi)
                                {
                                        flags|=Z_FLAG;
                                        regs[reg].l=readmeml(0,((tempw&4)?ldt.base:gdt.base)+(tempw&~7)+4)&0xFFFF00;
                                }
                                cycles-=11;
                                break;

                                case 3: /*LSL*/
                                fetchea2();
                                tempw=geteaw();
                                flags&=~Z_FLAG;
                                if (!(tempw&0xFFFC)) break; /*Null selector*/
                                tempi=(tempw&~7)<((tempw&4)?ldt.limit:gdt.limit);
                                tempw2=readmemw(0,((tempw&4)?ldt.base:gdt.base)+(tempw&~7)+4);
                                if ((tempw2&0xE00)==0x600) tempi=0; /*Interrupt or trap gate*/
                                if ((tempw2&0xC00)!=0xC00) /*Exclude conforming code segments*/
                                {
                                        tempw3=(tempw2>>13)&3;
                                        if (tempw3<CPL || tempw3<(tempw&3)) tempi=0;
                                }
                                if (tempi)
                                {
                                        flags|=Z_FLAG;
                                        regs[reg].l=readmemw(0,((tempw&4)?ldt.base:gdt.base)+(tempw&~7));
                                        regs[reg].l|=(readmemb(0,((tempw&4)?ldt.base:gdt.base)+(tempw&~7)+6)&0xF)<<16;
                                        if (readmemb(0,((tempw&4)?ldt.base:gdt.base)+(tempw&~7)+6)&0x80) regs[reg].l<<=12;
                                }
                                cycles-=10;
                                break;

                                case 6: /*CLTS*/
                                cr0&=~8;
                                cycles-=5;
                                break;

                                case 9: /*WBINVD*/
                                cycles-=10000;
                                break;

                                case 0x20: /*MOV reg32,CRx*/
                                if ((CPL || (eflags&VM_FLAG)) && (cr0&1))
                                {
                                        printf("Can't load from CRx\n");
                                        x86gpf(NULL,0);
                                        break;
                                }
                                fetchea2();
                                switch (reg)
                                {
                                        case 0:
                                        regs[rm].l=cr0;
                                        if (is486) regs[rm].l|=0x10; /*ET hardwired on 486*/
                                        break;
                                        case 2:
                                        regs[rm].l=cr2;
                                        break;
                                        case 3:
                                        regs[rm].l=cr3;
                                        break;
                                        default:
                                        printf("Bad read of CR%i %i\n",rmdat&7,reg);
                                        dumpregs();
                                        exit(-1);
                                }
                                cycles-=6;
                                break;
                                case 0x21: /*MOV reg32,DRx*/
                                if ((CPL || (eflags&VM_FLAG)) && (cr0&1))
                                {
                                        printf("Can't load from DRx\n");
                                        x86gpf(NULL,0);
                                        break;
                                }
                                fetchea2();
                                regs[rm].l=0;
                                cycles-=6;
                                break;
                                case 0x22: /*MOV CRx,reg32*/
                                if ((CPL || (eflags&VM_FLAG)) && (cr0&1))
                                {
                                        printf("Can't load CRx\n");
                                        x86gpf(NULL,0);
                                        break;
                                }
                                fetchea2();
                                switch (reg)
                                {
                                        case 0:
                                        if ((cr0^regs[rm].l)>>31) flushmmucache();
                                        cr0=regs[rm].l;
                                        if (cr0&0x80000000)
                                        {
//                                                printf("Paging on!!!\n");
//                                                output=3;
//                                                dumpregs();
//                                                exit(-1);
                                        }
                                        break;
                                        case 2:
                                        cr2=regs[rm].l;
                                        break;
                                        case 3:
                                        cr3=regs[rm].l&~0xFFF;
                                        printf("Loading CR3 with %08X at %08X:%08X\n",cr3,cs,pc);
                                        flushmmucache();
                                        break;
                                        default:
                                        printf("Bad load CR%i\n",reg);
                                        dumpregs();
                                        exit(-1);
                                }
                                cycles-=10;
                                break;
                                case 0x23: /*MOV DRx,reg32*/
                                if ((CPL || (eflags&VM_FLAG)) && (cr0&1))
                                {
                                        printf("Can't load DRx\n");
                                        x86gpf(NULL,0);
                                        break;
                                }
                                fetchea2();
                                cycles-=6;
                                break;

                                case 0x82: /*JB*/
                                templ=getlong();
                                if (flags&C_FLAG) { pc+=templ; cycles-=((is486)?2:4); }
                                cycles-=((is486)?1:3);
                                break;
                                case 0x83: /*JNB*/
                                templ=getlong();
                                if (!(flags&C_FLAG)) { pc+=templ; cycles-=((is486)?2:4); }
                                cycles-=((is486)?1:3);
                                break;
                                case 0x84: /*JE*/
                                templ=getlong();
                                if (flags&Z_FLAG) pc+=templ;
                                cycles-=4;
                                break;
                                case 0x85: /*JNE*/
                                templ=getlong();
                                if (!(flags&Z_FLAG)) pc+=templ;
                                cycles-=4;
                                break;
                                case 0x86: /*JBE*/
                                templ=getlong();
                                if (flags&(C_FLAG|Z_FLAG)) { pc+=templ; cycles-=((is486)?2:4); }
                                cycles-=((is486)?1:3);
                                break;
                                case 0x87: /*JNBE*/
                                templ=getlong();
                                if (!(flags&(C_FLAG|Z_FLAG))) { pc+=templ; cycles-=((is486)?2:4); }
                                cycles-=((is486)?1:3);
                                break;
                                case 0x88: /*JS*/
                                templ=getlong();
                                if (flags&N_FLAG) pc+=templ;
                                cycles-=4;
                                break;
                                case 0x89: /*JNS*/
                                templ=getlong();
                                if (!(flags&N_FLAG)) pc+=templ;
                                cycles-=4;
                                break;
                                case 0x8A: /*JP*/
                                templ=getlong();
                                if (flags&P_FLAG) pc+=templ;
                                cycles-=4;
                                break;
                                case 0x8B: /*JNP*/
                                templ=getlong();
                                if (!(flags&P_FLAG)) pc+=templ;
                                cycles-=4;
                                break;
                                case 0x8C: /*JL*/
                                templ=getlong();
                                temp=(flags&N_FLAG)?1:0;
                                temp2=(flags&V_FLAG)?1:0;
                                if (temp!=temp2)  { pc+=templ; cycles-=((is486)?2:4); }
                                cycles-=((is486)?1:3);
                                break;
                                case 0x8D: /*JNL*/
                                templ=getlong();
                                temp=(flags&N_FLAG)?1:0;
                                temp2=(flags&V_FLAG)?1:0;
                                if (temp==temp2)  { pc+=templ; cycles-=((is486)?2:4); }
                                cycles-=((is486)?1:3);
                                break;
                                case 0x8E: /*JLE*/
                                templ=getlong();
                                temp=(flags&N_FLAG)?1:0;
                                temp2=(flags&V_FLAG)?1:0;
                                if ((flags&Z_FLAG) || (temp!=temp2))  { pc+=templ; cycles-=((is486)?2:4); }
                                cycles-=((is486)?1:3);
                                break;
                                case 0x8F: /*JNLE*/
                                templ=getlong();
                                temp=(flags&N_FLAG)?1:0;
                                temp2=(flags&V_FLAG)?1:0;
                                if (!((flags&Z_FLAG) || (temp!=temp2)))  { pc+=templ; cycles-=((is486)?2:4); }
                                cycles-=((is486)?1:3);
                                break;

                                case 0x90: /*SETO*/
                                fetchea2();
                                seteab((flags&V_FLAG)?1:0);
                                cycles-=4;
                                break;
                                case 0x91: /*SETNO*/
                                fetchea2();
                                seteab((flags&V_FLAG)?0:1);
                                cycles-=4;
                                break;
                                case 0x92: /*SETC*/
                                fetchea2();
                                seteab((flags&C_FLAG)?1:0);
                                cycles-=4;
                                break;
                                case 0x93: /*SETAE*/
                                fetchea2();
                                seteab((flags&C_FLAG)?0:1);
                                cycles-=4;
                                break;
                                case 0x94: /*SETZ*/
                                fetchea2();
                                seteab((flags&Z_FLAG)?1:0);
                                cycles-=4;
                                break;
                                case 0x95: /*SETNZ*/
                                fetchea2();
                                seteab((flags&Z_FLAG)?0:1);
                                cycles-=4;
                                break;
                                case 0x96: /*SETBE*/
                                fetchea2();
                                seteab((flags&(C_FLAG|Z_FLAG))?1:0);
                                cycles-=4;
                                break;
                                case 0x97: /*SETNBE*/
                                fetchea2();
                                seteab((flags&(C_FLAG|Z_FLAG))?0:1);
                                cycles-=4;
                                break;
                                case 0x98: /*SETS*/
                                fetchea2();
                                seteab((flags&N_FLAG)?1:0);
                                cycles-=4;
                                break;
                                case 0x99: /*SETNS*/
                                fetchea2();
                                seteab((flags&N_FLAG)?0:1);
                                cycles-=4;
                                break;
                                case 0x9A: /*SETP*/
                                fetchea2();
                                seteab((flags&P_FLAG)?1:0);
                                cycles-=4;
                                break;
                                case 0x9B: /*SETNP*/
                                fetchea2();
                                seteab((flags&P_FLAG)?0:1);
                                cycles-=4;
                                break;
                                case 0x9C: /*SETL*/
                                fetchea2();
                                temp=(flags&N_FLAG)?1:0;
                                temp2=(flags&V_FLAG)?1:0;
                                seteab(temp^temp2);
                                cycles-=4;
                                break;
                                case 0x9D: /*SETGE*/
                                fetchea2();
                                temp=(flags&N_FLAG)?1:0;
                                temp2=(flags&V_FLAG)?1:0;
                                seteab((temp^temp2)?0:1);
                                cycles-=4;
                                break;
                                case 0x9E: /*SETLE*/
                                fetchea2();
                                temp=(flags&N_FLAG)?1:0;
                                temp2=(flags&V_FLAG)?1:0;
                                seteab(((temp^temp2) || (flags&Z_FLAG))?1:0);
                                cycles-=4;
                                break;
                                case 0x9F: /*SETNLE*/
                                fetchea2();
                                temp=(flags&N_FLAG)?1:0;
                                temp2=(flags&V_FLAG)?1:0;
                                seteab(((temp^temp2) || (flags&Z_FLAG))?0:1);
                                cycles-=4;
                                break;

                                case 0xA0: /*PUSH FS*/
                                if (ssegs) ss=oldss;
                                if (stack32)
                                {
                                        writememl(ss,ESP-4,FS);
                                        ESP-=4;
                                }
                                else
                                {
                                        writememl(ss,((SP-4)&0xFFFF),FS);
                                        SP-=4;
                                }
                                cycles-=2;
                                break;
                                case 0xA1: /*POP FS*/
                                if (ssegs) ss=oldss;
                                if (stack32)
                                {
                                        tempw=readmemw(ss,ESP);
                                        ESP+=4;
                                }
                                else
                                {
                                        tempw=readmemw(ss,SP);
                                        SP+=4;
                                }
                                loadseg(tempw,&_fs);
                                cycles-=(is486)?3:7;
                                break;
                                case 0xA8: /*PUSH GS*/
                                if (ssegs) ss=oldss;
                                if (stack32)
                                {
                                        writememl(ss,ESP-4,GS);
                                        ESP-=4;
                                }
                                else
                                {
                                        writememl(ss,((SP-4)&0xFFFF),GS);
                                        SP-=4;
                                }
                                cycles-=2;
                                break;
                                case 0xA9: /*POP GS*/
                                if (ssegs) ss=oldss;
                                if (stack32)
                                {
                                        tempw=readmemw(ss,ESP);
                                        ESP+=4;
                                }
                                else
                                {
                                        tempw=readmemw(ss,SP);
                                        SP+=4;
                                }
                                loadseg(tempw,&_gs);
                                cycles-=(is486)?3:7;
                                break;

                                case 0xA3: /*BT r32*/
                                fetchea2();
                                eaaddr+=((regs[reg].l/32)*4);
                                templ=geteal();
                                if (templ&(1<<(regs[reg].l&31))) flags|=C_FLAG;
                                else                             flags&=~C_FLAG;
                                cycles-=3;
                                break;
                                case 0xA4: /*SHLD imm*/
                                fetchea2();
                                temp=readmemb(cs,pc)&31; pc++;
                                if (temp)
                                {
                                        templ=geteal();
                                        if ((templ<<(temp-1))&0x80000000) flags|=C_FLAG;
                                        else                              flags&=~C_FLAG;
                                        templ=(templ<<temp)|(regs[reg].l>>(32-temp));
                                        seteal(templ);
                                        setznp32(templ);
                                }
                                cycles-=3;
                                break;
                                case 0xA5: /*SHLD CL*/
                                fetchea2();
                                temp=CL&31;
                                if (temp)
                                {
                                        templ=geteal();
                                        if ((templ<<(temp-1))&0x80000000) flags|=C_FLAG;
                                        else                              flags&=~C_FLAG;
                                        templ=(templ<<temp)|(regs[reg].l>>(32-temp));
                                        seteal(templ);
                                        setznp32(templ);
                                }
                                cycles-=3;
                                break;
                                case 0xAB: /*BTS r32*/
                                fetchea2();
                                eaaddr+=((regs[reg].l/32)*4);
                                templ=geteal();
                                if (templ&(1<<(regs[reg].l&31))) flags|=C_FLAG;
                                else                             flags&=~C_FLAG;
                                templ|=(1<<(regs[reg].l&31));
                                seteal(templ);
                                cycles-=6;
                                break;
                                case 0xAC: /*SHRD imm*/
                                fetchea2();
                                temp=readmemb(cs,pc)&31; pc++;
                                if (temp)
                                {
                                        templ=geteal();
                                        if ((templ>>(temp-1))&1) flags|=C_FLAG;
                                        else                     flags&=~C_FLAG;
                                        templ=(templ>>temp)|(regs[reg].l<<(32-temp));
                                        seteal(templ);
                                        setznp32(templ);
                                }
                                cycles-=3;
                                break;
                                case 0xAD: /*SHRD CL*/
                                fetchea2();
                                temp=CL&31;
                                if (temp)
                                {
                                        templ=geteal();
                                        if ((templ>>(temp-1))&1) flags|=C_FLAG;
                                        else                     flags&=~C_FLAG;
                                        templ=(templ>>temp)|(regs[reg].l<<(32-temp));
                                        seteal(templ);
                                        setznp32(templ);
                                }
                                cycles-=3;
                                break;

                                case 0xAF: /*IMUL reg32,rm32*/
                                fetchea2();
                                temp64i=(int64_t)(signed long)regs[reg].l*(int64_t)(signed long)geteal();
                                regs[reg].l=temp64i&0xFFFFFFFF;
                                if ((temp64i>>32) && (temp64i>>32)!=-1) flags|=C_FLAG|V_FLAG;
                                else                                    flags&=~(C_FLAG|V_FLAG);
                                cycles-=30;
                                break;

                                case 0xB3: /*BTR r32*/
                                fetchea2();
                                eaaddr+=((regs[reg].l/32)*4);
                                templ=geteal();
                                if (templ&(1<<(regs[reg].l&31))) flags|=C_FLAG;
                                else                             flags&=~C_FLAG;
                                templ&=~(1<<(regs[reg].l&31));
                                seteal(templ);
                                cycles-=6;
                                break;

                                case 0xB2: /*LSS*/
                                fetchea2();
                                regs[reg].l=readmeml(easeg,eaaddr); //geteaw();
                                tempw=readmemw(easeg,(eaaddr+4)); //geteaw2();
//                                printf("LSS32 from %04X:%08X  %04X:%08X\n",easeg,eaaddr,tempw,regs[reg].l);
                                loadseg(tempw,&_ss);
                                oldss=ss;
                                if (!AT) cycles-=24;
                                else     cycles-=7;
                                break;
                                case 0xB4: /*LFS*/
                                fetchea2();
                                regs[reg].l=readmeml(easeg,eaaddr); //geteaw();
                                tempw=readmemw(easeg,(eaaddr+4)); //geteaw2();
                                loadseg(tempw,&_fs);
                                if (!AT) cycles-=24;
                                else     cycles-=7;
                                break;
                                case 0xB5: /*LGS*/
                                fetchea2();
                                regs[reg].l=readmeml(easeg,eaaddr); //geteaw();
                                tempw=readmemw(easeg,(eaaddr+4)); //geteaw2();
                                loadseg(tempw,&_gs);
                                if (!AT) cycles-=24;
                                else     cycles-=7;
                                break;

                                case 0xB6: /*MOVZX b*/
                                fetchea2();
                                regs[reg].l=geteab();
                                cycles-=3;
                                break;
                                case 0xB7: /*MOVZX w*/
                                fetchea2();
                                regs[reg].l=geteaw();
                                cycles-=3;
//                                if (pc==0x30B) output=1;
                                break;

                                case 0xBA: /*MORE?!?!?!*/
                                fetchea2();
                                switch (rmdat&0x38)
                                {
                                        case 0x20: /*BT l,imm*/
                                        templ=geteal();
                                        temp=readmemb(cs,pc); pc++;
                                        if (templ&(1<<temp)) flags|=C_FLAG;
                                        else                 flags&=~C_FLAG;
                                        cycles-=6;
                                        break;
                                        case 0x28: /*BTS l,imm*/
                                        templ=geteal();
                                        temp=readmemb(cs,pc); pc++;
                                        if (templ&(1<<temp)) flags|=C_FLAG;
                                        else                 flags&=~C_FLAG;
                                        templ|=(1<<temp);
                                        seteal(templ);
                                        cycles-=6;
                                        break;
                                        case 0x30: /*BTR l,imm*/
                                        templ=geteal();
                                        temp=readmemb(cs,pc); pc++;
                                        if (templ&(1<<temp)) flags|=C_FLAG;
                                        else                 flags&=~C_FLAG;
                                        templ&=~(1<<temp);
                                        seteal(templ);
                                        cycles-=6;
                                        break;
                                        case 0x38: /*BTC l,imm*/
                                        templ=geteal();
                                        temp=readmemb(cs,pc); pc++;
                                        if (templ&(1<<temp)) flags|=C_FLAG;
                                        else                 flags&=~C_FLAG;
                                        templ^=(1<<temp);
                                        seteal(templ);
                                        cycles-=6;
                                        break;

                                        default:
                                        printf("Bad 32-bit 0F BA opcode %02X\n",rmdat&0x38);
                                        dumpregs();
                                        exit(-1);
                                }
                                break;

                                case 0xBB: /*BTC r32*/
                                fetchea2();
                                eaaddr+=((regs[reg].l/32)*4);
                                templ=geteal();
                                if (templ&(1<<(regs[reg].l&31))) flags|=C_FLAG;
                                else                             flags&=~C_FLAG;
                                templ^=(1<<(regs[reg].l&31));
                                seteal(templ);
                                cycles-=6;
                                break;

                                case 0xBC: /*BSF l*/
                                fetchea2();
                                templ=geteal();
                                if (!templ)
                                {
//                                        regs[reg].l=0;
                                        flags|=Z_FLAG;
                                }
                                else
                                {
                                        for (tempi=0;tempi<32;tempi++)
                                        {
                                                cycles-=(is486)?2:3;
                                                if (templ&(1<<tempi))
                                                {
                                                        flags&=~Z_FLAG;
                                                        regs[reg].l=tempi;
                                                        break;
                                                }
                                        }
                                }
                                cycles-=(is486)?6:10;
                                break;
                                case 0xBD: /*BSR l*/
                                fetchea2();
                                templ=geteal();
                                if (!templ)
                                {
//                                        regs[reg].l=0;
                                        flags|=Z_FLAG;
                                }
                                else
                                {
                                        for (tempi=31;tempi>=0;tempi--)
                                        {
                                                cycles-=(is486)?6:3;
                                                if (templ&(1<<tempi))
                                                {
                                                        flags&=~Z_FLAG;
                                                        regs[reg].l=tempi;
                                                        break;
                                                }
                                        }
                                }
                                cycles-=(is486)?6:10;
                                break;

                                case 0xBE: /*MOVSX b*/
                                fetchea2();
                                regs[reg].l=geteab();
                                if (regs[reg].l&0x80) regs[reg].l|=0xFFFFFF00;
                                cycles-=3;
                                break;
                                case 0xBF: /*MOVSX w*/
                                fetchea2();
                                regs[reg].l=geteaw();
                                if (regs[reg].l&0x8000) regs[reg].l|=0xFFFF0000;
                                cycles-=3;
                                break;

                                case 0xC8: case 0xC9: case 0xCA: case 0xCB: /*BSWAP*/
                                case 0xCC: case 0xCD: case 0xCE: case 0xCF: /*486!!!*/
                                regs[opcode&7].l = (regs[opcode&7].l>>24)|((regs[opcode&7].l>>8)&0xFF00)|((regs[opcode&7].l<<8)&0xFF0000)|((regs[opcode&7].l<<24)&0xFF000000);
                                cycles--;
                                break;

                                case 0xFF:
                                inv32:
                                printf("INV32!\n");
                                default:
                                printf("Bad 32-bit 0F opcode %02X 386\n",temp);
                                pc-=2;
                                dumpregs();
                                exit(-1);
                        }
                        break;

/*                        case 0x66:
                        pc--;
                                if (msw&1)
                                {
                                        pmodeint(6,0);
                                }
                                else
                                {
                                        if (ssegs) ss=oldss;
                                        if (AT) writememw(ss,((SP-2)&0xFFFF),flags&~0xF000);
                                        else    writememw(ss,((SP-2)&0xFFFF),flags|0xF000);
                                        writememw(ss,((SP-4)&0xFFFF),CS);
                                        writememw(ss,((SP-6)&0xFFFF),pc);
                                        SP-=6;
                                        addr=6<<2;
//                                        flags&=~I_FLAG;
                                        pc=readmemw(0,addr);
                                        loadcs(readmemw(0,addr+2));
                                        if (!pc && !cs)
                                        {
                                                printf("Bad int %02X %04X:%04X\n",temp,oldcs,oldpc);
                                                dumpregs();
                                                exit(-1);
                                        }
                                }
                                cycles-=70;
                                break;*/

                        case 0x10: case 0x110: case 0x210: case 0x310: /*ADC 8,reg*/
                        fetchea();
                        temp=geteab();
                        temp2=getr8(reg);
                        setadc8(temp,temp2);
                        temp+=temp2+tempc;
                        seteab(temp);
                        if (is486) cycles-=((mod==3)?1:3);
                        else       cycles-=((mod==3)?2:7);
                        break;
                        case 0x11: case 0x211: /*ADC 16,reg*/
                        fetchea();
                        tempw=geteaw();
                        tempw2=regs[reg].w;
                        setadc16(tempw,tempw2);
                        tempw+=tempw2+tempc;
                        seteaw(tempw);
                        if (is486) cycles-=((mod==3)?1:3);
                        else       cycles-=((mod==3)?2:7);
                        break;
                        case 0x111: case 0x311: /*ADC 32,reg*/
                        fetchea();
                        templ=geteal();
                        templ2=regs[reg].l;
                        setadc32(templ,templ2);
                        templ+=templ2+tempc;
                        seteal(templ);
                        if (is486) cycles-=((mod==3)?1:3);
                        else       cycles-=((mod==3)?2:7);
                        break;
                        case 0x12: case 0x112: case 0x212: case 0x312: /*ADC reg,8*/
                        fetchea();
                        temp=geteab();
                        setadc8(getr8(reg),temp);
                        setr8(reg,getr8(reg)+temp+tempc);
                        if (is486) cycles-=((mod==3)?1:2);
                        else       cycles-=((mod==3)?2:6);
                        break;
                        case 0x13: case 0x213: /*ADC reg,16*/
                        fetchea();
                        tempw=geteaw();
                        setadc16(regs[reg].w,tempw);
                        regs[reg].w+=tempw+tempc;
                        if (is486) cycles-=((mod==3)?1:2);
                        else       cycles-=((mod==3)?2:6);
                        break;
                        case 0x113: case 0x313: /*ADC reg,32*/
                        fetchea();
                        templ=geteal();
                        setadc32(regs[reg].l,templ);
                        regs[reg].l+=templ+tempc;
                        if (is486) cycles-=((mod==3)?1:2);
                        else       cycles-=((mod==3)?2:6);
                        break;
                        case 0x14: case 0x114: case 0x214: case 0x314: /*ADC AL,#8*/
                        tempw=readmemb(cs,pc); pc++;
                        setadc8(AL,tempw);
                        AL+=tempw+tempc;
                        cycles-=(is486)?1:2;
                        break;
                        case 0x15: case 0x215: /*ADC AX,#16*/
                        tempw=getword();
                        setadc16(AX,tempw);
                        AX+=tempw+tempc;
                        cycles-=(is486)?1:2;
                        break;
                        case 0x115: case 0x315: /*ADC EAX,#32*/
                        templ=getlong();
                        setadc32(EAX,templ);
                        EAX+=templ+tempc;
                        cycles-=(is486)?1:2;
                        break;

                        case 0x16: case 0x216: /*PUSH SS*/
                        if (ssegs) ss=oldss;
                        if (stack32)
                        {
                                writememw(ss,ESP-2,SS);
                                ESP-=2;
                        }
                        else
                        {
                                writememw(ss,((SP-2)&0xFFFF),SS);
                                SP-=2;
                        }
                        cycles-=2;
                        break;
                        case 0x116: case 0x316: /*PUSH SS*/
                        if (ssegs) ss=oldss;
                        if (stack32)
                        {
                                writememl(ss,ESP-4,SS);
                                ESP-=4;
                        }
                        else
                        {
                                writememl(ss,((SP-4)&0xFFFF),SS);
                                SP-=4;
                        }
                        cycles-=2;
                        break;
                        case 0x17: case 0x217: /*POP SS*/
                        if (ssegs) ss=oldss;
                        if (stack32)
                        {
                                tempw=readmemw(ss,ESP);
                                ESP+=2;
                        }
                        else
                        {
                                tempw=readmemw(ss,SP);
                                SP+=2;
                        }
                        loadseg(tempw,&_ss);
                        cycles-=(is486)?3:7;
                        break;
                        case 0x117: case 0x317: /*POP SS*/
                        if (ssegs) ss=oldss;
                        if (stack32)
                        {
                                tempw=readmemw(ss,ESP);
                                ESP+=4;
                        }
                        else
                        {
                                tempw=readmemw(ss,SP);
                                SP+=4;
                        }
                        loadseg(tempw,&_ss);
                        cycles-=(is486)?3:7;
                        break;

                        case 0x18: case 0x118: case 0x218: case 0x318: /*SBB 8,reg*/
                        fetchea();
                        temp=geteab();
                        temp2=getr8(reg);
                        setsbc8(temp,temp2);
                        temp-=(temp2+tempc);
                        seteab(temp);
                        if (is486) cycles-=((mod==3)?1:3);
                        else       cycles-=((mod==3)?2:7);
                        break;
                        case 0x19: case 0x219: /*SBB 16,reg*/
                        fetchea();
                        tempw=geteaw();
                        tempw2=regs[reg].w;
                        setsbc16(tempw,tempw2);
                        tempw-=(tempw2+tempc);
                        seteaw(tempw);
                        if (is486) cycles-=((mod==3)?1:3);
                        else       cycles-=((mod==3)?2:7);
                        break;
                        case 0x119: case 0x319: /*SBB 32,reg*/
                        fetchea();
                        templ=geteal();
                        templ2=regs[reg].l;
                        setsbc32(templ,templ2);
                        templ-=(templ2+tempc);
                        seteal(templ);
                        if (is486) cycles-=((mod==3)?1:3);
                        else       cycles-=((mod==3)?2:7);
                        break;
                        case 0x1A: case 0x11A: case 0x21A: case 0x31A: /*SBB reg,8*/
                        fetchea();
                        temp=geteab();
                        setsbc8(getr8(reg),temp);
                        setr8(reg,getr8(reg)-(temp+tempc));
                        if (is486) cycles-=((mod==3)?1:2);
                        else       cycles-=((mod==3)?2:6);
                        break;
                        case 0x1B: case 0x21B: /*SBB reg,16*/
                        fetchea();
                        tempw=geteaw();
                        tempw2=regs[reg].w;
                        setsbc16(tempw2,tempw);
                        tempw2-=(tempw+tempc);
                        regs[reg].w=tempw2;
                        if (is486) cycles-=((mod==3)?1:2);
                        else       cycles-=((mod==3)?2:6);
                        break;
                        case 0x11B: case 0x31B: /*SBB reg,32*/
                        fetchea();
                        templ=geteal();
                        templ2=regs[reg].l;
                        setsbc32(templ2,templ);
                        templ2-=(templ+tempc);
                        regs[reg].l=templ2;
                        if (is486) cycles-=((mod==3)?1:2);
                        else       cycles-=((mod==3)?2:6);
                        break;
                        case 0x1C: case 0x11C: case 0x21C: case 0x31C: /*SBB AL,#8*/
                        temp=readmemb(cs,pc); pc++;
                        setsbc8(AL,temp);
                        AL-=(temp+tempc);
                        cycles-=(is486)?1:2;
                        break;
                        case 0x1D: case 0x21D: /*SBB AX,#16*/
                        tempw=getword();
                        setsbc16(AX,tempw);
                        AX-=(tempw+tempc);
                        cycles-=(is486)?1:2;
                        break;
                        case 0x11D: case 0x31D: /*SBB AX,#32*/
                        templ=getlong();
                        setsbc32(EAX,templ);
                        EAX-=(templ+tempc);
                        cycles-=(is486)?1:2;
                        break;

                        case 0x1E: case 0x21E: /*PUSH DS*/
                        if (ssegs) ss=oldss;
                        if (stack32)
                        {
//                                if (cr0&1) printf("PUSH DS %04X %08X\n",DS,ESP-2);
                                writememw(ss,ESP-2,DS);
                                ESP-=2;
                        }
                        else
                        {
//                                if (cr0&1) printf("PUSH DS %04X %04X %08X\n",DS,SP-2,pc);
//                                if (DS==0x00A0 && (SP-2)==0x6E06 && pc==0x00004C37) output=3;
                                writememw(ss,((SP-2)&0xFFFF),DS);
                                SP-=2;
                        }
                        cycles-=2;
                        break;
                        case 0x11E: case 0x31E: /*PUSH DS*/
                        if (ssegs) ss=oldss;
                        if (stack32)
                        {
//                                if (cr0&1) printf("PUSH DS %04X %08X\n",DS,ESP-4);
                                writememl(ss,ESP-4,DS);
                                ESP-=4;
                        }
                        else
                        {
//                                if (cr0&1) printf("PUSH DS %04X %04X %08X\n",DS,SP-4,pc);
//                                if (DS==0x00A0 && (SP-4)==0x6E06 && pc==0x00004C37) output=3;
                                writememl(ss,((SP-4)&0xFFFF),DS);
                                SP-=4;
                        }
                        cycles-=2;
                        break;
                        case 0x1F: case 0x21F: /*POP DS*/
                        if (ssegs) ss=oldss;
                        if (stack32)
                        {
                                tempw=readmemw(ss,ESP);
//                                if (cr0&1) printf("POP DS %04X %08X\n",tempw,ESP);
                                ESP+=2;
                        }
                        else
                        {
                                tempw=readmemw(ss,SP);
//                                if (cr0&1) printf("POP DS %04X %04X\n",tempw,SP);
                                SP+=2;
                        }
                        loadseg(tempw,&_ds);
                        cycles-=(is486)?3:7;
                        break;
                        case 0x11F: case 0x31F: /*POP DS*/
                        if (ssegs) ss=oldss;
                        if (stack32)
                        {
                                tempw=readmemw(ss,ESP);
//                                if (cr0&1) printf("POP DS %04X %08X\n",tempw,ESP);
                                ESP+=4;
                        }
                        else
                        {
                                tempw=readmemw(ss,SP);
//                                if (cr0&1) printf("POP DS %04X %04X\n",tempw,SP);
                                SP+=4;
                        }
                        loadseg(tempw,&_ds);
                        cycles-=(is486)?3:7;
                        break;

                        case 0x20: case 0x120: case 0x220: case 0x320: /*AND 8,reg*/
                        fetchea();
                        temp=geteab();
                        temp&=getr8(reg);
                        setznp8(temp);
                        flags&=~(C_FLAG|V_FLAG|A_FLAG);
                        seteab(temp);
                        if (is486) cycles-=((mod==3)?1:3);
                        else       cycles-=((mod==3)?2:7);
                        break;
                        case 0x21: case 0x221: /*AND 16,reg*/
                        fetchea();
                        tempw=geteaw();
                        tempw&=regs[reg].w;
                        setznp16(tempw);
                        flags&=~(C_FLAG|V_FLAG|A_FLAG);
                        seteaw(tempw);
                        if (is486) cycles-=((mod==3)?1:3);
                        else       cycles-=((mod==3)?2:7);
                        break;
                        case 0x121: case 0x321: /*AND 32,reg*/
                        fetchea();
                        templ=geteal();
                        templ&=regs[reg].l;
                        setznp32(templ);
                        flags&=~(C_FLAG|V_FLAG|A_FLAG);
                        seteal(templ);
                        if (is486) cycles-=((mod==3)?1:3);
                        else       cycles-=((mod==3)?2:7);
                        break;
                        case 0x22: case 0x122: case 0x222: case 0x322: /*AND reg,8*/
                        fetchea();
                        temp=geteab();
                        temp&=getr8(reg);
                        setznp8(temp);
                        flags&=~(C_FLAG|V_FLAG|A_FLAG);
                        setr8(reg,temp);
                        if (is486) cycles-=((mod==3)?1:2);
                        else       cycles-=((mod==3)?2:6);
                        break;
                        case 0x23: case 0x223: /*AND reg,16*/
                        fetchea();
                        tempw=geteaw();
                        tempw&=regs[reg].w;
                        setznp16(tempw);
                        flags&=~(C_FLAG|V_FLAG|A_FLAG);
                        regs[reg].w=tempw;
                        if (is486) cycles-=((mod==3)?1:2);
                        else       cycles-=((mod==3)?2:6);
                        break;
                        case 0x123: case 0x323: /*AND reg,32*/
                        fetchea();
                        templ=geteal();
                        templ&=regs[reg].l;
                        setznp32(templ);
                        flags&=~(C_FLAG|V_FLAG|A_FLAG);
                        regs[reg].l=templ;
                        if (is486) cycles-=((mod==3)?1:2);
                        else       cycles-=((mod==3)?2:6);
                        break;
                        case 0x24: case 0x124: case 0x224: case 0x324: /*AND AL,#8*/
                        AL&=readmemb(cs,pc); pc++;
                        setznp8(AL);
                        flags&=~(C_FLAG|V_FLAG|A_FLAG);
                        cycles-=(is486)?1:2;
                        break;
                        case 0x25: case 0x225: /*AND AX,#16*/
                        AX&=getword();
                        setznp16(AX);
                        flags&=~(C_FLAG|V_FLAG|A_FLAG);
                        cycles-=(is486)?1:2;
                        break;
                        case 0x125: case 0x325: /*AND EAX,#32*/
                        EAX&=getlong();
                        setznp32(EAX);
                        flags&=~(C_FLAG|V_FLAG|A_FLAG);
                        cycles-=(is486)?1:2;
                        break;

                        case 0x26: case 0x126: case 0x226: case 0x326: /*ES:*/
                        oldss=ss;
                        oldds=ds;
                        ds=ss=es;
                        ssegs=2;
                        cycles-=4;
                        goto opcodestart;
//                        break;

                        case 0x27: case 0x127: case 0x227: case 0x327: /*DAA*/
                        if ((flags&A_FLAG) || ((AL&0xF)>9))
                        {
                                tempi=((unsigned short)AL)+6;
                                AL+=6;
                                flags|=A_FLAG;
                                if (tempi&0x100) flags|=C_FLAG;
                        }
//                        else
//                           flags&=~A_FLAG;
                        if ((flags&C_FLAG) || (AL>0x9F))
                        {
                                AL+=0x60;
                                flags|=C_FLAG;
                        }
//                        else
//                           flags&=~C_FLAG;
                        setznp8(AL);
                        cycles-=4;
                        break;

                        case 0x28: case 0x128: case 0x228: case 0x328: /*SUB 8,reg*/
                        fetchea();
                        temp=geteab();
                        setsub8(temp,getr8(reg));
                        temp-=getr8(reg);
                        seteab(temp);
                        if (is486) cycles-=((mod==3)?1:3);
                        else       cycles-=((mod==3)?2:7);
                        break;
                        case 0x29: case 0x229: /*SUB 16,reg*/
                        fetchea();
                        tempw=geteaw();
                        setsub16(tempw,regs[reg].w);
                        tempw-=regs[reg].w;
                        seteaw(tempw);
                        if (is486) cycles-=((mod==3)?1:3);
                        else       cycles-=((mod==3)?2:7);
                        break;
                        case 0x129: case 0x329: /*SUB 32,reg*/
                        fetchea();
                        templ=geteal();
                        setsub32(templ,regs[reg].l);
                        templ-=regs[reg].l;
                        seteal(templ);
                        if (is486) cycles-=((mod==3)?1:3);
                        else       cycles-=((mod==3)?2:7);
                        break;
                        case 0x2A: case 0x12A: case 0x22A: case 0x32A: /*SUB reg,8*/
                        fetchea();
                        temp=geteab();
                        setsub8(getr8(reg),temp);
                        setr8(reg,getr8(reg)-temp);
                        if (is486) cycles-=((mod==3)?1:2);
                        else       cycles-=((mod==3)?2:6);
                        break;
                        case 0x2B: case 0x22B: /*SUB reg,16*/
                        fetchea();
                        tempw=geteaw();
                        setsub16(regs[reg].w,tempw);
                        regs[reg].w-=tempw;
                        if (is486) cycles-=((mod==3)?1:2);
                        else       cycles-=((mod==3)?2:6);
                        break;
                        case 0x12B: case 0x32B: /*SUB reg,32*/
                        fetchea();
                        templ=geteal();
                        setsub32(regs[reg].l,templ);
                        regs[reg].l-=templ;
                        if (is486) cycles-=((mod==3)?1:2);
                        else       cycles-=((mod==3)?2:6);
                        break;
                        case 0x2C: case 0x12C: case 0x22C: case 0x32C: /*SUB AL,#8*/
                        temp=readmemb(cs,pc); pc++;
                        setsub8(AL,temp);
                        AL-=temp;
                        cycles-=(is486)?1:2;
                        break;
                        case 0x2D: case 0x22D: /*SUB AX,#16*/
                        tempw=getword();
                        setsub16(AX,tempw);
                        AX-=tempw;
                        cycles-=(is486)?1:2;
                        break;
                        case 0x12D: case 0x32D: /*SUB EAX,#32*/
                        templ=getlong();
                        setsub32(EAX,templ);
                        EAX-=templ;
                        cycles-=(is486)?1:2;
                        break;
                        case 0x2E: case 0x12E: case 0x22E: case 0x32E: /*CS:*/
                        oldss=ss;
                        oldds=ds;
                        ds=ss=cs;
                        ssegs=2;
                        cycles-=4;
                        goto opcodestart;
                        case 0x2F: case 0x12F: case 0x22F: case 0x32F: /*DAS*/
                        if ((flags&A_FLAG)||((AL&0xF)>9))
                        {
                                tempi=((unsigned short)AL)-6;
                                AL-=6;
                                flags|=A_FLAG;
                                if (tempi&0x100) flags|=C_FLAG;
                        }
//                        else
//                           flags&=~A_FLAG;
                        if ((flags&C_FLAG)||(AL>0x9F))
                        {
                                AL-=0x60;
                                flags|=C_FLAG;
                        }
//                        else
//                           flags&=~C_FLAG;
                        setznp8(AL);
                        cycles-=4;
                        break;
                        case 0x30: case 0x130: case 0x230: case 0x330: /*XOR 8,reg*/
                        fetchea();
                        temp=geteab();
                        temp^=getr8(reg);
                        setznp8(temp);
                        flags&=~(C_FLAG|V_FLAG|A_FLAG);
                        seteab(temp);
                        if (is486) cycles-=((mod==3)?1:3);
                        else       cycles-=((mod==3)?2:7);
                        break;
                        case 0x31: case 0x231: /*XOR 16,reg*/
                        fetchea();
                        tempw=geteaw();
                        tempw^=regs[reg].w;
                        setznp16(tempw);
                        flags&=~(C_FLAG|V_FLAG|A_FLAG);
                        seteaw(tempw);
                        if (is486) cycles-=((mod==3)?1:3);
                        else       cycles-=((mod==3)?2:7);
                        break;
                        case 0x131: case 0x331: /*XOR 32,reg*/
                        fetchea();
                        templ=geteal();
                        templ^=regs[reg].l;
                        setznp32(templ);
                        flags&=~(C_FLAG|V_FLAG|A_FLAG);
                        seteal(templ);
                        if (is486) cycles-=((mod==3)?1:3);
                        else       cycles-=((mod==3)?2:7);
                        break;
                        case 0x32: case 0x132: case 0x232: case 0x332: /*XOR reg,8*/
                        fetchea();
                        temp=geteab();
                        temp^=getr8(reg);
                        setznp8(temp);
                        flags&=~(C_FLAG|V_FLAG|A_FLAG);
                        setr8(reg,temp);
                        if (is486) cycles-=((mod==3)?1:2);
                        else       cycles-=((mod==3)?2:6);
                        break;
                        case 0x33: case 0x233: /*XOR reg,16*/
                        fetchea();
                        tempw=geteaw();
                        tempw^=regs[reg].w;
                        setznp16(tempw);
                        flags&=~(C_FLAG|V_FLAG|A_FLAG);
                        regs[reg].w=tempw;
                        if (is486) cycles-=((mod==3)?1:2);
                        else       cycles-=((mod==3)?2:6);
                        break;
                        case 0x133: case 0x333: /*XOR reg,32*/
                        fetchea();
                        templ=geteal();
                        templ^=regs[reg].l;
                        setznp32(templ);
                        flags&=~(C_FLAG|V_FLAG|A_FLAG);
                        regs[reg].l=templ;
                        if (is486) cycles-=((mod==3)?1:2);
                        else       cycles-=((mod==3)?2:6);
                        break;
                        case 0x34: case 0x134: case 0x234: case 0x334: /*XOR AL,#8*/
                        AL^=readmemb(cs,pc); pc++;
                        setznp8(AL);
                        flags&=~(C_FLAG|V_FLAG|A_FLAG);
                        cycles-=(is486)?1:2;
                        break;
                        case 0x35: case 0x235: /*XOR AX,#16*/
                        AX^=getword();
                        setznp16(AX);
                        flags&=~(C_FLAG|V_FLAG|A_FLAG);
                        cycles-=(is486)?1:2;
                        break;
                        case 0x135: case 0x335: /*XOR EAX,#32*/
                        EAX^=getlong();
                        setznp32(EAX);
                        flags&=~(C_FLAG|V_FLAG|A_FLAG);
                        cycles-=(is486)?1:2;
                        break;

                        case 0x36: case 0x136: case 0x236: case 0x336: /*SS:*/
                        oldss=ss;
                        oldds=ds;
                        ds=ss=ss;
                        ssegs=2;
                        cycles-=4;
                        goto opcodestart;
//                        break;

                        case 0x37: case 0x137: case 0x237: case 0x337: /*AAA*/
                        if ((flags&A_FLAG)||((AL&0xF)>9))
                        {
                                AL+=6;
                                AH++;
                                flags|=(A_FLAG|C_FLAG);
                        }
                        else
                           flags&=~(A_FLAG|C_FLAG);
                        AL&=0xF;
                        cycles-=(is486)?3:4;
                        break;

                        case 0x38: case 0x138: case 0x238: case 0x338: /*CMP 8,reg*/
                        fetchea();
                        temp=geteab();
//                        if (output) printf("CMP %02X-%02X\n",temp,getr8(reg));
                        setsub8(temp,getr8(reg));
                        if (is486) cycles-=((mod==3)?1:2);
                        else       cycles-=((mod==3)?2:5);
                        break;
                        case 0x39: case 0x239: /*CMP 16,reg*/
                        fetchea();
                        tempw=geteaw();
                        setsub16(tempw,regs[reg].w);
                        if (is486) cycles-=((mod==3)?1:2);
                        else       cycles-=((mod==3)?2:5);
                        break;
                        case 0x139: case 0x339: /*CMP 32,reg*/
                        fetchea();
                        templ=geteal();
                        setsub32(templ,regs[reg].l);
                        if (is486) cycles-=((mod==3)?1:2);
                        else       cycles-=((mod==3)?2:5);
                        break;
                        case 0x3A: case 0x13A: case 0x23A: case 0x33A: /*CMP reg,8*/
                        fetchea();
                        temp=geteab();
//                        if (output) printf("CMP %02X-%02X\n",getr8(reg),temp);
                        setsub8(getr8(reg),temp);
                        if (is486) cycles-=((mod==3)?1:2);
                        else       cycles-=((mod==3)?2:6);
                        break;
                        case 0x3B: case 0x23B: /*CMP reg,16*/
                        fetchea();
                        tempw=geteaw();
                        setsub16(regs[reg].w,tempw);
                        if (is486) cycles-=((mod==3)?1:2);
                        else       cycles-=((mod==3)?2:6);
                        break;
                        case 0x13B: case 0x33B: /*CMP reg,32*/
                        fetchea();
                        templ=geteal();
                        setsub32(regs[reg].l,templ);
                        if (is486) cycles-=((mod==3)?1:2);
                        else       cycles-=((mod==3)?2:6);
                        break;
                        case 0x3C: case 0x13C: case 0x23C: case 0x33C: /*CMP AL,#8*/
                        temp=readmemb(cs,pc); pc++;
                        setsub8(AL,temp);
                        cycles-=(is486)?1:2;
                        break;
                        case 0x3D: case 0x23D: /*CMP AX,#16*/
                        tempw=getword();
                        setsub16(AX,tempw);
                        cycles-=(is486)?1:2;
                        break;
                        case 0x13D: case 0x33D: /*CMP EAX,#32*/
                        templ=getlong();
                        setsub32(EAX,templ);
                        cycles-=(is486)?1:2;
                        break;

                        case 0x3E: case 0x13E: case 0x23E: case 0x33E: /*DS:*/
                        oldss=ss;
                        oldds=ds;
                        ds=ss=ds;
                        ssegs=2;
                        cycles-=4;
                        goto opcodestart;
//                        break;

                        case 0x3F: case 0x13F: case 0x23F: case 0x33F: /*AAS*/
                        if ((flags&A_FLAG)||((AL&0xF)>9))
                        {
                                AL-=6;
                                AH--;
                                flags|=(A_FLAG|C_FLAG);
                        }
                        else
                           flags&=~(A_FLAG|C_FLAG);
                        AL&=0xF;
                        cycles-=(is486)?3:4;
                        break;

                        case 0x40: case 0x41: case 0x42: case 0x43: /*INC r16*/
                        case 0x44: case 0x45: case 0x46: case 0x47:
                        case 0x240: case 0x241: case 0x242: case 0x243:
                        case 0x244: case 0x245: case 0x246: case 0x247:
                        setadd16nc(regs[opcode&7].w,1);
                        regs[opcode&7].w++;
                        cycles-=(is486)?1:2;
                        break;
                        case 0x140: case 0x141: case 0x142: case 0x143: /*INC r32*/
                        case 0x144: case 0x145: case 0x146: case 0x147:
                        case 0x340: case 0x341: case 0x342: case 0x343:
                        case 0x344: case 0x345: case 0x346: case 0x347:
                        setadd32nc(regs[opcode&7].l,1);
                        regs[opcode&7].l++;
                        cycles-=(is486)?1:2;
                        break;
                        case 0x48: case 0x49: case 0x4A: case 0x4B: /*DEC r16*/
                        case 0x4C: case 0x4D: case 0x4E: case 0x4F:
                        case 0x248: case 0x249: case 0x24A: case 0x24B:
                        case 0x24C: case 0x24D: case 0x24E: case 0x24F:
                        setsub16nc(regs[opcode&7].w,1);
                        regs[opcode&7].w--;
                        cycles-=(is486)?1:2;
                        break;
                        case 0x148: case 0x149: case 0x14A: case 0x14B: /*DEC r32*/
                        case 0x14C: case 0x14D: case 0x14E: case 0x14F:
                        case 0x348: case 0x349: case 0x34A: case 0x34B:
                        case 0x34C: case 0x34D: case 0x34E: case 0x34F:
                        setsub32nc(regs[opcode&7].l,1);
                        regs[opcode&7].l--;
                        cycles-=(is486)?1:2;
                        break;

                        case 0x50: case 0x51: case 0x52: case 0x53: /*PUSH r16*/
                        case 0x54: case 0x55: case 0x56: case 0x57:
                        case 0x250: case 0x251: case 0x252: case 0x253:
                        case 0x254: case 0x255: case 0x256: case 0x257:
                        if (ssegs) ss=oldss;
                        if (stack32)
                        {
                                writememw(ss,ESP-2,regs[opcode&7].w);
                                ESP-=2;
                        }
                        else
                        {
                                writememw(ss,(SP-2)&0xFFFF,regs[opcode&7].w);
                                SP-=2;
                        }
//                        if (pc>=0x1A1BED && pc<0x1A1C00) printf("PUSH %02X! %08X\n",opcode,ESP);
                        cycles-=(is486)?1:2;
                        break;
                        case 0x150: case 0x151: case 0x152: case 0x153: /*PUSH r32*/
                        case 0x154: case 0x155: case 0x156: case 0x157:
                        case 0x350: case 0x351: case 0x352: case 0x353:
                        case 0x354: case 0x355: case 0x356: case 0x357:
                        if (ssegs) ss=oldss;
                        if (stack32)
                        {
                                writememl(ss,ESP-4,regs[opcode&7].l);
                                ESP-=4;
                        }
                        else
                        {
                                writememl(ss,(SP-4)&0xFFFF,regs[opcode&7].l);
                                SP-=4;
                        }
                        cycles-=(is486)?1:2;
                        break;
                        case 0x58: case 0x59: case 0x5A: case 0x5B: /*POP r16*/
                        case 0x5C: case 0x5D: case 0x5E: case 0x5F:
                        case 0x258: case 0x259: case 0x25A: case 0x25B:
                        case 0x25C: case 0x25D: case 0x25E: case 0x25F:
                        if (ssegs) ss=oldss;
                        if (stack32)
                        {
                                ESP+=2;
                                regs[opcode&7].w=readmemw(ss,ESP-2);
                        }
                        else
                        {
                                SP+=2;
                                regs[opcode&7].w=readmemw(ss,(SP-2)&0xFFFF);
                        }
                        cycles-=(is486)?1:4;
                        break;
                        case 0x158: case 0x159: case 0x15A: case 0x15B: /*POP r32*/
                        case 0x15C: case 0x15D: case 0x15E: case 0x15F:
                        case 0x358: case 0x359: case 0x35A: case 0x35B:
                        case 0x35C: case 0x35D: case 0x35E: case 0x35F:
                        if (ssegs) ss=oldss;
                        if (stack32)
                        {
                                ESP+=4;
                                regs[opcode&7].l=readmeml(ss,ESP-4);
                        }
                        else
                        {
                                SP+=4;
                                regs[opcode&7].l=readmeml(ss,(SP-4)&0xFFFF);
                        }
                        cycles-=(is486)?1:4;
                        break;

                        case 0x60: case 0x260: /*PUSHA*/
                        if (stack32)
                        {
                                writememw(ss,ESP-2,AX);
                                writememw(ss,ESP-4,CX);
                                writememw(ss,ESP-6,DX);
                                writememw(ss,ESP-8,BX);
                                writememw(ss,ESP-10,SP);
                                writememw(ss,ESP-12,BP);
                                writememw(ss,ESP-14,SI);
                                writememw(ss,ESP-16,DI);
                                ESP-=16;
                        }
                        else
                        {
                                writememw(ss,((SP-2)&0xFFFF),AX);
                                writememw(ss,((SP-4)&0xFFFF),CX);
                                writememw(ss,((SP-6)&0xFFFF),DX);
                                writememw(ss,((SP-8)&0xFFFF),BX);
                                writememw(ss,((SP-10)&0xFFFF),SP);
                                writememw(ss,((SP-12)&0xFFFF),BP);
                                writememw(ss,((SP-14)&0xFFFF),SI);
                                writememw(ss,((SP-16)&0xFFFF),DI);
                                SP-=16;
                        }
                        cycles-=(is486)?11:18;
                        break;
                        case 0x61: case 0x261: /*POPA*/
                        if (stack32)
                        {
                                DI=readmemw(ss,ESP);
                                SI=readmemw(ss,ESP+2);
                                BP=readmemw(ss,ESP+4);
                                BX=readmemw(ss,ESP+8);
                                DX=readmemw(ss,ESP+10);
                                CX=readmemw(ss,ESP+12);
                                AX=readmemw(ss,ESP+14);
                                ESP+=16;
                        }
                        else
                        {
                                DI=readmemw(ss,((SP)&0xFFFF));
                                SI=readmemw(ss,((SP+2)&0xFFFF));
                                BP=readmemw(ss,((SP+4)&0xFFFF));
                                BX=readmemw(ss,((SP+8)&0xFFFF));
                                DX=readmemw(ss,((SP+10)&0xFFFF));
                                CX=readmemw(ss,((SP+12)&0xFFFF));
                                AX=readmemw(ss,((SP+14)&0xFFFF));
                                SP+=16;
                        }
                        cycles-=(is486)?9:24;
                        break;
                        case 0x160: case 0x360: /*PUSHA*/
                        if (stack32)
                        {
                                writememl(ss,ESP-4,EAX);
                                writememl(ss,ESP-8,ECX);
                                writememl(ss,ESP-12,EDX);
                                writememl(ss,ESP-16,EBX);
                                writememl(ss,ESP-20,ESP);
                                writememl(ss,ESP-24,EBP);
                                writememl(ss,ESP-28,ESI);
                                writememl(ss,ESP-32,EDI);
                                ESP-=32;
                        }
                        else
                        {
                                writememl(ss,((SP-4)&0xFFFF),EAX);
                                writememl(ss,((SP-8)&0xFFFF),ECX);
                                writememl(ss,((SP-12)&0xFFFF),EDX);
                                writememl(ss,((SP-16)&0xFFFF),EBX);
                                writememl(ss,((SP-20)&0xFFFF),ESP);
                                writememl(ss,((SP-24)&0xFFFF),EBP);
                                writememl(ss,((SP-28)&0xFFFF),ESI);
                                writememl(ss,((SP-32)&0xFFFF),EDI);
                                SP-=32;
                        }
                        cycles-=(is486)?11:18;
                        break;
                        case 0x161: case 0x361: /*POPA*/
                        if (stack32)
                        {
                                EDI=readmeml(ss,ESP);
                                ESI=readmeml(ss,ESP+4);
                                EBP=readmeml(ss,ESP+8);
                                EBX=readmeml(ss,ESP+16);
                                EDX=readmeml(ss,ESP+20);
                                ECX=readmeml(ss,ESP+24);
                                EAX=readmeml(ss,ESP+28);
                                ESP+=32;
                        }
                        else
                        {
                                EDI=readmeml(ss,((SP)&0xFFFF));
                                ESI=readmeml(ss,((SP+4)&0xFFFF));
                                EBP=readmeml(ss,((SP+8)&0xFFFF));
                                EBX=readmeml(ss,((SP+16)&0xFFFF));
                                EDX=readmeml(ss,((SP+20)&0xFFFF));
                                ECX=readmeml(ss,((SP+24)&0xFFFF));
                                EAX=readmeml(ss,((SP+28)&0xFFFF));
                                SP+=32;
                        }
                        cycles-=(is486)?9:24;
                        break;

                        case 0x63: /*ARPL*/
                        if (eflags&VM_FLAG || !(cr0&1))
                        {
//                                printf("ARPL int!\n");
//                                output=3;
                                int6();
//                                printf("INT6 %04X:%04X\n",CS,pc);
                                break;
                                printf("ARPL in real or v86 mode!\n");
                                dumpregs();
                                exit(-1);
                        }
//                        else
//                          printf("ARPL %04X%04X %08X\n",eflags,flags,cr0);
                        fetchea();
                        tempw=geteaw();
                        if ((tempw&3)<(regs[reg].w&3))
                        {
                                tempw=(tempw&0xFFFC)|(regs[reg].w&3);
                                flags|=Z_FLAG;
                        }
                        else
                           flags&=~Z_FLAG;
                        seteaw(tempw);
                        cycles-=(is486)?9:20;
                        break;
                        case 0x64: case 0x164: case 0x264: case 0x364: /*FS:*/
                        oldss=ss;
                        oldds=ds;
                        ds=ss=fs;
                        ssegs=2;
                        cycles-=4;
                        goto opcodestart;
                        case 0x65: case 0x165: case 0x265: case 0x365: /*GS:*/
                        oldss=ss;
                        oldds=ds;
                        ds=ss=gs;
                        ssegs=2;
                        cycles-=4;
                        goto opcodestart;

                        case 0x66: case 0x166: case 0x266: case 0x366: /*Data size select*/
                        op32=((use32&0x100)^0x100)|(op32&0x200);
//                        op32^=0x100;
                        cycles-=2;
                        goto opcodestart;
                        case 0x67: case 0x167: case 0x267: case 0x367: /*Address size select*/
                        op32=((use32&0x200)^0x200)|(op32&0x100);
//                        op32^=0x200;
                        cycles-=2;
                        goto opcodestart;

                        case 0x68: case 0x268: /*PUSH #w*/
                        tempw=getword();
                        if (stack32)
                        {
                                writememw(ss,ESP-2,tempw);
                                ESP-=2;
                        }
                        else
                        {
                                writememw(ss,((SP-2)&0xFFFF),tempw);
                                SP-=2;
                        }
                        cycles-=2;
                        break;
                        case 0x168: case 0x368: /*PUSH #l*/
                        templ=getlong();
                        if (stack32)
                        {
                                writememl(ss,ESP-4,templ);
                                ESP-=4;
                        }
                        else
                        {
                                writememl(ss,((SP-4)&0xFFFF),templ);
                                SP-=4;
                        }
                        cycles-=2;
                        break;
                        case 0x69: case 0x269: /*IMUL r16*/
                        fetchea();
                        tempw=geteaw();
                        tempw2=getword();
                        templ=((int)(signed short)tempw)*((int)(signed short)tempw2);
                        if ((templ>>16)!=0 && (templ>>16)!=0xFFFF) flags|=C_FLAG|V_FLAG;
                        else                                       flags&=~(C_FLAG|V_FLAG);
                        regs[reg].w=templ&0xFFFF;
                        cycles-=((mod==3)?14:17);
                        break;
                        case 0x169: case 0x369: /*IMUL r32*/
                        fetchea();
                        templ=geteal();
                        templ2=getlong();
                        temp64i=((int)(signed long)templ)*((int)(signed long)templ2);
                        if ((temp64i>>32)!=0 && (temp64i>>32)!=-1) flags|=C_FLAG|V_FLAG;
                        else                                       flags&=~(C_FLAG|V_FLAG);
                        regs[reg].l=temp64i&0xFFFFFFFF;
                        cycles-=25;
                        break;
                        case 0x6A: case 0x26A:/*PUSH #eb*/
                        tempw=readmemb(cs,pc); pc++;
                        if (tempw&0x80) tempw|=0xFF00;
                        if (stack32)
                        {
                                writememw(ss,ESP-2,tempw);
                                ESP-=2;
                        }
                        else
                        {
                                writememw(ss,((SP-2)&0xFFFF),tempw);
                                SP-=2;
                        }
                        cycles-=2;
                        break;
                        case 0x16A: case 0x36A:/*PUSH #eb*/
                        templ=readmemb(cs,pc); pc++;
                        if (templ&0x80) templ|=0xFFFFFF00;
                        if (stack32)
                        {
                                writememl(ss,ESP-4,templ);
                                ESP-=4;
                        }
                        else
                        {
                                writememl(ss,((SP-4)&0xFFFF),templ);
                                SP-=4;
                        }
                        cycles-=2;
                        break;
//                        #if 0
                        case 0x6B: case 0x26B: /*IMUL r8*/
                        fetchea();
                        tempw=geteaw();
                        tempw2=readmemb(cs,pc); pc++;
                        if (tempw2&0x80) tempw2|=0xFF00;
                        templ=((int)(signed short)tempw)*((int)(signed short)tempw2);
//                        printf("IMULr8  %08X %08X %08X\n",tempw,tempw2,templ);
                        if ((templ>>16)!=0 && ((templ>>16)&0xFFFF)!=0xFFFF) flags|=C_FLAG|V_FLAG;
                        else                                                flags&=~(C_FLAG|V_FLAG);
                        regs[reg].w=templ&0xFFFF;
                        cycles-=((mod==3)?14:17);
                        break;
                        case 0x16B: case 0x36B: /*IMUL r8*/
                        fetchea();
                        templ=geteal();
                        templ2=readmemb(cs,pc); pc++;
                        if (templ2&0x80) templ2|=0xFFFFFF00;
                        temp64i=((int64_t)(signed long)templ)*((int64_t)(signed long)templ2);
//                        printf("IMULr8  %08X %08X %i\n",templ,templ2,temp64i>>32);
                        if ((temp64i>>32)!=0 && (temp64i>>32)!=-1) flags|=C_FLAG|V_FLAG;
                        else                                       flags&=~(C_FLAG|V_FLAG);
                        regs[reg].l=temp64i&0xFFFFFFFF;
                        cycles-=20;
                        break;
//#endif
                        case 0x6C: case 0x16C: /*INSB*/
                        temp=inb(DX);
                        writememb(es,DI,temp);
                        if (flags&D_FLAG) DI--;
                        else              DI++;
                        cycles-=15;
                        break;
                        case 0x26C: case 0x36C: /*INSB*/
                        temp=inb(DX);
                        writememb(es,EDI,temp);
                        if (flags&D_FLAG) EDI--;
                        else              EDI++;
                        cycles-=15;
                        break;
                        case 0x6E: case 0x16E: /*OUTSB*/
                        temp=readmemb(ds,SI);
                        if (flags&D_FLAG) SI--;
                        else              SI++;
                        outb(DX,temp);
                        cycles-=14;
                        break;
                        case 0x26E: case 0x36E: /*OUTSB*/
                        temp=readmemb(ds,ESI);
                        if (flags&D_FLAG) ESI--;
                        else              ESI++;
                        outb(DX,temp);
                        cycles-=14;
                        break;
                        case 0x6F: /*OUTSW*/
                        tempw=readmemw(ds,SI);
                        if (flags&D_FLAG) SI-=2;
                        else              SI+=2;
                        outb(DX,tempw);
                        outb(DX+1,tempw>>8);
                        cycles-=14;
                        break;
                        case 0x26F: /*OUTSW*/
                        tempw=readmemw(ds,ESI);
                        if (flags&D_FLAG) ESI-=2;
                        else              ESI+=2;
                        outb(DX,tempw);
                        outb(DX+1,tempw>>8);
                        cycles-=14;
                        break;


                        case 0x70: case 0x170: case 0x270: case 0x370: /*JO*/
                        offset=(signed char)readmemb(cs,pc); pc++;
                        if (flags&V_FLAG) { pc+=offset; cycles-=((is486)?2:4); }
                        cycles-=((is486)?1:3);
                        break;
                        case 0x71: case 0x171: case 0x271: case 0x371: /*JNO*/
                        offset=(signed char)readmemb(cs,pc); pc++;
                        if (!(flags&V_FLAG)) { pc+=offset; cycles-=((is486)?2:4); }
                        cycles-=((is486)?1:3);
                        break;
                        case 0x72: case 0x172: case 0x272: case 0x372: /*JB*/
                        offset=(signed char)readmemb(cs,pc); pc++;
                        if (flags&C_FLAG) { pc+=offset; cycles-=((is486)?2:4); }
                        cycles-=((is486)?1:3);
                        break;
                        case 0x73: case 0x173: case 0x273: case 0x373: /*JNB*/
                        offset=(signed char)readmemb(cs,pc); pc++;
                        if (!(flags&C_FLAG)) { pc+=offset; cycles-=((is486)?2:4); }
                        cycles-=((is486)?1:3);
                        break;
                        case 0x74: case 0x174: case 0x274: case 0x374: /*JZ*/
                        offset=(signed char)readmemb(cs,pc); pc++;
                        if (flags&Z_FLAG) { pc+=offset; cycles-=((is486)?2:4); }
                        cycles-=((is486)?1:3);
                        break;
                        case 0x75: case 0x175: case 0x275: case 0x375: /*JNZ*/
                        offset=(signed char)readmemb(cs,pc); pc++;
                        if (!(flags&Z_FLAG)) { pc+=offset; cycles-=((is486)?2:4); }
                        cycles-=((is486)?1:3);
                        break;
                        case 0x76: case 0x176: case 0x276: case 0x376: /*JBE*/
                        offset=(signed char)readmemb(cs,pc); pc++;
                        if (flags&(C_FLAG|Z_FLAG)) { pc+=offset; cycles-=((is486)?2:4); }
                        cycles-=((is486)?1:3);
                        break;
                        case 0x77: case 0x177: case 0x277: case 0x377: /*JNBE*/
                        offset=(signed char)readmemb(cs,pc); pc++;
                        if (!(flags&(C_FLAG|Z_FLAG))) { pc+=offset; cycles-=((is486)?2:4); }
                        cycles-=((is486)?1:3);
                        break;
                        case 0x78: case 0x178: case 0x278: case 0x378: /*JS*/
                        offset=(signed char)readmemb(cs,pc); pc++;
                        if (flags&N_FLAG)  { pc+=offset; cycles-=((is486)?2:4); }
                        cycles-=((is486)?1:3);
                        break;
                        case 0x79: case 0x179: case 0x279: case 0x379: /*JNS*/
                        offset=(signed char)readmemb(cs,pc); pc++;
                        if (!(flags&N_FLAG))  { pc+=offset; cycles-=((is486)?2:4); }
                        cycles-=((is486)?1:3);
                        break;
                        case 0x7A: case 0x17A: case 0x27A: case 0x37A: /*JP*/
                        offset=(signed char)readmemb(cs,pc); pc++;
                        if (flags&P_FLAG)  { pc+=offset; cycles-=((is486)?2:4); }
                        cycles-=((is486)?1:3);
                        break;
                        case 0x7B: case 0x17B: case 0x27B: case 0x37B: /*JNP*/
                        offset=(signed char)readmemb(cs,pc); pc++;
                        if (!(flags&P_FLAG))  { pc+=offset; cycles-=((is486)?2:4); }
                        cycles-=((is486)?1:3);
                        break;
                        case 0x7C: case 0x17C: case 0x27C: case 0x37C: /*JL*/
                        offset=(signed char)readmemb(cs,pc); pc++;
                        temp=(flags&N_FLAG)?1:0;
                        temp2=(flags&V_FLAG)?1:0;
                        if (temp!=temp2)  { pc+=offset; cycles-=((is486)?2:4); }
                        cycles-=((is486)?1:3);
                        break;
                        case 0x7D: case 0x17D: case 0x27D: case 0x37D: /*JNL*/
                        offset=(signed char)readmemb(cs,pc); pc++;
                        temp=(flags&N_FLAG)?1:0;
                        temp2=(flags&V_FLAG)?1:0;
                        if (temp==temp2)  { pc+=offset; cycles-=((is486)?2:4); }
                        cycles-=((is486)?1:3);
                        break;
                        case 0x7E: case 0x17E: case 0x27E: case 0x37E: /*JLE*/
                        offset=(signed char)readmemb(cs,pc); pc++;
                        temp=(flags&N_FLAG)?1:0;
                        temp2=(flags&V_FLAG)?1:0;
                        if ((flags&Z_FLAG) || (temp!=temp2))  { pc+=offset; cycles-=((is486)?2:4); }
                        cycles-=((is486)?1:3);
                        break;
                        case 0x7F: case 0x17F: case 0x27F: case 0x37F: /*JNLE*/
                        offset=(signed char)readmemb(cs,pc); pc++;
                        temp=(flags&N_FLAG)?1:0;
                        temp2=(flags&V_FLAG)?1:0;
                        if (!((flags&Z_FLAG) || (temp!=temp2)))  { pc+=offset; cycles-=((is486)?2:4); }
                        cycles-=((is486)?1:3);
                        break;

                        case 0x80: case 0x180: case 0x280: case 0x380:
                        case 0x82: case 0x182: case 0x282: case 0x382:
                        fetchea();
                        temp=geteab();
                        temp2=readmemb(cs,pc); pc++;
                        switch (rmdat&0x38)
                        {
                                case 0x00: /*ADD b,#8*/
                                setadd8(temp,temp2);
                                seteab(temp+temp2);
                                if (is486) cycles-=((mod==3)?1:3);
                                else       cycles-=((mod==3)?2:7);
                                break;
                                case 0x08: /*OR b,#8*/
                                temp|=temp2;
                                setznp8(temp);
                                flags&=~(C_FLAG|V_FLAG|A_FLAG);
                                seteab(temp);
                                if (is486) cycles-=((mod==3)?1:3);
                                else       cycles-=((mod==3)?2:7);
                                break;
                                case 0x10: /*ADC b,#8*/
//                                temp2+=(flags&C_FLAG);
                                setadc8(temp,temp2);
                                seteab(temp+temp2+tempc);
                                if (is486) cycles-=((mod==3)?1:3);
                                else       cycles-=((mod==3)?2:7);
                                break;
                                case 0x18: /*SBB b,#8*/
//                                temp2+=(flags&C_FLAG);
                                setsbc8(temp,temp2);
                                seteab(temp-(temp2+tempc));
                                if (is486) cycles-=((mod==3)?1:3);
                                else       cycles-=((mod==3)?2:7);
                                break;
                                case 0x20: /*AND b,#8*/
                                temp&=temp2;
                                setznp8(temp);
                                flags&=~(C_FLAG|V_FLAG|A_FLAG);
                                seteab(temp);
                                if (is486) cycles-=((mod==3)?1:3);
                                else       cycles-=((mod==3)?2:7);
                                break;
                                case 0x28: /*SUB b,#8*/
                                setsub8(temp,temp2);
                                seteab(temp-temp2);
                                if (is486) cycles-=((mod==3)?1:3);
                                else       cycles-=((mod==3)?2:7);
                                break;
                                case 0x30: /*XOR b,#8*/
                                temp^=temp2;
                                setznp8(temp);
                                flags&=~(C_FLAG|V_FLAG|A_FLAG);
                                seteab(temp);
                                if (is486) cycles-=((mod==3)?1:3);
                                else       cycles-=((mod==3)?2:7);
                                break;
                                case 0x38: /*CMP b,#8*/
//                                printf("CMP %02X,%02X\n",temp,temp2);
//                                if (output) printf("83CMP %02X-%02X\n",temp,temp2);
                                setsub8(temp,temp2);
                                if (is486) cycles-=((mod==3)?1:2);
                                else       cycles-=((mod==3)?2:7);
                                break;

                                default:
                                printf("Bad 80 opcode %02X\n",rmdat&0x38);
//                                dumpregs();
//                                exit(-1);
                        }
                        break;

                        case 0x81: case 0x281:
                        fetchea();
                        tempw=geteaw();
                        tempw2=getword();
                        switch (rmdat&0x38)
                        {
                                case 0x00: /*ADD w,#16*/
                                setadd16(tempw,tempw2);
                                tempw+=tempw2;
                                seteaw(tempw);
                                if (is486) cycles-=((mod==3)?1:3);
                                else       cycles-=((mod==3)?2:7);
                                break;
                                case 0x08: /*OR w,#16*/
                                tempw|=tempw2;
                                setznp16(tempw);
                                flags&=~(C_FLAG|V_FLAG|A_FLAG);
                                seteaw(tempw);
                                if (is486) cycles-=((mod==3)?1:3);
                                else       cycles-=((mod==3)?2:7);
                                break;
                                case 0x10: /*ADC w,#16*/
//                                tempw2+=(flags&C_FLAG);
                                setadc16(tempw,tempw2);
                                tempw+=tempw2+tempc;
                                seteaw(tempw);
                                if (is486) cycles-=((mod==3)?1:3);
                                else       cycles-=((mod==3)?2:7);
                                break;
                                case 0x20: /*AND w,#16*/
                                tempw&=tempw2;
                                setznp16(tempw);
                                flags&=~(C_FLAG|V_FLAG|A_FLAG);
                                seteaw(tempw);
                                if (is486) cycles-=((mod==3)?1:3);
                                else       cycles-=((mod==3)?2:7);
                                break;
                                case 0x18: /*SBB w,#16*/
//                                tempw2+=(flags&C_FLAG);
                                setsbc16(tempw,tempw2);
                                seteaw(tempw-(tempw2+tempc));
                                if (is486) cycles-=((mod==3)?1:3);
                                else       cycles-=((mod==3)?2:7);
                                break;
                                case 0x28: /*SUB w,#16*/
                                setsub16(tempw,tempw2);
                                tempw-=tempw2;
                                seteaw(tempw);
                                if (is486) cycles-=((mod==3)?1:3);
                                else       cycles-=((mod==3)?2:7);
                                break;
                                case 0x30: /*XOR w,#16*/
                                tempw^=tempw2;
                                setznp16(tempw);
                                flags&=~(C_FLAG|V_FLAG|A_FLAG);
                                seteaw(tempw);
                                if (is486) cycles-=((mod==3)?1:3);
                                else       cycles-=((mod==3)?2:7);
                                break;
                                case 0x38: /*CMP w,#16*/
//                                printf("CMP %04X %04X\n",tempw,tempw2);
                                setsub16(tempw,tempw2);
                                if (is486) cycles-=((mod==3)?1:2);
                                else       cycles-=((mod==3)?2:7);
                                break;

                                default:
                                printf("Bad 81 opcode %02X\n",rmdat&0x38);
//                                dumpregs();
//                                exit(-1);
                        }
                        break;
                        case 0x181: case 0x381:
                        fetchea();
                        templ=geteal();
                        templ2=getlong();
                        switch (rmdat&0x38)
                        {
                                case 0x00: /*ADD l,#32*/
                                setadd32(templ,templ2);
                                templ+=templ2;
                                seteal(templ);
                                if (is486) cycles-=((mod==3)?1:3);
                                else       cycles-=((mod==3)?2:7);
                                break;
                                case 0x08: /*OR l,#32*/
                                templ|=templ2;
                                setznp32(templ);
                                flags&=~(C_FLAG|V_FLAG|A_FLAG);
                                seteal(templ);
                                if (is486) cycles-=((mod==3)?1:3);
                                else       cycles-=((mod==3)?2:7);
                                break;
                                case 0x10: /*ADC l,#32*/
                                setadc32(templ,templ2);
                                templ+=templ2+tempc;
                                seteal(templ);
                                if (is486) cycles-=((mod==3)?1:3);
                                else       cycles-=((mod==3)?2:7);
                                break;
                                case 0x20: /*AND l,#32*/
                                templ&=templ2;
                                setznp32(templ);
                                flags&=~(C_FLAG|V_FLAG|A_FLAG);
                                seteal(templ);
                                if (is486) cycles-=((mod==3)?1:3);
                                else       cycles-=((mod==3)?2:7);
                                break;
                                case 0x18: /*SBB l,#32*/
                                setsbc32(templ,templ2);
                                seteal(templ-(templ2+tempc));
                                if (is486) cycles-=((mod==3)?1:3);
                                else       cycles-=((mod==3)?2:7);
                                break;
                                case 0x28: /*SUB l,#32*/
                                setsub32(templ,templ2);
                                templ-=templ2;
                                seteal(templ);
                                if (is486) cycles-=((mod==3)?1:3);
                                else       cycles-=((mod==3)?2:7);
                                break;
                                case 0x30: /*XOR l,#32*/
                                templ^=templ2;
                                setznp32(templ);
                                flags&=~(C_FLAG|V_FLAG|A_FLAG);
                                seteal(templ);
                                if (is486) cycles-=((mod==3)?1:3);
                                else       cycles-=((mod==3)?2:7);
                                break;
                                case 0x38: /*CMP l,#32*/
                                setsub32(templ,templ2);
                                if (is486) cycles-=((mod==3)?1:2);
                                else       cycles-=((mod==3)?2:7);
                                break;

                                default:
                                printf("Bad 81 opcode %02X\n",rmdat&0x38);
//                                dumpregs();
//                                exit(-1);
                        }
                        break;

                        case 0x83: case 0x283:
                        fetchea();
                        tempw=geteaw();
                        tempw2=readmemb(cs,pc); pc++;
                        if (tempw2&0x80) tempw2|=0xFF00;
                        switch (rmdat&0x38)
                        {
                                case 0x00: /*ADD w,#8*/
                                setadd16(tempw,tempw2);
                                tempw+=tempw2;
                                seteaw(tempw);
                                if (is486) cycles-=((mod==3)?1:3);
                                else       cycles-=((mod==3)?2:7);
                                break;
                                case 0x08: /*OR w,#8*/
                                tempw|=tempw2;
                                setznp16(tempw);
                                seteaw(tempw);
                                flags&=~(C_FLAG|A_FLAG|V_FLAG);
                                if (is486) cycles-=((mod==3)?1:3);
                                else       cycles-=((mod==3)?2:7);
                                break;
                                case 0x10: /*ADC w,#8*/
//                                tempw2+=(flags&C_FLAG);
                                setadc16(tempw,tempw2);
                                tempw+=tempw2+tempc;
                                seteaw(tempw);
                                if (is486) cycles-=((mod==3)?1:3);
                                else       cycles-=((mod==3)?2:7);
                                break;
                                case 0x18: /*SBB w,#8*/
//                                tempw2+=(flags&C_FLAG);
                                setsbc16(tempw,tempw2);
                                tempw-=(tempw2+tempc);
                                seteaw(tempw);
                                if (is486) cycles-=((mod==3)?1:3);
                                else       cycles-=((mod==3)?2:7);
                                break;
                                case 0x20: /*AND w,#8*/
                                tempw&=tempw2;
                                setznp16(tempw);
                                seteaw(tempw);
                                flags&=~(C_FLAG|A_FLAG|V_FLAG);
                                if (is486) cycles-=((mod==3)?1:3);
                                else       cycles-=((mod==3)?2:7);
                                break;
                                case 0x28: /*SUB w,#8*/
                                setsub16(tempw,tempw2);
                                tempw-=tempw2;
                                seteaw(tempw);
                                if (is486) cycles-=((mod==3)?1:3);
                                else       cycles-=((mod==3)?2:7);
                                break;
                                case 0x30: /*XOR w,#8*/
                                tempw^=tempw2;
                                setznp16(tempw);
                                seteaw(tempw);
                                flags&=~(C_FLAG|A_FLAG|V_FLAG);
                                if (is486) cycles-=((mod==3)?1:3);
                                else       cycles-=((mod==3)?2:7);
                                break;
                                case 0x38: /*CMP w,#8*/
                                setsub16(tempw,tempw2);
                                if (is486) cycles-=((mod==3)?1:2);
                                else       cycles-=((mod==3)?2:7);
                                break;

                                default:
                                printf("Bad 83 opcode %02X\n",rmdat&0x38);
//                                dumpregs();
//                                exit(-1);
                        }
                        break;
                        case 0x183: case 0x383:
                        fetchea();
                        templ=geteal();
                        templ2=readmemb(cs,pc); pc++;
                        if (templ2&0x80) templ2|=0xFFFFFF00;
                        switch (rmdat&0x38)
                        {
                                case 0x00: /*ADD l,#32*/
                                setadd32(templ,templ2);
                                templ+=templ2;
                                seteal(templ);
                                if (is486) cycles-=((mod==3)?1:3);
                                else       cycles-=((mod==3)?2:7);
                                break;
                                case 0x08: /*OR l,#32*/
                                templ|=templ2;
                                setznp32(templ);
                                flags&=~(C_FLAG|V_FLAG|A_FLAG);
                                seteal(templ);
                                if (is486) cycles-=((mod==3)?1:3);
                                else       cycles-=((mod==3)?2:7);
                                break;
                                case 0x10: /*ADC l,#32*/
                                setadc32(templ,templ2);
                                templ+=templ2+tempc;
                                seteal(templ);
                                if (is486) cycles-=((mod==3)?1:3);
                                else       cycles-=((mod==3)?2:7);
                                break;
                                case 0x20: /*AND l,#32*/
                                templ&=templ2;
                                setznp32(templ);
                                flags&=~(C_FLAG|V_FLAG|A_FLAG);
                                seteal(templ);
                                if (is486) cycles-=((mod==3)?1:3);
                                else       cycles-=((mod==3)?2:7);
                                break;
                                case 0x18: /*SBB l,#32*/
                                setsbc32(templ,templ2);
                                seteal(templ-(templ2+tempc));
                                if (is486) cycles-=((mod==3)?1:3);
                                else       cycles-=((mod==3)?2:7);
                                break;
                                case 0x28: /*SUB l,#32*/
                                setsub32(templ,templ2);
                                templ-=templ2;
                                seteal(templ);
                                if (is486) cycles-=((mod==3)?1:3);
                                else       cycles-=((mod==3)?2:7);
                                break;
                                case 0x30: /*XOR l,#32*/
                                templ^=templ2;
                                setznp32(templ);
                                flags&=~(C_FLAG|V_FLAG|A_FLAG);
                                seteal(templ);
                                if (is486) cycles-=((mod==3)?1:3);
                                else       cycles-=((mod==3)?2:7);
                                break;
                                case 0x38: /*CMP l,#32*/
                                setsub32(templ,templ2);
                                if (is486) cycles-=((mod==3)?1:2);
                                else       cycles-=((mod==3)?2:7);
                                break;

                                default:
                                printf("Bad 83 opcode %02X\n",rmdat&0x38);
//                                dumpregs();
//                                exit(-1);
                        }
                        break;

                        case 0x84: case 0x184: case 0x284: case 0x384: /*TEST b,reg*/
                        fetchea();
                        temp=geteab();
                        temp2=getr8(reg);
                        setznp8(temp&temp2);
                        flags&=~(C_FLAG|V_FLAG|A_FLAG);
                        if (is486) cycles-=((mod==3)?1:2);
                        else       cycles-=((mod==3)?2:5);
                        break;
                        case 0x85: case 0x285: /*TEST w,reg*/
                        fetchea();
                        tempw=geteaw();
                        tempw2=regs[reg].w;
                        setznp16(tempw&tempw2);
                        flags&=~(C_FLAG|V_FLAG|A_FLAG);
                        if (is486) cycles-=((mod==3)?1:2);
                        else       cycles-=((mod==3)?2:5);
                        break;
                        case 0x185: case 0x385: /*TEST l,reg*/
                        fetchea();
                        templ=geteal();
                        templ2=regs[reg].l;
                        setznp32(templ&templ2);
                        flags&=~(C_FLAG|V_FLAG|A_FLAG);
                        if (is486) cycles-=((mod==3)?1:2);
                        else       cycles-=((mod==3)?2:5);
                        break;
                        case 0x86: case 0x186: case 0x286: case 0x386: /*XCHG b,reg*/
                        fetchea();
                        temp=geteab();
                        seteab(getr8(reg));
                        setr8(reg,temp);
                        if (!AT) cycles-=((mod==3)?4:25);
                        else     cycles-=((mod==3)?3:5);
                        break;
                        case 0x87: case 0x287: /*XCHG w,reg*/
                        fetchea();
                        tempw=geteaw();
                        seteaw(regs[reg].w);
                        regs[reg].w=tempw;
                        if (!AT) cycles-=((mod==3)?4:25);
                        else     cycles-=((mod==3)?3:5);
                        break;
                        case 0x187: case 0x387: /*XCHG l,reg*/
                        fetchea();
                        templ=geteal();
                        seteal(regs[reg].l);
                        regs[reg].l=templ;
                        if (!AT) cycles-=((mod==3)?4:25);
                        else     cycles-=((mod==3)?3:5);
                        break;

                        case 0x88: case 0x188: case 0x288: case 0x388: /*MOV b,reg*/
                        fetchea();
                        seteab(getr8(reg));
                        cycles-=(is486)?1:2;
                        break;
                        case 0x89: case 0x289: /*MOV w,reg*/
                        fetchea();
                        seteaw(regs[reg].w);
                        cycles-=(is486)?1:2;
                        break;
                        case 0x189: case 0x389: /*MOV l,reg*/
                        fetchea();
                        seteal(regs[reg].l);
                        cycles-=(is486)?1:2;
                        break;
                        case 0x8A: case 0x18A: case 0x28A: case 0x38A: /*MOV reg,b*/
                        fetchea();
                        temp=geteab();
                        setr8(reg,temp);
//                        if (output) printf("Loaded from %06X:%06X  %04X(%06X)\n",easeg,eaaddr,DS,ds);
                        if (is486) cycles--;
                        else       cycles-=((mod==3)?2:4);
                        break;
                        case 0x8B: case 0x28B: /*MOV reg,w*/
                        fetchea();
//                        if (output) printf("%08X %08X\n",EBP+4,eaaddr);
                        tempw=geteaw();
                        regs[reg].w=tempw;
                        if (is486) cycles--;
                        else       cycles-=((mod==3)?2:4);
                        break;
                        case 0x18B: case 0x38B: /*MOV reg,l*/
                        fetchea();
//                        if (output) printf("EA %08X\n",easeg+eaaddr);
                        templ=geteal();
                        regs[reg].l=templ;
                        if (is486) cycles--;
                        else       cycles-=((mod==3)?2:4);
                        break;

                        case 0x8C: case 0x28C: /*MOV w,sreg*/
                        fetchea();
                        switch (rmdat&0x38)
                        {
                                case 0x00: /*ES*/
                                seteaw(ES);
                                break;
                                case 0x08: /*CS*/
                                seteaw(CS);
                                break;
                                case 0x18: /*DS*/
                                if (ssegs) ds=oldds;
                                seteaw(DS);
                                break;
                                case 0x10: /*SS*/
                                if (ssegs) ss=oldss;
                                seteaw(SS);
                                break;
                                case 0x20: /*FS*/
                                seteaw(FS);
                                break;
                                case 0x28: /*GS*/
                                seteaw(GS);
                                break;
                        }
                        if (!AT) cycles-=((mod==3)?2:13);
                        else     cycles-=((mod==3)?2:3);
                        break;
                        case 0x18C: case 0x38C: /*MOV l,sreg*/
                        fetchea();
                        switch (rmdat&0x38)
                        {
                                case 0x00: /*ES*/
                                seteal(ES);
                                break;
                                case 0x08: /*CS*/
                                seteal(CS);
                                break;
                                case 0x18: /*DS*/
                                if (ssegs) ds=oldds;
                                seteal(DS);
                                break;
                                case 0x10: /*SS*/
                                if (ssegs) ss=oldss;
                                seteal(SS);
                                break;
                                case 0x20: /*FS*/
                                seteal(FS);
                                break;
                                case 0x28: /*GS*/
                                seteal(GS);
                                break;
                        }
                        if (!AT) cycles-=((mod==3)?2:13);
                        else     cycles-=((mod==3)?2:3);
                        break;

                        case 0x8D: case 0x28D: /*LEA*/
                        fetchea();
                        regs[reg].w=eaaddr;
                        cycles-=(is486)?1:2;
                        break;
                        case 0x18D: /*LEA*/
                        fetchea();
                        regs[reg].l=eaaddr&0xFFFF;
                        cycles-=(is486)?1:2;
                        break;
                        case 0x38D: /*LEA*/
                        fetchea();
                        regs[reg].l=eaaddr;
                        cycles-=(is486)?1:2;
                        break;

                        case 0x8E: case 0x18E: case 0x28E: case 0x38E: /*MOV sreg,w*/
//                        if (output) printf("MOV %04X  ",pc);
                        fetchea();
//                        if (output) printf("%04X %02X\n",pc,rmdat);
                        switch (rmdat&0x38)
                        {
                                case 0x00: /*ES*/
                                tempw=geteaw();
                                loadseg(tempw,&_es);
                                break;
                                case 0x18: /*DS*/
                                tempw=geteaw();
                                loadseg(tempw,&_ds);
                                if (ssegs) oldds=ds;
//                                printf("LOAD DS %04X %04X\n",tempw,DS);
                                break;
                                case 0x10: /*SS*/
                                tempw=geteaw();
                                loadseg(tempw,&_ss);
                                if (ssegs) oldss=ss;
                                skipnextprint=1;
				noint=1;
//                                printf("LOAD SS %04X %04X\n",tempw,SS);
//				printf("SS loaded with %04X %04X:%04X %04X %04X %04X\n",ss>>4,cs>>4,pc,CX,DX,es>>4);
                                break;
                                case 0x20: /*FS*/
                                tempw=geteaw();
                                loadseg(tempw,&_fs);
                                break;
                                case 0x28: /*GS*/
                                tempw=geteaw();
                                loadseg(tempw,&_gs);
                                break;
                        }
                        if (!AT) cycles-=((mod==3)?2:12);
                        else     cycles-=((mod==3)?2:5);
                        break;

                        case 0x8F: case 0x28F: /*POPW*/
                        if (ssegs) templ2=oldss;
                        else       templ2=ss;
                        if (stack32)
                        {
                                tempw=readmemw(templ2,ESP);
                                ESP+=2;
                        }
                        else
                        {
                                tempw=readmemw(templ2,SP);
                                SP+=2;
                        }
                        fetchea();
                        if (ssegs) ss=oldss;
                        seteaw(tempw);
                        if (is486) cycles-=((mod==3)?1:6);
                        else       cycles-=((mod==3)?4:5);
                        break;
                        case 0x18F: case 0x38F: /*POPL*/
                        if (ssegs) templ2=oldss;
                        else       templ2=ss;
                        if (stack32)
                        {
                                templ=readmeml(templ2,ESP);
                                ESP+=4;
                        }
                        else
                        {
                                templ=readmeml(templ2,SP);
                                SP+=4;
                        }
                        fetchea();
                        if (ssegs) ss=oldss;
                        seteal(templ);
                        if (is486) cycles-=((mod==3)?1:6);
                        else       cycles-=((mod==3)?4:5);
                        break;

                        case 0x90: case 0x190: case 0x290: case 0x390: /*NOP*/
                        cycles-=(is486)?1:3;
                        break;

                        case 0x91: case 0x92: case 0x93: /*XCHG AX*/
                        case 0x94: case 0x95: case 0x96: case 0x97:
                        case 0x291: case 0x292: case 0x293:
                        case 0x294: case 0x295: case 0x296: case 0x297:
                        tempw=AX;
                        AX=regs[opcode&7].w;
                        regs[opcode&7].w=tempw;
                        cycles-=3;
                        break;
                        case 0x191: case 0x192: case 0x193: /*XCHG EAX*/
                        case 0x194: case 0x195: case 0x196: case 0x197:
                        case 0x391: case 0x392: case 0x393: /*XCHG EAX*/
                        case 0x394: case 0x395: case 0x396: case 0x397:
                        templ=EAX;
                        EAX=regs[opcode&7].l;
                        regs[opcode&7].l=templ;
                        cycles-=3;
                        break;

                        case 0x98: case 0x298: /*CBW*/
                        AH=(AL&0x80)?0xFF:0;
                        cycles-=3;
                        break;
                        case 0x198: case 0x398: /*CWDE*/
                        EAX=(AX&0x8000)?(0xFFFF0000|AX):AX;
                        cycles-=3;
                        break;
                        case 0x99: case 0x299: /*CWD*/
                        DX=(AX&0x8000)?0xFFFF:0;
                        cycles-=2;
                        break;
                        case 0x199: case 0x399: /*CDQ*/
                        EDX=(EAX&0x80000000)?0xFFFFFFFF:0;
                        cycles-=2;
                        break;
                        case 0x9A: /*CALL FAR*/
                        tempw=getword();
                        tempw2=getword();
                        tempw3=CS;
                        tempw4=pc;
                        if (ssegs) ss=oldss;
                        oxpc=pc;
                        pc=tempw;
                        optype=CALL;
                        cgate32=0;
                        if (msw&1) loadcscall(tempw2);
                        else       loadcs(tempw2);
                        if (notpresent) break;
                        if (cgate32) goto writecall32;
                        if (stack32)
                        {
                                writememw(ss,ESP-2,tempw3);
                                writememw(ss,ESP-4,tempw4);
                                ESP-=4;
                        }
                        else
                        {
                                writememw(ss,(SP-2)&0xFFFF,tempw3);
                                writememw(ss,(SP-4)&0xFFFF,tempw4);
                                SP-=4;
                        }
                        cycles-=(is486)?18:17;
                        break;
                        case 0x19A: /*CALL FAR*/
                        templ=getword(); templ|=(getword()<<16);
                        tempw2=getword();
                        tempw3=CS;
                        templ2=pc;
                        if (ssegs) ss=oldss;
                        oxpc=pc;
                        pc=templ;
                        optype=CALL;
                        if (msw&1) loadcscall(tempw2);
                        else       loadcs(tempw2);
                        if (notpresent) break;
                writecall32:
                        cgate32=0;
                        if (stack32)
                        {
                                writememl(ss,ESP-4,tempw3);
                                writememl(ss,ESP-8,templ2);
                                ESP-=8;
                        }
                        else
                        {
                                writememl(ss,(SP-4)&0xFFFF,tempw3);
                                writememl(ss,(SP-8)&0xFFFF,templ2);
                                SP-=8;
                        }
                        cycles-=(is486)?18:17;
                        break;
                        case 0x9B: case 0x19B: case 0x29B: case 0x39B: /*WAIT*/
                        cycles-=4;
                        break;
                        case 0x9C: case 0x29C: /*PUSHF*/
                        if (ssegs) ss=oldss;
                        if ((eflags&VM_FLAG) && (IOPL<3))
                        {
                                x86gpf(NULL,0);
                                break;
                        }
                        if (stack32)
                        {
                                writememw(ss,ESP-2,flags);
                                ESP-=2;
                        }
                        else
                        {
                                writememw(ss,((SP-2)&0xFFFF),flags);
                                SP-=2;
                        }
                        cycles-=4;
                        break;
                        case 0x19C: case 0x39C: /*PUSHFD*/
//                        printf("PUSHFD %04X(%08X):%08X\n",CS,cs,pc);
                        if (ssegs) ss=oldss;
                        if ((eflags&VM_FLAG) && (IOPL<3))
                        {
                                x86gpf(NULL,0);
                                break;
                        }
                        if (stack32)
                        {
                                writememw(ss,ESP-2,eflags&7); ESP-=2;
                                writememw(ss,ESP-2,flags);    ESP-=2;
//                                if (output==3) printf("Pushing %04X %04X\n",eflags,flags);
                        }
                        else
                        {
                                writememw(ss,((SP-2)&0xFFFF),eflags&7); SP-=2;
                                writememw(ss,((SP-2)&0xFFFF),flags);  SP-=2;
                        }
                        cycles-=4;
                        break;
                        case 0x9D: case 0x29D: /*POPF*/
                        if (ssegs) ss=oldss;
                        if ((eflags&VM_FLAG) && (IOPL<3))
                        {
                                x86gpf(NULL,0);
                                break;
                        }
                        if (stack32)
                        {
                                tempw=readmemw(ss,ESP);
                                ESP+=2;
                        }
                        else
                        {
                                tempw=readmemw(ss,SP);
                                SP+=2;
                        }
//                        printf("POPF! %i %i %i\n",CPL,msw&1,IOPLp);
                        if (!(CPL) || !(msw&1)) flags=tempw;
                        else if (IOPLp) flags=(flags&0x3000)|(tempw&0xCFFF);
                        else            flags=(flags&0xF300)|(tempw&0x0CFF);
//                        if (flags==0xF000) printf("POPF - flags now F000 %04X(%06X):%04X %08X %08X %08X\n",CS,cs,pc,old8,old82,old83);
                        cycles-=5;
                        break;
                        case 0x19D: case 0x39D: /*POPFD*/
                        if (ssegs) ss=oldss;
                        if ((eflags&VM_FLAG) && (IOPL<3))
                        {
                                x86gpf(NULL,0);
                                break;
                        }
                        if (stack32)
                        {
                                tempw=readmemw(ss,ESP); ESP+=2;
                                tempw2=readmemw(ss,ESP); ESP+=2;
                        }
                        else
                        {
                                tempw=readmemw(ss,SP); SP+=2;
                                tempw2=readmemw(ss,SP); SP+=2;
                        }
//                        eflags|=0x200000;
                        if (!(CPL) || !(msw&1)) flags=tempw;
                        else if (IOPLp) flags=(flags&0x3000)|(tempw&0xCFFF);
                        else            flags=(flags&0xF300)|(tempw&0x0CFF);
                        tempw2&=(is486)?4:0;
                        tempw2|=(eflags&3);
                        if (is486) eflags=tempw2&7;
                        else       eflags=tempw2&3;
//                        if (flags==0xF000) printf("POPF - flags now F000 %04X(%06X):%04X %08X %08X %08X\n",CS,cs,pc,old8,old82,old83);
                        cycles-=5;
                        break;
                        case 0x9E: case 0x19E: case 0x29E: case 0x39E: /*SAHF*/
                        flags=(flags&0xFF00)|AH;
                        cycles-=3;
                        break;
                        case 0x9F: case 0x19F: case 0x29F: case 0x39F: /*LAHF*/
                        AH=flags&0xFF;
                        cycles-=3;
                        break;

                        case 0xA0: case 0x1A0: /*MOV AL,(w)*/
                        addr=getword();
                        AL=readmemb(ds,addr);
                        cycles-=(is486)?1:4;
                        break;
                        case 0x2A0: case 0x3A0: /*MOV AL,(l)*/
                        addr=getlong();
                        AL=readmemb(ds,addr);
                        cycles-=(is486)?1:4;
                        break;
                        case 0xA1: /*MOV AX,(w)*/
                        addr=getword();
                        AX=readmemw(ds,addr);
                        cycles-=(is486)?1:4;
                        break;
                        case 0x1A1: /*MOV EAX,(w)*/
                        addr=getword();
                        EAX=readmeml(ds,addr);
                        cycles-=(is486)?1:4;
                        break;
                        case 0x2A1: /*MOV AX,(l)*/
                        addr=getlong();
                        AX=readmemw(ds,addr);
                        cycles-=(is486)?1:4;
                        break;
                        case 0x3A1: /*MOV EAX,(l)*/
                        addr=getlong();
                        EAX=readmeml(ds,addr);
                        cycles-=(is486)?1:4;
                        break;
                        case 0xA2: case 0x1A2: /*MOV (w),AL*/
                        addr=getword();
                        writememb(ds,addr,AL);
                        cycles-=(is486)?1:2;
                        break;
                        case 0x2A2: case 0x3A2: /*MOV (l),AL*/
                        addr=getlong();
                        writememb(ds,addr,AL);
                        cycles-=(is486)?1:2;
                        break;
                        case 0xA3: /*MOV (w),AX*/
                        addr=getword();
                        writememw(ds,addr,AX);
                        cycles-=(is486)?1:2;
                        break;
                        case 0x1A3: /*MOV (w),EAX*/
                        addr=getword();
                        writememl(ds,addr,EAX);
                        cycles-=(is486)?1:2;
                        break;
                        case 0x2A3: /*MOV (l),AX*/
                        addr=getlong();
                        writememw(ds,addr,AX);
                        cycles-=(is486)?1:2;
                        break;
                        case 0x3A3: /*MOV (l),EAX*/
                        addr=getlong();
                        writememl(ds,addr,EAX);
                        cycles-=(is486)?1:2;
                        break;

                        case 0xA4: case 0x1A4: /*MOVSB*/
                        temp=readmemb(ds,SI);
                        writememb(es,DI,temp);
                        if (flags&D_FLAG) { DI--; SI--; }
                        else              { DI++; SI++; }
                        cycles-=7;
                        break;
                        case 0x2A4: case 0x3A4: /*MOVSB*/
                        temp=readmemb(ds,ESI);
                        writememb(es,EDI,temp);
                        if (flags&D_FLAG) { EDI--; ESI--; }
                        else              { EDI++; ESI++; }
                        cycles-=7;
                        break;
                        case 0xA5: /*MOVSW*/
                        tempw=readmemw(ds,SI);
                        writememw(es,DI,tempw);
                        if (flags&D_FLAG) { DI-=2; SI-=2; }
                        else              { DI+=2; SI+=2; }
                        cycles-=7;
                        break;
                        case 0x2A5: /*MOVSW*/
                        tempw=readmemw(ds,ESI);
                        writememw(es,EDI,tempw);
                        if (flags&D_FLAG) { EDI-=2; ESI-=2; }
                        else              { EDI+=2; ESI+=2; }
                        cycles-=7;
                        break;
                        case 0x1A5: /*MOVSL*/
                        templ=readmeml(ds,SI);
                        writememl(es,DI,templ);
                        if (flags&D_FLAG) { DI-=4; SI-=4; }
                        else              { DI+=4; SI+=4; }
                        cycles-=7;
                        break;
                        case 0x3A5: /*MOVSL*/
                        templ=readmeml(ds,ESI);
                        writememl(es,EDI,templ);
                        if (flags&D_FLAG) { EDI-=4; ESI-=4; }
                        else              { EDI+=4; ESI+=4; }
                        cycles-=7;
                        break;
                        case 0xA6: case 0x1A6: /*CMPSB*/
                        temp =readmemb(ds,SI);
                        temp2=readmemb(es,DI);
                        setsub8(temp,temp2);
                        if (flags&D_FLAG) { DI--; SI--; }
                        else              { DI++; SI++; }
                        cycles-=(is486)?8:10;
                        break;
                        case 0x2A6: case 0x3A6: /*CMPSB*/
                        temp =readmemb(ds,ESI);
                        temp2=readmemb(es,EDI);
                        setsub8(temp,temp2);
                        if (flags&D_FLAG) { EDI--; ESI--; }
                        else              { EDI++; ESI++; }
                        cycles-=(is486)?8:10;
                        break;
                        case 0xA7: /*CMPSW*/
                        tempw =readmemw(ds,SI);
                        tempw2=readmemw(es,DI);
                        setsub16(tempw,tempw2);
                        if (flags&D_FLAG) { DI-=2; SI-=2; }
                        else              { DI+=2; SI+=2; }
                        cycles-=(is486)?8:10;
                        break;
                        case 0x1A7: /*CMPSL*/
                        templ =readmeml(ds,SI);
                        templ2=readmeml(es,DI);
                        setsub32(templ,templ2);
                        if (flags&D_FLAG) { DI-=4; SI-=4; }
                        else              { DI+=4; SI+=4; }
                        cycles-=(is486)?8:10;
                        break;
                        case 0x2A7: /*CMPSW*/
                        tempw =readmemw(ds,ESI);
                        tempw2=readmemw(es,EDI);
                        setsub16(tempw,tempw2);
                        if (flags&D_FLAG) { EDI-=2; ESI-=2; }
                        else              { EDI+=2; ESI+=2; }
                        cycles-=(is486)?8:10;
                        break;
                        case 0x3A7: /*CMPSL*/
                        templ =readmeml(ds,ESI);
                        templ2=readmeml(es,EDI);
                        setsub32(templ,templ2);
                        if (flags&D_FLAG) { EDI-=4; ESI-=4; }
                        else              { EDI+=4; ESI+=4; }
                        cycles-=(is486)?8:10;
                        break;
                        case 0xA8: case 0x1A8: case 0x2A8: case 0x3A8: /*TEST AL,#8*/
                        temp=readmemb(cs,pc); pc++;
                        setznp8(AL&temp);
                        flags&=~(C_FLAG|V_FLAG|A_FLAG);
                        cycles-=(is486)?1:2;
                        break;
                        case 0xA9: case 0x2A9: /*TEST AX,#16*/
                        tempw=getword();
                        setznp16(AX&tempw);
                        flags&=~(C_FLAG|V_FLAG|A_FLAG);
                        cycles-=(is486)?1:2;
                        break;
                        case 0x1A9: case 0x3A9: /*TEST EAX,#32*/
                        templ=getlong();
                        setznp32(EAX&templ);
                        flags&=~(C_FLAG|V_FLAG|A_FLAG);
                        cycles-=(is486)?1:2;
                        break;
                        case 0xAA: case 0x1AA: /*STOSB*/
                        writememb(es,DI,AL);
                        if (flags&D_FLAG) DI--;
                        else              DI++;
                        cycles-=4;
//                        if (pc==0x15D7D6) printf("STOSB16 %08X %02X\n",EDI,AL);
                        break;
                        case 0x2AA: case 0x3AA: /*STOSB*/
                        writememb(es,EDI,AL);
                        if (flags&D_FLAG) EDI--;
                        else              EDI++;
                        cycles-=4;
/*                        if ((cs+pc)>=0x14D690 && (cs+pc)<0x14D6B0)
                        {
                                printf("STOSB %08X %02X\n",EDI,AL);
                                if (output==1)
                                {
                                        dumpregs();
                                        exit(-1);
                                }
                        }*/
                        break;
                        case 0xAB: /*STOSW*/
                        writememw(es,DI,AX);
                        if (flags&D_FLAG) DI-=2;
                        else              DI+=2;
                        cycles-=4;
                        break;
                        case 0x1AB: /*STOSL*/
                        writememl(es,DI,EAX);
                        if (flags&D_FLAG) DI-=4;
                        else              DI+=4;
                        cycles-=4;
                        break;
                        case 0x2AB: /*STOSW*/
                        writememw(es,EDI,AX);
                        if (flags&D_FLAG) EDI-=2;
                        else              EDI+=2;
                        cycles-=4;
                        break;
                        case 0x3AB: /*STOSL*/
                        writememl(es,EDI,EAX);
                        if (flags&D_FLAG) EDI-=4;
                        else              EDI+=4;
                        cycles-=4;
                        break;
                        case 0xAC: case 0x1AC: /*LODSB*/
                        AL=readmemb(ds,SI);
                        if (output==3) printf("LODSB %02X from %05X:%04X\n",AL,ds,SI);
                        if (flags&D_FLAG) SI--;
                        else              SI++;
                        cycles-=5;
                        break;
                        case 0x2AC: case 0x3AC: /*LODSB*/
                        AL=readmemb(ds,ESI);
                        if (flags&D_FLAG) ESI--;
                        else              ESI++;
                        cycles-=5;
                        break;
                        case 0xAD: /*LODSW*/
                        AX=readmemw(ds,SI);
//                        printf("Load from %05X:%04X\n",ds,SI);
                        if (flags&D_FLAG) SI-=2;
                        else              SI+=2;
                        cycles-=5;
                        break;
                        case 0x1AD: /*LODSL*/
                        EAX=readmeml(ds,SI);
                        if (flags&D_FLAG) SI-=4;
                        else              SI+=4;
                        cycles-=5;
                        break;
                        case 0x2AD: /*LODSW*/
                        AX=readmemw(ds,ESI);
                        if (flags&D_FLAG) ESI-=2;
                        else              ESI+=2;
                        cycles-=5;
                        break;
                        case 0x3AD: /*LODSL*/
                        EAX=readmeml(ds,ESI);
                        if (flags&D_FLAG) ESI-=4;
                        else              ESI+=4;
                        cycles-=5;
                        break;
                        case 0xAE: case 0x1AE: /*SCASB*/
                        temp=readmemb(es,DI);
                        setsub8(AL,temp);
                        if (flags&D_FLAG) DI--;
                        else              DI++;
                        cycles-=7;
                        break;
                        case 0x2AE: case 0x3AE: /*SCASB*/
                        temp=readmemb(es,EDI);
                        setsub8(AL,temp);
                        if (flags&D_FLAG) EDI--;
                        else              EDI++;
                        cycles-=7;
                        break;
                        case 0xAF: /*SCASW*/
                        tempw=readmemw(es,DI);
                        setsub16(AX,tempw);
                        if (flags&D_FLAG) DI-=2;
                        else              DI+=2;
                        cycles-=7;
                        break;
                        case 0x1AF: /*SCASL*/
                        templ=readmeml(es,DI);
                        setsub32(EAX,templ);
                        if (flags&D_FLAG) DI-=4;
                        else              DI+=4;
                        cycles-=7;
                        break;
                        case 0x2AF: /*SCASW*/
                        tempw=readmemw(es,EDI);
                        setsub16(AX,tempw);
                        if (flags&D_FLAG) EDI-=2;
                        else              EDI+=2;
                        cycles-=7;
                        break;
                        case 0x3AF: /*SCASL*/
                        templ=readmeml(es,EDI);
                        setsub32(EAX,templ);
                        if (flags&D_FLAG) EDI-=4;
                        else              EDI+=4;
                        cycles-=7;
                        break;

                        case 0xB0: case 0x1B0: case 0x2B0: case 0x3B0: /*MOV AL,#8*/
                        AL=readmemb(cs,pc),pc++;
                        cycles-=(is486)?1:2;
                        break;
                        case 0xB1: case 0x1B1: case 0x2B1: case 0x3B1: /*MOV CL,#8*/
                        CL=readmemb(cs,pc),pc++;
                        cycles-=(is486)?1:2;
                        break;
                        case 0xB2: case 0x1B2: case 0x2B2: case 0x3B2: /*MOV DL,#8*/
                        DL=readmemb(cs,pc),pc++;
                        cycles-=(is486)?1:2;
                        break;
                        case 0xB3: case 0x1B3: case 0x2B3: case 0x3B3: /*MOV BL,#8*/
                        BL=readmemb(cs,pc),pc++;
                        cycles-=(is486)?1:2;
                        break;
                        case 0xB4: case 0x1B4: case 0x2B4: case 0x3B4: /*MOV AH,#8*/
                        AH=readmemb(cs,pc),pc++;
                        cycles-=(is486)?1:2;
                        break;
                        case 0xB5: case 0x1B5: case 0x2B5: case 0x3B5: /*MOV CH,#8*/
                        CH=readmemb(cs,pc),pc++;
                        cycles-=(is486)?1:2;
                        break;
                        case 0xB6: case 0x1B6: case 0x2B6: case 0x3B6: /*MOV DH,#8*/
                        DH=readmemb(cs,pc),pc++;
                        cycles-=(is486)?1:2;
                        break;
                        case 0xB7: case 0x1B7: case 0x2B7: case 0x3B7: /*MOV BH,#8*/
                        BH=readmemb(cs,pc),pc++;
                        cycles-=(is486)?1:2;
                        break;
                        case 0xB8: case 0xB9: case 0xBA: case 0xBB: /*MOV reg,#16*/
                        case 0xBC: case 0xBD: case 0xBE: case 0xBF:
                        case 0x2B8: case 0x2B9: case 0x2BA: case 0x2BB:
                        case 0x2BC: case 0x2BD: case 0x2BE: case 0x2BF:
                        regs[opcode&7].w=getword();
                        cycles-=(is486)?1:2;
                        break;
                        case 0x1B8: case 0x1B9: case 0x1BA: case 0x1BB: /*MOV reg,#32*/
                        case 0x1BC: case 0x1BD: case 0x1BE: case 0x1BF:
                        case 0x3B8: case 0x3B9: case 0x3BA: case 0x3BB:
                        case 0x3BC: case 0x3BD: case 0x3BE: case 0x3BF:
                        regs[opcode&7].l=getlong();
                        cycles-=(is486)?1:2;
                        break;

                        case 0xC0: case 0x1C0: case 0x2C0: case 0x3C0:
                        fetchea();
                        c=readmemb(cs,pc); pc++;
                        temp=geteab();
                        c&=31;
                        if (!c) break;
                        switch (rmdat&0x38)
                        {
                                case 0x00: /*ROL b,CL*/
                                while (c>0)
                                {
                                        temp2=(temp&0x80)?1:0;
                                        temp=(temp<<1)|temp2;
                                        c--;
                                }
                                if (temp2) flags|=C_FLAG;
                                else       flags&=~C_FLAG;
                                seteab(temp);
                                if ((flags&C_FLAG)^(temp>>7)) flags|=V_FLAG;
                                else                          flags&=~V_FLAG;
//                                setznp8(temp);
                                cycles-=((mod==3)?3:7);
                                break;
                                case 0x08: /*ROR b,CL*/
                                while (c>0)
                                {
                                        temp2=temp&1;
                                        temp>>=1;
                                        if (temp2) temp|=0x80;
                                        c--;
                                }
                                if (temp2) flags|=C_FLAG;
                                else       flags&=~C_FLAG;
                                seteab(temp);
                                if ((temp^(temp>>1))&0x40) flags|=V_FLAG;
                                else                       flags&=~V_FLAG;
                                cycles-=((mod==3)?3:7);
                                break;
                                case 0x10: /*RCL b,CL*/
                                while (c>0)
                                {
                                        tempc=(flags&C_FLAG)?1:0;
                                        if (temp&0x80) flags|=C_FLAG;
                                        else           flags&=~C_FLAG;
                                        temp=(temp<<1)|tempc;
                                        c--;
                                        if (is486) cycles--;
                                }
                                seteab(temp);
                                if ((flags&C_FLAG)^(temp>>7)) flags|=V_FLAG;
                                else                          flags&=~V_FLAG;
                                cycles-=((mod==3)?9:10);
                                break;
                                case 0x18: /*RCR b,CL*/
                                while (c>0)
                                {
                                        tempc=(flags&C_FLAG)?0x80:0;
                                        if (temp&1) flags|=C_FLAG;
                                        else        flags&=~C_FLAG;
                                        temp=(temp>>1)|tempc;
                                        c--;
                                        if (is486) cycles--;
                                }
                                seteab(temp);
                                if ((temp^(temp>>1))&0x40) flags|=V_FLAG;
                                else                       flags&=~V_FLAG;
                                cycles-=((mod==3)?9:10);
                                break;
                                case 0x20: case 0x30: /*SHL b,CL*/
                                if ((temp<<(c-1))&0x80) flags|=C_FLAG;
                                else                    flags&=~C_FLAG;
                                temp<<=c;
                                seteab(temp);
                                setznp8(temp);
                                cycles-=((mod==3)?3:7);
                                flags|=A_FLAG;
                                break;
                                case 0x28: /*SHR b,CL*/
                                if ((temp>>(c-1))&1) flags|=C_FLAG;
                                else                 flags&=~C_FLAG;
                                temp>>=c;
                                seteab(temp);
                                setznp8(temp);
                                cycles-=((mod==3)?3:7);
                                flags|=A_FLAG;
                                break;
                                case 0x38: /*SAR b,CL*/
                                if ((temp>>(c-1))&1) flags|=C_FLAG;
                                else                 flags&=~C_FLAG;
                                while (c>0)
                                {
                                        temp>>=1;
                                        if (temp&0x40) temp|=0x80;
                                        c--;
                                }
                                seteab(temp);
                                setznp8(temp);
                                cycles-=((mod==3)?3:7);
                                flags|=A_FLAG;
                                break;

                                default:
                                printf("Bad C0 opcode %02X\n",rmdat&0x38);
//                                dumpregs();
//                                exit(-1);
                        }
                        break;

                        case 0xC1: case 0x2C1:
                        fetchea();
                        c=readmemb(cs,pc)&31; pc++;
                        tempw=geteaw();
                        if (!c) break;
                        switch (rmdat&0x38)
                        {
                                case 0x00: /*ROL w,CL*/
                                while (c>0)
                                {
                                        temp=(tempw&0x8000)?1:0;
                                        tempw=(tempw<<1)|temp;
                                        c--;
                                }
                                if (temp) flags|=C_FLAG;
                                else      flags&=~C_FLAG;
                                seteaw(tempw);
                                if ((flags&C_FLAG)^(tempw>>15)) flags|=V_FLAG;
                                else                            flags&=~V_FLAG;
                                cycles-=((mod==3)?3:7);
                                break;
                                case 0x08: /*ROR w,CL*/
                                while (c>0)
                                {
                                        tempw2=(tempw&1)?0x8000:0;
                                        tempw=(tempw>>1)|tempw2;
                                        c--;
                                }
                                if (tempw2) flags|=C_FLAG;
                                else        flags&=~C_FLAG;
                                seteaw(tempw);
                                if ((tempw^(tempw>>1))&0x4000) flags|=V_FLAG;
                                else                           flags&=~V_FLAG;
//                                setznp16(tempw);
                                cycles-=((mod==3)?3:7);
                                break;
                                case 0x10: /*RCL w,CL*/
                                while (c>0)
                                {
                                        tempc=(flags&C_FLAG)?1:0;
                                        if (tempw&0x8000) flags|=C_FLAG;
                                        else              flags&=~C_FLAG;
                                        tempw=(tempw<<1)|tempc;
                                        c--;
                                        if (is486) cycles--;
                                }
                                seteaw(tempw);
                                if ((flags&C_FLAG)^(tempw>>15)) flags|=V_FLAG;
                                else                            flags&=~V_FLAG;
                                cycles-=((mod==3)?9:10);
                                break;
                                case 0x18: /*RCR w,CL*/
                                while (c>0)
                                {
                                        tempc=(flags&C_FLAG)?0x8000:0;
                                        if (tempw&1) flags|=C_FLAG;
                                        else         flags&=~C_FLAG;
                                        tempw=(tempw>>1)|tempc;
                                        c--;
                                        if (is486) cycles--;
                                }
                                seteaw(tempw);
                                if ((tempw^(tempw>>1))&0x4000) flags|=V_FLAG;
                                else                           flags&=~V_FLAG;
                                cycles-=((mod==3)?9:10);
                                break;

                                case 0x20: case 0x30: /*SHL w,CL*/
                                if ((tempw<<(c-1))&0x8000) flags|=C_FLAG;
                                else                       flags&=~C_FLAG;
                                tempw<<=c;
                                seteaw(tempw);
                                setznp16(tempw);
                                cycles-=((mod==3)?3:7);
                                flags|=A_FLAG;
                                break;

                                case 0x28:            /*SHR w,CL*/
                                if ((tempw>>(c-1))&1) flags|=C_FLAG;
                                else                  flags&=~C_FLAG;
                                tempw>>=c;
                                seteaw(tempw);
                                setznp16(tempw);
                                cycles-=((mod==3)?3:7);
                                flags|=A_FLAG;
                                break;

                                case 0x38:            /*SAR w,CL*/
                                tempw2=tempw&0x8000;
                                if ((tempw>>(c-1))&1) flags|=C_FLAG;
                                else                  flags&=~C_FLAG;
                                while (c>0)
                                {
                                        tempw=(tempw>>1)|tempw2;
                                        c--;
                                }
                                seteaw(tempw);
                                setznp16(tempw);
                                cycles-=((mod==3)?3:7);
                                flags|=A_FLAG;
                                break;

                                default:
                                printf("Bad C1 opcode %02X\n",rmdat&0x38);
//                                dumpregs();
//                                exit(-1);
                        }
                        break;
                        case 0x1C1: case 0x3C1:
                        fetchea();
                        c=readmemb(cs,pc); pc++;
                        c&=31;
                        templ=geteal();
                        if (!c) break;
                        switch (rmdat&0x38)
                        {
                                case 0x00: /*ROL l,CL*/
                                while (c>0)
                                {
                                        temp=(templ&0x80000000)?1:0;
                                        templ=(templ<<1)|temp;
                                        c--;
                                }
                                if (temp) flags|=C_FLAG;
                                else      flags&=~C_FLAG;
                                seteal(templ);
                                if ((flags&C_FLAG)^(templ>>31)) flags|=V_FLAG;
                                else                            flags&=~V_FLAG;
                                cycles-=((mod==3)?9:10);
                                break;
                                case 0x08: /*ROR l,CL*/
                                while (c>0)
                                {
                                        templ2=(templ&1)?0x80000000:0;
                                        templ=(templ>>1)|templ2;
                                        c--;
                                }
                                if (templ2) flags|=C_FLAG;
                                else        flags&=~C_FLAG;
                                seteal(templ);
                                if ((templ^(templ>>1))&0x40000000) flags|=V_FLAG;
                                else                               flags&=~V_FLAG;
                                cycles-=((mod==3)?9:10);
                                break;
                                case 0x10: /*RCL l,CL*/
                                while (c>0)
                                {
                                        tempc=(flags&C_FLAG)?1:0;
                                        if (templ&0x80000000) flags|=C_FLAG;
                                        else                  flags&=~C_FLAG;
                                        templ=(templ<<1)|tempc;
                                        c--;
                                        if (is486) cycles--;
                                }
                                seteal(templ);
                                if ((flags&C_FLAG)^(templ>>31)) flags|=V_FLAG;
                                else                            flags&=~V_FLAG;
                                cycles-=((mod==3)?9:10);
                                break;
                                case 0x18: /*RCR l,CL*/
                                while (c>0)
                                {
                                        tempc=(flags&C_FLAG)?0x80000000:0;
                                        if (templ&1) flags|=C_FLAG;
                                        else         flags&=~C_FLAG;
                                        templ=(templ>>1)|tempc;
                                        c--;
                                        if (is486) cycles--;
                                }
                                seteal(templ);
                                if ((templ^(templ>>1))&0x40000000) flags|=V_FLAG;
                                else                               flags&=~V_FLAG;
                                cycles-=((mod==3)?9:10);
                                break;

                                case 0x20: case 0x30: /*SHL l,CL*/
                                if ((templ<<(c-1))&0x80000000) flags|=C_FLAG;
                                else                           flags&=~C_FLAG;
                                templ<<=c;
                                seteal(templ);
                                setznp32(templ);
                                cycles-=((mod==3)?3:7);
                                flags|=A_FLAG;
                                break;

                                case 0x28:            /*SHR l,CL*/
                                if ((templ>>(c-1))&1) flags|=C_FLAG;
                                else                  flags&=~C_FLAG;
                                templ>>=c;
                                seteal(templ);
                                setznp32(templ);
                                cycles-=((mod==3)?3:7);
                                flags|=A_FLAG;
                                break;

                                case 0x38:            /*SAR l,CL*/
                                templ2=templ&0x80000000;
                                if ((templ>>(c-1))&1) flags|=C_FLAG;
                                else                  flags&=~C_FLAG;
                                while (c>0)
                                {
                                        templ=(templ>>1)|templ2;
                                        c--;
                                }
                                seteal(templ);
                                setznp32(templ);
                                cycles-=((mod==3)?3:7);
                                flags|=A_FLAG;
                                break;

                                default:
                                printf("Bad 32-bit C1 opcode %02X\n",rmdat&0x38);
//                                dumpregs();
//                                exit(-1);
                        }
                        break;

                        case 0xC2: case 0x2C2: /*RET*/
                        tempw=getword();
                        if (ssegs) ss=oldss;
                        if (stack32)
                        {
                                pc=readmemw(ss,ESP);
                                ESP+=2+tempw;
                        }
                        else
                        {
                                pc=readmemw(ss,SP);
                                SP+=2+tempw;
                        }
                        cycles-=(is486)?5:10;
                        break;
                        case 0x1C2: case 0x3C2: /*RET*/
                        tempw=getword();
                        if (ssegs) ss=oldss;
                        if (stack32)
                        {
                                pc=readmeml(ss,ESP);
                                ESP+=4+tempw;
                        }
                        else
                        {
                                pc=readmeml(ss,SP);
                                SP+=4+tempw;
                        }
                        cycles-=(is486)?5:10;
                        break;
                        case 0xC3: case 0x2C3: /*RET*/
                        if (ssegs) ss=oldss;
                        if (stack32)
                        {
                                pc=readmemw(ss,ESP);
                                ESP+=2;
                        }
                        else
                        {
                                pc=readmemw(ss,SP);
                                SP+=2;
                        }
                        cycles-=(is486)?5:10;
                        break;
                        case 0x1C3: case 0x3C3: /*RET*/
                        if (ssegs) ss=oldss;
                        if (stack32)
                        {
                                pc=readmeml(ss,ESP);
                                ESP+=4;
                        }
                        else
                        {
                                pc=readmeml(ss,SP);
                                SP+=4;
                        }
                        cycles-=(is486)?5:10;
                        break;
                        case 0xC4: case 0x2C4: /*LES*/
                        fetchea();
                        regs[reg].w=readmemw(easeg,eaaddr);
                        tempw=readmemw(easeg,eaaddr+2);
                        loadseg(tempw,&_es);
                        cycles-=7;
                        break;
                        case 0x1C4: case 0x3C4: /*LES*/
                        fetchea();
                        regs[reg].l=readmeml(easeg,eaaddr);
                        tempw=readmemw(easeg,eaaddr+4);
                        loadseg(tempw,&_es);
                        cycles-=7;
                        break;
                        case 0xC5: case 0x2C5: /*LDS*/
                        fetchea();
                        regs[reg].w=readmemw(easeg,eaaddr);
                        tempw=readmemw(easeg,eaaddr+2);
                        loadseg(tempw,&_ds);
                        if (ssegs) oldds=ds;
                        cycles-=7;
                        break;
                        case 0x1C5: case 0x3C5: /*LDS*/
                        fetchea();
                        regs[reg].l=readmeml(easeg,eaaddr);
                        tempw=readmemw(easeg,eaaddr+4);
                        loadseg(tempw,&_ds);
                        if (ssegs) oldds=ds;
                        cycles-=7;
                        break;
                        case 0xC6: case 0x1C6: case 0x2C6: case 0x3C6: /*MOV b,#8*/
                        fetchea();
                        temp=readmemb(cs,pc); pc++;
                        seteab(temp);
                        cycles-=(is486)?1:2;
                        break;
                        case 0xC7: case 0x2C7: /*MOV w,#16*/
                        fetchea();
                        tempw=getword();
                        seteaw(tempw);
                        cycles-=(is486)?1:2;
                        break;
                        case 0x1C7: case 0x3C7: /*MOV l,#32*/
                        fetchea();
                        templ=getlong();
                        seteal(templ);
                        cycles-=(is486)?1:2;
                        break;
                        case 0xC8: case 0x2C8: /*ENTER*/
//                        if (cr0&1) printf("ENTER at %04X:%08X\n",CS,pc);
                        if (output==1 && SS==0xA0)
                        {
                                enters++;
                                for (ec=0;ec<enters;ec++) printf(" ");
                                printf("ENTER %02X %04X %04X %i\n",SS,BP,SP,eflags&VM_FLAG);
                        }
                        tempw2=getword();
                        tempi=readmemb(cs,pc); pc++;
                        if (stack32) { writememw(ss,(ESP-2),BP);        ESP-=2; }
                        else         { writememw(ss,((SP-2)&0xFFFF),BP); SP-=2; }
                        templ2=ESP;
                        if (tempi>0)
                        {
                                while (--tempi)
                                {
                                        EBP-=2;
                                        if (stack32) tempw=readmemw(ss,EBP);
                                        else         tempw=readmemw(ss,BP);
                                        if (stack32) { writememw(ss,(ESP-2),tempw);        ESP-=2; }
                                        else         { writememw(ss,((SP-2)&0xFFFF),tempw); SP-=2; }
                                        cycles-=(is486)?3:4;
                                }
                                if (stack32) { writememw(ss,(ESP-2),templ2);        ESP-=2; }
                                else         { writememw(ss,((SP-2)&0xFFFF),templ2); SP-=2; }
                                cycles-=(is486)?3:5;
                        }
                        if (stack32) { EBP=templ2; ESP-=tempw2; }
                        else         {  BP=templ2;  SP-=tempw2; }
                        cycles-=(is486)?14:10;
//                        if (cr0&1) printf("BP %04X\n",BP);
//                        if (output==3) printf("\n");
                        break;
                        case 0x1C8: case 0x3C8: /*ENTER*/
                        if (output==1 && SS==0xA0)
                        {
                                enters++;
                                for (ec=0;ec<enters;ec++) printf(" ");
                                printf("ENTER %02X %04X %04X %i\n",SS,BP,SP,eflags&VM_FLAG);
                        }
                        tempw=getword();
                        tempi=readmemb(cs,pc); pc++;
                        if (stack32) { writememl(ss,(ESP-4),EBP);        ESP-=4; }
                        else         { writememl(ss,((SP-4)&0xFFFF),EBP); SP-=4; }
                        templ2=ESP;
                        if (tempi>0)
                        {
                                while (--tempi)
                                {
                                        EBP-=4;
                                        if (stack32) templ=readmeml(ss,EBP);
                                        else         templ=readmeml(ss,BP);
                                        if (stack32) { writememl(ss,(ESP-4),templ);        ESP-=4; }
                                        else         { writememl(ss,((SP-4)&0xFFFF),templ); SP-=4; }
                                        cycles-=(is486)?3:4;
                                }
                                if (stack32) { writememl(ss,(ESP-4),templ2);        ESP-=4; }
                                else         { writememl(ss,((SP-4)&0xFFFF),templ2); SP-=4; }
                                cycles-=(is486)?3:5;
                        }
                        if (stack32) { EBP=templ2; ESP-=tempw; }
                        else         {  BP=templ2;  SP-=tempw; }
                        cycles-=(is486)?14:10;
                        if (output==3) printf("\n");
                        break;
                        case 0xC9: case 0x2C9: /*LEAVE*/
                        SP=BP;
                        if (stack32) { BP=readmemw(ss,ESP); ESP+=2; }
                        else         { BP=readmemw(ss,SP);   SP+=2; }
                        cycles-=4;
                        if (output==1 && SS==0xA0)
                        {
                                for (ec=0;ec<enters;ec++) printf(" ");
                                printf("LEAVE %02X %04X %04X %i\n",SS,BP,SP,eflags&VM_FLAG);
                                enters--;
                        }
//                        if (output==3) printf("\n");
                        break;
                        case 0x3C9: case 0x1C9: /*LEAVE*/
                        ESP=EBP;
                        if (stack32)
                        {
                                EBP=readmeml(ss,ESP);
                                ESP+=4;
                        }
                        else
                        {
                                EBP=readmeml(ss,SP);
                                SP+=4;
                        }
                        cycles-=4;
                        if (output==1 && SS==0xA0)
                        {
                                for (ec=0;ec<enters;ec++) printf(" ");
                                printf("LEAVE %02X %04X %04X %i\n",SS,BP,SP,eflags&VM_FLAG);
                                enters--;
                        }
//                        if (output==3) printf("\n");
                        break;
                        case 0xCA: case 0x2CA: /*RETF*/
                        tempw=getword();
                        tempw2=CPL;
                        if (ssegs) ss=oldss;
                        oxpc=pc;
                        if (stack32)
                        {
                                pc=readmemw(ss,ESP);
                                loadcs(readmemw(ss,ESP+2));
                        }
                        else
                        {
                                pc=readmemw(ss,SP);
                                loadcs(readmemw(ss,SP+2));
                        }
                        if (notpresent) break;
                        if (stack32) ESP+=4+tempw;
                        else         SP+=4+tempw;
                        if ((msw&1) && CPL>tempw2)
                        {
                                if (stack32) { printf("stack32 RETF to lower priv!\n"); dumpregs(); exit(-1); }
                                tempw=readmemw(ss,SP);
                                loadseg(readmemw(ss,SP+2),&_ss);
                                SP=tempw;
                        }
                        cycles-=(is486)?13:18;
                        break;
                        case 0x1CA: case 0x3CA: /*RETF*/
                        tempw=getword();
                        tempw2=CPL;
                        if (ssegs) ss=oldss;
                        oxpc=pc;
                        if (stack32)
                        {
                                pc=readmeml(ss,ESP);
                                loadcs(readmeml(ss,ESP+4)&0xFFFF);
                        }
                        else
                        {
                                pc=readmeml(ss,SP);
                                loadcs(readmeml(ss,SP+4)&0xFFFF);
                        }
                        if (notpresent) break;
                        if (stack32) ESP+=8+tempw;
                        else         SP+=8+tempw;
                        if ((msw&1) && CPL>tempw2)
                        {
                                printf("Drop down to lower level RETF CA!\n");
                                dumpregs();
                                exit(-1);
                                tempw=readmemw(ss,SP);
                                loadseg(readmemw(ss,SP+2),&_ss);
                                SP=tempw;
                        }
                        cycles-=(is486)?13:18;
                        break;
                        case 0xCB: case 0x2CB: /*RETF*/
                        tempw2=CPL;
                        if (ssegs) ss=oldss;
                        oxpc=pc;
                        if (stack32)
                        {
                                pc=readmemw(ss,ESP);
                                loadcs(readmemw(ss,ESP+2));
                        }
                        else
                        {
                                pc=readmemw(ss,SP);
                                loadcs(readmemw(ss,SP+2));
                        }
                        if (notpresent) break;
                        if (stack32) ESP+=4;
                        else         SP+=4;
                        if ((msw&1) && CPL>tempw2)
                        {
                                if (stack32) { printf("stack32 RETF to lower priv!\n"); dumpregs(); exit(-1); }
                                tempw=readmemw(ss,SP);
                                loadseg(readmemw(ss,SP+2),&_ss);
                                SP=tempw;
                        }
                        cycles-=(is486)?13:18;
                        break;
                        case 0x1CB: case 0x3CB: /*RETF*/
                        tempw2=CPL;
                        if (ssegs) ss=oldss;
                        oxpc=pc;
                        if (stack32)
                        {
                                pc=readmeml(ss,ESP);
                                loadcs(readmemw(ss,ESP+4));
                        }
                        else
                        {
                                pc=readmeml(ss,SP);
                                loadcs(readmemw(ss,SP+4));
                        }
                        if (notpresent) break;
                        if (stack32) ESP+=8;
                        else         SP+=8;
                        if ((msw&1) && CPL>tempw2)
                        {
/*                                printf("32-bit RETF to lower level!\n");
                                dumpregs();
                                exit(-1);*/
                                if (stack32)
                                {
                                        templ=readmeml(ss,ESP);
                                        loadseg(readmeml(ss,ESP+4),&_ss);
                                        ESP=templ;
                                }
                                else
                                {
                                        templ=readmeml(ss,SP);
                                        loadseg(readmeml(ss,SP+4),&_ss);
                                        ESP=templ;
                                }
                        }
                        cycles-=(is486)?13:18;
                        break;
                        case 0xCC: case 0x1CC: case 0x2CC: case 0x3CC: /*INT 3*/
                        if (msw&1)
                        {
                                pmodeint(3,1);
                                cycles-=(is486)?44:59;
                        }
                        else
                        {
                                if (ssegs) ss=oldss;
                                if (stack32)
                                {
                                        writememw(ss,ESP-2,flags);
                                        writememw(ss,ESP-4,CS);
                                        writememw(ss,ESP-6,pc);
                                        ESP-=6;
                                }
                                else
                                {
                                        writememw(ss,((SP-2)&0xFFFF),flags);
                                        writememw(ss,((SP-4)&0xFFFF),CS);
                                        writememw(ss,((SP-6)&0xFFFF),pc);
                                        SP-=6;
                                }
                                addr=3<<2;
                                flags&=~I_FLAG;
                                oxpc=pc;
                                pc=readmemw(0,addr);
                                loadcs(readmemw(0,addr+2));
                                cycles-=(is486)?26:33;
                        }
                        if (!AT) cycles-=72;
                        else     cycles-=23;
                        break;
                        case 0xCD: case 0x1CD: case 0x2CD: case 0x3CD: /*INT*/
                        lastpc=pc;
                        lastcs=CS;
                        temp=readmemb(cs,pc); pc++;
//                        if (temp==0x21 && AH==0x4C) printf("Program exit\n");
//                        if (temp==0x15 && AH!=0x4F && AH!=0x91)
//printf("INT %02X %04X %04X %04X %04X %04X:%04X\n",temp,AX,BX,CX,DX,CS,pc);
//                        if (temp==0x10 && AH==0xE) printf("%c\n",AL);
//                        if (temp==0x10 && !AH) printf("Entering video mode %02X\n",AL);
/*                        if (temp==0x10 && AH==0xE)
                        {
                                printf("Text out %04X:%04X %02X %c\n",CS,pc,AL,(AL>31)?AL:'.');
                                if (CS==0xC800 && AL==0xD) output=3;
/*                                if (AL==0xBC) output=3;
                                if (output && AL=='M')
                                {
                                        dumpregs();
                                        exit(-1);
                                }*/
//                        }
//                        if (CS==0x180) output=1;
//                        if (temp==0x18 || temp==0x19) { printf("INT %02X\n",temp); output=1; }
//                        /*if (output==3) */printf("INT %02X %04X %04X %04X %04X %04X:%04X\n",temp,AX,BX,CX,DX,CS,pc);
/*                        if (temp==0x21) printf("INT 21 %04X %04X %04X %04X %04X:%04X %06X %06X\n",AX,BX,CX,DX,cs>>4,pc,ds,ds+DX);
                        if (temp==0x21 && AH==9)
                        {
                                addr=0;
                                while (ram[ds+DX+addr]!='$')
                                {
                                        printf("%c",ram[ds+DX+addr]);
                                        addr++;
                                }
                                printf("\n");
                                printf("Called from %04X\n",readmemw(ss,SP));
                        }*/
//                        output=0;
//                        if (temp==0x13 && AH==3) printf("Write sector %04X:%04X %05X\n",es>>4,BX,es+BX);
                        if (temp==0x13 && (DL==0x80 || DL==0x81) && AH>0)
                        {
                                int13hdc();
                        }
                        else if (temp==0x13 && AH==2 && DL<2 && FASTDISC)
                        {
                                int13read();
                        }
                        else if (temp==0x13 && AH==3 && DL<2 && FASTDISC)
                        {
                                int13write();
                        }
                        else if (temp==0x13 && AH==4 && DL<2 && FASTDISC)
                        {
                                AH=0;
                                flags&=~C_FLAG;
                        }
                        else
                        {
                                if (msw&1)
                                {
//                                        printf("PMODE int %02X %04X at %04X:%04X  ",temp,AX,CS,pc);
                                        pmodeint(temp,1);
                                        cycles-=(is486)?44:59;
//                                        printf("to %04X:%04X\n",CS,pc);
                                }
                                else
                                {
                                        if (ssegs) ss=oldss;
                                        if (stack32)
                                        {
                                                writememw(ss,ESP-2,flags);
                                                writememw(ss,ESP-4,CS);
                                                writememw(ss,ESP-6,pc);
                                                ESP-=6;
                                        }
                                        else
                                        {
                                                writememw(ss,((SP-2)&0xFFFF),flags);
                                                writememw(ss,((SP-4)&0xFFFF),CS);
                                                writememw(ss,((SP-6)&0xFFFF),pc);
                                                SP-=6;
                                        }
                                        addr=temp<<2;
//                                        flags&=~I_FLAG;
                                        oxpc=pc;
//                                        printf("%04X:%04X : ",CS,pc);
                                        pc=readmemw(0,addr);
                                        loadcs(readmemw(0,addr+2));
                                        if (!pc && !cs)
                                        {
                                                printf("Bad int %02X %04X:%04X\n",temp,oldcs,oldpc);
                                                dumpregs();
                                                exit(-1);
                                        }
                                        cycles-=(is486)?30:37;
//                                        printf("INT %02X - %04X %04X:%04X\n",temp,addr,CS,pc);
                                }
                        }
                        break;
                        case 0xCE: /*INTO*/
                        if (flags&V_FLAG)
                        {
                                printf("INTO interrupt!\n");
                                dumpregs();
                                exit(-1);
                        }
                        cycles-=3;
                        break;
                        case 0xCF: case 0x2CF: /*IRET*/
                        optype=IRET;
//                        output=0;
                        if (ssegs) ss=oldss;
                        if (msw&1) pmodeiret();
                        else
                        {
                                tempw=CS;
                                tempw2=pc;
                                inint=0;
                                oxpc=pc;
                                if (stack32)
                                {
                                        pc=readmemw(ss,ESP);
                                        loadcs(readmemw(ss,ESP+2));
                                }
                                else
                                {
                                        pc=readmemw(ss,SP);
                                        loadcs(readmemw(ss,((SP+2)&0xFFFF)));
                                }
                                if (notpresent) break;
                                if (stack32)
                                {
                                        flags=readmemw(ss,ESP+4);
                                        ESP+=6;
                                }
                                else
                                {
                                        flags=readmemw(ss,((SP+4)&0xFFFF));
                                        SP+=6;
                                }
                        }
                        cycles-=(is486)?15:22;
                        break;
                        case 0x1CF: case 0x3CF: /*IRETD*/
                        optype=IRET;
//                        output=0;
                        if (ssegs) ss=oldss;
                        if (msw&1) pmodeiretd();
                        else
                        {
                                tempw=CS;
                                tempw2=pc;
                                inint=0;
                                oxpc=pc;
                                if (stack32)
                                {
                                        pc=readmeml(ss,ESP);
                                        templ=readmeml(ss,ESP+4);
                                }
                                else
                                {
                                        pc=readmeml(ss,SP);
                                        templ=readmeml(ss,((SP+4)&0xFFFF));
                                }
                                if (notpresent) break;
                                if (stack32)
                                {
                                        flags=readmemw(ss,ESP+8);
                                        eflags=readmemw(ss,ESP+10);
                                        ESP+=12;
                                }
                                else
                                {
                                        flags=readmemw(ss,(SP+8)&0xFFFF);
                                        eflags=readmemw(ss,(SP+10)&0xFFFF);
                                        SP+=12;
                                }
                                loadcs(templ);
                        }
                        cycles-=(is486)?15:22;
                        break;
                        case 0xD0: case 0x1D0: case 0x2D0: case 0x3D0:
                        fetchea();
                        temp=geteab();
                        switch (rmdat&0x38)
                        {
                                case 0x00: /*ROL b,1*/
                                if (temp&0x80) flags|=C_FLAG;
                                else           flags&=~C_FLAG;
                                temp<<=1;
                                if (flags&C_FLAG) temp|=1;
                                seteab(temp);
//                                setznp8(temp);
                                if ((flags&C_FLAG)^(temp>>7)) flags|=V_FLAG;
                                else                          flags&=~V_FLAG;
                                cycles-=((mod==3)?3:7);
                                break;
                                case 0x08: /*ROR b,1*/
                                if (temp&1) flags|=C_FLAG;
                                else        flags&=~C_FLAG;
                                temp>>=1;
                                if (flags&C_FLAG) temp|=0x80;
                                seteab(temp);
//                                setznp8(temp);
                                if ((temp^(temp>>1))&0x40) flags|=V_FLAG;
                                else                       flags&=~V_FLAG;
                                cycles-=((mod==3)?3:7);
                                break;
                                case 0x10: /*RCL b,1*/
                                temp2=flags&C_FLAG;
                                if (temp&0x80) flags|=C_FLAG;
                                else           flags&=~C_FLAG;
                                temp<<=1;
                                if (temp2) temp|=1;
                                seteab(temp);
//                                setznp8(temp);
                                if ((flags&C_FLAG)^(temp>>7)) flags|=V_FLAG;
                                else                          flags&=~V_FLAG;
                                cycles-=((mod==3)?3:7);
                                break;
                                case 0x18: /*RCR b,1*/
                                temp2=flags&C_FLAG;
                                if (temp&1) flags|=C_FLAG;
                                else        flags&=~C_FLAG;
                                temp>>=1;
                                if (temp2) temp|=0x80;
                                seteab(temp);
//                                setznp8(temp);
                                if ((temp^(temp>>1))&0x40) flags|=V_FLAG;
                                else                       flags&=~V_FLAG;
                                cycles-=((mod==3)?3:7);
                                break;
                                case 0x20: /*SHL b,1*/
                                if (temp&0x80) flags|=C_FLAG;
                                else           flags&=~C_FLAG;
                                if ((temp^(temp<<1))&0x80) flags|=V_FLAG;
                                else                       flags&=~V_FLAG;
                                temp<<=1;
                                seteab(temp);
                                setznp8(temp);
                                cycles-=((mod==3)?3:7);
                                flags|=A_FLAG;
                                break;
                                case 0x28: /*SHR b,1*/
                                if (temp&1) flags|=C_FLAG;
                                else        flags&=~C_FLAG;
                                if (temp&0x80) flags|=V_FLAG;
                                else           flags&=~V_FLAG;
                                temp>>=1;
                                seteab(temp);
                                setznp8(temp);
                                cycles-=((mod==3)?3:7);
                                flags|=A_FLAG;
                                break;
                                case 0x38: /*SAR b,1*/
                                if (temp&1) flags|=C_FLAG;
                                else        flags&=~C_FLAG;
                                temp>>=1;
                                if (temp&0x40) temp|=0x80;
                                seteab(temp);
                                setznp8(temp);
                                cycles-=((mod==3)?3:7);
                                flags|=A_FLAG;
                                flags&=~V_FLAG;
                                break;

                                default:
                                printf("Bad D0 opcode %02X\n",rmdat&0x38);
//                                dumpregs();
//                                exit(-1);
                        }
                        break;

                        case 0xD1: case 0x2D1:
                        fetchea();
                        tempw=geteaw();
                        switch (rmdat&0x38)
                        {
                                case 0x00: /*ROL w,1*/
                                if (tempw&0x8000) flags|=C_FLAG;
                                else              flags&=~C_FLAG;
                                tempw<<=1;
                                if (flags&C_FLAG) tempw|=1;
                                seteaw(tempw);
                                if ((flags&C_FLAG)^(tempw>>15)) flags|=V_FLAG;
                                else                            flags&=~V_FLAG;
                                cycles-=((mod==3)?3:7);
                                break;
                                case 0x08: /*ROR w,1*/
                                if (tempw&1) flags|=C_FLAG;
                                else         flags&=~C_FLAG;
                                tempw>>=1;
                                if (flags&C_FLAG) tempw|=0x8000;
                                seteaw(tempw);
                                if ((tempw^(tempw>>1))&0x4000) flags|=V_FLAG;
                                else                           flags&=~V_FLAG;
                                cycles-=((mod==3)?3:7);
                                break;
                                case 0x10: /*RCL w,1*/
                                temp2=flags&C_FLAG;
                                if (tempw&0x8000) flags|=C_FLAG;
                                else              flags&=~C_FLAG;
                                tempw<<=1;
                                if (temp2) tempw|=1;
                                seteaw(tempw);
                                if ((flags&C_FLAG)^(tempw>>15)) flags|=V_FLAG;
                                else                            flags&=~V_FLAG;
                                cycles-=((mod==3)?3:7);
                                break;
                                case 0x18: /*RCR w,1*/
                                temp2=flags&C_FLAG;
                                if (tempw&1) flags|=C_FLAG;
                                else         flags&=~C_FLAG;
                                tempw>>=1;
                                if (temp2) tempw|=0x8000;
                                seteaw(tempw);
                                if ((tempw^(tempw>>1))&0x4000) flags|=V_FLAG;
                                else                           flags&=~V_FLAG;
                                cycles-=((mod==3)?3:7);
                                break;
                                case 0x20: /*SHL w,1*/
                                if (tempw&0x8000) flags|=C_FLAG;
                                else              flags&=~C_FLAG;
                                if ((tempw^(tempw<<1))&0x8000) flags|=V_FLAG;
                                else                           flags&=~V_FLAG;
                                tempw<<=1;
                                seteaw(tempw);
                                setznp16(tempw);
                                cycles-=((mod==3)?3:7);
                                flags|=A_FLAG;
                                break;
                                case 0x28: /*SHR w,1*/
                                if (tempw&1) flags|=C_FLAG;
                                else         flags&=~C_FLAG;
                                if (tempw&0x8000) flags|=V_FLAG;
                                else              flags&=~V_FLAG;
                                tempw>>=1;
                                seteaw(tempw);
                                setznp16(tempw);
                                cycles-=((mod==3)?3:7);
                                flags|=A_FLAG;
                                break;

                                case 0x38: /*SAR w,1*/
                                if (tempw&1) flags|=C_FLAG;
                                else         flags&=~C_FLAG;
                                tempw>>=1;
                                if (tempw&0x4000) tempw|=0x8000;
                                seteaw(tempw);
                                setznp16(tempw);
                                cycles-=((mod==3)?3:7);
                                flags|=A_FLAG;
                                flags&=~V_FLAG;
                                break;

                                default:
                                printf("Bad D1 opcode %02X\n",rmdat&0x38);
                        }
                        break;
                        case 0x1D1: case 0x3D1:
                        fetchea();
                        templ=geteal();
                        switch (rmdat&0x38)
                        {
                                case 0x00: /*ROL l,1*/
                                if (templ&0x80000000) flags|=C_FLAG;
                                else                  flags&=~C_FLAG;
                                templ<<=1;
                                if (flags&C_FLAG) templ|=1;
                                seteal(templ);
                                if ((flags&C_FLAG)^(templ>>31)) flags|=V_FLAG;
                                else                            flags&=~V_FLAG;
                                cycles-=((mod==3)?3:7);
                                break;
                                case 0x08: /*ROR l,1*/
                                if (templ&1) flags|=C_FLAG;
                                else         flags&=~C_FLAG;
                                templ>>=1;
                                if (flags&C_FLAG) templ|=0x80000000;
                                seteal(templ);
                                if ((templ^(templ>>1))&0x40000000) flags|=V_FLAG;
                                else                               flags&=~V_FLAG;
                                cycles-=((mod==3)?3:7);
                                break;
                                case 0x10: /*RCL l,1*/
                                temp2=flags&C_FLAG;
                                if (templ&0x80000000) flags|=C_FLAG;
                                else                  flags&=~C_FLAG;
                                templ<<=1;
                                if (temp2) templ|=1;
                                seteal(templ);
                                if ((flags&C_FLAG)^(templ>>31)) flags|=V_FLAG;
                                else                            flags&=~V_FLAG;
                                cycles-=((mod==3)?3:7);
                                break;
                                case 0x18: /*RCR l,1*/
                                temp2=flags&C_FLAG;
                                if (templ&1) flags|=C_FLAG;
                                else         flags&=~C_FLAG;
                                templ>>=1;
                                if (temp2) templ|=0x80000000;
                                seteal(templ);
                                if ((templ^(templ>>1))&0x40000000) flags|=V_FLAG;
                                else                               flags&=~V_FLAG;
                                cycles-=((mod==3)?3:7);
                                break;
                                case 0x20: /*SHL l,1*/
                                if (templ&0x80000000) flags|=C_FLAG;
                                else                  flags&=~C_FLAG;
                                if ((templ^(templ<<1))&0x80000000) flags|=V_FLAG;
                                else                               flags&=~V_FLAG;
                                templ<<=1;
                                seteal(templ);
                                setznp32(templ);
                                cycles-=((mod==3)?3:7);
                                flags|=A_FLAG;
                                break;
                                case 0x28: /*SHR l,1*/
                                if (templ&1) flags|=C_FLAG;
                                else         flags&=~C_FLAG;
                                if (templ&0x80000000) flags|=V_FLAG;
                                else                  flags&=~V_FLAG;
                                templ>>=1;
                                seteal(templ);
                                setznp32(templ);
                                cycles-=((mod==3)?3:7);
                                flags|=A_FLAG;
                                break;

                                case 0x38: /*SAR l,1*/
                                if (templ&1) flags|=C_FLAG;
                                else         flags&=~C_FLAG;
                                templ>>=1;
                                if (templ&0x40000000) templ|=0x80000000;
                                seteal(templ);
                                setznp32(templ);
                                cycles-=((mod==3)?3:7);
                                flags|=A_FLAG;
                                flags&=~V_FLAG;
                                break;

                                default:
                                printf("Bad D1 opcode %02X\n",rmdat&0x38);
                        }
                        break;

                        case 0xD2: case 0x1D2: case 0x2D2: case 0x3D2:
                        fetchea();
                        temp=geteab();
                        c=CL&31;
//                        cycles-=c;
                        if (!c) break;
//                        if (c>7) printf("Shiftb %i %02X\n",rmdat&0x38,c);
                        switch (rmdat&0x38)
                        {
                                case 0x00: /*ROL b,CL*/
                                while (c>0)
                                {
                                        temp2=(temp&0x80)?1:0;
                                        temp=(temp<<1)|temp2;
                                        c--;
                                }
                                if (temp2) flags|=C_FLAG;
                                else       flags&=~C_FLAG;
                                seteab(temp);
//                                setznp8(temp);
                                if ((flags&C_FLAG)^(temp>>7)) flags|=V_FLAG;
                                else                          flags&=~V_FLAG;
                                cycles-=((mod==3)?3:7);
                                break;
                                case 0x08: /*ROR b,CL*/
                                while (c>0)
                                {
                                        temp2=temp&1;
                                        temp>>=1;
                                        if (temp2) temp|=0x80;
                                        c--;
                                }
                                if (temp2) flags|=C_FLAG;
                                else       flags&=~C_FLAG;
                                seteab(temp);
                                if ((temp^(temp>>1))&0x40) flags|=V_FLAG;
                                else                       flags&=~V_FLAG;
                                cycles-=((mod==3)?3:7);
                                break;
                                case 0x10: /*RCL b,CL*/
//                                printf("RCL %i %02X %02X\n",c,CL,temp);
                                while (c>0)
                                {
                                        templ=flags&C_FLAG;
                                        temp2=temp&0x80;
                                        temp<<=1;
                                        if (temp2) flags|=C_FLAG;
                                        else       flags&=~C_FLAG;
                                        if (templ) temp|=1;
                                        c--;
                                }
//                                printf("Now %02X\n",temp);
                                seteab(temp);
                                if ((flags&C_FLAG)^(temp>>7)) flags|=V_FLAG;
                                else                          flags&=~V_FLAG;
                                cycles-=((mod==3)?3:7);
                                break;
                                case 0x18: /*RCR b,CL*/
                                while (c>0)
                                {
                                        templ=flags&C_FLAG;
                                        temp2=temp&1;
                                        temp>>=1;
                                        if (temp2) flags|=C_FLAG;
                                        else       flags&=~C_FLAG;
                                        if (templ) temp|=0x80;
                                        c--;
                                }
//                                if (temp2) flags|=C_FLAG;
//                                else       flags&=~C_FLAG;
                                seteab(temp);
                                if ((temp^(temp>>1))&0x40) flags|=V_FLAG;
                                else                       flags&=~V_FLAG;
                                cycles-=((mod==3)?3:7);
                                break;
                                case 0x20: case 0x30: /*SHL b,CL*/
                                if ((temp<<(c-1))&0x80) flags|=C_FLAG;
                                else                    flags&=~C_FLAG;
                                temp<<=c;
                                seteab(temp);
                                setznp8(temp);
                                cycles-=((mod==3)?3:7);
                                flags|=A_FLAG;
                                break;
                                case 0x28: /*SHR b,CL*/
                                if ((temp>>(c-1))&1) flags|=C_FLAG;
                                else                 flags&=~C_FLAG;
                                temp>>=c;
                                seteab(temp);
                                setznp8(temp);
                                cycles-=((mod==3)?3:7);
                                flags|=A_FLAG;
                                break;
                                case 0x38: /*SAR b,CL*/
                                if ((temp>>(c-1))&1) flags|=C_FLAG;
                                else                 flags&=~C_FLAG;
                                while (c>0)
                                {
                                        temp>>=1;
                                        if (temp&0x40) temp|=0x80;
                                        c--;
                                }
                                seteab(temp);
                                setznp8(temp);
                                cycles-=((mod==3)?3:7);
                                flags|=A_FLAG;
                                break;

                                default:
                                printf("Bad D2 opcode %02X\n",rmdat&0x38);
//                                dumpregs();
//                                exit(-1);
                        }
                        break;

                        case 0xD3: case 0x2D3:
                        fetchea();
                        tempw=geteaw();
                        c=CL&31;
                        if (!c) break;
                        switch (rmdat&0x38)
                        {
                                case 0x00: /*ROL w,CL*/
                                while (c>0)
                                {
                                        temp=(tempw&0x8000)?1:0;
                                        tempw=(tempw<<1)|temp;
                                        c--;
                                }
                                if (temp) flags|=C_FLAG;
                                else      flags&=~C_FLAG;
                                seteaw(tempw);
                                if ((flags&C_FLAG)^(tempw>>15)) flags|=V_FLAG;
                                else                            flags&=~V_FLAG;
                                cycles-=((mod==3)?3:7);
                                break;
                                case 0x08: /*ROR w,CL*/
                                while (c>0)
                                {
                                        tempw2=(tempw&1)?0x8000:0;
                                        tempw=(tempw>>1)|tempw2;
                                        c--;
                                }
                                if (tempw2) flags|=C_FLAG;
                                else        flags&=~C_FLAG;
                                seteaw(tempw);
                                if ((tempw^(tempw>>1))&0x4000) flags|=V_FLAG;
                                else                           flags&=~V_FLAG;
                                cycles-=((mod==3)?3:7);
                                break;
                                case 0x10: /*RCL w,CL*/
                                while (c>0)
                                {
                                        templ=flags&C_FLAG;
                                        if (tempw&0x8000) flags|=C_FLAG;
                                        else              flags&=~C_FLAG;
                                        tempw=(tempw<<1)|templ;
                                        c--;
                                }
                                if (temp) flags|=C_FLAG;
                                else      flags&=~C_FLAG;
                                seteaw(tempw);
                                if ((flags&C_FLAG)^(tempw>>15)) flags|=V_FLAG;
                                else                            flags&=~V_FLAG;
                                cycles-=((mod==3)?3:7);
                                break;
                                case 0x18: /*RCR w,CL*/
                                while (c>0)
                                {
                                        templ=flags&C_FLAG;
                                        tempw2=(templ&1)?0x8000:0;
                                        if (tempw&1) flags|=C_FLAG;
                                        else         flags&=~C_FLAG;
                                        tempw=(tempw>>1)|tempw2;
                                        c--;
                                }
                                if (tempw2) flags|=C_FLAG;
                                else        flags&=~C_FLAG;
                                seteaw(tempw);
                                if ((tempw^(tempw>>1))&0x4000) flags|=V_FLAG;
                                else                           flags&=~V_FLAG;
                                cycles-=((mod==3)?3:7);
                                break;

                                case 0x20: case 0x30: /*SHL w,CL*/
                                if (c>16)
                                {
                                        tempw=0;
                                        flags&=~C_FLAG;
                                }
                                else
                                {
                                        if ((tempw<<(c-1))&0x8000) flags|=C_FLAG;
                                        else                       flags&=~C_FLAG;
                                        tempw<<=c;
                                }
                                seteaw(tempw);
                                setznp16(tempw);
                                cycles-=((mod==3)?3:7);
                                flags|=A_FLAG;
                                break;

                                case 0x28:            /*SHR w,CL*/
                                if ((tempw>>(c-1))&1) flags|=C_FLAG;
                                else                  flags&=~C_FLAG;
                                tempw>>=c;
                                seteaw(tempw);
                                setznp16(tempw);
                                cycles-=((mod==3)?3:7);
                                flags|=A_FLAG;
                                break;

                                case 0x38:            /*SAR w,CL*/
                                tempw2=tempw&0x8000;
                                if ((tempw>>(c-1))&1) flags|=C_FLAG;
                                else                  flags&=~C_FLAG;
                                while (c>0)
                                {
                                        tempw=(tempw>>1)|tempw2;
                                        c--;
                                }
                                seteaw(tempw);
                                setznp16(tempw);
                                cycles-=((mod==3)?3:7);
                                flags|=A_FLAG;
                                break;

                                default:
                                printf("Bad D3 opcode %02X\n",rmdat&0x38);
//                                dumpregs();
//                                exit(-1);
                        }
                        break;
                        case 0x1D3: case 0x3D3:
                        fetchea();
                        templ=geteal();
                        c=CL&31;
                        if (!c) break;
                        switch (rmdat&0x38)
                        {
                                case 0x00: /*ROL l,CL*/
                                while (c>0)
                                {
                                        temp=(templ&0x80000000)?1:0;
                                        templ=(templ<<1)|temp;
                                        c--;
                                }
                                if (temp) flags|=C_FLAG;
                                else      flags&=~C_FLAG;
                                seteal(templ);
                                if ((flags&C_FLAG)^(templ>>31)) flags|=V_FLAG;
                                else                            flags&=~V_FLAG;
                                cycles-=((mod==3)?3:7);
                                break;
                                case 0x08: /*ROR l,CL*/
                                while (c>0)
                                {
                                        templ2=(templ&1)?0x80000000:0;
                                        templ=(templ>>1)|templ2;
                                        c--;
                                }
                                if (templ2) flags|=C_FLAG;
                                else        flags&=~C_FLAG;
                                seteal(templ);
                                if ((templ^(templ>>1))&0x40000000) flags|=V_FLAG;
                                else                               flags&=~V_FLAG;
                                cycles-=((mod==3)?3:7);
                                break;
                                case 0x10: /*RCL l,CL*/
                                while (c>0)
                                {
                                        templ2=flags&C_FLAG;
                                        if (templ&0x80000000) flags|=C_FLAG;
                                        else                  flags&=~C_FLAG;
                                        templ=(templ<<1)|templ2;
                                        c--;
                                }
//                                if (templ2) flags|=C_FLAG;
//                                else        flags&=~C_FLAG;
                                seteal(templ);
                                if ((flags&C_FLAG)^(templ>>31)) flags|=V_FLAG;
                                else                            flags&=~V_FLAG;
                                cycles-=((mod==3)?3:7);
                                break;
                                case 0x18: /*RCR l,CL*/
                                while (c>0)
                                {
                                        templ2=(flags&C_FLAG)?0x80000000:0;
                                        if (templ&1) flags|=C_FLAG;
                                        else         flags&=~C_FLAG;
                                        templ=(templ>>1)|templ2;
                                        c--;
                                }
//                                if (templ2) flags|=C_FLAG;
//                                else        flags&=~C_FLAG;
                                seteal(templ);
                                if ((templ^(templ>>1))&0x40000000) flags|=V_FLAG;
                                else                               flags&=~V_FLAG;
                                cycles-=((mod==3)?3:7);
                                break;

                                case 0x20: case 0x30: /*SHL l,CL*/
                                if ((templ<<(c-1))&0x80000000) flags|=C_FLAG;
                                else                           flags&=~C_FLAG;
                                templ<<=c;
                                seteal(templ);
                                setznp32(templ);
                                cycles-=((mod==3)?3:7);
                                flags|=A_FLAG;
                                break;

                                case 0x28:            /*SHR l,CL*/
                                if ((templ>>(c-1))&1) flags|=C_FLAG;
                                else                  flags&=~C_FLAG;
                                templ>>=c;
                                seteal(templ);
                                setznp32(templ);
                                cycles-=((mod==3)?3:7);
                                flags|=A_FLAG;
                                break;

                                case 0x38:            /*SAR w,CL*/
                                templ2=templ&0x80000000;
                                if ((templ>>(c-1))&1) flags|=C_FLAG;
                                else                  flags&=~C_FLAG;
                                while (c>0)
                                {
                                        templ=(templ>>1)|templ2;
                                        c--;
                                }
                                seteal(templ);
                                setznp32(templ);
                                cycles-=((mod==3)?3:7);
                                flags|=A_FLAG;
                                break;

                                default:
                                printf("Bad D3 opcode %02X\n",rmdat&0x38);
//                                dumpregs();
//                                exit(-1);
                        }
                        break;

                        case 0xD4: case 0x1D4: case 0x2D4: case 0x3D4: /*AAM*/
                        tempws=readmemb(cs,pc); pc++;
                        AH=AL/tempws;
                        AL%=tempws;
                        setznp168(AX);
                        cycles-=(is486)?15:17;
                        break;
                        case 0xD5: case 0x1D5: case 0x2D5: case 0x3D5: /*AAD*/
                        tempws=readmemb(cs,pc); pc++;
                        AL=(AH*tempws)+AL;
                        AH=0;
                        setznp168(AX);
                        cycles-=(is486)?14:19;
                        break;
                        case 0xD7: case 0x1D7: /*XLAT*/
                        addr=(BX+AL)&0xFFFF;
                        AL=readmemb(ds,addr);
                        cycles-=5;
                        break;
                        case 0x2D7: case 0x3D7: /*XLAT*/
                        addr=EBX+AL;
                        AL=readmemb(ds,addr);
                        cycles-=5;
                        break;
                        case 0xD9: case 0xDA: case 0xDB: case 0xDD:     /*ESCAPE*/
                        case 0x1D9: case 0x1DA: case 0x1DB: case 0x1DD: /*ESCAPE*/
                        case 0x2D9: case 0x2DA: case 0x2DB: case 0x2DD: /*ESCAPE*/
                        case 0x3D9: case 0x3DA: case 0x3DB: case 0x3DD: /*ESCAPE*/
                        case 0xD8: case 0x1D8: case 0x2D8: case 0x3D8:
                        case 0xDC: case 0x1DC: case 0x2DC: case 0x3DC:
                        case 0xDE: case 0x1DE: case 0x2DE: case 0x3DE:
                        case 0xDF: case 0x1DF: case 0x2DF: case 0x3DF:
                        if (cr0&1)
                        {
                                if ((cr0&5)==5)
                                {
                                        pc--;
                                        pmodeint(7,0);
                                        cycles-=59;
                                }
                                else
                                {
                                        fetchea();
                                        geteab();
                                }
                        }
                        else
                        {
                                fetchea();
                                geteab();
                        }
                        break;

                        case 0xE0: case 0x1E0: /*LOOPNE*/
                        offset=(signed char)readmemb(cs,pc); pc++;
                        CX--;
                        if (CX && !(flags&Z_FLAG)) { pc+=offset; }
                        cycles-=(is486)?7:11;
                        break;
                        case 0x2E0: case 0x3E0: /*LOOPNE*/
                        offset=(signed char)readmemb(cs,pc); pc++;
                        ECX--;
                        if (ECX && !(flags&Z_FLAG)) { pc+=offset; }
                        cycles-=(is486)?7:11;
                        break;
                        case 0xE1: case 0x1E1: /*LOOPE*/
                        offset=(signed char)readmemb(cs,pc); pc++;
                        CX--;
                        if (CX && (flags&Z_FLAG)) { pc+=offset; }
                        cycles-=(is486)?7:11;
                        break;
                        case 0x2E1: case 0x3E1: /*LOOPE*/
                        offset=(signed char)readmemb(cs,pc); pc++;
                        ECX--;
                        if (ECX && (flags&Z_FLAG)) { pc+=offset; }
                        cycles-=(is486)?7:11;
                        break;
                        case 0xE2: case 0x1E2: /*LOOP*/
                        offset=(signed char)readmemb(cs,pc); pc++;
                        CX--;
                        if (CX) { pc+=offset; }
                        cycles-=(is486)?7:11;
                        break;
                        case 0x2E2: case 0x3E2: /*LOOP*/
                        offset=(signed char)readmemb(cs,pc); pc++;
                        ECX--;
                        if (ECX) { pc+=offset; }
                        cycles-=(is486)?7:11;
                        break;
                        case 0xE3: case 0x1E3: /*JCXZ*/
                        offset=(signed char)readmemb(cs,pc); pc++;
                        if (!CX) { pc+=offset; cycles-=4; }
                        cycles-=5;
                        break;
                        case 0x2E3: case 0x3E3: /*JECXZ*/
                        offset=(signed char)readmemb(cs,pc); pc++;
                        if (!ECX) { pc+=offset; cycles-=4; }
                        cycles-=5;
                        break;

                        case 0xE4: case 0x1E4: case 0x2E4: case 0x3E4: /*IN AL*/
                        temp=readmemb(cs,pc);
                        if (!IOPLp && checkio(temp))
                        {
                                printf("Can't IN AL\n");
//                                output=3;
                                x86gpf(NULL,0);
                        }
                        else
                        {
                                temp=readmemb(cs,pc); pc++;
                                AL=inb(temp);
                                cycles-=12;
                        }
                        break;
                        case 0xE5: case 0x2E5: /*IN AX*/
                        temp=readmemb(cs,pc);
                        if (!IOPLp && checkio(temp))
                        {
                                printf("Can't IN AX\n");
//                                output=3;
                                x86gpf(NULL,0);
                        }
                        else
                        {
                                temp=readmemb(cs,pc); pc++;
                                AL=inb(temp);
                                AH=inb(temp+1);
                                cycles-=12;
                        }
                        break;
                        case 0x1E5: case 0x3E5: /*IN EAX*/
                        temp=readmemb(cs,pc);
                        if (!IOPLp && checkio(temp))
                        {
                                printf("Can't IN EAX\n");
//                                output=3;
                                x86gpf(NULL,0);
                        }
                        else
                        {
                                temp=readmemb(cs,pc); pc++;
                                AL=inb(temp);
                                AH=inb(temp+1);
                                EAX<<=16;
                                AL=inb(temp+2);
                                AH=inb(temp+3);
                                cycles-=12;
                        }
                        break;
                        case 0xE6: case 0x1E6: case 0x2E6: case 0x3E6: /*OUT AL*/
                        temp=readmemb(cs,pc);
                        if (!IOPLp && checkio(temp))
                        {
                                printf("Can't OUT AL\n");
//                                output=3;
                                x86gpf(NULL,0);
                        }
                        else
                        {
                                temp=readmemb(cs,pc); pc++;
                                outb(temp,AL);
                                cycles-=10;
                        }
                        break;
                        case 0xE7: case 0x2E7: /*OUT AX*/
                        temp=readmemb(cs,pc);
                        if (!IOPLp && checkio(temp))
                        {
                                printf("Can't OUT AX\n");
//                                output=3;
                                x86gpf(NULL,0);
                        }
                        else
                        {
                                temp=readmemb(cs,pc); pc++;
                                outb(temp,AL);
                                outb(temp+1,AH);
                                cycles-=10;
                        }
                        break;
                        case 0x1E7: case 0x3E7: /*OUT EAX*/
                        temp=readmemb(cs,pc);
                        if (!IOPLp && checkio(temp))
                        {
                                printf("Can't OUT EAX\n");
//                                output=3;
                                x86gpf(NULL,0);
                        }
                        else
                        {
                                temp=readmemb(cs,pc); pc++;
                                outb(temp,AL);
                                outb(temp+1,AH);
                                outb(temp+2,(EAX>>16)&0xFF);
                                outb(temp+3,(EAX>>24)&0xFF);
                                cycles-=10;
                        }
                        break;

                        case 0xE8: /*CALL rel 16*/
                        tempw=getword();
                        if (ssegs) ss=oldss;
                        if (stack32)
                        {
                                writememw(ss,ESP-2,pc);
//                                if (output) printf("Write %04X to %04X(%08X):%08X\n",pc,SS,ss,ESP-2);
                                ESP-=2;
                        }
                        else
                        {
                                writememw(ss,((SP-2)&0xFFFF),pc);
//                                if (output) printf("Write %04X to %04X(%08X):%04X\n",pc,SS,ss,(SP-2)&0xFFFF);
                                SP-=2;
                        }
                        pc+=(signed short)tempw;
                        cycles-=(is486)?3:7;
                        break;
                        case 0x3E8: /*CALL rel 16*/
                        templ=getlong();
                        if (ssegs) ss=oldss;
                        if (stack32)
                        {
                                writememl(ss,ESP-4,pc);
                                ESP-=4;
                                if (output==3) printf("Write PC %08X to %08X - %08X:%08X\n",pc,ESP,ss,ESP);
                        }
                        else
                        {
                                writememl(ss,((SP-4)&0xFFFF),pc);
                                SP-=4;
                                if (output==3) printf("Write PC %08X to 16-bit %08X - %08X:%08X\n",pc,SP,ss,SP);
                        }
                        pc+=templ;
                        cycles-=(is486)?3:7;
                        break;
                        case 0xE9: case 0x2E9: /*JMP rel 16*/
                        pc+=(signed short)getword();
                        cycles-=(is486)?3:7;
                        break;
                        case 0x1E9: case 0x3E9: /*JMP rel 32*/
                        pc+=getlong();
                        cycles-=(is486)?3:7;
                        break;
                        case 0xEA: case 0x2EA: /*JMP far*/
                        addr=getword();
                        tempw=getword();
                        oxpc=pc;
                        pc=addr;
                        optype=JMP;
                        loadcs(tempw);
                        cycles-=(is486)?17:12;
                        break;
                        case 0x1EA: case 0x3EA: /*JMP far*/
                        templ=getlong();
                        tempw=getword();
                        oxpc=pc;
                        pc=templ;
                        optype=JMP;
                        loadcs(tempw);
                        cycles-=(is486)?17:12;
                        break;
                        case 0xEB: case 0x1EB: case 0x2EB: case 0x3EB: /*JMP rel*/
                        offset=(signed char)readmemb(cs,pc); pc++;
                        pc+=offset;
                        cycles-=(is486)?3:7;
                        break;
                        case 0xEC: case 0x1EC: case 0x2EC: case 0x3EC: /*IN AL,DX*/
                        AL=inb(DX);
                        cycles-=13;
                        break;
                        case 0xED: case 0x2ED: /*IN AX,DX*/
                        AL=inb(DX);
                        AH=inb(DX+1);
                        cycles-=13;
                        break;
                        case 0x1ED: case 0x3ED: /*IN EAX,DX*/
                        AL=inb(DX);
                        AH=inb(DX+1);
                        EAX<<=16;
                        AL=inb(DX+2);
                        AH=inb(DX+3);
                        cycles-=13;
                        break;
                        case 0xEE: case 0x1EE: case 0x2EE: case 0x3EE: /*OUT DX,AL*/
                        outb(DX,AL);
                        cycles-=11;
                        break;
                        case 0xEF: case 0x2EF: /*OUT DX,AX*/
                        outb(DX,AL);
                        outb(DX+1,AH);
                        cycles-=11;
                        break;
                        case 0x1EF: case 0x3EF: /*OUT DX,EAX*/
                        outb(DX,AL);
                        outb(DX+1,AH);
                        outb(DX+2,(EAX>>16)&0xFF);
                        outb(DX+3,(EAX>>24)&0xFF);
                        cycles-=11;
                        break;

                        case 0xF0: case 0x1F0: case 0x2F0: case 0x3F0: /*LOCK*/
                        cycles-=4;
                        break;

                        case 0xF2: case 0x1F2: case 0x2F2: case 0x3F2: /*REPNE*/
                        rep386(0);
                        break;
                        case 0xF3: case 0x1F3: case 0x2F3: case 0x3F3: /*REPE*/
                        rep386(1);
                        break;

                        case 0xF4: case 0x1F4: case 0x2F4: case 0x3F4: /*HLT*/
/*                        if (flags&I_FLAG)
                        {
                                softresetx86();
                                break;
                        }*/

//                        printf("IN HLT!!!! %04X:%04X %08X %08X %08X\n",oldcs,oldpc,old8,old82,old83);
//                        dumpregs();
//                        exit(-1);
                        inhlt=1;
                        pc--;
                        cycles-=5;
                        break;
                        case 0xF5: case 0x1F5: case 0x2F5: case 0x3F5: /*CMC*/
                        flags^=C_FLAG;
                        cycles-=2;
                        break;

                        case 0xF6: case 0x1F6: case 0x2F6: case 0x3F6:
                        fetchea();
                        temp=geteab();
                        switch (rmdat&0x38)
                        {
                                case 0x00: /*TEST b,#8*/
                                temp2=readmemb(cs,pc); pc++;
//                                printf("TEST %02X,%02X\n",temp,temp2);
/*                        if (cs==0x700 && !temp && temp2==0x10)
                        {
                                dumpregs();
                                exit(-1);
                        }*/
                                temp&=temp2;
                                setznp8(temp);
                                flags&=~(C_FLAG|V_FLAG|A_FLAG);
                                if (is486) cycles-=((mod==3)?1:2);
                                else       cycles-=((mod==3)?2:5);
                                break;
                                case 0x10: /*NOT b*/
                                temp=~temp;
                                seteab(temp);
                                if (is486) cycles-=((mod==3)?1:3);
                                else       cycles-=((mod==3)?2:6);
                                break;
                                case 0x18: /*NEG b*/
                                setsub8(0,temp);
                                temp=0-temp;
                                seteab(temp);
                                if (is486) cycles-=((mod==3)?1:3);
                                else       cycles-=((mod==3)?2:6);
                                break;
                                case 0x20: /*MUL AL,b*/
//                                setznp8(AL);
                                AX=AL*temp;
//                                if (AX) flags&=~Z_FLAG;
//                                else    flags|=Z_FLAG;
                                if (AH) flags|=(C_FLAG|V_FLAG);
                                else    flags&=~(C_FLAG|V_FLAG);
                                cycles-=13;
                                break;
                                case 0x28: /*IMUL AL,b*/
//                                setznp8(AL);
                                tempws=(int)((signed char)AL)*(int)((signed char)temp);
                                AX=tempws&0xFFFF;
//                                if (AX) flags&=~Z_FLAG;
//                                else    flags|=Z_FLAG;
                                if (AH && AH!=0xFF) flags|=(C_FLAG|V_FLAG);
                                else                flags&=~(C_FLAG|V_FLAG);
                                cycles-=14;
                                break;
                                case 0x30: /*DIV AL,b*/
                                tempw=AX;
                                if (temp)
                                {
                                        tempw2=tempw%temp;
                                        AH=tempw2;
                                        tempw/=temp;
                                        AL=tempw&0xFF;
                                }
                                else
                                {
                                        printf("DIVb BY 0 %04X:%04X\n",cs>>4,pc);
                                        pc=oldpc;
                                        if (msw&1) pmodeint(0,1);
                                        else
                                        {
//                                        printf("%04X:%04X\n",cs>>4,pc);
                                                writememw(ss,(SP-2)&0xFFFF,flags);
                                                writememw(ss,(SP-4)&0xFFFF,CS);
                                                writememw(ss,(SP-6)&0xFFFF,pc);
                                                SP-=6;
                                                flags&=~I_FLAG;
                                                oxpc=pc;
                                                pc=readmemw(0,0);
                                                loadcs(readmemw(0,2));
                                        }
//                                                cs=loadcs(CS);
//                                                cs=CS<<4;
//                                        printf("Div by zero %04X:%04X %02X %02X\n",cs>>4,pc,0xf6,0x30);
//                                        dumpregs();
//                                        exit(-1);
                                }
                                cycles-=(is486)?16:14;
                                break;
                                case 0x38: /*IDIV AL,b*/
                                tempws=(int)(signed short)AX;
                                if (temp)
                                {
                                        tempw2=tempws%(int)((signed char)temp);
                                        AH=tempw2&0xFF;
                                        tempws/=(int)((signed char)temp);
                                        AL=tempws&0xFF;
                                }
                                else
                                {
                                        printf("IDIVb BY 0 %04X:%04X\n",cs>>4,pc);
                                        pc=oldpc;
                                        if (msw&1) pmodeint(0,1);
                                        else
                                        {
                                                writememw(ss,(SP-2)&0xFFFF,flags);
                                                writememw(ss,(SP-4)&0xFFFF,CS);
                                                writememw(ss,(SP-6)&0xFFFF,pc);
                                                SP-=6;
                                                flags&=~I_FLAG;
                                                oxpc=pc;
                                                pc=readmemw(0,0);
                                                loadcs(readmemw(0,2));
                                        }
//                                                cs=loadcs(CS);
//                                                cs=CS<<4;
//                                        printf("Div by zero %04X:%04X %02X %02X\n",cs>>4,pc,0xf6,0x38);
                                }
                                cycles-=19;
                                break;

                                default:
                                printf("Bad F6 opcode %02X\n",rmdat&0x38);
//                                dumpregs();
//                                exit(-1);
                        }
                        break;

                        case 0xF7: case 0x2F7:
                        fetchea();
                        tempw=geteaw();
                        switch (rmdat&0x38)
                        {
                                case 0x00: /*TEST w*/
                                tempw2=getword();
                                setznp16(tempw&tempw2);
                                flags&=~(C_FLAG|V_FLAG|A_FLAG);
                                if (is486) cycles-=((mod==3)?1:2);
                                else       cycles-=((mod==3)?2:5);
                                break;
                                case 0x10: /*NOT w*/
                                seteaw(~tempw);
                                if (is486) cycles-=((mod==3)?1:3);
                                else       cycles-=((mod==3)?2:6);
                                break;
                                case 0x18: /*NEG w*/
                                setsub16(0,tempw);
                                tempw=0-tempw;
                                seteaw(tempw);
                                if (is486) cycles-=((mod==3)?1:3);
                                else       cycles-=((mod==3)?2:6);
                                break;
                                case 0x20: /*MUL AX,w*/
//                                setznp16(AX);
                                templ=AX*tempw;
                                AX=templ&0xFFFF;
                                DX=templ>>16;
//                                if (AX|DX) flags&=~Z_FLAG;
//                                else       flags|=Z_FLAG;
                                if (DX)    flags|=(C_FLAG|V_FLAG);
                                else       flags&=~(C_FLAG|V_FLAG);
                                cycles-=21;
                                break;
                                case 0x28: /*IMUL AX,w*/
//                                setznp16(AX);
//                                printf("IMUL %i %i ",(int)((signed short)AX),(int)((signed short)tempw));
                                tempws=(int)((signed short)AX)*(int)((signed short)tempw);
                                if ((tempws>>15) && ((tempws>>15)!=-1)) flags|=(C_FLAG|V_FLAG);
                                else                                    flags&=~(C_FLAG|V_FLAG);
//                                printf("%i ",tempws);
                                AX=tempws&0xFFFF;
                                tempws=(unsigned short)(tempws>>16);
                                DX=tempws&0xFFFF;
//                                printf("%04X %04X\n",AX,DX);
//                                dumpregs();
//                                exit(-1);
//                                if (AX|DX) flags&=~Z_FLAG;
//                                else       flags|=Z_FLAG;
                                cycles-=22;
                                break;
                                case 0x30: /*DIV AX,w*/
                                templ=(DX<<16)|AX;
//                                printf("DIV %08X/%04X\n",templ,tempw);
                                if (tempw)
                                {
                                        tempw2=templ%tempw;
                                        DX=tempw2;
                                        templ/=tempw;
                                        AX=templ&0xFFFF;
                                }
                                else
                                {
//                                        AX=DX=0;
//                                        break;
                                        printf("DIVw BY 0 %04X:%04X\n",cs>>4,pc);
//                                        dumpregs();
//                                        exit(-1);
                                        pc=oldpc;
                                        if (msw&1) pmodeint(0,1);
                                        else
                                        {
//                                        printf("%04X:%04X\n",cs>>4,pc);
                                                writememw(ss,(SP-2)&0xFFFF,flags);
                                                writememw(ss,(SP-4)&0xFFFF,CS);
                                                writememw(ss,(SP-6)&0xFFFF,pc);
                                                SP-=6;
                                                flags&=~I_FLAG;
                                                oxpc=pc;
                                                pc=readmemw(0,0);
                                                loadcs(readmemw(0,2));
                                        }
//                                                cs=loadcs(CS);
//                                                cs=CS<<4;
//                                        printf("Div by zero %04X:%04X %02X %02X 1\n",cs>>4,pc,0xf7,0x30);
                                }
                                cycles-=(is486)?24:22;
                                break;
                                case 0x38: /*IDIV AX,w*/
                                tempws=(int)((DX<<16)|AX);
//                                printf("IDIV %i %i ",tempws,tempw);
                                if (tempw)
                                {
                                        tempw2=tempws%(int)((signed short)tempw);
                                        DX=tempw2;
                                        tempws/=(int)((signed short)tempw);
                                        AX=tempws&0xFFFF;
                                }
                                else
                                {
                                        printf("IDIVw BY 0 %04X:%04X\n",cs>>4,pc);
                                        DX=0;
                                        AX=0xFFFF;
/*                                        pc=oldpc;
                                        if (msw&1) pmodeint(0,1);
                                        else
                                        {
//                                        printf("%04X:%04X\n",cs>>4,pc);
                                                writememw(ss,(SP-2)&0xFFFF,flags);
                                                writememw(ss,(SP-4)&0xFFFF,CS);
                                                writememw(ss,(SP-6)&0xFFFF,pc);
                                                SP-=6;
                                                flags&=~I_FLAG;
                                                oxpc=pc;
                                                pc=readmemw(0,0);
                                                loadcs(readmemw(0,2));
                                        }*/
//                                                cs=loadcs(CS);
//                                                cs=CS<<4;
//                                        printf("Div by zero %04X:%04X %02X %02X 1\n",cs>>4,pc,0xf7,0x38);
                                }
                                cycles-=27;
                                break;

                                default:
                                printf("Bad F7 opcode %02X\n",rmdat&0x38);
//                                dumpregs();
//                                exit(-1);
                        }
                        break;
                        case 0x1F7: case 0x3F7:
                        fetchea();
                        templ=geteal();
                        switch (rmdat&0x38)
                        {
                                case 0x00: /*TEST l*/
                                templ2=getlong();
                                setznp32(templ&templ2);
                                flags&=~(C_FLAG|V_FLAG|A_FLAG);
                                if (is486) cycles-=((mod==3)?1:2);
                                else       cycles-=((mod==3)?2:5);
                                break;
                                case 0x10: /*NOT l*/
                                seteal(~templ);
                                if (is486) cycles-=((mod==3)?1:3);
                                else       cycles-=((mod==3)?2:6);
                                break;
                                case 0x18: /*NEG l*/
                                setsub32(0,templ);
                                templ=0-templ;
                                seteal(templ);
                                if (is486) cycles-=((mod==3)?1:3);
                                else       cycles-=((mod==3)?2:6);
                                break;
                                case 0x20: /*MUL EAX,l*/
                                temp64=(uint64_t)EAX*(uint64_t)templ;
                                EAX=temp64&0xFFFFFFFF;
                                EDX=temp64>>32;
                                if (EDX) flags|= (C_FLAG|V_FLAG);
                                else     flags&=~(C_FLAG|V_FLAG);
                                cycles-=21;
                                break;
                                case 0x28: /*IMUL EAX,l*/
                                temp64i=(int64_t)(signed long)EAX*(int64_t)(signed long)templ;
                                EAX=temp64i&0xFFFFFFFF;
                                EDX=temp64i>>32;
                                if ((temp64i>>31) && ((temp64i>>31)!=-1)) flags|=(C_FLAG|V_FLAG);
                                else                                      flags&=~(C_FLAG|V_FLAG);
                                cycles-=38;
                                break;
                                case 0x30: /*DIV EAX,l*/
                                temp64=((uint64_t)EDX<<32)|EAX;
//                                printf("DIV %08X/%04X\n",templ,tempw);
                                if (templ)
                                {
//                                        printf("DIV %08X%08X / %08X = ",EDX,EAX,templ);
                                        templ2=temp64%templ;
                                        EDX=templ2;
                                        temp64/=templ;
                                        EAX=temp64&0xFFFFFFFF;
//                                        printf("%08X %08X\n",EAX,EDX);
                                }
                                else
                                {
                                        printf("DIV EAX by 0\n");
                                        pc=oldpc;
//                                        printf("%04X:%04X\n",cs>>4,pc);
                                        if (msw&1) pmodeint(0,1);
                                        else
                                        {
//                                        printf("%04X:%04X\n",cs>>4,pc);
                                                writememw(ss,(SP-2)&0xFFFF,flags);
                                                writememw(ss,(SP-4)&0xFFFF,CS);
                                                writememw(ss,(SP-6)&0xFFFF,pc);
                                                SP-=6;
                                                flags&=~I_FLAG;
                                                oxpc=pc;
                                                pc=readmemw(0,0);
                                                loadcs(readmemw(0,2));
                                        }
//                                                cs=CS<<4;
//                                        printf("Div by zero %04X:%04X %02X %02X 1\n",cs>>4,pc,0xf7,0x30);
                                }
                                cycles-=(is486)?40:38;
                                break;
                                case 0x38: /*IDIV EAX,l*/
                                temp64i=(int64_t)((uint64_t)EDX<<32)|EAX;
                                if (templ)
                                {
//                                        printf("IDIV - %08X%08X / %08X = ",EDX,EAX,templ);
                                        templ2=temp64i%(int)((signed long)templ);
                                        EDX=templ2;
                                        temp64i/=(int)((signed long)templ);
                                        EAX=temp64i&0xFFFFFFFF;
//                                        printf("%08X %08X\n",EAX,EDX);
                                }
                                else
                                {
//                                        printf("IDIV EAX by 0\n");
                                        pc=oldpc;
                                        if (msw&1) pmodeint(0,1);
                                        else
                                        {
//                                        printf("%04X:%04X\n",cs>>4,pc);
                                                writememw(ss,(SP-2)&0xFFFF,flags);
                                                writememw(ss,(SP-4)&0xFFFF,CS);
                                                writememw(ss,(SP-6)&0xFFFF,pc);
                                                SP-=6;
                                                flags&=~I_FLAG;
                                                oxpc=pc;
                                                pc=readmemw(0,0);
                                                loadcs(readmemw(0,2));
                                        }
                                }
                                cycles-=43;
                                break;

                                default:
                                printf("Bad F7 opcode %02X\n",rmdat&0x38);
//                                dumpregs();
//                                exit(-1);
                        }
                        break;

                        case 0xF8: case 0x1F8: case 0x2F8: case 0x3F8: /*CLC*/
                        flags&=~C_FLAG;
                        cycles-=2;
                        break;
                        case 0xF9: case 0x1F9: case 0x2F9: case 0x3F9: /*STC*/
//                        printf("STC %04X\n",pc);
                        flags|=C_FLAG;
                        cycles-=2;
                        break;
                        case 0xFA: case 0x1FA: case 0x2FA: case 0x3FA: /*CLI*/
                        if (!IOPLp)
                        {
                                printf("Can't CLI\n");
                                x86gpf(NULL,0);
                        }
                        else
                           flags&=~I_FLAG;
//                                printf("CLI in <IOPL shocker!\n");
//                                dumpregs();
//                                exit(-1);
//                        printf("CLI at %04X:%04X\n",cs>>4,pc);
                        cycles-=3;
                        break;
                        case 0xFB: case 0x1FB: case 0x2FB: case 0x3FB: /*STI*/
                        if (!IOPLp)
                        {
                                printf("Can't STI\n");
//                                output=3;
                                x86gpf(NULL,0);
                        }
                        else
                           flags|=I_FLAG;
/*                        if (!IOPLp)
                        {
                                printf("STI in <IOPL shocker!\n");
                                dumpregs();
                                exit(-1);
                        }
                        flags|=I_FLAG;*/
//                        printf("STI at %04X:%04X\n",cs>>4,pc);
                        cycles-=2;
                        break;
                        case 0xFC: case 0x1FC: case 0x2FC: case 0x3FC: /*CLD*/
                        flags&=~D_FLAG;
                        cycles-=2;
                        break;
                        case 0xFD: case 0x1FD: case 0x2FD: case 0x3FD: /*STD*/
                        flags|=D_FLAG;
                        cycles-=2;
                        break;

                        case 0xFE: case 0x1FE: case 0x2FE: case 0x3FE: /*INC/DEC b*/
                        fetchea();
                        temp=geteab();
                        flags&=~V_FLAG;
                        if (rmdat&0x38)
                        {
                                setsub8nc(temp,1);
                                temp2=temp-1;
                                if ((temp&0x80) && !(temp2&0x80)) flags|=V_FLAG;
                        }
                        else
                        {
                                setadd8nc(temp,1);
                                temp2=temp+1;
                                if ((temp2&0x80) && !(temp&0x80)) flags|=V_FLAG;
                        }
//                        setznp8(temp2);
                        seteab(temp2);
                        if (is486) cycles-=((mod==3)?1:2);
                        else       cycles-=((mod==3)?2:6);
                        break;

                        case 0xFF: case 0x2FF:
                        fetchea();
                        switch (rmdat&0x38)
                        {
                                case 0x00: /*INC w*/
                                tempw=geteaw();
                                setadd16nc(tempw,1);
                                seteaw(tempw+1);
                                if (is486) cycles-=((mod==3)?1:2);
                                else       cycles-=((mod==3)?2:6);
                                break;
                                case 0x08: /*DEC w*/
                                tempw=geteaw();
                                setsub16nc(tempw,1);
                                seteaw(tempw-1);
                                if (is486) cycles-=((mod==3)?1:2);
                                else       cycles-=((mod==3)?2:6);
                                break;
                                case 0x10: /*CALL*/
                                tempw=geteaw();
                                if (ssegs) ss=oldss;
                                if (stack32)
                                {
                                        writememw(ss,ESP-2,pc);
                                        ESP-=2;
                                }
                                else
                                {
                                        writememw(ss,(SP-2)&0xFFFF,pc);
                                        SP-=2;
                                }
                                pc=tempw;
                                if (is486) cycles-=5;
                                else       cycles-=((mod==3)?7:10);
                                break;
                                case 0x18: /*CALL far*/
                                tempw=readmemw(easeg,eaaddr);
                                tempw2=readmemw(easeg,(eaaddr+2)); //geteaw2();
                                tempw3=CS;
                                tempw4=pc;
                                if (ssegs) ss=oldss;
                                oxpc=pc;
                                pc=tempw;
                                optype=CALL;
                                cgate32=0;
                                if (msw&1) loadcscall(tempw2);
                                else       loadcs(tempw2);
                                if (notpresent) break;
                                if (cgate32) goto writecall32_2;
                                if (stack32)
                                {
                                        writememw(ss,ESP-2,tempw3);
                                        writememw(ss,ESP-4,tempw4);
                                        ESP-=4;
                                }
                                else
                                {
                                        writememw(ss,(SP-2)&0xFFFF,tempw3);
                                        writememw(ss,((SP-4)&0xFFFF),tempw4);
                                        SP-=4;
                                }
                                cycles-=(is486)?17:22;
                                break;
                                case 0x20: /*JMP*/
                                pc=geteaw();
                                if (is486) cycles-=5;
                                else       cycles-=((mod==3)?7:10);
                                break;
                                case 0x28: /*JMP far*/
                                oxpc=pc;
                                pc=readmemw(easeg,eaaddr); //geteaw();
                                optype=JMP;
                                loadcs(readmemw(easeg,(eaaddr+2))); //geteaw2();
                                cycles-=(is486)?13:12;
                                break;
                                case 0x30: /*PUSH w*/
                                tempw=geteaw();
                                if (ssegs) ss=oldss;
                                if (stack32)
                                {
                                        writememw(ss,ESP-2,tempw);
                                        ESP-=2;
                                }
                                else
                                {
                                        writememw(ss,((SP-2)&0xFFFF),tempw);
                                        SP-=2;
                                }
                                cycles-=((mod==3)?2:5);
                                break;

                                default:
                                printf("Bad FF opcode %02X\n",rmdat&0x38);
                                dumpregs();
                                exit(-1);
                        }
                        break;
                        case 0x1FF: case 0x3FF:
                        fetchea();
                        switch (rmdat&0x38)
                        {
                                case 0x00: /*INC l*/
                                templ=geteal();
                                setadd32nc(templ,1);
                                seteal(templ+1);
                                cycles-=((mod==3)?2:6);
                                break;
                                case 0x08: /*DEC l*/
                                templ=geteal();
                                setsub32nc(templ,1);
                                seteal(templ-1);
                                cycles-=((mod==3)?2:6);
                                break;
                                case 0x10: /*CALL*/
                                templ=geteal();
                                if (ssegs) ss=oldss;
                                if (stack32)
                                {
                                        writememl(ss,ESP-4,pc);
                                        ESP-=4;
                                }
                                else
                                {
                                        writememl(ss,(SP-4)&0xFFFF,pc);
                                        SP-=4;
                                }
                                pc=templ;
                                if (pc==0xFFFFFFFF) printf("Failed CALL!\n");
                                if (is486) cycles-=5;
                                else       cycles-=((mod==3)?7:10);
                                break;
                                case 0x18: /*CALL far*/
                                templ=readmeml(easeg,eaaddr);
                                tempw2=readmemw(easeg,(eaaddr+4)); //geteaw2();
                                tempw3=CS;
                                templ2=pc;
                                if (ssegs) ss=oldss;
                                oxpc=pc;
                                pc=templ;
                                optype=CALL;
                                if (msw&1) loadcscall(tempw2);
                                else       loadcs(tempw2);
                                if (notpresent) break;
                                writecall32_2:
                                if (stack32)
                                {
                                        writememl(ss,ESP-4,tempw3);
                                        writememl(ss,ESP-8,templ2);
                                        ESP-=8;
                                }
                                else
                                {
                                        writememl(ss,(SP-4)&0xFFFF,tempw3);
                                        writememl(ss,(SP-8)&0xFFFF,templ2);
                                        SP-=8;
                                }
                                if (pc==0xFFFFFFFF) printf("Failed CALL far!\n");
                                cycles-=(is486)?17:22;
                                break;
                                case 0x20: /*JMP*/
                                pc=geteal();
                                if (is486) cycles-=5;
                                else       cycles-=((mod==3)?7:12);
                                if (pc==0xFFFFFFFF) printf("Failed JMP!\n");
                                break;
                                case 0x28: /*JMP far*/
                                oxpc=pc;
                                pc=readmeml(easeg,eaaddr);
                                optype=JMP;
                                loadcs(readmemw(easeg,(eaaddr+4)));
                                if (pc==0xFFFFFFFF) printf("Failed JMP far!\n");
                                cycles-=(is486)?13:12;
                                break;
                                case 0x30: /*PUSH l*/
                                templ=geteal();
                                if (ssegs) ss=oldss;
                                if (stack32)
                                {
                                        writememl(ss,ESP-4,templ);
                                        ESP-=4;
                                }
                                else
                                {
                                        writememl(ss,((SP-4)&0xFFFF),templ);
                                        SP-=4;
                                }
                                cycles-=((mod==3)?2:5);
                                break;

                                default:
                                printf("Bad 32-bit FF opcode %02X\n",rmdat&0x38);
                                dumpregs();
                                exit(-1);
                        }
                        break;

                        default:
//                        pc--;
//                        cycles-=8;
//                        break;
                        printf("Bad opcode %02X %i %03X at %04X:%04X from %04X:%04X %08X\n",opcode,op32>>8,opcode|op32,cs>>4,pc,old8>>16,old8&0xFFFF,old82);
                        dumpregs();
                        exit(-1);
                }
                if (!use32) pc&=0xFFFF;
                if (ssegs)
                {
                                ds=oldds;
                                ss=oldss;
                        ssegs=0;
                }
//                if (SI==0x37D4) printf("SI=37D4 %04X:%04X\n",CS,pc);
                if (abrt)
                {
/*                EAX=backupregs[0]; EBX=backupregs[1]; ECX=backupregs[2]; EDX=backupregs[3];
                ESI=backupregs[4]; EDI=backupregs[5]; EBP=backupregs[6]; ESP=backupregs[7];
                CS=backupregs[8];  DS=backupregs[9];  ES=backupregs[10]; FS=backupregs[11];
                GS=backupregs[12]; SS=backupregs[13]; flags=backupregs[14]; eflags=backupregs[15];

printf("Abort! %08X\n",oldpc);
output=0;*/
//dumpregs();
//exit(-1);
                        pc=oldpc;
                        pmodeint(14,0); /*Page Fault*/
                        inttype=1; writeerror(abrt>>8);
                        abrt=0;
                }
                if (notpresent)
                {
                        CS=oldcs;
                        pc=oldpc;
                        _cs.access=oldcpl<<5;
                        notpresent=0;
                        x86np();
                }
                cycdiff=oldcyc-cycles;
                if ((flags&I_FLAG) && ((pic.pend&~pic.mask) || (pic2.pend&~pic2.mask)) && !ssegs && !noint)
                {
                        temp=picinterrupt();
                        if (temp!=0xFF)
                        {
                                if (inhlt) pc++;
/*                                if (temp==8)
                                {
                                        intcount++;
                                }*/
                                if (msw&1)
                                {
                                        pmodeint(temp,0);
                                }
                                else
                                {
                                        writememw(ss,(SP-2)&0xFFFF,flags);
                                        writememw(ss,(SP-4)&0xFFFF,CS);
                                        writememw(ss,(SP-6)&0xFFFF,pc);
                                        SP-=6;
                                        addr=temp<<2;
                                        flags&=~I_FLAG;
                                        oxpc=pc;
                                        pc=readmemw(0,addr);
                                        loadcs(readmemw(0,addr+2));
                                }
                                inint=1;
                        }
                }
                if (noint) noint=0;
/*                ins++;
                if (timetolive)
                {
                        timetolive--;
                        if (!timetolive)
                        {
                                output=0;
//                                dumpregs();
//                                exit(-1);
                        }
                }*/
                }
                if (keybsenddelay)
                {
                        keybsenddelay-=10;
                        if (keybsenddelay<1)
                        {
                                keybsenddelay=0;
                                keybsendcallback();
                        }
                }
                if (keyboardtimer)
                {
                        keyboardtimer-=cycdiff;
                        if (keyboardtimer<1)
                        {
                                keyboardtimer=0;
                                keyboardtimeout();
                        }
                }
                if (!pit.delay[0]) pit.c[0]-=cycdiff;
                if (!pit.delay[1]) pit.c[1]-=(cycdiff<<1);
                if (!pit.delay[2]) pit.c[2]-=cycdiff;
                if ((pit.c[0]<1)||(pit.c[1]<1)||(pit.c[2]<1)) pollpit();
                spktime-=cycdiff;
                if (spktime<=0.0)
                {
                        spktime+=SPKCONST;
//                        printf("1Poll spk\n");
                        pollspk();
                        pollgussamp();
                        getsbsamp();
//                        printf("2Poll spk\n");
                }
                soundtime-=cycdiff;
                if (soundtime<=0.0)
                {
                        soundtime+=SOUNDCONST;
//                        printf("1Poll sound60hz\n");
                        pollsound60hz();
//                        printf("2Poll sound60hz\n");
                }
                gustime-=cycdiff;
                while (gustime<=0.0)
                {
                        gustime+=GUSCONST;
//                        printf("1Poll GUS %f %f\n",gustime,GUSCONST);
                        pollgus();
//                        printf("2Poll GUS\n");
                }
                vidtime-=cycdiff;
                if (vidtime<=0.0)
                {
//                        printf("1Poll video\n");
                        pollvideo();
//                        printf("2Poll video\n");
                }
                if (disctime)
                {
                        disctime-=(cycdiff/2);
                        if (disctime<=0)
                        {
//                                printf("1Poll disc\n");
                                disctime=0;
                                polldisc();
//                                printf("2Poll disc\n");
                        }
                }
                if (mousedelay)
                {
                        mousedelay-=20;
                        if (!mousedelay)
                        {
//                                printf("1Poll mouse\n");
                                mousecallback();
//                                printf("2Poll disc\n");
                        }
                }
                if (sbenable)
                {
                        sbcount-=cycdiff;
                        if (sbcount<0)
                        {
                                sbcount+=sblatch;
//                                printf("1Poll SB\n");
                                pollsb();
//                                printf("2Poll SB\n");
                        }
                }
        }
}
