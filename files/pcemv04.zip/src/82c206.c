/*This is the chipset used in the AMI 286 clone model*/
#include "ibm.h"

unsigned char amiregs[256];
int amiindex;
int emspage[4];

void write82c206(unsigned short addr, unsigned char val)
{
        if (addr&1)
        {
                amiregs[amiindex]=val;
                switch (amiindex)
                {
                        case 0x6E: /*EMS page extension*/
                        emspage[3]=(emspage[3]&0x7F)|((val&3)<<7);
                        emspage[2]=(emspage[2]&0x7F)|(((val>>2)&3)<<7);
                        emspage[1]=(emspage[1]&0x7F)|(((val>>4)&3)<<7);
                        emspage[0]=(emspage[0]&0x7F)|(((val>>6)&3)<<7);
                        break;
                }
        }
        else
           amiindex=val;
}

unsigned char read82c206(unsigned short addr)
{
        if (addr&1)
        {
                switch (amiindex)
                {
                }
                return amiregs[amiindex];
        }
        return amiindex;
}

void write82c206ems(unsigned short port, unsigned char val)
{
        emspage[port>>14]=(emspage[port>>14]&0x180)|(val&0x7F);
}

void writeems(unsigned long addr, unsigned char val)
{
        ram[(emspage[(addr>>14)&3]<<14)+(addr&0x3FFF)]=val;
}

unsigned char readems(unsigned long addr)
{
        return ram[(emspage[(addr>>14)&3]<<14)+(addr&0x3FFF)];
}
