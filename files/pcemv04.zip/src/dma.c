#include "ibm.h"

int output;
unsigned char dmaregs[16];
int dmaon[4];
unsigned char dma16regs[16];
int dma16on[4];

void resetdma()
{
        int c;
        dma.wp=0;
        for (c=0;c<16;c++) dmaregs[c]=0;
        for (c=0;c<4;c++)
        {
                dma.mode[c]=0;
                dma.ac[c]=0;
                dma.cc[c]=0;
                dma.ab[c]=0;
                dma.cb[c]=0;
        }
        dma.m=0;
        
        dma16.wp=0;
        for (c=0;c<16;c++) dma16regs[c]=0;
        for (c=0;c<4;c++)
        {
                dma16.mode[c]=0;
                dma16.ac[c]=0;
                dma16.cc[c]=0;
                dma16.ab[c]=0;
                dma16.cb[c]=0;
        }
        dma16.m=0;
}

unsigned char readdma(unsigned short addr)
{
        unsigned char temp;
//        printf("Read DMA %04X %04X:%04X\n",addr,cs>>4,pc);
        switch (addr&0xF)
        {
                case 0:
                if (((dma.mode[0]>>2)&3)==2)
                {
                        dma.ac[0]++;
                        dma.cc[0]--;
                        if (dma.cc[0]<0)
                        {
                                dma.ac[0]=dma.ab[0];
                                dma.cc[0]=dma.cb[0];
                        }
                }
                case 2: case 4: case 6: /*Address registers*/
                dma.wp^=1;
                if (dma.wp) return dma.ac[(addr>>1)&3]&0xFF;
                return dma.ac[(addr>>1)&3]>>8;
                case 1: case 3: case 5: case 7: /*Count registers*/
                dma.wp^=1;
                if (dma.wp) temp=dma.cc[(addr>>1)&3]&0xFF;
                else        temp=dma.cc[(addr>>1)&3]>>8;
//                printf("%02X\n",temp);
                return temp;
                case 8: /*Status register*/
                temp=dma.stat;
                dma.stat=0;
                return temp|1;
        }
        return dmaregs[addr&0xF];
        printf("Bad DMA read %04X\n",addr);
        dumpregs();
        exit(-1);
}

void writedma(unsigned short addr, unsigned char val)
{
//        printf("Write DMA %04X %02X %04X:%04X\n",addr,val,cs>>4,pc);
        dmaregs[addr&0xF]=val;
        switch (addr&0xF)
        {
                case 0: case 2: case 4: case 6: /*Address registers*/
                dma.wp^=1;
                if (dma.wp) dma.ab[(addr>>1)&3]=(dma.ab[(addr>>1)&3]&0xFF00)|val;
                else        dma.ab[(addr>>1)&3]=(dma.ab[(addr>>1)&3]&0xFF)|(val<<8);
                dma.ac[(addr>>1)&3]=dma.ab[(addr>>1)&3];
                dmaon[(addr>>1)&3]=1;
//                printf("DMA addr %i now %04X\n",(addr>>1)&3,dma.ac[(addr>>1)&3]);
                return;
                case 1: case 3: case 5: case 7: /*Count registers*/
                dma.wp^=1;
                if (dma.wp) dma.cb[(addr>>1)&3]=(dma.cb[(addr>>1)&3]&0xFF00)|val;
                else        dma.cb[(addr>>1)&3]=(dma.cb[(addr>>1)&3]&0xFF)|(val<<8);
                dma.cc[(addr>>1)&3]=dma.cb[(addr>>1)&3];
                dmaon[(addr>>1)&3]=1;
//                printf("DMA count %i now %04X\n",(addr>>1)&3,dma.cc[(addr>>1)&3]);
                return;
                case 8: /*Control register*/
                return;
                case 0xA: /*Mask*/
                if (val&4) dma.m|=(1<<(val&3));
                else       dma.m&=~(1<<(val&3));
                return;
                case 0xB: /*Mode*/
                dma.mode[val&3]=val;
                return;
                case 0xC: /*Clear FF*/
                dma.wp=0;
                return;
                case 0xD: /*Master clear*/
                dma.wp=0;
                dma.m=0xF;
                return;
                case 0xF: /*Mask write*/
                dma.m=val&0xF;
                return;
        }
        printf("Bad DMA write %04X %02X\n",addr,val);
//        dumpregs();
//        exit(-1);
}

unsigned char readdma16(unsigned short addr)
{
        unsigned char temp;
        addr>>=1;
//        printf("Read DMA %04X %04X:%04X\n",addr,cs>>4,pc);
        switch (addr&0xF)
        {
                case 0:
                if (((dma16.mode[0]>>2)&3)==2)
                {
                        dma16.ac[0]++;
                        dma16.cc[0]--;
                        if (dma16.cc[0]<0)
                        {
                                dma16.ac[0]=dma16.ab[0];
                                dma16.cc[0]=dma16.cb[0];
                        }
                }
                case 2: case 4: case 6: /*Address registers*/
                dma16.wp^=1;
                if (dma16.wp) return dma16.ac[(addr>>1)&3]&0xFF;
                return dma16.ac[(addr>>1)&3]>>8;
                case 1: case 3: case 5: case 7: /*Count registers*/
                dma16.wp^=1;
                if (dma16.wp) temp=dma16.cc[(addr>>1)&3]&0xFF;
                else        temp=dma16.cc[(addr>>1)&3]>>8;
//                printf("%02X\n",temp);
                return temp;
                case 8: /*Status register*/
                temp=dma16.stat;
                dma16.stat=0;
                return temp|1;
        }
        return dma16regs[addr&0xF];
        printf("Bad DMA16 read %04X\n",addr);
        dumpregs();
        exit(-1);
}

void writedma16(unsigned short addr, unsigned char val)
{
        addr>>=1;
//        printf("Write dma16 %04X %02X %04X:%04X\n",addr,val,cs>>4,pc);
        dma16regs[addr&0xF]=val;
        switch (addr&0xF)
        {
                case 0: case 2: case 4: case 6: /*Address registers*/
                dma16.wp^=1;
                if (dma16.wp) dma16.ab[(addr>>1)&3]=(dma16.ab[(addr>>1)&3]&0xFF00)|val;
                else        dma16.ab[(addr>>1)&3]=(dma16.ab[(addr>>1)&3]&0xFF)|(val<<8);
                dma16.ac[(addr>>1)&3]=dma16.ab[(addr>>1)&3];
                dma16on[(addr>>1)&3]=1;
//                printf("dma16 addr %i now %04X\n",(addr>>1)&3,dma16.ac[(addr>>1)&3]);
                return;
                case 1: case 3: case 5: case 7: /*Count registers*/
                dma16.wp^=1;
                if (dma16.wp) dma16.cb[(addr>>1)&3]=(dma16.cb[(addr>>1)&3]&0xFF00)|val;
                else        dma16.cb[(addr>>1)&3]=(dma16.cb[(addr>>1)&3]&0xFF)|(val<<8);
                dma16.cc[(addr>>1)&3]=dma16.cb[(addr>>1)&3];
                dma16on[(addr>>1)&3]=1;
//                printf("dma16 count %i now %04X\n",(addr>>1)&3,dma16.cc[(addr>>1)&3]);
                return;
                case 8: /*Control register*/
                return;
                case 0xA: /*Mask*/
                if (val&4) dma16.m|=(1<<(val&3));
                else       dma16.m&=~(1<<(val&3));
                return;
                case 0xB: /*Mode*/
                dma16.mode[val&3]=val;
                return;
                case 0xC: /*Clear FF*/
                dma16.wp=0;
                return;
                case 0xD: /*Master clear*/
                dma16.wp=0;
                dma16.m=0xF;
                return;
                case 0xF: /*Mask write*/
                dma16.m=val&0xF;
                return;
        }
        printf("Bad DMA16 write %04X %02X\n",addr,val);
//        dumpregs();
//        exit(-1);
}

unsigned char dmapages[16];
void writepage(unsigned short addr, unsigned char val)
{
        if (!(addr&0xF))
        {
//                printf("Write page %03X %02X %04X:%04X\n",addr,val,CS,pc);
//                if (val==0x29 && pc==0xD25) output=1;
        }
        dmapages[addr&0xF]=val;
        switch (addr&0xF)
        {
                case 1:
                dma.page[2]=val&0xF;
                break;
                case 2:
                dma.page[3]=val&0xF;
                break;
                case 3:
                dma.page[1]=val&0xF;
                break;
        }
//        printf("Page write %04X %02X\n",addr,val);
}

unsigned char readpage(unsigned short addr)
{
        return dmapages[addr&0xF];
}

void writedma2(unsigned char val)
{
//        printf("Write to %05X %02X %i\n",(dma.page[2]<<16)+dma.ac[2],val,dma.m&4);
        if (!(dma.m&4))
        {
                writememb((dma.page[2]<<16)+dma.ac[2],val);
                dma.ac[2]++;
                dma.cc[2]--;
                if (dma.cc[2]==-1)
                {
                        dma.m|=4;
                        dma.stat|=4;
                }
        }
}

unsigned char readdma1()
{
        unsigned char temp=readmembl(dma.ac[1]+(dma.page[1]<<16));
//        printf("Read DMA1 from %05X %02X\n",dma.ac[1]+(dma.page[1]<<16),dma.mode[1]);
        if (!dmaon[1])
        {
//                printf("DMA off!\n");
                return temp;
        }
        dma.ac[1]++;
        dma.cc[1]--;
        if (dma.cc[1]<=-1 && (dma.mode[1]&0x10))
        {
                dma.cc[1]=dma.cb[1];
                dma.ac[1]=dma.ab[1];
        }
        else if (dma.cc[1]<=-1)
           dmaon[1]=0;
        return temp;
}

void writedma1(unsigned char temp)
{
//        printf("DMA write!!! %04X:%04X %02X\n",dma.page[1]<<12,dma.ac[1],temp);
        if (!dmaon[1]) return;
        writememb(dma.ac[1]+(dma.page[1]<<16),temp);
        dma.ac[1]++;
        dma.cc[1]--;
        if (!dma.cc[1] && (dma.mode[1]&0x10))
        {
                dma.cc[1]=dma.cb[1]+1;
                dma.ac[1]=dma.ab[1];
        }
        else if (dma.cc[1]<=-1)
           dmaon[1]=0;
}

int readdma2()
{
        unsigned char temp=readmembl((dma.page[2]<<16)+dma.ac[2]);
        if (dma.m&4)
        {
                return -1;
        }
//        printf("Read DMA 2 - %02X %05X\n",temp,(dma.page[2]<<16)+dma.ac[2]);
        if (!(dma.m&4))
        {
                dma.ac[2]++;
                dma.cc[2]--;
                if (dma.cc[2]==-1)
                {
                        dma.m|=4;
                        dma.stat|=4;
                }
        }
        return temp;
}

int readdma3()
{
        unsigned char temp=readmembl((dma.page[3]<<16)+dma.ac[3]);
        if (dma.m&8)
        {
                return -1;
        }
//        printf("Read DMA 3 - %02X %05X %i\n",temp,(dma.page[3]<<16)+dma.ac[3],dma.cc[3]);
        if (!(dma.m&8))
        {
                dma.ac[3]++;
                dma.cc[3]--;
                if (dma.cc[3]==-1)
                {
                        dma.m|=8;
                        dma.stat|=8;
                }
        }
        return temp;
}
void readdma0()
{
        if (AMSTRAD) return;
        refreshread();
//        readmembl((dma.page[0]<<16)+dma.ac[0]);
//        if (!(dma.m&1))
//        {
                dma.ac[0]+=2;
                dma.cc[0]--;
                if (dma.cc[0]==-1)
                {
                        dma.stat|=1;
                        dma.ac[0]=dma.ab[0];
                        dma.cc[0]=dma.cb[0];
                }
//        }
//        ppi.pb^=0x10;
}

void dumpdma()
{
        printf("Address : %04X %04X %04X %04X\n",dma.ac[0],dma.ac[1],dma.ac[2],dma.ac[3]);
        printf("Count   : %04X %04X %04X %04X\n",dma.cc[0],dma.cc[1],dma.cc[2],dma.cc[3]);
        printf("Mask %02X Stat %02X\n",dma.m,dma.stat);
}
