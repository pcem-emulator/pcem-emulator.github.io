#include <allegro.h>
#include "ibm.h"

int framecount=0;
int changeframecount=2;

void redotextlookup();
int output;
int svgaon=0;
unsigned long svgarbank,svgawbank;
unsigned char svgaseg;
unsigned char svga3d8;

unsigned char oldvram=0;
int frames;
int incga=1;
int hsync;
unsigned char cgastat;

unsigned char crtc[64];
unsigned char gdcreg[16];
int gdcaddr;
unsigned char attrregs[32];
int attraddr,attrff=0;
unsigned char ega3c2;

unsigned char rotatevga[8][256];
unsigned char writemask,charset;
int writemode,readmode,readplane,chain4;
unsigned char colourcompare,colournocare;
unsigned char la,lb,lc,ld;

unsigned char *vram;

int egares;

unsigned char seqregs[16];
int seqaddr;

/*3C2 controls default mode on EGA. On VGA, it determines monitor type (mono or colour)*/
int egaswitchread,egaswitches=9; /*7=CGA mode (200 lines), 9=EGA mode (350 lines), 8=EGA mode (200 lines)*/
/*For VGA non-interlace colour, ID bits should be 1 1 0 or 6*/
int vres=0;

PALETTE vgapal;
unsigned long *pallook,pallook16[256],pallook64[256],pallook256[256];
int dacread,dacwrite,dacpos=0;
int palchange=1;

int fullchange;

float dispontime,dispofftime,disptime;

int ega_vtotal,ega_dispend,ega_vsyncstart,ega_split;
int vidclock;
float cpuclock;

unsigned char trident3d8,trident3d9;
int tridentoldmode;
int tridentoldctrl2,tridentnewctrl2;
unsigned char tridentdac;
int bpp;

unsigned long vrammask;

unsigned char changedvram[(2048*1024)/512];

void recalcegatimings()
{
        float crtcconst;
        int temp;
        ega_vtotal=crtc[6];
        ega_dispend=crtc[0x12];
        ega_vsyncstart=crtc[0x10];
        ega_split=crtc[0x18];
        
        if (crtc[7]&1) ega_vtotal|=0x100;
        if (crtc[7]&32) ega_vtotal|=0x200;
        if (SVGA && crtc[0x35]&2) ega_vtotal|=0x400;
        ega_vtotal++;
        if (VGA) ega_vtotal++;
        
        if (crtc[7]&2) ega_dispend|=0x100;
        if (crtc[7]&64) ega_dispend|=0x200;
        if (SVGA && crtc[0x35]&4) ega_dispend|=0x400;
        ega_dispend++;

        if (crtc[7]&4) ega_vsyncstart|=0x100;
        if (crtc[7]&128) ega_vsyncstart|=0x200;
        if (SVGA && crtc[0x35]&8) ega_vsyncstart|=0x400;
        ega_vsyncstart++;

        if (crtc[7]&0x10)    ega_split|=0x100;
        if (crtc[9]&0x40)    ega_split|=0x200;
        if (SVGA && crtc[0x35]&0x10) ega_split|=0x400;
//        if (crtc[0x35]&0x10) split|=0x400;
        ega_split++;
        if (!VGA && !SVGA) ega_split++;

//printf("Recalc! %i %i %i %i\n",ega_vtotal,ega_dispend,ega_vsyncstart,ega_split);
        if (VGA)
        {
//                printf("VGA clock\n");
                if (TRIDENT)
                {
                        switch (((ega3c2>>2)&3) | ((tridentnewctrl2<<2)&4))
                        {
                                case 0: crtcconst=(seqregs[1]&1)?(VGACONST1*8.0):(VGACONST1*9.0); break;
                                case 1: crtcconst=(seqregs[1]&1)?(VGACONST2*8.0):(VGACONST2*9.0); break;
                                case 2: crtcconst=(seqregs[1]&1)?((cpuclock/44900000.0)*8.0):((cpuclock/44900000.0)*9.0); break;
                                case 3: crtcconst=(seqregs[1]&1)?((cpuclock/36000000.0)*8.0):((cpuclock/36000000.0)*9.0); break;
                                case 4: crtcconst=(seqregs[1]&1)?((cpuclock/57272000.0)*8.0):((cpuclock/57272000.0)*9.0); break;
                                case 5: crtcconst=(seqregs[1]&1)?((cpuclock/65000000.0)*8.0):((cpuclock/65000000.0)*9.0); break;
                                case 6: crtcconst=(seqregs[1]&1)?((cpuclock/50350000.0)*8.0):((cpuclock/50350000.0)*9.0); break;
                                case 7: crtcconst=(seqregs[1]&1)?((cpuclock/40000000.0)*8.0):((cpuclock/40000000.0)*9.0); break;
                        }
                }
                else if (SVGA)
                {
                        switch (((ega3c2>>2)&3) | ((crtc[0x34]<<1)&4))
                        {
                                case 0: crtcconst=(seqregs[1]&1)?(VGACONST1*8.0):(VGACONST1*9.0); break;
                                case 1: crtcconst=(seqregs[1]&1)?(VGACONST2*8.0):(VGACONST2*9.0); break;
                                case 3: crtcconst=(seqregs[1]&1)?((cpuclock/40000000.0)*8.0):((cpuclock/40000000.0)*9.0); break;
                                case 5: crtcconst=(seqregs[1]&1)?((cpuclock/65000000.0)*8.0):((cpuclock/65000000.0)*9.0); break;
                                default: crtcconst=(seqregs[1]&1)?((cpuclock/36000000.0)*8.0):((cpuclock/36000000.0)*9.0); break;
                        }
                }
                else if (vidclock) crtcconst=(seqregs[1]&1)?(VGACONST2*8.0):(VGACONST2*9.0);
                else               crtcconst=(seqregs[1]&1)?(VGACONST1*8.0):(VGACONST1*9.0);
        }
        else
        {
//                printf("EGA clock %i %i\n",vidclock,seqregs[1]&1);
                if (vidclock) crtcconst=(seqregs[1]&1)?(MDACONST*(8.0/9.0)):MDACONST;
                else          crtcconst=(seqregs[1]&1)?(CGACONST*(8.0/9.0)):CGACONST;
        }
        
        disptime=(VGA)?(crtc[0]+5):(crtc[0]+2);
        dispontime=crtc[1]+1;
        
//        printf("Disptime %f dispontime %f\n",disptime,dispontime);
        if (seqregs[1]&8) { disptime*=2; dispontime*=2; }
        dispofftime=disptime-dispontime;
        dispontime*=crtcconst;
        dispofftime*=crtcconst;
        
        if (TRIDENT && gdcreg[0xF]&8)
        {
                dispontime*=2;
                dispofftime*=2;
        }
        
/*        if (ega_vtotal<ega_vsyncstart)
        {
                disptime*=100;
                dispontime*=100;
                dispofftime*=100;
        }*/
        
        if (SVGA)
        {
                temp=((ega3c2>>2)&3) | ((crtc[0x34]<<1)&4) | ((crtc[0x31]>>3)&0x18);
//                printf("ET4000 clock select %02X\n",temp);
                /*3=40mhz - 800x600x60*/
                /*5=65mhz - 1024x768x60*/
        }
//        printf("Sync %i %02X %02X\n",ega_vsyncstart,crtc[0x10],crtc[7]);
        
//        printf("EGA horiz total %i display end %i clock rate %i vidclock %i %i\n",crtc[0],crtc[1],egaswitchread,vidclock,((ega3c2>>2)&3) | ((tridentnewctrl2<<2)&4));
//        printf("EGA vert total %i display end %i max row %i vsync %i\n",ega_vtotal,ega_dispend,(crtc[9]&31)+1,ega_vsyncstart);
//        printf("total %f on %f cycles off %f cycles frame %f sec %f %02X\n",disptime*crtcconst,dispontime,dispofftime,(dispontime+dispofftime)*ega_vtotal,(dispontime+dispofftime)*ega_vtotal*70,seqregs[1]);
}

int charseta,charsetb;

int egapal[16];

int displine;

int rowdbl=0;
int scrblank=0;

void outega(unsigned short addr, unsigned char val)
{
        int c;
        unsigned char o;
//        printf("Write %03X %02X\n",addr,val);
        switch (addr)
        {
                case 0x3C0:
//                printf("Write 3C0 %i %02X %02X %02X  %02X %04X:%04X\n",attrff,val,attraddr,attrregs[0x10],cgastat,cs>>4,pc);
                if (!attrff)
                {
                        attraddr=val&31;
//                        printf("ATTR index %02X\n",val);
//                        scrblank=(scrblank&~1)|((val&0x20)?0:1);
                }
                else
                {
                        attrregs[attraddr&31]=val;
                        if (attraddr<16) { /*redotextlookup(); */fullchange=changeframecount; /*printf("ATTR %02X = %02X\n",attraddr,val);*/ }
//                        else printf("ATTR %02X = %02X\n",attraddr,val);
                        if (attraddr==0x10 || attraddr==0x14 || attraddr<0x10)
                        {
//                                printf("%i Update pal %02X %02X : ",displine,attrregs[0x10],attrregs[0x14]);
                                for (c=0;c<16;c++)
                                {
                                        if (attrregs[0x10]&0x80) egapal[c]=(attrregs[c]&0xF)|((attrregs[0x14]&0xF)<<4);
                                        else                     egapal[c]=(attrregs[c]&0x3F)|((attrregs[0x14]&0xC)<<4);
//                                        printf("%02X ",egapal[c]);
                                }
//                                printf("\n");
                        }
                }
                attrff^=1;
                break;
                case 0x3C2:
                egaswitchread=val&0xC;
                at70hz=((val&0xC0)!=0xC0);
                vres=!(val&0x80); pallook=(vres)?pallook16:pallook64;
                if (VGA) { vres=0; pallook=pallook256; }
                vidclock=val&4; /*printf("3C2 write %02X\n",val);*/
                ega3c2=val; break;
                case 0x3C4: seqaddr=val; break;
                case 0x3C5:
                o=seqregs[seqaddr&0xF];
                if ((seqaddr&0xF)!=0xC || !TRIDENT) seqregs[seqaddr&0xF]=val;
                if (o!=val && (seqaddr&0xF)==1) recalcegatimings();
//                if ((seqaddr&0xF)>10) printf("Write Trident seq %02X %02X %04X:%04X %04X\n",seqaddr,val,CS,pc,readmemw(ss,SP));
//                        printf("Sequencer write %02X %02X\n",val,seqaddr);
                switch (seqaddr&0xF)
                {
                        case 1: egares=val&8; if (scrblank && !(val&0x20)) fullchange=3; scrblank=(scrblank&~0x20)|(val&0x20); break;
                        case 2: writemask=val&0xF; break;
                        case 3:
                        charset=val&0xF;
                        charseta=((charset>>2)*0x10000)+2;
                        charsetb=((charset&3) *0x10000)+2;
                        break;
                        case 4: chain4=val&8; /*printf("Chain4 %i %02X\n",val&8,gdcreg[5]&0x60); */break;
                        case 0xB: if (TRIDENT) tridentoldmode=1; break;
                        case 0xC: if (TRIDENT && seqregs[0xE]&0x80) seqregs[0xC]=val; if (val==0xC0) output=0; break;
                        case 0xD: if (TRIDENT && tridentoldmode) { tridentoldctrl2=val; rowdbl=val&0x10; } else if (TRIDENT) tridentnewctrl2=val; break;
                        case 0xE: if (TRIDENT) seqregs[0xE]=val^2; break;
                }
                break;
                case 0x3C6: 
                if (TRIDENT)
                {
                        if (!val) bpp=8;
                        if (val==0xA0) bpp=15;
                        if (val==0xE0) bpp=16;
                        if (val==0xC2) bpp=24;
                }
                break;
                case 0x3C7: dacread=val; dacpos=0; break;
                case 0x3C8: dacwrite=val; dacpos=0; break;
                case 0x3C9:
                palchange=1;
                fullchange=changeframecount;
                switch (dacpos)
                {
                        case 0: vgapal[dacwrite].r=val&63; pallook256[dacwrite]=makecol32(vgapal[dacwrite].r*4,vgapal[dacwrite].g*4,vgapal[dacwrite].b*4); dacpos++; break;
                        case 1: vgapal[dacwrite].g=val&63; pallook256[dacwrite]=makecol32(vgapal[dacwrite].r*4,vgapal[dacwrite].g*4,vgapal[dacwrite].b*4); dacpos++; break;
                        case 2: vgapal[dacwrite].b=val&63; pallook256[dacwrite]=makecol32(vgapal[dacwrite].r*4,vgapal[dacwrite].g*4,vgapal[dacwrite].b*4); dacpos=0; dacwrite=(dacwrite+1)&255; break;
                }
                break;
                case 0x3CD:
//                printf("Write 3CD %02X\n",val);
                svgawbank=(val&0xF)*65536;
                svgarbank=((val>>4)&0xF)*65536;
                svgaseg=val;
                break;
                case 0x3CE: gdcaddr=val; break;
                case 0x3CF:
                gdcreg[gdcaddr&15]=val;
//                printf("GDC write %02X %02X\n",gdcaddr,val);
                switch (gdcaddr&15)
                {
                        case 2: colourcompare=val; break;
                        case 4: readplane=val&3; break;
                        case 5: writemode=val&3; readmode=val&8; /*printf("Chain4 %i %02X\n",val&8,gdcreg[5]&0x60);  */break;
                        case 7: colournocare=val; break;
                        case 0xF:
                        if (TRIDENT)
                        {
                                if (val&1) svgarbank=(trident3d9&0x1F)*65536;
                                else       svgarbank=(trident3d8&0x1F)*65536;
                        }
                        break;
                }
                break;
                case 0x3D8:
                if (SVGA)
                {
                        if (val==0xA0) svgaon=1;
                        if (val==0x29) svgaon=0;
                }
                else if (TRIDENT)
                {
                        trident3d8=val;
                        svgawbank=(val&0x1F)*65536;
                        if (!(gdcreg[0xF]&1)) svgarbank=(val&0x1F)*65536;
                }
//                printf("3D8 write %02X\n",val);
//                if (cs==0xC0000) output=1;
                svga3d8=val;
                break;
                case 0x3D9:
                if (TRIDENT)
                {
                        trident3d9=val;
                        if (gdcreg[0xF]&1) svgarbank=(val&0x1F)*65536;
                }
                break;
                case 0x3DB: if (EGA) incga=val&0x40; break;
//                default:
//                        printf("Bad OUT TRIDENT %04X %02X %04X:%04X\n",addr,val,CS,pc);
        }
}

unsigned char inega(unsigned short addr)
{
        switch (addr)
        {
                case 0x3C2:
//                printf("Read egaswitch %02X %02X %i\n",egaswitchread,egaswitches,VGA);
                if (VGA) return 0x10;
                switch (egaswitchread)
                {
                        case 0xC: return (egaswitches&1)?0x10:0;
                        case 0x8: return (egaswitches&2)?0x10:0;
                        case 0x4: return (egaswitches&4)?0x10:0;
                        case 0x0: return (egaswitches&8)?0x10:0;
                }
                break;
                case 0x3C5:
                if ((seqaddr&0xF)==7 && SVGA) return seqregs[seqaddr&0xF]|4;
                if ((seqaddr&0xF)==0xB && TRIDENT)
                {
//                        printf("Read Trident ID %04X:%04X %04X\n",CS,pc,readmemw(ss,SP));
                        tridentoldmode=0;
                        return 0x33; /*TVGA8900D*/
                }
                if ((seqaddr&0xF)==0xC && TRIDENT)
                {
//                        printf("Read Trident Power Up 1 %04X:%04X %04X\n",CS,pc,readmemw(ss,SP));
//                        return 0x20; /*2 DRAM banks*/
                }
//                if ((seqaddr&0xF)>10) printf("Read Trident seq %02X %02X %04X:%04X %04X\n",seqaddr,seqregs[seqaddr&0xF],CS,pc,readmemw(ss,SP));
//                        printf("Sequencer read %02X %02X\n",seqaddr,seqregs[seqaddr&0xF]);
                if ((seqaddr&0xF)==0xD && TRIDENT)
                {
                        if (tridentoldmode) return tridentoldctrl2;
                        return tridentnewctrl2;
                }
                return seqregs[seqaddr&0xF];
                case 0x3C9:
                palchange=1;
                switch (dacpos)
                {
                        case 0: dacpos++; return vgapal[dacread].r;
                        case 1: dacpos++; return vgapal[dacread].g;
                        case 2: dacpos=0; dacread=(dacread+1)&255; return vgapal[(dacread-1)&255].b;
                }
                break;
                case 0x3CD:
//                        printf("Read 3CD at %04X\n",pc);
//                        output=1;
                return svgaseg;
                case 0x3CF:
                return gdcreg[gdcaddr&0xF];
                case 0x3D8: return svga3d8;
                case 0x3DA:
                attrff=0;
//                hsync++;
//                hsync&=31;
//                cgastat^=1;
//                printf("Read 3DA %02X\n",(cgastat&8)?(cgastat|1):(cgastat|(hsync)>>4));
//                if (cgastat&8) return cgastat|1;
//                return cgastat|(hsync>>4);
                return cgastat;
        }
//        printf("Bad EGA read %04X %04X:%04X\n",addr,cs>>4,pc);
        return 0xFF;
}

void writeega(unsigned long addr, unsigned char val)
{
        int x,y;
        char s[2]={0,0};
        unsigned char vala,valb,valc,vald,wm=writemask;
        int bankaddr;
        addr&=0xFFFF;
        if (!(gdcreg[6]&1)) fullchange=2;
        if (SVGA/* && svgaon*/ || TRIDENT) addr|=svgawbank;
        /*if ((gdcreg[0xF]&5)==5) bankaddr=svgawbank2*65536;
        else if (tridentoldmode) bankaddr=((trident.oldctrl2>>1)&3)*128*1024;
        else *///bankaddr=svgawbank*65536;
//        if (addr<0x1000) printf("Write VRAM %04X %02X %c %05X %i %02X %02X\n",addr,val,(val>31)?val:'.',svgawbank,chain4,vram[0x3480],writemask);
//        if (SVGA) addr+=bankaddr;
//        printf("%04X ",addr);
        if (chain4)
        {
//                printf("%05X ",addr);
                writemask=1<<(addr&3);
                addr&=~3;
/*                addr=addr>>2;
                if (addr&0x30000)
                {
                        addr=((addr<<2)&~0x3FFFF)|(addr&0xFFFF);
                }*/
//                printf("%05X %i\n",addr,writemask);
        }
        else
        {
                addr<<=2;
        }
//                addr&=~0x30000;
//                if (SVGA) addr|=svgawbank;
/*                if (SVGA) addr=(addr&0xFFFF)|(svgawbank<<2);
                else      addr&=~0x30000;*/
//                printf(" %05X\n",addr);
//        }
addr&=0x1FFFFF;
        changedvram[addr>>9]=changeframecount;

//        if (!addr && writemask&1)
//           if (addr<4) printf("Write VRAM %04X %02X %04X(%06X):%04X %i\n",addr,val,CS,cs,pc,writemask);
//        if (!addr && writemask&2)
//           printf("Write VRAM %04X %02X %04X(%06X):%04X %i\n",addr,val,CS,cs,pc,writemask);
//        if (addr==1 && writemask&1) printf("Write to 1 %02X %04X(%06X):%04X\n",val,cs,CS,pc);
//printf("Write %05X %02X\n",addr,writemask);
        switch (writemode)
                {
                        case 1:
                        if (writemask&1) vram[addr]=la;
                        if (writemask&2) vram[addr|0x1]=lb;
                        if (writemask&4) vram[addr|0x2]=lc;
                        if (writemask&8) vram[addr|0x3]=ld;
                        break;
                        case 0:
                        if (gdcreg[3]&7) val=rotatevga[gdcreg[3]&7][val];
                        if (gdcreg[8]==0xFF && !(gdcreg[3]&0x18) && !gdcreg[1])
                        {
                                if (writemask&1) vram[addr]=val;
                                if (writemask&2) vram[addr|0x1]=val;
                                if (writemask&4) vram[addr|0x2]=val;
                                if (writemask&8) vram[addr|0x3]=val;
                        }
                        else
                        {
                                if (gdcreg[1]&1) vala=(gdcreg[0]&1)?0xFF:0;
                                else             vala=val;
                                if (gdcreg[1]&2) valb=(gdcreg[0]&2)?0xFF:0;
                                else             valb=val;
                                if (gdcreg[1]&4) valc=(gdcreg[0]&4)?0xFF:0;
                                else             valc=val;
                                if (gdcreg[1]&8) vald=(gdcreg[0]&8)?0xFF:0;
                                else             vald=val;
                                switch (gdcreg[3]&0x18)
                                {
                                        case 0: /*Set*/
                                        if (writemask&1) vram[addr]=(vala&gdcreg[8])|(la&~gdcreg[8]);
                                        if (writemask&2) vram[addr|0x1]=(valb&gdcreg[8])|(lb&~gdcreg[8]);
                                        if (writemask&4) vram[addr|0x2]=(valc&gdcreg[8])|(lc&~gdcreg[8]);
                                        if (writemask&8) vram[addr|0x3]=(vald&gdcreg[8])|(ld&~gdcreg[8]);
                                        break;
                                        case 8: /*AND*/
                                        if (writemask&1) vram[addr]=(vala|~gdcreg[8])&la;
                                        if (writemask&2) vram[addr|0x1]=(valb|~gdcreg[8])&lb;
                                        if (writemask&4) vram[addr|0x2]=(valc|~gdcreg[8])&lc;
                                        if (writemask&8) vram[addr|0x3]=(vald|~gdcreg[8])&ld;
                                        break;
                                        case 0x10: /*OR*/
                                        if (writemask&1) vram[addr]=(vala&gdcreg[8])|la;
                                        if (writemask&2) vram[addr|0x1]=(valb&gdcreg[8])|lb;
                                        if (writemask&4) vram[addr|0x2]=(valc&gdcreg[8])|lc;
                                        if (writemask&8) vram[addr|0x3]=(vald&gdcreg[8])|ld;
                                        break;
                                        case 0x18: /*XOR*/
                                        if (writemask&1) vram[addr]=(vala&gdcreg[8])^la;
                                        if (writemask&2) vram[addr|0x1]=(valb&gdcreg[8])^lb;
                                        if (writemask&4) vram[addr|0x2]=(valc&gdcreg[8])^lc;
                                        if (writemask&8) vram[addr|0x3]=(vald&gdcreg[8])^ld;
                                        break;
                                }
                        }
                        break;
                        case 2:
                        if (!(gdcreg[3]&0x18) && !gdcreg[1])
                        {
                                if (writemask&1) vram[addr]=(((val&1)?0xFF:0)&gdcreg[8])|(la&~gdcreg[8]);
                                if (writemask&2) vram[addr|0x1]=(((val&2)?0xFF:0)&gdcreg[8])|(lb&~gdcreg[8]);
                                if (writemask&4) vram[addr|0x2]=(((val&4)?0xFF:0)&gdcreg[8])|(lc&~gdcreg[8]);
                                if (writemask&8) vram[addr|0x3]=(((val&8)?0xFF:0)&gdcreg[8])|(ld&~gdcreg[8]);
                        }
                        else
                        {
                                vala=((val&1)?0xFF:0);
                                valb=((val&2)?0xFF:0);
                                valc=((val&4)?0xFF:0);
                                vald=((val&8)?0xFF:0);
                                switch (gdcreg[3]&0x18)
                                {
                                        case 0: /*Set*/
                                        if (writemask&1) vram[addr]=(vala&gdcreg[8])|(la&~gdcreg[8]);
                                        if (writemask&2) vram[addr|0x1]=(valb&gdcreg[8])|(lb&~gdcreg[8]);
                                        if (writemask&4) vram[addr|0x2]=(valc&gdcreg[8])|(lc&~gdcreg[8]);
                                        if (writemask&8) vram[addr|0x3]=(vald&gdcreg[8])|(ld&~gdcreg[8]);
                                        break;
                                        case 8: /*AND*/
                                        if (writemask&1) vram[addr]=(vala|~gdcreg[8])&la;
                                        if (writemask&2) vram[addr|0x1]=(valb|~gdcreg[8])&lb;
                                        if (writemask&4) vram[addr|0x2]=(valc|~gdcreg[8])&lc;
                                        if (writemask&8) vram[addr|0x3]=(vald|~gdcreg[8])&ld;
                                        break;
                                        case 0x10: /*OR*/
                                        if (writemask&1) vram[addr]=(vala&gdcreg[8])|la;
                                        if (writemask&2) vram[addr|0x1]=(valb&gdcreg[8])|lb;
                                        if (writemask&4) vram[addr|0x2]=(valc&gdcreg[8])|lc;
                                        if (writemask&8) vram[addr|0x3]=(vald&gdcreg[8])|ld;
                                        break;
                                        case 0x18: /*XOR*/
                                        if (writemask&1) vram[addr]=(vala&gdcreg[8])^la;
                                        if (writemask&2) vram[addr|0x1]=(valb&gdcreg[8])^lb;
                                        if (writemask&4) vram[addr|0x2]=(valc&gdcreg[8])^lc;
                                        if (writemask&8) vram[addr|0x3]=(vald&gdcreg[8])^ld;
                                        break;
                                }
                        }
                        break;
                        case 3:
//                        printf("Writemode 3! %02X %02X %02X %04X:%04X\n",gdcreg[3]&0x18,val,gdcreg[0],cs>>4,pc);
                        if (gdcreg[3]&7) val=rotatevga[gdcreg[3]&7][val];
                        wm=gdcreg[8];
                        gdcreg[8]&=val;
//                        printf("Write mask %02X %02X %02X\n",gdcreg[8],val,wm);
//                        printf("Latches %02X %02X %02X %02X\n",la,lb,lc,ld);
/*                        if (!(gdcreg[3]&0x18) && !gdcreg[1])
                        {
                                if (writemask&1) vram[addr]=(((val&1)?0xFF:0)&gdcreg[8])|(la&~gdcreg[8]);
                                if (writemask&2) vram[addr|0x10000]=(((val&2)?0xFF:0)&gdcreg[8])|(lb&~gdcreg[8]);
                                if (writemask&4) vram[addr|0x20000]=(((val&4)?0xFF:0)&gdcreg[8])|(lc&~gdcreg[8]);
                                if (writemask&8) vram[addr|0x30000]=(((val&8)?0xFF:0)&gdcreg[8])|(ld&~gdcreg[8]);
                        }
                        else
                        {*/
                                vala=(gdcreg[0]&1)?0xFF:0;
                                valb=(gdcreg[0]&2)?0xFF:0;
                                valc=(gdcreg[0]&4)?0xFF:0;
                                vald=(gdcreg[0]&8)?0xFF:0;
                                switch (gdcreg[3]&0x18)
                                {
                                        case 0: /*Set*/
                                        if (writemask&1) vram[addr]=(vala&gdcreg[8])|(la&~gdcreg[8]);
                                        if (writemask&2) vram[addr|0x1]=(valb&gdcreg[8])|(lb&~gdcreg[8]);
                                        if (writemask&4) vram[addr|0x2]=(valc&gdcreg[8])|(lc&~gdcreg[8]);
                                        if (writemask&8) vram[addr|0x3]=(vald&gdcreg[8])|(ld&~gdcreg[8]);
                                        break;
                                        case 8: /*AND*/
                                        if (writemask&1) vram[addr]=(vala|~gdcreg[8])&la;
                                        if (writemask&2) vram[addr|0x1]=(valb|~gdcreg[8])&lb;
                                        if (writemask&4) vram[addr|0x2]=(valc|~gdcreg[8])&lc;
                                        if (writemask&8) vram[addr|0x3]=(vald|~gdcreg[8])&ld;
                                        break;
                                        case 0x10: /*OR*/
                                        if (writemask&1) vram[addr]=(vala&gdcreg[8])|la;
                                        if (writemask&2) vram[addr|0x1]=(valb&gdcreg[8])|lb;
                                        if (writemask&4) vram[addr|0x2]=(valc&gdcreg[8])|lc;
                                        if (writemask&8) vram[addr|0x3]=(vald&gdcreg[8])|ld;
                                        break;
                                        case 0x18: /*XOR*/
                                        if (writemask&1) vram[addr]=(vala&gdcreg[8])^la;
                                        if (writemask&2) vram[addr|0x1]=(valb&gdcreg[8])^lb;
                                        if (writemask&4) vram[addr|0x2]=(valc&gdcreg[8])^lc;
                                        if (writemask&8) vram[addr|0x3]=(vald&gdcreg[8])^ld;
                                        break;
                                }
//                        }
                        gdcreg[8]=wm;
                        break;
//                        dumpregs();
//                        exit(-1);
                }
/*        if (vram[1]!=oldvram)
        {
                printf("VRAM 1 changed! %02X %02X %04X(%06X):%04X %i\n",vram[1],oldvram,CS,cs,pc,chain4);
                if (vram[1]==0x1E)
                {
                        printf("itititit 1E\n");
                }
                oldvram=vram[1];
        }*/
}

unsigned char readega(unsigned long addr)
{
        unsigned char temp,temp2,temp3,temp4;
        unsigned long addr2;
        addr&=0xFFFF;
        if (SVGA/* && svgaon*/ || TRIDENT) addr|=svgarbank;
        if (chain4) return vram[addr];
        else        addr<<=2;
                la=vram[addr];
                lb=vram[addr|0x1];
                lc=vram[addr|0x2];
                ld=vram[addr|0x3];
                if (readmode)
                {
                        temp= (colournocare&1) ?0xFF:0;
                        temp&=la;
                        temp^=(colourcompare&1)?0xFF:0;
                        temp2= (colournocare&2) ?0xFF:0;
                        temp2&=lb;
                        temp2^=(colourcompare&2)?0xFF:0;
                        temp3= (colournocare&4) ?0xFF:0;
                        temp3&=lc;
                        temp3^=(colourcompare&4)?0xFF:0;
                        temp4= (colournocare&8) ?0xFF:0;
                        temp4&=ld;
                        temp4^=(colourcompare&8)?0xFF:0;
                        return ~(temp|temp2|temp3|temp4);
                }
//printf("Read %02X %04X %04X\n",vram[addr|readplane],addr,readplane);
                return vram[addr|readplane];
}

unsigned char edatlookup[4][4];

unsigned long textlookup[256][2][16][16];

/*void redotextlookup()
{
        int c,d,e;
        unsigned long temp;
        int coffset=(VGA)?0:64;
        for (c=0;c<256;c++)
        {
                for (d=0;d<16;d++)
                {
//                        printf("ATTR %i=%02X+%02X\n",d,attrregs[d],coffset);
                        for (e=0;e<16;e++)
                        {
                                temp=0;
                                if (c&0x80) temp|=(attrregs[d]+coffset);
                                else        temp|=(attrregs[e]+coffset);
                                if (c&0x40) temp|=(attrregs[d]+coffset)<<8;
                                else        temp|=(attrregs[e]+coffset)<<8;
                                if (c&0x20) temp|=(attrregs[d]+coffset)<<16;
                                else        temp|=(attrregs[e]+coffset)<<16;
                                if (c&0x10) temp|=(attrregs[d]+coffset)<<24;
                                else        temp|=(attrregs[e]+coffset)<<24;
//                                if (c==0x5) printf("%08X %i %i %02X %02X\n",temp,d,e,attrregs[d],attrregs[e]);
                                textlookup[c][0][d][e]=temp;
                                temp=0;
                                if (c&0x08) temp|=(attrregs[d]+coffset);
                                else        temp|=(attrregs[e]+coffset);
                                if (c&0x04) temp|=(attrregs[d]+coffset)<<8;
                                else        temp|=(attrregs[e]+coffset)<<8;
                                if (c&0x02) temp|=(attrregs[d]+coffset)<<16;
                                else        temp|=(attrregs[e]+coffset)<<16;
                                if (c&0x01) temp|=(attrregs[d]+coffset)<<24;
                                else        temp|=(attrregs[e]+coffset)<<24;
                                textlookup[c][1][d][e]=temp;
                        }
                }
        }
}*/

void initega()
{
        int c,d,e;
        for (c=0;c<256;c++)
        {
                e=c;
                for (d=0;d<8;d++)
                {
                        rotatevga[d][c]=e;
                        e=(e>>1)|((e&1)?0x80:0);
                }
        }
        crtc[0xC]=crtc[0xD]=0;
        if (romset==ROM_PC1640 || romset==ROM_PC1512) incga=1;
        else                    incga=0;
        for (c=0;c<4;c++)
        {
                for (d=0;d<4;d++)
                {
                        edatlookup[c][d]=0;
                        if (c&1) edatlookup[c][d]|=1;
                        if (d&1) edatlookup[c][d]|=2;
                        if (c&2) edatlookup[c][d]|=0x10;
                        if (d&2) edatlookup[c][d]|=0x20;
//                        printf("Edat %i,%i now %02X\n",c,d,edatlookup[c][d]);
                }
        }
        /*redotextlookup();*/
        for (c=0;c<256;c++)
        {
                pallook64[c]=makecol32(((c>>2)&1)*0xAA,((c>>1)&1)*0xAA,(c&1)*0xAA);
                pallook64[c]+=makecol32(((c>>5)&1)*0x55,((c>>4)&1)*0x55,((c>>3)&1)*0x55);
                pallook16[c]=makecol32(((c>>2)&1)*0xAA,((c>>1)&1)*0xAA,(c&1)*0xAA);
                pallook16[c]+=makecol32(((c>>4)&1)*0x55,((c>>4)&1)*0x55,((c>>4)&1)*0x55);
                if ((c&0x17)==6) pallook16[c]=makecol32(0xAA,0x55,0);
//                printf("%03i %08X\n",c,pallook[c]);
        }
        pallook=pallook16;
        seqregs[0xC]=0x20;
        vrammask=0x3FFFF;
}
unsigned long egabase,egaoffset;

void cacheega()
{
        egabase=(crtc[0xC]<<8)|crtc[0xD];
        if (SVGA || TRIDENT)
           egabase|=((crtc[0x33]&3)<<18);
//        printf("EGABASE %05X\n",egabase);
//        egaoffset=8-((attrregs[0x13])&7);
//        printf("Cache base!\n");
}
void cacheega2()
{
//        egabase=(crtc[0xC]<<8)|crtc[0xD];
        if (gdcreg[5]&0x40) egaoffset=8-(((attrregs[0x13])&7)>>1);
        else                egaoffset=8-((attrregs[0x13])&7);
//        printf("Cache offset!\n");
}

int olddisplines,oldxsize;

int oldreadflash;
int oldegaaddr,oldegasplit;

int vc,sc;
int egadispon=0;
int linepos;
int displine;
unsigned long ma,maback,ca;
int firstline,lastline;
int xsize,ysize;
int scrollcache;
int con,cursoron,cgablink;

BITMAP *buffer,*vbuf,*buffer32;

int linecountff=0;

void dumpegaregs()
{
        int c;
        printf("CRTC :");
        for (c=0;c<0x20;c++) printf(" %02X",crtc[c]);
        printf("\n");
        printf(" EXT :");
        for (c=0;c<0x20;c++) printf(" %02X",crtc[c+32]);
        printf("\n");
        printf("SEQ  :");
        for (c=0;c<0x10;c++) printf(" %02X",seqregs[c]);
        printf("\n");
        printf("ATTR :");
        for (c=0;c<0x20;c++) printf(" %02X",attrregs[c]);
        printf("\n");
        printf("GDC  :");
        for (c=0;c<0x10;c++) printf(" %02X",gdcreg[c]);
        printf("\n");
        printf("OLD CTRL2 = %02X  NEW CTRL2 = %02X  DAC = %02X  3C2 = %02X\n",tridentoldctrl2,tridentnewctrl2,tridentdac,ega3c2);
}

int oddeven;

void pollega()
{
        unsigned char chr,dat,attr;
        unsigned long charaddr;
        int x,xx;
        unsigned long fg,bg;
//        int coffset=(vres)?64:128;
        int offset;
        unsigned char edat[4];
        int drawcursor=0;
//        pallook=(vres)?pallook16:pallook64;
//        printf("PollEGA %i\n",incga);
        if (incga)
        {
                pollcga();
                return;
        }
//        printf("1 %i ",ega_vsyncstart);
        if (TRIDENT && gdcreg[0xF]&8) crtc[1]<<=1;
        if (!linepos)
        {
                vidtime+=dispofftime;
//                if (output) printf("Display off %f\n",vidtime);
                cgastat|=1;
                linepos=1;

                if (egadispon)
                {
                        ma&=vrammask;
                        if (firstline==2000) firstline=displine;
//                        if (displine<10) printf("Draw %i %i %i %05X\n",displine,firstline,lastline,ma);
//                        printf("GDCREG 6 %02X\n",gdcreg[6]);
                        if (scrblank)
                        {
                                for (x=0;x<=crtc[1];x++)
                                {
                                        switch (seqregs[1]&9)
                                        {
                                                case 0:
                                                for (xx=0;xx<9;xx++) ((unsigned long *)buffer32->line[displine])[(x*9)+xx+32]=0;
                                                break;
                                                case 1:
                                                for (xx=0;xx<8;xx++) ((unsigned long *)buffer32->line[displine])[(x*8)+xx+32]=0;
                                                break;
                                                case 8:
                                                for (xx=0;xx<18;xx++) ((unsigned long *)buffer32->line[displine])[(x*18)+xx+32]=0;
                                                break;
                                                case 9:
                                                for (xx=0;xx<16;xx++) ((unsigned long *)buffer32->line[displine])[(x*16)+xx+32]=0;
                                                break;
                                        }
                                }
                        }
                        else if (!(gdcreg[6]&1))
                        {
                                if (fullchange)
                                {
                                        for (x=0;x<=crtc[1];x++)
                                        {
                                                drawcursor=((ma==ca) && con && cursoron);
                                                chr=vram[(ma<<1)];
                                                attr=vram[(ma<<1)+4];
//                                                printf("Read %05X %05X %02X %02X\n",ma<<1,(ma<<1)+4,chr,attr);
//if (!x) printf("Charsets %04X %04X\n",charseta,charsetb);
                                                if (attr&8) charaddr=charsetb+(chr*128);
                                                else        charaddr=charseta+(chr*128);

                                                if (drawcursor) { bg=pallook[egapal[attr&15]]; fg=pallook[egapal[attr>>4]]; }
                                                else            { fg=pallook[egapal[attr&15]]; bg=pallook[egapal[attr>>4]]; }

                                                dat=vram[charaddr+(sc<<2)];
                                                if (seqregs[1]&8)
                                                {
                                                        if (seqregs[1]&1) { for (xx=0;xx<8;xx++) ((unsigned long *)buffer32->line[displine])[((x<<4)+32+(xx<<1))&2047]=((unsigned long *)buffer32->line[displine])[((x<<4)+33+(xx<<1))&2047]=(dat&(0x80>>xx))?fg:bg; }
                                                        else
                                                        {
                                                                for (xx=0;xx<8;xx++) ((unsigned long *)buffer32->line[displine])[((x*18)+32+(xx<<1))&2047]=((unsigned long *)buffer32->line[displine])[((x*18)+33+(xx<<1))&2047]=(dat&(0x80>>xx))?fg:bg;
                                                                if ((chr&~0x1F)!=0xC0 || !(attrregs[0x10]&4)) ((unsigned long *)buffer32->line[displine])[((x*18)+32+16)&2047]=((unsigned long *)buffer32->line[displine])[((x*18)+32+17)&2047]=bg;
                                                                else                  ((unsigned long *)buffer32->line[displine])[((x*18)+32+16)&2047]=((unsigned long *)buffer32->line[displine])[((x*18)+32+17)&2047]=(dat&1)?fg:bg;
                                                        }
                                                }
                                                else
                                                {
                                                        if (seqregs[1]&1) { for (xx=0;xx<8;xx++) ((unsigned long *)buffer32->line[displine])[((x<<3)+32+xx)&2047]=(dat&(0x80>>xx))?fg:bg; }
                                                        else
                                                        {
                                                                for (xx=0;xx<8;xx++) ((unsigned long *)buffer32->line[displine])[((x*9)+32+xx)&2047]=(dat&(0x80>>xx))?fg:bg;
                                                                if ((chr&~0x1F)!=0xC0 || !(attrregs[0x10]&4)) ((unsigned long *)buffer32->line[displine])[((x*9)+32+8)&2047]=bg;
                                                                else                  ((unsigned long *)buffer32->line[displine])[((x*9)+32+8)&2047]=(dat&1)?fg:bg;
                                                        }
                                                }
                                                ma+=4; ma&=vrammask;
                                        }
                                }
                        }
                        else
                        {
                                switch (gdcreg[5]&0x60)
                                {
                                        case 0x00:
                                        if (seqregs[1]&8)
                                        {
                                                offset=((8-scrollcache)<<1)+16;
                                                for (x=0;x<=(crtc[1]+1);x++)
                                                {
                                                        edat[0]=vram[ma];
                                                        edat[1]=vram[ma|0x1];
                                                        edat[2]=vram[ma|0x2];
                                                        edat[3]=vram[ma|0x3];
                                                        ma+=4; ma&=vrammask;
//                                                        ma&=0xFFFF;
                                                        dat=edatlookup[edat[0]&3][edat[1]&3]|(edatlookup[edat[2]&3][edat[3]&3]<<2);
                                                        ((unsigned long *)buffer32->line[displine])[(x<<4)+14+offset]=((unsigned long *)buffer32->line[displine])[(x<<4)+15+offset]=pallook[egapal[dat&0xF]];
                                                        ((unsigned long *)buffer32->line[displine])[(x<<4)+12+offset]=((unsigned long *)buffer32->line[displine])[(x<<4)+13+offset]=pallook[egapal[dat>>4]];
                                                        dat=edatlookup[(edat[0]>>2)&3][(edat[1]>>2)&3]|(edatlookup[(edat[2]>>2)&3][(edat[3]>>2)&3]<<2);
                                                        ((unsigned long *)buffer32->line[displine])[(x<<4)+10+offset]=((unsigned long *)buffer32->line[displine])[(x<<4)+11+offset]=pallook[egapal[dat&0xF]];
                                                        ((unsigned long *)buffer32->line[displine])[(x<<4)+8+offset]= ((unsigned long *)buffer32->line[displine])[(x<<4)+9+offset]=pallook[egapal[dat>>4]];
                                                        dat=edatlookup[(edat[0]>>4)&3][(edat[1]>>4)&3]|(edatlookup[(edat[2]>>4)&3][(edat[3]>>4)&3]<<2);
                                                        ((unsigned long *)buffer32->line[displine])[(x<<4)+6+offset]= ((unsigned long *)buffer32->line[displine])[(x<<4)+7+offset]=pallook[egapal[dat&0xF]];
                                                        ((unsigned long *)buffer32->line[displine])[(x<<4)+4+offset]= ((unsigned long *)buffer32->line[displine])[(x<<4)+5+offset]=pallook[egapal[dat>>4]];
                                                        dat=edatlookup[edat[0]>>6][edat[1]>>6]|(edatlookup[edat[2]>>6][edat[3]>>6]<<2);
                                                        ((unsigned long *)buffer32->line[displine])[(x<<4)+2+offset]= ((unsigned long *)buffer32->line[displine])[(x<<4)+3+offset]=pallook[egapal[dat&0xF]];
                                                        ((unsigned long *)buffer32->line[displine])[(x<<4)+offset]=   ((unsigned long *)buffer32->line[displine])[(x<<4)+1+offset]=pallook[egapal[dat>>4]];
                                                }
                                        }
                                        else
                                        {
                                                offset=(8-scrollcache)+24;
                                                for (x=0;x<=(crtc[1]+1);x++)
                                                {
                                                        edat[0]=vram[ma];
                                                        edat[1]=vram[ma|0x1];
                                                        edat[2]=vram[ma|0x2];
                                                        edat[3]=vram[ma|0x3];
                                                        ma+=4; ma&=vrammask;
//                                                        ma&=0xFFFF;
                                                        dat=edatlookup[edat[0]&3][edat[1]&3]|(edatlookup[edat[2]&3][edat[3]&3]<<2);
                                                        ((unsigned long *)buffer32->line[displine])[(x<<3)+7+offset]=pallook[egapal[dat&0xF]];
                                                        ((unsigned long *)buffer32->line[displine])[(x<<3)+6+offset]=pallook[egapal[dat>>4]];
                                                        dat=edatlookup[(edat[0]>>2)&3][(edat[1]>>2)&3]|(edatlookup[(edat[2]>>2)&3][(edat[3]>>2)&3]<<2);
                                                        ((unsigned long *)buffer32->line[displine])[(x<<3)+5+offset]=pallook[egapal[dat&0xF]];
                                                        ((unsigned long *)buffer32->line[displine])[(x<<3)+4+offset]=pallook[egapal[dat>>4]];
                                                        dat=edatlookup[(edat[0]>>4)&3][(edat[1]>>4)&3]|(edatlookup[(edat[2]>>4)&3][(edat[3]>>4)&3]<<2);
                                                        ((unsigned long *)buffer32->line[displine])[(x<<3)+3+offset]=pallook[egapal[dat&0xF]];
                                                        ((unsigned long *)buffer32->line[displine])[(x<<3)+2+offset]=pallook[egapal[dat>>4]];
                                                        dat=edatlookup[edat[0]>>6][edat[1]>>6]|(edatlookup[edat[2]>>6][edat[3]>>6]<<2);
                                                        ((unsigned long *)buffer32->line[displine])[(x<<3)+1+offset]=pallook[egapal[dat&0xF]];
                                                        ((unsigned long *)buffer32->line[displine])[(x<<3)+offset]=  pallook[egapal[dat>>4]];
                                                }
                                        }
                                        break;
                                        case 0x20:
                                                offset=((8-scrollcache)<<1)+16;
//                                                printf("Displine %i MA %04X\n",displine,ma);
                                                for (x=0;x<=(crtc[1]+1);x++)
                                                {
                                                        if (sc&1 && !(crtc[0x17]&1))
                                                        {
                                                                edat[0]=vram[(ma<<1)+0x8000];
                                                                edat[1]=vram[(ma<<1)+0x8004];
                                                        }
                                                        else
                                                        {
                                                                edat[0]=vram[(ma<<1)];
                                                                edat[1]=vram[(ma<<1)+4];
                                                        }
                                                        ma+=4; ma&=vrammask;
//                                                        ma&=0xFFFF;
                                                        ((unsigned long *)buffer32->line[displine])[(x<<4)+14+offset]=((unsigned long *)buffer32->line[displine])[(x<<4)+15+offset]=pallook[egapal[edat[1]&3]];
                                                        ((unsigned long *)buffer32->line[displine])[(x<<4)+12+offset]=((unsigned long *)buffer32->line[displine])[(x<<4)+13+offset]=pallook[egapal[(edat[1]>>2)&3]];
                                                        dat=edatlookup[(edat[0]>>2)&3][(edat[1]>>2)&3]|(edatlookup[(edat[2]>>2)&3][(edat[3]>>2)&3]<<2);
                                                        ((unsigned long *)buffer32->line[displine])[(x<<4)+10+offset]=((unsigned long *)buffer32->line[displine])[(x<<4)+11+offset]=pallook[egapal[(edat[1]>>4)&3]];
                                                        ((unsigned long *)buffer32->line[displine])[(x<<4)+8+offset]= ((unsigned long *)buffer32->line[displine])[(x<<4)+9+offset]=pallook[egapal[(edat[1]>>6)&3]];
                                                        dat=edatlookup[(edat[0]>>4)&3][(edat[1]>>4)&3]|(edatlookup[(edat[2]>>4)&3][(edat[3]>>4)&3]<<2);
                                                        ((unsigned long *)buffer32->line[displine])[(x<<4)+6+offset]= ((unsigned long *)buffer32->line[displine])[(x<<4)+7+offset]=pallook[egapal[(edat[0]>>0)&3]];
                                                        ((unsigned long *)buffer32->line[displine])[(x<<4)+4+offset]= ((unsigned long *)buffer32->line[displine])[(x<<4)+5+offset]=pallook[egapal[(edat[0]>>2)&3]];
                                                        dat=edatlookup[edat[0]>>6][edat[1]>>6]|(edatlookup[edat[2]>>6][edat[3]>>6]<<2);
                                                        ((unsigned long *)buffer32->line[displine])[(x<<4)+2+offset]= ((unsigned long *)buffer32->line[displine])[(x<<4)+3+offset]=pallook[egapal[(edat[0]>>4)&3]];
                                                        ((unsigned long *)buffer32->line[displine])[(x<<4)+offset]=   ((unsigned long *)buffer32->line[displine])[(x<<4)+1+offset]=pallook[egapal[(edat[0]>>6)&3]];
                                                }
                                        break;
                                        case 0x40: case 0x60:
                                        if (changedvram[ma>>9] || changedvram[(ma>>9)+1] || fullchange)
                                        {
                                                if ((attrregs[0x10]&0x40) && !(tridentoldctrl2&0x10))
                                                {
                                                        offset=(8-(scrollcache&6))+24;
                                                        for (x=0;x<=(crtc[1]+1);x++)
                                                        {
                                                                edat[0]=vram[ma];
                                                                edat[1]=vram[ma|0x1];
                                                                edat[2]=vram[ma|0x2];
                                                                edat[3]=vram[ma|0x3];
                                                                ma+=4; ma&=vrammask;
//                                                                ma&=0xFFFF;
                                                                ((unsigned long *)buffer32->line[displine])[(x<<3)+6+offset]= ((unsigned long *)buffer32->line[displine])[(x<<3)+7+offset]=pallook[edat[3]];
                                                                ((unsigned long *)buffer32->line[displine])[(x<<3)+4+offset]= ((unsigned long *)buffer32->line[displine])[(x<<3)+5+offset]=pallook[edat[2]];
                                                                ((unsigned long *)buffer32->line[displine])[(x<<3)+2+offset]= ((unsigned long *)buffer32->line[displine])[(x<<3)+3+offset]=pallook[edat[1]];
                                                                ((unsigned long *)buffer32->line[displine])[(x<<3)+offset]=   ((unsigned long *)buffer32->line[displine])[(x<<3)+1+offset]=pallook[edat[0]];
                                                        }
                                                }
                                                else
                                                {
                                                        offset=(8-((scrollcache&6)>>1))+24;
                                                        if (!TRIDENT || bpp==8)
                                                        {
                                                                for (x=0;x<=((crtc[1]+1)<<1);x++)
                                                                {
                                                                        edat[0]=vram[ma];
                                                                        edat[1]=vram[ma|0x1];
                                                                        edat[2]=vram[ma|0x2];
                                                                        edat[3]=vram[ma|0x3];
                                                                        ma+=4; ma&=vrammask;
/*                                                                        if (ma&0x10000)
                                                                        {
                                                                                ma&=~0x30000;
                                                                                ma+=0x40000;
                                                                        }*/
                                                                        ((unsigned long *)buffer32->line[displine])[(x<<2)+3+offset]=pallook[edat[3]];
                                                                        ((unsigned long *)buffer32->line[displine])[(x<<2)+2+offset]=pallook[edat[2]];
                                                                        ((unsigned long *)buffer32->line[displine])[(x<<2)+1+offset]=pallook[edat[1]];
                                                                        ((unsigned long *)buffer32->line[displine])[(x<<2)+offset]=  pallook[edat[0]];
                                                                }
                                                        }
                                                        else if (bpp==16)
                                                        {
                                                                for (x=0;x<=((crtc[1]+1)<<1);x++)
                                                                {
                                                                        fg=vram[ma]|(vram[ma|0x1]<<8);
                                                                        bg=vram[ma|0x2]|(vram[ma|0x3]<<8);
                                                                        ma+=4; ma&=vrammask;
/*                                                                        if (ma&0x10000)
                                                                        {
                                                                                ma&=~0x30000;
                                                                                ma+=0x40000;
                                                                        }*/
                                                                        ((unsigned long *)buffer32->line[displine])[(x<<1)+1+offset]=((bg&31)<<3)|(((bg>>5)&63)<<10)|(((bg>>11)&31)<<19);
                                                                        ((unsigned long *)buffer32->line[displine])[(x<<1)+0+offset]=((fg&31)<<3)|(((fg>>5)&63)<<10)|(((fg>>11)&31)<<19);
                                                                }
                                                        }
                                                        else if (bpp==15)
                                                        {
                                                                for (x=0;x<=((crtc[1]+1)<<1);x++)
                                                                {
                                                                        fg=vram[ma]|(vram[ma|0x1]<<8);
                                                                        bg=vram[ma|0x2]|(vram[ma|0x3]<<8);
                                                                        ma+=4; ma&=vrammask;
/*                                                                        if (ma&0x10000)
                                                                        {
                                                                                ma&=~0x30000;
                                                                                ma+=0x40000;
                                                                        }*/
                                                                        ((unsigned long *)buffer32->line[displine])[(x<<1)+1+offset]=((bg&31)<<3)|(((bg>>5)&31)<<11)|(((bg>>10)&31)<<19);
                                                                        ((unsigned long *)buffer32->line[displine])[(x<<1)+0+offset]=((fg&31)<<3)|(((fg>>5)&31)<<11)|(((fg>>10)&31)<<19);
                                                                }
                                                        }
                                                        else if (bpp==24)
                                                        {
                                                                for (x=0;x<=(((crtc[1]+1)<<4)/6);x++)
                                                                {
                                                                        fg=vram[ma]|(vram[ma+1]<<8)|(vram[ma+2]<<16);
                                                                        ma+=3; ma&=vrammask;
                                                                        ((unsigned long *)buffer32->line[displine])[x+offset]=fg;
                                                                }
                                                        }
                                                }
                                        }
                                        break;
                                }
                        }
                        if (lastline<displine) lastline=displine;
                }

                displine++;
                if (TRIDENT && crtc[0x1E]&4) displine++;
                if ((cgastat&8) && ((displine&15)==(crtc[0x11]&15)))
                {
//                        printf("Vsync off at line %i\n",displine);
                        cgastat&=~8;
                }
                if (displine>((SVGA || TRIDENT)?1500:500)) displine=0;
        }
        else
        {
                vidtime+=dispontime;
//                if (output) printf("Display on %f\n",vidtime);
                if (egadispon) cgastat&=~1;
                linepos=0;
                if (sc==(crtc[11]&31) || ((crtc[8]&3)==3 && sc==((crtc[11]&31)>>1))) { con=0; }
                if (egadispon)
                {
                        if ((crtc[9]&0x80) && !linecountff)
                        {
                                linecountff=1;
                                ma=maback;
                        }
                        else if (sc==(crtc[9]&31))
                        {
                                linecountff=0;
                                sc=0;

                                if (TRIDENT && rowdbl) maback+=(crtc[0x13]<<4);
                                else                   maback+=(crtc[0x13]<<3);
/*                                if ((SVGA || TRIDENT) && (maback&0x10000))
                                {
                                        maback&=~0x30000;
                                        maback+=0x40000;
                                }
                                else */if (!(SVGA || TRIDENT)) maback&=0xFFFF;
                                else maback&=vrammask;
                                ma=maback;
                        }
                        else
                        {
                                linecountff=0;
                                sc++;
                                sc&=31;
                                ma=maback;
                        }
                }
                vc++;
                vc&=1023;
//                printf("Line now %i %i ma %05X\n",vc,displine,ma);
                if (vc==ega_split)
                {
//                        printf("Split at line %i %i\n",displine,vc);
                        ma=maback=0;
                        if (attrregs[0x10]&0x20) scrollcache=0;
                }
                if (vc==ega_dispend)
                {
//                        printf("Display over at line %i %i\n",displine,vc);
                        egadispon=0;
                        if ((crtc[10]&0x60)==0x20) cursoron=0;
                        else                       cursoron=cgablink&16;
                        if (!(gdcreg[6]&1) && !(cgablink&15)) fullchange=2;
                        cgablink++;

                        for (x=0;x<2048;x++) if (changedvram[x]) changedvram[x]--;
//                        memset(changedvram,0,2048);
                        if (fullchange) fullchange--;
                }
                if (vc==ega_vsyncstart)
                {
                        egadispon=0;
//                        printf("Vsync on at line %i %i\n",displine,vc);
                        cgastat|=8;
                        if (seqregs[1]&8) x=(crtc[1]+1)*((seqregs[1]&1)?8:9)*2;
                        else              x=(crtc[1]+1)*((seqregs[1]&1)?8:9);
                        if (TRIDENT && (bpp==16 || bpp==15)) x/=2;
                        if (TRIDENT && bpp==24) x=(x*2)/6;
                        if (TRIDENT && crtc[0x1E]&4 && !oddeven) lastline++;
                        startblit();
                        if (x!=xsize || (lastline-firstline)!=ysize)
                        {
                                xsize=x;
                                ysize=(lastline-firstline)+1;
//                                printf("Lastline %i Firstline %i Ysize %i\n",lastline,firstline,ysize);
                                if (xsize<64) xsize=656;
                                if (ysize<32) ysize=200;
                                if (vres) updatewindowsize(xsize,ysize<<1);
                                else      updatewindowsize(xsize,ysize);
                        }
//                        printf("Blit\n");
                        if (vres)
                        {
                                blit(buffer32,vbuf,32,0,0,0,xsize,ysize);
                                stretch_blit(vbuf,screen,0,0,xsize,ysize,0,0,xsize,ysize<<1);
                        }
                        else
                           blit(buffer32,screen,32,0,0,0,xsize,ysize);
                        if (readflash) rectfill(screen,xsize-40,8,xsize-8,14,0xFFFFFFFF);
                        endblit();
                        readflash=0;
                        framecount++;
                        firstline=2000;
                        lastline=0;
                        oddeven^=1;
                        maback=ma=(crtc[0xC]<<8)|crtc[0xD];
                        ca=(crtc[0xE]<<8)|crtc[0xF];
                        if (SVGA)
                        {
                                ma|=(crtc[0x33]&0x3)<<18;
                                maback|=(crtc[0x33]&0x3)<<18;
                                ca|=(crtc[0x33]&0xC)<<16;
                        }
                        if (TRIDENT)
                        {
                                if ((crtc[0x1E]&0xA0)==0xA0) ma=maback=ma|0x40000;
                                if ((crtc[0x27]&0x01)==0x01) ma=maback=ma|0x80000;
                                if ((crtc[0x27]&0x02)==0x02) ma=maback=ma|0x100000;
                                if (rowdbl)
                                {
                                        ma<<=1;
                                        maback<<=1;
                                }
                                if (crtc[0x1E]&4) /*Interlace*/
                                {
                                        if (oddeven) ma=maback=ma+(crtc[0x13]<<1);
                                }
                        }
                        ma<<=2;
                        maback<<=2;
//                                printf("New MA %05X %02X %02X\n",ma,crtc[0x1E],crtc[0x27]);
                        ca<<=2;
                        changeframecount=(TRIDENT && (crtc[0x1E]&4))?3:2;
                }
                if (vc==ega_vtotal)
                {
//                        printf("Frame over at line %i %i  %i %i\n",displine,vc,ega_vsyncstart,ega_dispend);
                        vc=0;
                        sc=0;
                        egadispon=1;
                        displine=(TRIDENT && (crtc[0x1E]&4) && oddeven)?1:0;
                        scrollcache=attrregs[0x13]&7;
                        linecountff=0;
                }
                if ((sc==(crtc[10]&31) || ((crtc[8]&3)==3 && sc==((crtc[10]&31)>>1)))) con=1;
        }
        if (TRIDENT && gdcreg[0xF]&8) crtc[1]>>=1;
//        printf("2 %i\n",ega_vsyncstart);
}
