#include <allegro.h>
#include <stdio.h>
#include "ibm.h"

int soundon=1;
AUDIOSTREAM *as;
signed short *adbuffer,*adbuffer2;
signed short *psgbuffer;
unsigned short *cmsbuffer;
signed short *spkbuffer;
signed short *outbuffer;
unsigned short *gusbuffer;

void initsound()
{
        initalmain(0,NULL);
        inital();
//        install_sound(DIGI_AUTODETECT,MIDI_NONE,0);
//        as=play_audio_stream(SOUNDBUFLEN,16,1,48000,255,128);
        initadlib();
        adbuffer=malloc((SOUNDBUFLEN)*2);
        adbuffer2=malloc((SOUNDBUFLEN)*2);
        psgbuffer=malloc((SOUNDBUFLEN)*2);
        cmsbuffer=malloc((SOUNDBUFLEN)*2*2);
        gusbuffer=malloc((SOUNDBUFLEN)*2*2);
        spkbuffer=malloc(((SOUNDBUFLEN)*2)+32);
        outbuffer=malloc((SOUNDBUFLEN)*2*2);
}

int adpoll=0;
void pollad()
{
        if (adpoll>=20) return;
        getadlibl(adbuffer+(adpoll*(48000/200)),48000/200);
        getadlibr(adbuffer2+(adpoll*(48000/200)),48000/200);
        adpoll++;
//        printf("ADPOLL %i\n",adpoll);
}

int psgpoll=0;
void pollpsg()
{
        if (psgpoll>=20) return;
        getpsg(psgbuffer+(psgpoll*(48000/200)),48000/200);
        psgpoll++;
}

int cmspoll=0;
void pollcms()
{
        if (cmspoll>=20) return;
        getcms(cmsbuffer+(cmspoll*(48000/200)*2),48000/200);
        cmspoll++;
}

int guspoll=0;
void pollgussnd()
{
        if (guspoll>=20) return;
        getgus(gusbuffer+(guspoll*(48000/200)*2),48000/200);
        guspoll++;
}

int spkpos=0;
void pollspk()
{
        if (spkpos>=SOUNDBUFLEN) return;
//        printf("SPeaker - %i %i %i %02X\n",speakval,gated,speakon,pit.m[2]);
        if (gated)
        {
                if (!pit.m[2] || pit.m[2]==4)
                   spkbuffer[spkpos]=speakval;
                else 
                   spkbuffer[spkpos]=(speakon)?0x1400:0;
        }
        else
           spkbuffer[spkpos]=0;
        spkpos++;
}

FILE *soundf;
void pollsound()
{
        int c;
//        printf("Pollsound! %i\n",soundon);
        if (soundon)
        {
                for (c=0;c<(SOUNDBUFLEN);c++)
                {
                        outbuffer[c<<1]=adbuffer[c]^0x8000;
                        outbuffer[(c<<1)+1]=adbuffer2[c]^0x8000;
                }
//                printf("AD0 %i %i\n",outbuffer[0],adbuffer[0]);
//                printf("%04X ",outbuffer[0]);
//                memcpy(outbuffer,adbuffer,(SOUNDBUFLEN)*2);
                for (c=0;c<spkpos;c++)
                {
                        outbuffer[c<<1]+=(spkbuffer[c]/2);
                        outbuffer[(c<<1)+1]+=(spkbuffer[c]/2);
                }
//                printf("%04X ",outbuffer[0]);
                for (c=spkpos;c<(SOUNDBUFLEN);c++)
                {
                        outbuffer[c<<1]+=(spkbuffer[spkpos-1]/2);
                        outbuffer[(c<<1)+1]+=(spkbuffer[spkpos-1]/2);
                }
//                printf("OUT0 %i\n",outbuffer[0]);
                for (c=0;c<(SOUNDBUFLEN);c++)
                {
                        outbuffer[c<<1]+=(psgbuffer[c]/2);
                        outbuffer[(c<<1)+1]+=(psgbuffer[c]/2);
                }
//                printf("PSG0 %i %i\n",psgbuffer[0],psgbuffer[0]/2);
//                printf("OUT1 %i\n",outbuffer[0]);
//                printf("%04X ",outbuffer[0]);
                for (c=0;c<((SOUNDBUFLEN)*2);c++)
                    outbuffer[c]+=(cmsbuffer[c]/2);
//                printf("%04X ",outbuffer[0]);
                for (c=0;c<((SOUNDBUFLEN)*2);c++)
                    outbuffer[c]+=(gusbuffer[c]);
//                printf("%04X ",outbuffer[0]);
                addsb(outbuffer);
//                printf("%04X ",outbuffer[0]);
                adddac(outbuffer);
//                printf("%04X\n",outbuffer[0]);
//                addgus(outbuffer);
//                for (c=0;c<((SOUNDBUFLEN)*2);c++) outbuffer[c]^=0x8000;
//                getpsgbuffer(outbuffer,SOUNDBUFLEN);
//                outputsoundbuffer(outbuffer);
                if (!soundf) soundf=fopen("sound.pcm","wb");
                fwrite(outbuffer,(SOUNDBUFLEN)*2*2,1,soundf);
                givealbuffer(outbuffer);
//                for (c=0;c<((SOUNDBUFLEN)*2);c++) outbuffer[c]^=0x8000;
        }
        addsb(outbuffer);
        adddac(outbuffer);
        adpoll=0;
        psgpoll=0;
        cmspoll=0;
        spkpos=0;
        guspoll=0;
}

int sndcount;
void pollsound60hz()
{
//        printf("Poll sound %i\n",sndcount);
                pollad();
                pollpsg();
                pollcms();
                pollgussnd();
                sndcount++;
                if (sndcount==20)
                {
                        sndcount=0;
                        pollsound();
                }
}
