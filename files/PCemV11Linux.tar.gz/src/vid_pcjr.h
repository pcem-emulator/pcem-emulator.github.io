extern device_t pcjr_video_device;
