extern device_t tgui9440_device;
