void piix_init(int card);
