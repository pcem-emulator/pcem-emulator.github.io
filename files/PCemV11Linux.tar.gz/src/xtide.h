void xtide_init();
