extern device_t gd5429_device;
