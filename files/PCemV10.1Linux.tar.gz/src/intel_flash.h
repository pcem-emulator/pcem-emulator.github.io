extern device_t intel_flash_device;
