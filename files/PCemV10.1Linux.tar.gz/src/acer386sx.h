void acer386sx_init();
