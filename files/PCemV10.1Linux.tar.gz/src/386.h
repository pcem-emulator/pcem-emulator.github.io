extern void cpu_386_flags_extract();
extern void cpu_386_flags_rebuild();
