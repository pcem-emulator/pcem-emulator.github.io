void mouse_ps2_init();
