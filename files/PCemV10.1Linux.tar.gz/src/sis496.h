extern device_t sis496_device;
