extern device_t sn76489_device;

extern int sn76489_mute;
