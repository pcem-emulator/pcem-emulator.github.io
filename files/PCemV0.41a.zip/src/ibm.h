#include <stdio.h>
#define printf pclog

unsigned long rmbmask(int i);
int isram[256];

int readlookup[64];
unsigned long *readlookup2;
int readlnext;
int writelookup[64];
unsigned long *writelookup2;
int writelnext;

#define readmemb(a) ((readlookup2[(a)>>12]==0xFFFFFFFF)?readmembl(a):ram[readlookup2[(a)>>12]+((a)&0xFFF)])
#define readmemw(s,a) ((readlookup2[((s)+(a))>>12]==0xFFFFFFFF || (s)==0xFFFFFFFF)?readmemwl(s,a):*((unsigned short *)(&ram[readlookup2[((s)+(a))>>12]+(((s)+(a))&0xFFF)])))
#define readmeml(s,a) ((readlookup2[((s)+(a))>>12]==0xFFFFFFFF || (s)==0xFFFFFFFF)?readmemll(s,a):*((unsigned long *)(&ram[readlookup2[((s)+(a))>>12]+(((s)+(a))&0xFFF)])))

//#define writememb(a,v) if (writelookup2[(a)>>12]==0xFFFFFFFF) writemembl(a,v); else ram[writelookup2[(a)>>12]+((a)&0xFFF)]=v
//#define writememw(s,a,v) if (writelookup2[((s)+(a))>>12]==0xFFFFFFFF || (s)==0xFFFFFFFF) writememwl(s,a,v); else *((unsigned short *)(&ram[writelookup2[((s)+(a))>>12]+(((s)+(a))&0xFFF)]))=v
//#define writememl(s,a,v) if (writelookup2[((s)+(a))>>12]==0xFFFFFFFF || (s)==0xFFFFFFFF) writememll(s,a,v); else *((unsigned long *)(&ram[writelookup2[((s)+(a))>>12]+(((s)+(a))&0xFFF)]))=v
//#define readmemb(a) ((isram[((a)>>16)&255] && !(cr0>>31))?ram[a&0xFFFFFF]:readmembl(a))
//#define writememb(a,v) if (isram[((a)>>16)&255] && !(cr0>>31)) ram[a&0xFFFFFF]=v; else writemembl(a,v)

//void writememb(unsigned long addr, unsigned char val);
unsigned short readmemwl(unsigned long seg, unsigned long addr);
void writememwl(unsigned long seg, unsigned long addr, unsigned short val);
unsigned long readmemll(unsigned long seg, unsigned long addr);
void writememll(unsigned long seg, unsigned long addr, unsigned long val);


#define EAX regs[0].l
#define ECX regs[1].l
#define EDX regs[2].l
#define EBX regs[3].l
#define ESP regs[4].l
#define EBP regs[5].l
#define ESI regs[6].l
#define EDI regs[7].l
#define AX regs[0].w
#define CX regs[1].w
#define DX regs[2].w
#define BX regs[3].w
#define SP regs[4].w
#define BP regs[5].w
#define SI regs[6].w
#define DI regs[7].w
#define AL regs[0].b.l
#define AH regs[0].b.h
#define CL regs[1].b.l
#define CH regs[1].b.h
#define DL regs[2].b.l
#define DH regs[2].b.h
#define BL regs[3].b.l
#define BH regs[3].b.h

typedef union
{
        unsigned long l;
        unsigned short w;
        struct
        {
                unsigned char l,h;
        } b;
} x86reg;

x86reg regs[8];
unsigned short flags,eflags;
unsigned long /*cs,ds,es,ss,*/oldds,oldss,pc;
unsigned short msw;

typedef struct
{
        unsigned long base;
        unsigned short limit;
        unsigned char access;
        unsigned short seg;
} x86seg;

x86seg gdt,ldt,idt,tr;
x86seg _cs,_ds,_es,_ss,_fs,_gs;

unsigned long pccache;
unsigned char *pccache2;
/*Segments -
  _cs,_ds,_es,_ss are the segment structures
  CS,DS,ES,SS is the 16-bit data
  cs,ds,es,ss are defines to the bases*/
//unsigned short CS,DS,ES,SS;
#define CS _cs.seg
#define DS _ds.seg
#define ES _es.seg
#define SS _ss.seg
#define FS _fs.seg
#define GS _gs.seg
#define cs _cs.base
#define ds _ds.base
#define es _es.base
#define ss _ss.base
#define fs _fs.base
#define gs _gs.base

#define CPL ((_cs.access>>5)&3)

void loadseg(unsigned short seg, x86seg *s);
void loadcs(unsigned short seg);
unsigned long rammask;

union
{
        unsigned long l;
        unsigned short w;
} CR0;

#define cr0 CR0.l
#define msw CR0.w

unsigned long cr2,cr3;

#define C_FLAG  0x0001
#define P_FLAG  0x0004
#define A_FLAG  0x0010
#define Z_FLAG  0x0040
#define N_FLAG  0x0080
#define T_FLAG  0x0100
#define I_FLAG  0x0200
#define D_FLAG  0x0400
#define V_FLAG  0x0800
#define NT_FLAG 0x4000
#define VM_FLAG 0x0002 /*In EFLAGS*/
#define IOPL ((flags>>12)&3)

#define IOPLp ((!(msw&1)) || (CPL<=IOPL))
//#define IOPLV86 ((!(msw&1)) || (CPL<=IOPL))

typedef struct PIT
{
        unsigned long l[3];
        float c[3];
        unsigned char m[3];
        unsigned char ctrl,ctrls[2];
        int wp,rm[3];
        unsigned short rl[3];
        int thit[3];
        int delay[3];
        int rereadlatch[3];
} PIT;

PIT pit;
void setpitclock(float clock);

typedef struct DMA
{
        unsigned short ab[4],ac[4];
        unsigned short cb[4];
        int cc[4];
        int wp;
        unsigned char m,mode[4];
        unsigned char page[4];
        unsigned char stat;
} DMA;

DMA dma,dma16;

typedef struct PPI
{
        int s2;
        unsigned char pa,pb;
} PPI;

PPI ppi;

typedef struct PIC
{
        unsigned char icw1,mask,ins,pend;
        int icw;
        unsigned char vector;
} PIC;

PIC pic,pic2;

typedef struct FDC
{
        unsigned char dor,stat,command,dat,st0;
        int head,track[2],sector,drive,lastdrive;
        int pos;
        unsigned char params[8];
        unsigned char res[8];
        int pnum,ptot;
} FDC;

FDC fdc;
int disctime;

#define MDA ((gfxcard==GFX_MDA || gfxcard==GFX_HERCULES) && (romset<ROM_TANDY || romset>=ROM_IBMAT))
#define HERCULES (gfxcard==GFX_HERCULES && (romset<ROM_TANDY || romset>=ROM_IBMAT))
#define AMSTRAD (romset==ROM_PC1512 || romset==ROM_PC1640)
#define AMSTRADIO (romset==ROM_PC1512 || romset==ROM_PC1640 || romset==ROM_PC200)
#define TANDY (romset==ROM_TANDY/* || romset==ROM_IBMPCJR*/)
#define EGA (romset==ROM_PC1640 || VGA)
#define VGA ((gfxcard==GFX_SVGA || gfxcard==GFX_ET4000) && romset!=ROM_PC1640 && romset!=ROM_PC1512 && romset!=ROM_TANDY && romset!=ROM_PC200)
#define SVGA (gfxcard==GFX_ET4000 && VGA)
#define TRIDENT (gfxcard==GFX_SVGA)
#define AT (romset==ROM_IBMAT || romset==ROM_IBMAT386 || romset==ROM_AMI386 || romset==ROM_AMI286 || romset==ROM_AMI486)

#define AMIBIOS (romset==ROM_AMI386 || romset==ROM_AMI486)
int FASTDISC;
int ADLIB;
int GAMEBLASTER;

char discfns[2][256];

int intcount,pitcount;

#define ROM_IBMPC    0 /*301 keyboard error, 131 cassette (!!!) error*/
#define ROM_IBMXT    1 /*301 keyboard error*/
#define ROM_GENXT    2 /*'Generic XT BIOS'*/
#define ROM_EUROPC   3
#define ROM_TANDY    4 /*Works fine*/
#define ROM_PC1512   5 /*Works fine*/
#define ROM_PC200    6 /*Video controller not emulated, so has to run in diagnostic mode*/
#define ROM_PC1640   7 /*Works fine*/
#define ROM_IBMAT    8
#define ROM_AMI286   9
#define ROM_IBMAT386 10
#define ROM_AMI386   11
#define ROM_AMI486   12

//#define ROM_IBMPCJR 5 /*Not working! ROMs are corrupt*/
#define is386 (romset==ROM_IBMAT386 || romset==ROM_AMI386 || romset==ROM_AMI486)
#define is386sx 0

int romset;

#define GFX_CGA 0
#define GFX_MDA 1
#define GFX_HERCULES 2
#define GFX_SVGA 3     /*Using Trident BIOS*/
#define GFX_ET4000 4   /*Tseng ET4000*/

void (*pollvideo)();
void pollega();

int gfxcard;

unsigned char spkstat;

float spktime,soundtime,gustime,vidtime;
int ppispeakon;
//#define SPKCONST (8000000.0/44100.0)
float SPKCONST;
float SOUNDCONST;
float CASCONST;
float GUSCONST;
float CGACONST;
float MDACONST;
float VGACONST1,VGACONST2;
int gated,speakval,speakon;

int readflash;

/*0=4.77mhz 8088
  1=8mhz 8086*/
int cpuspeed;

unsigned char *ram,*vram;
unsigned char hercctrl;

int mousedelay;

int driveempty[2];

#define SOUNDBUFLEN (48000/10)

/*Sound Blaster*/
int sbenable,sblatch,sbcount;
unsigned char sbdat;
void setsbclock(float clock);

#define SADLIB 1 /*No DSP*/
#define SB1    2 /*DSP v1.00*/
#define SB2    3 /*DSP v2.01 - needed for high-speed DMA*/
#define SBPRO  4 /*DSP v3.00*/
int sbtype;

struct
{
        int vocl,vocr,voc;
        int midl,midr,mid;
        int masl,masr,mas;
} sbpmixer;



int clocks[3][5][4];
int at70hz;

char pcempath[512];

FILE *romfopen(char *fn, char *mode);

typedef struct
{
        FILE *f;
        int spt,hpc; /*Sectors per track, heads per cylinder*/
        int tracks;
} PcemHDC;

PcemHDC hdc[2];


int output2;

int keybsenddelay;
int shadowbios;
int dssmode;

/*Set to 1 to enable 386 emulation*/
#define emu386 1

int slowega,egacycles;
extern int cycles;

extern unsigned char gdcreg[16];
