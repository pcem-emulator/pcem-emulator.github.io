#include <stdio.h>
#include "ibm.h"

void polldisc();
int timetolive;
int SECTORS[2]={9,9};
int SIDES[2]={2,2};
//#define SECTORS 9
int output;
int lastbyte=0;
unsigned char disc[2][2][80][36][512];

int discchanged[2];
int discmodified[2];

void loaddisc(char *fn)
{
        FILE *f=fopen(fn,"rb");
        int h,t,s,b;
        if (!f)
        {
                SECTORS[0]=9; SIDES[0]=1;
                driveempty[0]=1;
                return;
        }
        driveempty[0]=0;
        SIDES[0]=2;
        fseek(f,-1,SEEK_END);
        if (ftell(f)<=(160*1024))      { SECTORS[0]=8; SIDES[0]=1; }
        else if (ftell(f)<=(180*1024)) { SECTORS[0]=9; SIDES[0]=1; }
        else if (ftell(f)<=(320*1024)) SECTORS[0]=8;
        else if (ftell(f)<(1024*1024)) SECTORS[0]=9;  /*Double density*/
        else if (ftell(f)<(0x1A4000-1))  SECTORS[0]=18; /*High density (not supported by Tandy 1000)*/
        else if (ftell(f)<(2048*1024)) SECTORS[0]=21; /*DMF format - used by Windows 95*/
        else                           SECTORS[0]=36; /*E density (not supported by anything)*/
        printf("Drive A: has %i sectors and %i sides and is %i bytes long\n",SECTORS[0],SIDES[0],ftell(f));
        fseek(f,0,SEEK_SET);
        for (t=0;t<80;t++)
        {
                for (h=0;h<SIDES[0];h++)
                {
                        for (s=0;s<SECTORS[0];s++)
                        {
                                for (b=0;b<512;b++)
                                {
                                        disc[0][h][t][s][b]=getc(f);
                                }
                        }
                }
        }
        fclose(f);
        discmodified[0]=0;
        strcpy(discfns[0],fn);
        discchanged[0]=1;
}

void loaddisc2(char *fn)
{
        FILE *f=fopen(fn,"rb");
        int h,t,s,b;
        if (!f)
        {
                SECTORS[1]=9; SIDES[1]=1;
                driveempty[1]=1;
                return;

        }
        driveempty[1]=0;
        SIDES[1]=2;
        fseek(f,-1,SEEK_END);
        if (ftell(f)<=(160*1024))      { SECTORS[1]=8; SIDES[1]=1; }
        else if (ftell(f)<=(180*1024)) { SECTORS[1]=9; SIDES[1]=1; }
        else if (ftell(f)<=(320*1024)) SECTORS[1]=8;
        else if (ftell(f)<(1024*1024)) SECTORS[1]=9;  /*Double density*/
        else if (ftell(f)<(0x1A4000))  SECTORS[1]=18; /*High density (not supported by Tandy 1000)*/
        else if (ftell(f)<(2048*1024)) SECTORS[1]=21; /*DMF format - used by Windows 95*/
        else                           SECTORS[1]=36; /*E density (not supported by anything)*/
        fseek(f,0,SEEK_SET);
        for (t=0;t<80;t++)
        {
                for (h=0;h<SIDES[1];h++)
                {
                        for (s=0;s<SECTORS[1];s++)
                        {
                                for (b=0;b<512;b++)
                                {
                                        disc[1][h][t][s][b]=getc(f);
                                }
                        }
                }
        }
        fclose(f);
        discmodified[1]=0;
        strcpy(discfns[1],fn);
        discchanged[1]=1;
}

void ejectdisc()
{
        discfns[0][0]=0;
        driveempty[0]=1;
}
void ejectdisc2()
{
        discfns[1][0]=0;
        driveempty[1]=1;
}

void savedisc()
{
        FILE *f;
        int h,t,s,b;
        if (!discmodified[0]) return;
        f=fopen(discfns[0],"wb");
        if (!f) return;
        printf("Save disc0 %s %i %i\n",discfns[0],SIDES[0],SECTORS[0]);
        for (t=0;t<80;t++)
        {
                for (h=0;h<SIDES[0];h++)
                {
                        for (s=0;s<SECTORS[0];s++)
                        {
                                for (b=0;b<512;b++)
                                {
                                        putc(disc[0][h][t][s][b],f);
                                }
                        }
                }
        }
        fclose(f);
}

void savedisc2(char *fn)
{
        FILE *f;
        int h,t,s,b;
        if (!discmodified[1]) return;
        f=fopen(discfns[1],"wb");
        if (!f) return;
        printf("Save disc1 %s %i %i\n",discfns[1],SIDES[1],SECTORS[1]);
        for (t=0;t<80;t++)
        {
                for (h=0;h<SIDES[1];h++)
                {
                        for (s=0;s<SECTORS[1];s++)
                        {
                                for (b=0;b<512;b++)
                                {
                                        putc(disc[1][h][t][s][b],f);
                                }
                        }
                }
        }
        fclose(f);
}
int ratio1,ratio2;
void int13read()
{
        int c;
        unsigned short b=BX;
        int temp=AL;
        int sector=(CL&63)-1;
        int track=CH;
        fullspeed();
//        output=3;
        ratio1=ratio2=0;
//        printf("Read sector! %02X %04X:%04X\n",DL,CS,pc);
        if (driveempty[DL&1])
        {
//                printf("Drive empty!\n");
                flags|=C_FLAG;
                AH=0x80;
                return;
        }
        if (discchanged[DL&1])
        {
                discchanged[DL&1]=0;
                flags|=C_FLAG;
                AH=6;
                return;
        }
        readflash=1;
        while (temp>0)
        {
//                if (CL==4 && CH==14 && DL&1 && DL&1 && AL==7) output=1;
//                printf("Reading sector %i track %i side %i drive %i %02X to %04X:%04X %05X\n",CL,CH,DH&1,DL&1,AL,es>>4,BX,b);
                for (c=0;c<512;c++)
                {
                        writememb(es+b,disc[DL&1][DH&1][track][sector][c]);
                        b++;
                }
                temp--;
                        sector++;
                        if (sector==SECTORS[DL&1]+1)
                        {
//                                printf("Wrapped!\n");
                                sector=0;
//                                DH^=1;
//                                if (!DH)
//                                   CH++;
                        }
        }
        flags&=~C_FLAG;
        AH=0;
}

void int13write()
{
        int c;
        unsigned short b=BX;
        int temp=AL;
        int sector=(CL&63)-1;
        int track=CH;
        if (driveempty[DL&1])
        {
                flags|=C_FLAG;
                AH=0x80;
                return;
        }
        if (discchanged[DL&1])
        {
                discchanged[DL&1]=0;
                flags|=C_FLAG;
                AH=6;
                return;
        }
        readflash=1;
        discmodified[DL&1]=1;
        while (temp>0)
        {
//                printf("Writing sector %i track %i side %i drive %i %02X to %04X:%04X %05X\n",CL,CH,DH&1,DL&1,AL,es>>4,BX,b);
                for (c=0;c<512;c++)
                {
                        disc[DL&1][DH&1][track][sector][c]=readmembl(es+b);
                        b++;
                }
                temp--;
                        sector++;
                        if (sector==SECTORS[DL&1]+1)
                        {
//                                printf("Wrapped!\n");
                                sector=0;
//                                DH^=1;
//                                if (!DH)
//                                   CH++;
                        }
        }
        flags&=~C_FLAG;
        AH=0;
}

int discint;
void resetfdc()
{
        fdc.stat=0x80;
        fdc.pnum=fdc.ptot=0;
        fdc.st0=0xC0;
//        printf("Reset FDC\n");
}
int ins;
void writefdc(unsigned short addr, unsigned char val)
{
        int c;
//        printf("Write FDC %04X %02X %04X:%04X %i %02X\n",addr,val,cs>>4,pc,ins,fdc.st0);
        switch (addr&7)
        {
                case 1: return;
                case 2: /*DOR*/
//                printf("DOR was %02X\n",fdc.dor);
                if (val&4)
                {
                        fdc.stat=0x80;
                        fdc.pnum=fdc.ptot=0;
                }
                if ((val&4) && !(fdc.dor&4))
                {
                        disctime=128;
                        discint=-1;
                        resetfdc();
                }
                fdc.dor=val;
//                printf("DOR now %02X\n",val);
                return;
                case 5: /*Command register*/
                if (fdc.pnum==fdc.ptot)
                {
                        fdc.command=val;
//                        printf("Starting FDC command %02X\n",fdc.command);
                        switch (fdc.command&0x1F)
                        {
                                case 2: /*Read track*/
//                                printf("Read track!\n");
                                fdc.pnum=0;
                                fdc.ptot=8;
                                fdc.stat=0x90;
                                fdc.pos=0;
                                break;
                                case 3: /*Specify*/
                                fdc.pnum=0;
                                fdc.ptot=2;
                                fdc.stat=0x90;
                                break;
                                case 4: /*Sense drive status*/
                                fdc.pnum=0;
                                fdc.ptot=1;
                                fdc.stat=0x90;
                                break;
                                case 5: /*Write data*/
//                                printf("Write data!\n");
                                fdc.pnum=0;
                                fdc.ptot=8;
                                fdc.stat=0x90;
                                fdc.pos=0;
                                readflash=1;
                                break;
                                case 6: /*Read data*/
                                fullspeed();
                                fdc.pnum=0;
                                fdc.ptot=8;
                                fdc.stat=0x90;
                                fdc.pos=0;
                                readflash=1;
                                break;
                                case 7: /*Recalibrate*/
                                fdc.pnum=0;
                                fdc.ptot=1;
                                fdc.stat=0x90;
                                break;
                                case 8: /*Sense interrupt status*/
//                                printf("Sense interrupt status %i\n",fdc.drive);
                                fdc.lastdrive=fdc.drive;
                                fdc.stat=0x30;
                                disctime=1024;
                                discint=8;
                                fdc.pos=0;
//                                if (output)
//                                {
//                                        dumpregs();
//                                        exit(-1);
//                                }
//                                else
//                                   output=1;
                                break;
                                case 10: /*Read sector ID*/
                                fdc.pnum=0;
                                fdc.ptot=1;
                                fdc.stat=0x90;
                                fdc.pos=0;
                                break;
                                case 15: /*Seek*/
                                fdc.pnum=0;
                                fdc.ptot=2;
                                fdc.stat=0x90;
                                break;
                                case 0x10: /*Invalid*/
                                fdc.stat=0x30;
                                discint=fdc.command&0x1F;
                                disctime=1024;
                                break;

                                default:
                                pclog("Bad FDC command %02X\n",val);
                                dumpregs();
                                exit(-1);
                        }
                }
                else
                {
                        fdc.params[fdc.pnum++]=val;
                        if (fdc.pnum==fdc.ptot)
                        {
//                                printf("FDC start command %02X ",fdc.command);
//                                for (c=0;c<fdc.ptot;c++) printf("%02X ",fdc.params[c]);
//                                printf("  %04X:%04X\n",cs>>4,pc);
                                fdc.stat=0x30;
                                discint=fdc.command&0x1F;
                                disctime=1024;
                                fdc.drive=fdc.params[0]&1;
/*                                if (discint==7)
                                {
                                        fdc.track=0;
                                        if (fdc.drive) fdc.stat=2|0x30;
                                        else           fdc.stat=1|0x30;
                                }*/
//                                if (discint==7 && fdc.drive) output=timetolive=15000;
                                if (discint==2 || discint==5 || discint==6)
                                {
                                        fdc.track[fdc.drive]=fdc.params[1];
                                        fdc.head=fdc.params[2];
                                        fdc.sector=fdc.params[3];
//                                        if (discint==5) printf("Par 5 %02X\n",fdc.params[5]);
                                        if (!fdc.params[5])
                                        {
                                                printf("Bad num of sectors %i\n",fdc.params[5]);
                                                dumpregs();
                                                exit(-1);
                                                fdc.params[5]=fdc.sector;
                                        }
                                        if (fdc.params[5]>SECTORS[fdc.drive]) fdc.params[5]=SECTORS[fdc.drive];
//                                        if (fdc.params[5]<fdc.sector) fdc.params[5]=fdc.sector;
//                                        printf("Par 5 %02X\n",fdc.params[5]);
//                                        if (fdc.params[6]==0x8) fdc.params[5]=SECTORS;
//                                        if (discint==6) printf("Read sector - Drive %i Head %i Track %i Sector %i\n",fdc.drive,fdc.head,fdc.track[fdc.drive],fdc.sector);
//                                        if (discint==5) printf("Write sector - Drive %i Head %i Track %i Sector %i %i\n",fdc.drive,fdc.head,fdc.track[fdc.drive],fdc.sector,fdc.params[5]);
//                                        if (fdc.params[5]>SECTORS) fdc.params[5]=SECTORS;
                                        if (driveempty[fdc.drive])
                                        {
                                                discint=-3;
                                        }
                                }
//                                if (discint==5) fdc.pos=512;
                        }
                }
                case 7:
                return;
        }
//        printf("Write FDC %04X %02X\n",addr,val);
//        dumpregs();
//        exit(-1);
}

int paramstogo=0;
unsigned char readfdc(unsigned short addr)
{
        unsigned char temp;
//        printf("Read FDC %04X %04X:%04X %04X %i %02X ",addr,cs>>4,pc,BX,fdc.pos,fdc.st0);
        switch (addr&7)
        {
                case 1: /*???*/
                temp=0x50;
                break;
                case 4: /*Status*/
                temp=fdc.stat;
                break;
                case 5: /*Data*/
                fdc.stat&=~0x80;
                if (paramstogo)
                {
                        paramstogo--;
                        temp=fdc.res[6-paramstogo];
//                        printf("Read param %i %02X\n",6-paramstogo,temp);
                        if (!paramstogo) fdc.stat=0x80;
                        else
                        {
                                fdc.stat|=0xC0;
//                                polldisc();
                        }
                }
                else
                {
                        if (lastbyte) fdc.stat=0x80;
                        lastbyte=0;
                        temp=fdc.dat;
                }
                break;
                case 7: /*Disk change*/
                temp=(discchanged[fdc.dor&1])?0x80:0;
                discchanged[fdc.dor&1]=0;
                break;
                default:
                        temp=0xFF;
//                printf("Bad read FDC %04X\n",addr);
//                dumpregs();
//                exit(-1);
        }
//        printf("%02X\n",temp);
        return temp;
}

void polldisc()
{
        int temp;
        switch (discint)
        {
                case -3: /*End of command with interrupt*/
//                if (output) printf("EOC - interrupt!\n");
                picint(0x40);
                case -2: /*End of command*/
                fdc.stat=0x80;
                return;
                case -1: /*Reset*/
                picint(0x40);
                return;
                case 2: /*Read track*/
                if (!fdc.pos)
                {
//                        printf("Read Track Side %i Track %i Sector %02X sector size %i end sector %02X %05X\n",fdc.head,fdc.track,fdc.sector,fdc.params[4],fdc.params[5],(dma.page[2]<<16)+dma.ac[2]);
                }
                if (fdc.pos<512)
                {
                        fdc.dat=disc[fdc.drive][fdc.head][fdc.track[fdc.drive]][fdc.sector-1][fdc.pos];
//                        printf("Read %i %i %i %i %02X\n",fdc.head,fdc.track,fdc.sector,fdc.pos,fdc.dat);
                        writedma2(fdc.dat);
                        disctime=60;
                }
                else
                {
                        disctime=0;
                        discint=-2;
                        picint(0x40);
                        fdc.stat=0xD0;
                        fdc.res[0]=fdc.res[1]=fdc.res[2]=0;
                        fdc.res[3]=fdc.track[fdc.drive];
                        fdc.res[4]=fdc.head;
                        fdc.res[5]=fdc.sector;
                        fdc.res[6]=fdc.params[4];
                        paramstogo=7;
                        return;
                        disctime=1024;
                        picint(0x40);
                        fdc.stat=0xD0;
                        switch (fdc.pos-512)
                        {
                                case 0: case 1: case 2: fdc.dat=0; break;
                                case 3: fdc.dat=fdc.track[fdc.drive]; break;
                                case 4: fdc.dat=fdc.head; break;
                                case 5: fdc.dat=fdc.sector; break;
                                case 6: fdc.dat=fdc.params[4]; discint=-2; lastbyte=1; break;
                        }
                }
                fdc.pos++;
                if (fdc.pos==512 && fdc.params[5]!=1)
                {
                        fdc.pos=0;
                        fdc.sector++;
                        if (fdc.sector==SECTORS[fdc.drive]+1)
                        {
                                fdc.sector=1;
                        }
                        fdc.params[5]--;
                }
                return;
                case 3: /*Specify*/
                fdc.stat=0x80;
                return;
                case 4: /*Sense drive status*/
                fdc.dat=0x28;
                if (fdc.head) fdc.dat|=4;
                if (!fdc.track[fdc.drive]) fdc.dat|=0x10;
                if (fdc.drive) fdc.dat|=1;
                picint(0x40);
                fdc.stat=0xC0;
                discint=-2;
                disctime=1024;
                return;
                case 5: /*Write data*/
                discmodified[fdc.drive]=1;
//                printf("Write data %i\n",fdc.pos);
                if (!fdc.pos)
                {
//                        printf("Write data Side %i Track %i Sector %02X sector size %i end sector %02X\n",fdc.params[2],fdc.params[1],fdc.params[3],fdc.params[4],fdc.params[5]);
//                        dumpregs();
//                        exit(-1);
                }
                if (fdc.pos<512)
                {
                        temp=readdma2();
                        if (temp!=-1) fdc.dat=disc[fdc.drive][fdc.head][fdc.track[fdc.drive]][fdc.sector-1][fdc.pos]=temp;
//                        printf("Write data %i %i %02X\n",fdc.sector-1,fdc.pos,fdc.dat);
                        disctime=60;
                }
                else
                {
                        disctime=0;
                        discint=-2;
                        picint(0x40);
                        fdc.stat=0xD0;
                        fdc.res[0]=0;
                        fdc.res[1]=0;
                        fdc.res[2]=0;
                        fdc.res[3]=fdc.track[fdc.drive];
                        fdc.res[4]=fdc.head;
                        fdc.res[5]=fdc.sector;
                        fdc.res[6]=fdc.params[4];
                        paramstogo=7;
                        return;
                        disctime=1024;
                        picint(0x40);
                        fdc.stat=0xD0;
                        switch (fdc.pos-512)
                        {
                                case 0: fdc.dat=0x40; break;
                                case 1: fdc.dat=2; break;
                                case 2: fdc.dat=0; break;
                                case 3: fdc.dat=fdc.track[fdc.drive]; break;
                                case 4: fdc.dat=fdc.head; break;
                                case 5: fdc.dat=fdc.sector; break;
                                case 6: fdc.dat=fdc.params[4]; discint=-2; break;
                        }
                }
                fdc.pos++;
                if (fdc.pos==512 && fdc.sector!=fdc.params[5])
                {
                        fdc.pos=0;
                        fdc.sector++;
                }
                return;
                case 6: /*Read data*/
                if (!fdc.pos)
                {
//                        printf("Side %i Track %i Sector %02X sector size %i end sector %02X %05X\n",fdc.head,fdc.track[fdc.drive],fdc.sector,fdc.params[4],fdc.params[5],(dma.page[2]<<16)+dma.ac[2]);
                }
                if (fdc.pos<512)
                {
                        fdc.dat=disc[fdc.drive][fdc.head][fdc.track[fdc.drive]][fdc.sector-1][fdc.pos];
//                        printf("Read %i %i %i %i %02X  ",fdc.head,fdc.track,fdc.sector,fdc.pos,fdc.dat);
                        writedma2(fdc.dat);
                        disctime=60;
                }
                else
                {
//                        printf("End of command - params to go!\n");
                        disctime=0;
                        discint=-2;
                        picint(0x40);
                        fdc.stat=0xD0;
                        fdc.res[0]=fdc.res[1]=fdc.res[2]=0;
                        fdc.res[3]=fdc.track[fdc.drive];
                        fdc.res[4]=fdc.head;
                        fdc.res[5]=fdc.sector;
                        fdc.res[6]=fdc.params[4];
                        paramstogo=7;
                        return;
                        switch (fdc.pos-512)
                        {
                                case 0: case 1: case 2: fdc.dat=0; break;
                                case 3: fdc.dat=fdc.track[fdc.drive]; break;
                                case 4: fdc.dat=fdc.head; break;
                                case 5: fdc.dat=fdc.sector; break;
                                case 6: fdc.dat=fdc.params[4]; discint=-2; lastbyte=1; break;
                        }
                }
                fdc.pos++;
                if (fdc.pos==512 && fdc.sector!=fdc.params[5])
                {
//                        printf("Sector complete! %02X\n",fdc.params[5]);
                        fdc.pos=0;
                        fdc.sector++;
                        if (fdc.sector==SECTORS[fdc.drive]+1)
                        {
//                                printf("Overrunnit!\n");
//                                dumpregs();
//                                exit(-1);
                                fdc.sector=1;
                                if (fdc.command&0x80)
                                   fdc.head^=1;
                        }
                }
                return;
/*                printf("Read data\n");
                printf("Side %i Track %i Sector %i sector size %i\n",fdc.params[1],fdc.params[2],fdc.params[3],fdc.params[4]);
                dumpregs();
                exit(-1);*/
                case 7: /*Recalibrate*/
                fdc.track[fdc.drive]=0;
                fdc.st0=0x00|fdc.drive;
                discint=-3;
                disctime=2048;
                printf("Recalibrate complete!\n");
                return;
                case 8: /*Sense interrupt status*/
                if (TANDY || romset==ROM_AMI386 || romset==ROM_AMI486)
                {
//                if (!fdc.pos)
//                {
//                        fdc.pos=1;
                        fdc.dat=fdc.st0;//&0xFC)|fdc.lastdrive;
//                        printf("Returning status as drive %i\n",fdc.dat&3);
//                        fdc.st0=(fdc.st0&0xFC)|((fdc.st0+1)&3);
//                        if (fdc.lastdrive) fdc.dat|=1;
                        picint(0x40);
                        fdc.stat|=0xC0;
                        fdc.res[5]=fdc.st0;
                        fdc.res[6]=fdc.track[fdc.drive];
                        paramstogo=2;
                        discint=-2;
                        disctime=0;
                }
                else
                {
                        paramstogo=0;
                        if (!fdc.pos)
                        {
                                fdc.pos=1;
                                fdc.dat=fdc.st0;
//                        printf("Returning status as drive %i\n",fdc.dat&3);
                                fdc.st0=(fdc.st0&0xFC)|((fdc.st0+1)&3);
//                        if (fdc.lastdrive) fdc.dat|=1;
                                picint(0x40);
                                fdc.stat|=0xC0;
                                disctime=1024;
//                        if (fdc.dor&3) fdc.dat|=0xC0|(fdc.dor&3);
                                return;
                        }
                        fdc.dat=fdc.track[fdc.drive];
                        picint(0x40);
                        fdc.stat=0xC0;
                        discint=-2;
                        disctime=1024;
                        lastbyte=1;
                }
                return;
                case 10: /*Read sector ID*/
                switch (fdc.pos)
                {
                        case 0: fdc.dat=0; break;
                        case 1: fdc.dat=0; break;
                        case 2: fdc.dat=0; break;
                        case 3: fdc.dat=fdc.track[fdc.drive]; break;
                        case 4: fdc.dat=fdc.head; break;
                        case 5:
                        fdc.dat=fdc.sector;
                        fdc.sector++;
                        if (fdc.sector==SECTORS[fdc.drive]+1)
                           fdc.sector=1;
                        break;
                        case 6: fdc.dat=2; discint=-2; lastbyte=1; break;
                }
                disctime=1024;
                picint(0x40);
                fdc.stat=0xD0;
                fdc.pos++;
                return;
                case 15: /*Seek*/
                fdc.track[fdc.drive]=fdc.params[1];
//                printf("Seeked to track %i\n",fdc.track[fdc.drive]);
                fdc.st0=0x20|fdc.drive;
                discint=-3;
                disctime=2048;
                return;
                case 0x10: /*Invalid*/
                fdc.dat=fdc.st0=0x80;
                picint(0x40);
                fdc.stat|=0xC0;
                discint=-2;
                disctime=0;
                return;
        }
        printf("Bad FDC disc int %i\n",discint);
//        dumpregs();
//        exit(-1);
}
