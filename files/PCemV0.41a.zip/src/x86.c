/*SHR AX,1

        4 clocks - fetch opcode
        4 clocks - fetch mod/rm
        2 clocks - execute              2 clocks - fetch opcode 1
                                        2 clocks - fetch opcode 2
                                        4 clocks - fetch mod/rm
        2 clocks - fetch opcode 1       2 clocks - execute
        2 clocks - fetch opcode 2  etc*/
#include <stdio.h>
#include "ibm.h"
#include "x86.h"

int is8086=0;

int readlnum=0,writelnum=0;

int memcycs;
int nopageerrors=0;
float cassettetime;

unsigned char readmembl(unsigned long addr);
void writemembl(unsigned long addr, unsigned char val);
unsigned short readmemwl(unsigned long seg, unsigned long addr);
void writememwl(unsigned long seg, unsigned long addr, unsigned short val);
unsigned long readmemll(unsigned long seg, unsigned long addr);
void writememll(unsigned long seg, unsigned long addr, unsigned long val);

#undef readmemb
#undef readmemw
unsigned char readmemb(unsigned long a)
{
        if (a!=(cs+pc)) memcycs+=4;
        if (readlookup2[(a)>>12]==0xFFFFFFFF) return readmembl(a);
        else return ram[readlookup2[(a)>>12]+((a)&0xFFF)];
}

unsigned char readmembf(unsigned long a)
{
        if (readlookup2[(a)>>12]==0xFFFFFFFF) return readmembl(a);
        else return ram[readlookup2[(a)>>12]+((a)&0xFFF)];
}

unsigned short readmemw(unsigned long s, unsigned short a)
{
        if (a!=(cs+pc)) memcycs+=(8>>is8086);
        if ((readlookup2[((s)+(a))>>12]==0xFFFFFFFF || (s)==0xFFFFFFFF)) return readmemwl(s,a);
        else return *((unsigned short *)(&ram[readlookup2[((s)+(a))>>12]+(((s)+(a))&0xFFF)]));
}

void refreshread() { memcycs+=4; }

#undef fetchea
#define fetchea()   { rmdat=FETCH();  \
                    reg=(rmdat>>3)&7;             \
                    mod=rmdat>>6;                 \
                    rm=rmdat&7;                   \
                    if (mod!=3) fetcheal(); }

void writemembl(unsigned long addr, unsigned char val);
void writememb(unsigned long a, unsigned char v)
{
        memcycs+=4;
//        if (a>=(cs+pc) && a<(cs+pc+10)) printf("Self modifying %04X:%04X\n",CS,pc);
//        if (a==0x4D682) printf("Writeb %08X %02X %04X:%08X\n",a,v,CS,pc);
//        if (a==0x4D693) printf("Writeb %08X %02X %04X:%08X\n",a,v,CS,pc);
//        if (a==0x426330+0x6E08) printf("Writeb %08X %02X %04X:%08X\n",a,v,CS,pc);
//        if ((a&~3)==0xC13A1F94) printf("Writeb %08X %02X %04X:%08X\n",a,v,CS,pc);
        if (writelookup2[(a)>>12]==0xFFFFFFFF) writemembl(a,v);
        else ram[writelookup2[(a)>>12]+((a)&0xFFF)]=v;
}
void writememwl(unsigned long seg, unsigned long addr, unsigned short val);
void writememw(unsigned long s, unsigned long a, unsigned short v)
{
//        if (a==0xC01B218C) printf("Write %08X %08X %04X:%08X\n",a,v,CS,pc);
        memcycs+=(8>>is8086);
//        if ((s+a)==0x1C669) printf("Writew %08X %04X %04X:%08X\n",a,v,CS,pc);
//        if ((s+a)==0x4D693) printf("Writew %08X %04X %04X:%08X\n",a,v,CS,pc);
//        if (v==0x4157) printf("Write 4157 to %08X %08X %08X %04X:%08X\n",s,a,s+a,CS,pc);
//        if ((s+a)==0x426330+0x6E08) printf("Writew %08X %04X %04X:%08X\n",a,v,CS,pc);
//        if ((a&~3)==0xC13A1F94) printf("Writew %08X %04X %04X:%08X\n",a,v,CS,pc);
        if (writelookup2[((s)+(a))>>12]==0xFFFFFFFF || (s)==0xFFFFFFFF) writememwl(s,a,v);
        else *((unsigned short *)(&ram[writelookup2[((s)+(a))>>12]+(((s)+(a))&0xFFF)]))=v;
}
void writememll(unsigned long seg, unsigned long addr, unsigned long val);
void writememl(unsigned long s, unsigned long a, unsigned long v)
{
//        if (a==0xC01B218C) printf("Writel %08X %08X %04X:%08X\n",a,v,CS,pc);
//        if ((s+a)==0x426330+0x6E08) printf("Writel %08X %08X %04X:%08X\n",a,v,CS,pc);
//        if ((a&~3)==0xC13A1F94) printf("Writel %08X %08X %04X:%08X\n",a,v,CS,pc);
        if (writelookup2[((s)+(a))>>12]==0xFFFFFFFF || (s)==0xFFFFFFFF) writememll(s,a,v);
        else *((unsigned long *)(&ram[writelookup2[((s)+(a))>>12]+(((s)+(a))&0xFFF)]))=v;
}

unsigned char romext[32768];
int lldt=0;
int notpresent;
unsigned short oldflags;
void dumpregs();
int incga;
int hsync;
unsigned long old8,old82,old83;
unsigned short oldcs;
int oldcpl;

int dlE=0;
/*#define CS (cs>>4)
#define DS (ds>>4)
#define ES (es>>4)
#define SS (ss>>4)*/

//#define loadseg(a) ((a)<<4)

int keyboardtimer;
int tempc;
int bxcheck=0,spcheck=0;
unsigned short getword();
int count40=0;
int dosfunc;
unsigned char opcode;
int times=0;
unsigned short pc2,pc3;
int pit0=1;
int noint=0;
unsigned char cgamode,cgastat=0,cgacol;
int output=0;

int shadowbios=0;
int isram[256];
int inint=0;
int ins=0;
//#define readmemb(a) (((a)<0xA0000)?ram[a]:readmembl(a))

unsigned char *ram,*rom,*vram,*vrom;

int ssegs;
unsigned short biosmask;

int fetchcycles=0,memcycs,fetchclocks;

unsigned char prefetchqueue[6];
unsigned short prefetchpc;
int prefetchw=0;
inline unsigned char FETCH()
{
        unsigned char temp;
/*        temp=prefetchqueue[0];
        prefetchqueue[0]=prefetchqueue[1];
        prefetchqueue[1]=prefetchqueue[2];
        prefetchqueue[2]=prefetchqueue[3];
        prefetchqueue[3]=prefetchqueue[4];
        prefetchqueue[4]=prefetchqueue[5];
        if (prefetchw<=((is8086)?4:3))
        {
                prefetchqueue[prefetchw++]=readmembf(cs+prefetchpc); prefetchpc++;
                if (is8086 && (prefetchpc&1))
                {
                        prefetchqueue[prefetchw++]=readmembf(cs+prefetchpc); prefetchpc++;
                }
        }*/

//        unsigned char temp=readmemb(cs+pc);
//        if (output) printf("FETCH %04X %i\n",pc,fetchcycles);
        if (prefetchw==0) //(fetchcycles<4)
        {
                cycles-=(4-(fetchcycles&3));
                fetchclocks+=(4-(fetchcycles&3));
                fetchcycles=4;
                temp=readmembf(cs+pc);
                prefetchpc=pc=pc+1;
//                if (output) printf("   FETCH %04X:%04X %02X %04X %04X %i\n",CS,pc-1,temp,pc,prefetchpc,prefetchw);
                if (is8086 && (pc&1))
                {
                        prefetchqueue[0]=readmembf(cs+pc);
//                        if (output) printf("   PREFETCHED from %04X:%04X %02X 8086\n",CS,prefetchpc,prefetchqueue[prefetchw]);
                        prefetchpc++;
                        prefetchw++;
                }
        }
        else
        {
                temp=prefetchqueue[0];
                prefetchqueue[0]=prefetchqueue[1];
                prefetchqueue[1]=prefetchqueue[2];
                prefetchqueue[2]=prefetchqueue[3];
                prefetchqueue[3]=prefetchqueue[4];
                prefetchqueue[4]=prefetchqueue[5];
                prefetchw--;
//                if (output) printf("PREFETCH %04X:%04X %02X %04X %04X %i\n",CS,pc,temp,pc,prefetchpc,prefetchw);
                fetchcycles-=4;
//                fetchclocks+=4;
                pc++;
        }
//        if (output) printf("%i\n",fetchcycles);
        return temp;
}

inline void FETCHADD(int c)
{
        int d;
//        if (output) printf("FETCHADD %i\n",c);
        if (c<0) return;
        if (prefetchw>((is8086)?4:3)) return;
        d=c+(fetchcycles&3);
        while (d>3 && prefetchw<((is8086)?6:4))
        {
                d-=4;
                if (is8086 && !(prefetchpc&1))
                {
                        prefetchqueue[prefetchw]=readmembf(cs+prefetchpc);
//                        if (output) printf("PREFETCHED from %04X:%04X %02X 8086\n",CS,prefetchpc,prefetchqueue[prefetchw]);
                        prefetchpc++;
                        prefetchw++;
                }
                if (prefetchw<6)
                {
                        prefetchqueue[prefetchw]=readmembf(cs+prefetchpc);
//                        if (output) printf("PREFETCHED from %04X:%04X %02X\n",CS,prefetchpc,prefetchqueue[prefetchw]);
                        prefetchpc++;
                        prefetchw++;
                }
        }
        fetchcycles+=c;
        if (fetchcycles>16) fetchcycles=16;
//        if (fetchcycles>24) fetchcycles=24;
}

inline void FETCHCLEAR()
{
        int c;
        fetchcycles=0;
        prefetchpc=pc;
        if (is8086 && (prefetchpc&1)) cycles-=4;
        for (c=0;c<((is8086)?6:4);c++)
        {
                prefetchqueue[c]=readmembf(cs+prefetchpc);
                if (!is8086 || !(prefetchpc&1)) cycles-=4;
                prefetchpc++;
        }
        prefetchw=(is8086)?6:4;
}

/*EA calculation*/

/*R/M - bits 0-2 - R/M   bits 3-5 - Reg   bits 6-7 - mod
  From 386 programmers manual :
r8(/r)                     AL    CL    DL    BL    AH    CH    DH    BH
r16(/r)                    AX    CX    DX    BX    SP    BP    SI    DI
r32(/r)                    EAX   ECX   EDX   EBX   ESP   EBP   ESI   EDI
/digit (Opcode)            0     1     2     3     4     5     6     7
REG =                      000   001   010   011   100   101   110   111
  ����Address
disp8 denotes an 8-bit displacement following the ModR/M byte, to be
sign-extended and added to the index. disp16 denotes a 16-bit displacement
following the ModR/M byte, to be added to the index. Default segment
register is SS for the effective addresses containing a BP index, DS for
other effective addresses.
            �Ŀ �Mod R/M� ���������ModR/M Values in Hexadecimal�������Ŀ

[BX + SI]            000   00    08    10    18    20    28    30    38
[BX + DI]            001   01    09    11    19    21    29    31    39
[BP + SI]            010   02    0A    12    1A    22    2A    32    3A
[BP + DI]            011   03    0B    13    1B    23    2B    33    3B
[SI]             00  100   04    0C    14    1C    24    2C    34    3C
[DI]                 101   05    0D    15    1D    25    2D    35    3D
disp16               110   06    0E    16    1E    26    2E    36    3E
[BX]                 111   07    0F    17    1F    27    2F    37    3F

[BX+SI]+disp8        000   40    48    50    58    60    68    70    78
[BX+DI]+disp8        001   41    49    51    59    61    69    71    79
[BP+SI]+disp8        010   42    4A    52    5A    62    6A    72    7A
[BP+DI]+disp8        011   43    4B    53    5B    63    6B    73    7B
[SI]+disp8       01  100   44    4C    54    5C    64    6C    74    7C
[DI]+disp8           101   45    4D    55    5D    65    6D    75    7D
[BP]+disp8           110   46    4E    56    5E    66    6E    76    7E
[BX]+disp8           111   47    4F    57    5F    67    6F    77    7F

[BX+SI]+disp16       000   80    88    90    98    A0    A8    B0    B8
[BX+DI]+disp16       001   81    89    91    99    A1    A9    B1    B9
[BX+SI]+disp16       010   82    8A    92    9A    A2    AA    B2    BA
[BX+DI]+disp16       011   83    8B    93    9B    A3    AB    B3    BB
[SI]+disp16      10  100   84    8C    94    9C    A4    AC    B4    BC
[DI]+disp16          101   85    8D    95    9D    A5    AD    B5    BD
[BP]+disp16          110   86    8E    96    9E    A6    AE    B6    BE
[BX]+disp16          111   87    8F    97    9F    A7    AF    B7    BF

EAX/AX/AL            000   C0    C8    D0    D8    E0    E8    F0    F8
ECX/CX/CL            001   C1    C9    D1    D9    E1    E9    F1    F9
EDX/DX/DL            010   C2    CA    D2    DA    E2    EA    F2    FA
EBX/BX/BL            011   C3    CB    D3    DB    E3    EB    F3    FB
ESP/SP/AH        11  100   C4    CC    D4    DC    E4    EC    F4    FC
EBP/BP/CH            101   C5    CD    D5    DD    E5    ED    F5    FD
ESI/SI/DH            110   C6    CE    D6    DE    E6    EE    F6    FE
EDI/DI/BH            111   C7    CF    D7    DF    E7    EF    F7    FF

mod = 11 - register
      10 - address + 16 bit displacement
      01 - address + 8 bit displacement
      00 - address

reg = If mod=11,  (depending on data size, 16 bits/8 bits, 32 bits=extend 16 bit registers)
      0=AX/AL   1=CX/CL   2=DX/DL   3=BX/BL
      4=SP/AH   5=BP/CH   6=SI/DH   7=DI/BH

      Otherwise, LSB selects SI/DI (0=SI), NMSB selects BX/BP (0=BX), and MSB
      selects whether BX/BP are used at all (0=used).

      mod=00 is an exception though
      6=16 bit displacement only
      7=[BX]

      Usage varies with instructions.

      MOV AL,BL has ModR/M as C3, for example.
      mod=11, reg=0, r/m=3
      MOV uses reg as dest, and r/m as src.
      reg 0 is AL, reg 3 is BL

      If BP or SP are in address calc, seg is SS, else DS
*/

int cycles=0;
unsigned long easeg,eaaddr;
int rm,reg,mod,rmdat;

unsigned short zero=0;
unsigned short *mod1add[2][8];
unsigned long *mod1seg[8];

int slowrm[8];

void makemod1table()
{
        mod1add[0][0]=&BX; mod1add[0][1]=&BX; mod1add[0][2]=&BP; mod1add[0][3]=&BP;
        mod1add[0][4]=&SI; mod1add[0][5]=&DI; mod1add[0][6]=&BP; mod1add[0][7]=&BX;
        mod1add[1][0]=&SI; mod1add[1][1]=&DI; mod1add[1][2]=&SI; mod1add[1][3]=&DI;
        mod1add[1][4]=&zero; mod1add[1][5]=&zero; mod1add[1][6]=&zero; mod1add[1][7]=&zero;
        slowrm[0]=0; slowrm[1]=1; slowrm[2]=1; slowrm[3]=0;
        mod1seg[0]=&ds; mod1seg[1]=&ds; mod1seg[2]=&ss; mod1seg[3]=&ss;
        mod1seg[4]=&ds; mod1seg[5]=&ds; mod1seg[6]=&ss; mod1seg[7]=&ds;
}

void fetcheal()
{
        if (!mod && rm==6) { eaaddr=getword(); easeg=ds; FETCHADD(6); }
        else
        {
                switch (mod)
                {
                        case 0:
                        eaaddr=0;
                        if (rm&4) FETCHADD(5);
                        else      FETCHADD(7+slowrm[rm]);
                        break;
                        case 1:
                        eaaddr=(unsigned short)(signed char)FETCH();
                        if (rm&4) FETCHADD(9);
                        else      FETCHADD(11+slowrm[rm]);
                        break;
                        case 2:
                        eaaddr=getword();
                        if (rm&4) FETCHADD(9);
                        else      FETCHADD(11+slowrm[rm]);
                        break;
                }
                eaaddr+=(*mod1add[0][rm])+(*mod1add[1][rm]);
                easeg=*mod1seg[rm];
                eaaddr&=0xFFFF;
        }
}

/*void fetchea()
{
        rmdat=readmemb(cs+pc); pc++;
        reg=(rmdat>>3)&7;
        mod=rmdat>>6;
        rm=rmdat&7;
        switch (mod)
        {
                case 0:
                switch (rm)
                {
                        case 0: eaaddr=BX+SI; easeg=ds; if (!AT) cycles-=7; break;
                        case 1: eaaddr=BX+DI; easeg=ds; if (!AT) cycles-=8; break;
                        case 2: eaaddr=BP+SI; easeg=ss; if (!AT) cycles-=8; break;
                        case 3: eaaddr=BP+DI; easeg=ss; if (!AT) cycles-=7; break;
                        case 4: eaaddr=SI; easeg=ds; if (!AT) cycles-=5; break;
                        case 5: eaaddr=DI; easeg=ds; if (!AT) cycles-=5; break;
                        case 6: eaaddr=getword(); easeg=ds; if (!AT) cycles-=6; break;
                        case 7: eaaddr=BX; easeg=ds; if (!AT) cycles-=5; break;
                }
                if (AT && !(rm&4)) cycles--;
                break;

                case 1:
                eaaddr=readmemb(cs+pc); pc++;
                if (eaaddr&0x80) eaaddr|=0xFF00;
//                if (output) printf("EAADDR %04X ",eaaddr);
                switch (rm)
                {
                        case 0: eaaddr+=BX+SI; easeg=ds; if (!AT) cycles-=11; break;
                        case 1: eaaddr+=BX+DI; easeg=ds; if (!AT) cycles-=12; break;
                        case 2: eaaddr+=BP+SI; easeg=ss; if (!AT) cycles-=12; break;
                        case 3: eaaddr+=BP+DI; easeg=ss; if (!AT) cycles-=11; break;
                        case 4: eaaddr+=SI; easeg=ds; if (!AT) cycles-=9; break;
                        case 5: eaaddr+=DI; easeg=ds; if (!AT) cycles-=9; break;
                        case 6: eaaddr+=BP; easeg=ss; if (!AT) cycles-=9; break;
                        case 7: eaaddr+=BX; easeg=ds; if (!AT) cycles-=9; break;
                }
                if (AT && !(rm&4)) cycles--;
//                if (output) printf("%04X %04X",eaaddr,BX);
                break;

                case 2:
                eaaddr=getword();
                switch (rm)
                {
                        case 0: eaaddr+=BX+SI; easeg=ds; if (!AT) cycles-=11; break;
                        case 1: eaaddr+=BX+DI; easeg=ds; if (!AT) cycles-=12; break;
                        case 2: eaaddr+=BP+SI; easeg=ss; if (!AT) cycles-=12; break;
                        case 3: eaaddr+=BP+DI; easeg=ss; if (!AT) cycles-=11; break;
                        case 4: eaaddr+=SI; easeg=ds; if (!AT) cycles-=9; break;
                        case 5: eaaddr+=DI; easeg=ds; if (!AT) cycles-=9; break;
                        case 6: eaaddr+=BP; easeg=ss; if (!AT) cycles-=9; break;
                        case 7: eaaddr+=BX; easeg=ds; if (!AT) cycles-=9; break;
                }
                if (AT && !(rm&4)) cycles--;
                break;
        }
        eaaddr&=0xFFFF;
}*/

static inline unsigned char geteab()
{
        if (mod==3)
           return (rm&4)?regs[rm&3].b.h:regs[rm&3].b.l;
        cycles-=3;
        return readmemb(easeg+eaaddr);
}

static inline unsigned short geteaw()
{
        if (mod==3)
           return regs[rm].w;
        cycles-=3;
//        if (output==3) printf("GETEAW %04X:%08X\n",easeg,eaaddr);
        return readmemw(easeg,eaaddr);
}

static inline unsigned short geteaw2()
{
        if (mod==3)
           return regs[rm].w;
        cycles-=2;
//        printf("Getting addr from %04X:%04X %05X\n",easeg,eaaddr+2,easeg+eaaddr+2);
        return readmemw(easeg,(eaaddr+2)&0xFFFF);
}

static inline void seteab(unsigned char val)
{
        if (mod==3)
        {
                if (rm&4) regs[rm&3].b.h=val;
                else      regs[rm&3].b.l=val;
        }
        else
        {
                cycles-=2;
                writememb(easeg+eaaddr,val);
        }
}

static inline void seteaw(unsigned short val)
{
        if (mod==3)
           regs[rm].w=val;
        else
        {
                cycles-=2;
                writememw(easeg,eaaddr,val);
//                writememb(easeg+eaaddr+1,val>>8);
        }
}

#define getr8(r)   ((r&4)?regs[r&3].b.h:regs[r&3].b.l)

#define setr8(r,v) if (r&4) regs[r&3].b.h=v; \
                   else     regs[r&3].b.l=v;


/*Flags*/
unsigned char znptable8[256];
unsigned short znptable16[65536];

void makeznptable()
{
        int c,d;
        for (c=0;c<256;c++)
        {
                d=0;
                if (c&1) d++;
                if (c&2) d++;
                if (c&4) d++;
                if (c&8) d++;
                if (c&16) d++;
                if (c&32) d++;
                if (c&64) d++;
                if (c&128) d++;
                if (d&1)
                   znptable8[c]=0;
                else
                   znptable8[c]=P_FLAG;
                if (!c) znptable8[c]|=Z_FLAG;
                if (c&0x80) znptable8[c]|=N_FLAG;
        }
        for (c=0;c<65536;c++)
        {
                d=0;
                if (c&1) d++;
                if (c&2) d++;
                if (c&4) d++;
                if (c&8) d++;
                if (c&16) d++;
                if (c&32) d++;
                if (c&64) d++;
                if (c&128) d++;
                if (d&1)
                   znptable16[c]=0;
                else
                   znptable16[c]=P_FLAG;
                if (!c) znptable16[c]|=Z_FLAG;
                if (c&0x8000) znptable16[c]|=N_FLAG;
      }
      for (c=0;c<256;c++) isram[c]=0;
      for (c=0;c</*0x80*//*0x40*/0x80;c++)
      {
                isram[c]=1;
                if (c>=0xA && c<=0xF) isram[c]=0;
        }
//        printf("isram 0 = %i\n",isram[0]);
      
//      makemod1table();
}
int timetolive=0;

unsigned long mmucache[0x100000];
int mmucaches[64];
int mmunext=0;
int abrt=0;

void initmmucache()
{
        int c;
        memset(mmucache,0xFF,sizeof(mmucache));
        for (c=0;c<64;c++) mmucaches[c]=0xFFFFFFFF;
        mmunext=0;
}

void resetreadlookup()
{
        int c;
        memset(readlookup2,0xFF,1024*1024*4);
        for (c=0;c<64;c++) readlookup[c]=0xFFFFFFFF;
        readlnext=0;
        memset(writelookup2,0xFF,1024*1024*4);
        for (c=0;c<64;c++) writelookup[c]=0xFFFFFFFF;
        writelnext=0;
        pccache=0xFFFFFFFF;
        readlnum=writelnum=0;
}

void flushmmucache()
{
        int c;
        for (c=0;c<64;c++)
        {
                if (readlookup[c]!=0xFFFFFFFF)
                {
                        readlookup2[readlookup[c]]=0xFFFFFFFF;
                        readlookup[c]=0xFFFFFFFF;
                }
                if (writelookup[c]!=0xFFFFFFFF)
                {
                        writelookup2[writelookup[c]]=0xFFFFFFFF;
                        writelookup[c]=0xFFFFFFFF;
                }
        }
        readlnum=writelnum=0;
        pccache=pccache2=0xFFFFFFFF;
/*        if (!(cr0>>31)) return;
        for (c=0;c<64;c++)
        {
                if (mmucaches[c]!=0xFFFFFFFF)
                {
                        mmucache[mmucaches[c]]=0xFFFFFFFF;
                        mmucaches[c]=0xFFFFFFFF;
                }
        }*/
}

#define mmutranslate(addr,rw) mmutranslatereal(addr,rw)
//#define mmutranslate(addr,rw) ((mmucache[addr>>12]!=0xFFFFFFFF)?(mmucache[addr>>12]+(addr&0xFFF)):mmutranslatereal(addr,rw))
unsigned long mmutranslatereal(unsigned long addr, int rw)
{
        int mmuout=0;
        unsigned long addr2;
//        int mmuoutput=(addr==0x80004068);
        unsigned long temp,temp2;
//        if ((addr>>12)==0x101) mmuout=1;
//        if (!output) mmuout=0;
//        if (mmuout) pclog("MMU translating %08X for %s\n",addr,(rw)?"write":"read");
//        if (mmucache[addr>>12]!=0xFFFFFFFF)
//           return mmucache[addr>>12]+(addr&0xFFF);
        addr2=(cr3+((addr>>20)&0xFFC));
//        if (!nopageerrors && mmuout) pclog("Translate %08X %08X   ",addr,addr2);
//        if (addr==0x22F6E) output++;
        temp=temp2=((unsigned long *)ram)[addr2>>2];
//        if (mmuout && !nopageerrors) pclog("%08X\n",temp);
        if (!(temp&1))
        {
//                if (mmuout || output==3) pclog("Section not present! %08X  %08X\n",addr,temp);
//                /*if (!nopageerrors) */printf("Section not present %08X! %08X %08X %08X %i  %02X  %08X %08X %08X\n",addr,cs,pc,addr2,output,opcode,  es,EDI,EAX);
//                dumpregs();
//                exit(-1);
//                pc=startpc;
                cr2=addr;
                temp=0;
                if (CS&3) temp|=4;
                if (rw) temp|=2;
                abrt=1|(temp<<8);
    //            dumpregs();
//                exit(-1);
//                exit(-1);
                return -1;
        }
//        if ((mmuout && !nopageerrors) || output==3) pclog("Loading descriptor from %08X  ",((temp&~0xFFF)+((addr>>10)&0xFFC)));
        temp=((unsigned long *)ram)[((temp&~0xFFF)+((addr>>10)&0xFFC))>>2];
//        if ((mmuout && !nopageerrors) || output==3) pclog("%08X\n",temp);
        if (!(temp&1))
        {
//                if (mmuout || output==3) pclog("Page not present!  %08X   %08X   %02X  %04X:%08X\n",addr,temp,opcode,CS,pc);
//                dumpregs();
//                exit(-1);
//                /*if (!nopageerrors)*/ printf("Page not present! %08X %08X\n",addr,temp);
                cr2=addr;
                temp=0;
                if (CS&3) temp|=4;
                if (rw) temp|=2;
                abrt=1|(temp<<8);
//                dumpregs();
//                exit(-1);
                return -1;
        }
        if (mmucaches[mmunext]!=0xFFFFFFFF)
           mmucache[mmucaches[mmunext]]=0xFFFFFFFF;
        mmucache[addr>>12]=temp&~0xFFF;
        mmucaches[mmunext++]=addr>>12;
        mmunext&=63;
//        if ((mmuout && !nopageerrors) || output==3) pclog("Translates to %08X %08X\n",(temp&~0xFFF)+(addr&0xFFF),temp2);
        ((unsigned long *)ram)[((temp2&~0xFFF)+((addr>>10)&0xFFC))>>2]|=0x60;
        return (temp&~0xFFF)+(addr&0xFFF);
}

unsigned char *getpccache(unsigned long a)
{
//        int logit=(a>0xFFFFF);
        unsigned long a2=a;
        if (cr0>>31)
        {
//                if (output==3) pclog("Translate GetPCCache %08X\n",a);
                a=mmutranslate(a,0);
//                if (output==3) pclog("GetPCCache output %08X\n",a);
                if (a==0xFFFFFFFF)
                {
                        printf("Bad getpccache %08X\n",a);
                        dumpregs();
                        exit(-1);
                }
        }
//        if (logit) printf("PCCACHE - %08X -> %08X\n",a2,a);
        switch ((a>>16)&0xFF)
        {
                case 0x00: case 0x01: case 0x02: case 0x03:
                case 0x04: case 0x05: case 0x06: case 0x07:
                case 0x08: case 0x09: 
                case 0x10: case 0x11: case 0x12: case 0x13:
                case 0x14: case 0x15: case 0x16: case 0x17:
                case 0x18: case 0x19: case 0x1A: case 0x1B:
                case 0x1C: case 0x1D: case 0x1E: case 0x1F:
                case 0x20: case 0x21: case 0x22: case 0x23:
                case 0x24: case 0x25: case 0x26: case 0x27:
                case 0x28: case 0x29: case 0x2A: case 0x2B:
                case 0x2C: case 0x2D: case 0x2E: case 0x2F:
                case 0x30: case 0x31: case 0x32: case 0x33:
                case 0x34: case 0x35: case 0x36: case 0x37:
                case 0x38: case 0x39: case 0x3A: case 0x3B:
                case 0x3C: case 0x3D: case 0x3E: case 0x3F:
                case 0x40: case 0x41: case 0x42: case 0x43:
                case 0x44: case 0x45: case 0x46: case 0x47:
                case 0x48: case 0x49: case 0x4A: case 0x4B:
                case 0x4C: case 0x4D: case 0x4E: case 0x4F:
                case 0x50: case 0x51: case 0x52: case 0x53:
                case 0x54: case 0x55: case 0x56: case 0x57:
                case 0x58: case 0x59: case 0x5A: case 0x5B:
                case 0x5C: case 0x5D: case 0x5E: case 0x5F:
                case 0x60: case 0x61: case 0x62: case 0x63:
                case 0x64: case 0x65: case 0x66: case 0x67:
                case 0x68: case 0x69: case 0x6A: case 0x6B:
                case 0x6C: case 0x6D: case 0x6E: case 0x6F:
                case 0x70: case 0x71: case 0x72: case 0x73:
                case 0x74: case 0x75: case 0x76: case 0x77:
                case 0x78: case 0x79: case 0x7A: case 0x7B:
                case 0x7C: case 0x7D: case 0x7E: case 0x7F:
                return &ram[(a&0x7FF000)-(a2&~0xFFF)];
                case 0xC: if (a&0x8000) return &romext[(a&0x7000)-(a2&~0xFFF)];
                return &vrom[(a&0x7000)-(a2&~0xFFF)];
                case 0xF: return &rom[(a&0xF000)-(a2&~0xFFF)];
        }
                        printf("Bad getpccache %08X\n",a);
                        dumpregs();
                        exit(-1);
}

void addreadlookup(unsigned long virt, unsigned long phys)
{
//        return;
//        printf("Addreadlookup %08X %08X %08X %08X %08X %08X %02X %08X\n",virt,phys,cs,ds,es,ss,opcode,pc);
        if (readlookup2[virt>>12]!=0xFFFFFFFF) return;
        readlnum++;
        if (readlookup[readlnext]!=0xFFFFFFFF)
        {
                readlookup2[readlookup[readlnext]]=0xFFFFFFFF;
                readlnum--;
        }
        readlookup2[virt>>12]=phys&~0xFFF;
        readlookup[readlnext++]=virt>>12;
        readlnext&=63;
}

void addwritelookup(unsigned long virt, unsigned long phys)
{
//        return;
//        printf("Addwritelookup %08X %08X\n",virt,phys);
        if (writelookup2[virt>>12]!=0xFFFFFFFF) return;
        writelnum++;
        if (writelookup[writelnext]!=0xFFFFFFFF)
        {
                writelookup2[writelookup[writelnext]]=0xFFFFFFFF;
                writelnum--;
        }
        writelookup2[virt>>12]=phys&~0xFFF;
        writelookup[writelnext++]=virt>>12;
        writelnext&=63;
}

unsigned char readmembl(unsigned long addr)
{
        unsigned long addr2=addr;
//        if (addr>0x800000) printf("1readmembl > %08X\n",addr);
        if (cr0>>31)
        {
//                if (output==3) pclog("Translate readmembl %08X\n",addr2);
                addr2=mmutranslate(addr,0);
                if (addr2==0xFFFFFFFF) return 0xFF;
        }
//        if ((addr2&0xFF0000)!=0xF0000) printf("Checking - %08X %08X %i\n",addr2&rammask,(addr2&rammask)>>16,isram[(addr2&rammask)>>16]);
        if (isram[(addr2&rammask)>>16])
        {
                addreadlookup(addr,addr2&rammask);
                return ram[addr2&rammask];
        }
//        if (addr>0x800000) printf("readmembl > %08X\n",addr);
//        if ((cs&0xFFFFF0)!=0xF0000 && (cs&0xFFFFF0)!=0xC0000) printf("READMEMBL %08X\n",addr);
        addr=addr2&rammask;
        switch ((addr>>16)&0xFF)
        {
                case 0: case 1: case 2: case 3: case 4:
                case 5: case 6: case 7: case 8: case 9:
                return ram[addr];
                case 10: if (EGA) return readega(addr);
                if (slowega) cycles-=egacycles;
                return 0xFF;
                case 11:
                if (slowega && EGA) cycles-=egacycles;
                if (addr&0x8000 && MDA)
                {
                        if (!HERCULES) return 0xFF;
                        if (!(hercctrl&2)) return 0xFF;
                }
                if (AMSTRAD && incga) return readvram(addr);
                if (AMSTRAD || EGA) return readega(addr&0x7FFF);
                if (TANDY) return readtandyvram(addr);
                return readvram(addr&0xFFFF);
//                return vram[addr&0xFFFF];
                case 12: if (addr&0x8000)
                {
//                        printf("Read extrom %04X:%04X %04X %02X %02X\n",CS,pc,addr,romext[addr&0x7FFF],AL);
                        return romext[addr&0x7FFF];
                }
//                return 0x63;
                return vrom[addr&0x7FFF];
                case 13: if (romset==ROM_AMI286) return readems(addr); return 0xFF;
                case 14: if (shadowbios) { /*printf("Read shadow RAM %08X %02X\n",addr,ram[addr]);*/ return ram[addr]; }
                case 15: if (!shadowbios) return rom[addr&biosmask];
//                printf("Read shadow RAM %08X %02X\n",addr,ram[addr]);
                return ram[addr];
                case 0x10: case 0x11: case 0x12: case 0x13:
                case 0x14: case 0x15: case 0x16: case 0x17:
                case 0x18: case 0x19: case 0x1A: case 0x1B:
                case 0x1C: case 0x1D: case 0x1E: case 0x1F:
                case 0x20: case 0x21: case 0x22: case 0x23:
                case 0x24: case 0x25: case 0x26: case 0x27:
                case 0x28: case 0x29: case 0x2A: case 0x2B:
                case 0x2C: case 0x2D: case 0x2E: case 0x2F:
                case 0x30: case 0x31: case 0x32: case 0x33:
                case 0x34: case 0x35: case 0x36: case 0x37:
                case 0x38: case 0x39: case 0x3A: case 0x3B:
                case 0x3C: case 0x3D: case 0x3E: case 0x3F:
                case 0x40: case 0x41: case 0x42: case 0x43:
                case 0x44: case 0x45: case 0x46: case 0x47:
                case 0x48: case 0x49: case 0x4A: case 0x4B:
                case 0x4C: case 0x4D: case 0x4E: case 0x4F:
                case 0x50: case 0x51: case 0x52: case 0x53:
                case 0x54: case 0x55: case 0x56: case 0x57:
                case 0x58: case 0x59: case 0x5A: case 0x5B:
                case 0x5C: case 0x5D: case 0x5E: case 0x5F:
                case 0x60: case 0x61: case 0x62: case 0x63:
                case 0x64: case 0x65: case 0x66: case 0x67:
                case 0x68: case 0x69: case 0x6A: case 0x6B:
                case 0x6C: case 0x6D: case 0x6E: case 0x6F:
                case 0x70: case 0x71: case 0x72: case 0x73:
                case 0x74: case 0x75: case 0x76: case 0x77:
                case 0x78: case 0x79: case 0x7A: case 0x7B:
                case 0x7C: case 0x7D: case 0x7E: case 0x7F:
//                if (cs!=0xF0000) printf("Read high mem %06X %04X:%04X\n",addr,CS,pc);
                return ram[addr];
                case 0xFF: return rom[addr&biosmask];
        }
/*        if (addr>0x801000 && addr<0xFC0000)
        {
                printf("Readb from bad address %08X!\n",addr);
                dumpregs();
                exit(-1);
        }*/
        return 0xFF;
}

unsigned char cpu_readop(unsigned long addr) { return readmemb(addr); }
unsigned char cpu_readmem20(unsigned long addr) { return readmemb(addr); }

void writemembl(unsigned long addr, unsigned char val)
{
        unsigned long addr2=addr;
//        printf("Writemem %08X %02X\n",addr,val);
//        if (addr==(0xA4BE)+0x100) printf("Write A4BE %02X %04X(%06X):%04X\n",val,CS,cs,pc);
//        if (addr==0x2A60+0x8C2 || addr==0x2A60+0x8C3) printf("Writememb %05X %02X %04X(%06X):%04X\n",addr,val,cs,CS,pc);
//        if (addr==0x12DC58) printf("Writememb %05X %02X %04X(%06X):%04X\n",addr,val,cs,CS,pc);
//        if ((addr&~3)==0xC01D59E8) printf("Writeb C01D59E8+%i %08X %04X:%08X\n",addr&3,val,CS,pc);
        if (cr0>>31)
        {
//                if (output==3) pclog("Translate writemembl %08X\n",addr2);
                addr2=mmutranslate(addr,1);
                if (addr2==0xFFFFFFFF) return;
//                if (addr2==0x158138) printf("Writemembl %02X %08X\n",val,addr);
        }
//        if (addr2==0x158138) printf("Writemembl %02X %08X %i\n",val,addr2,cr0>>31);
        if (isram[(addr2&rammask)>>16])
        {
                addwritelookup(addr,addr2&rammask);
        }
        addr=addr2&rammask;
        switch ((addr>>16)&0xFF)
        {
                case 0: case 1: case 2: case 3: case 4:
                case 5: case 6: case 7: case 8: case 9:
//                        printf("Writemem %05X %02X %04X:%04X\n",addr,val,cs>>4,pc);
                ram[addr]=val;
                return;
                case 10: if (EGA) writeega(addr,val);
                if (slowega) cycles-=egacycles;
//                printf("VRAM write %05X %02X %04X:%04X %c\n",addr,val,cs>>4,pc,val);
                return;
                case 11:
                if (slowega && EGA) cycles-=egacycles;
//                printf("x86 VRAM write %05X %02X %04X:%04X %c\n",addr,val,cs>>4,pc,val);
                if (AMSTRAD && incga) writevram(addr,val);
                else if ((AMSTRAD || EGA) && ((gdcreg[6]&0xC)==0xC)) writeega(addr&0x7FFF,val);
                else if (TANDY) writetandyvram(addr,val);
                else            writevramgen(addr,val);//vram[addr&0xFFFF]=val;
                return;
                case 13: if (romset==ROM_AMI286) writeems(addr,val); return;
                case 15: if (shadowbios) return;
                case 14: //printf("Write %08X %02X\n",addr,val); //ram[addr]=val;
                case 0x10: case 0x11: case 0x12: case 0x13:
                case 0x14: case 0x15: case 0x16: case 0x17:
                case 0x18: case 0x19: case 0x1A: case 0x1B:
                case 0x1C: case 0x1D: case 0x1E: case 0x1F:
                case 0x20: case 0x21: case 0x22: case 0x23:
                case 0x24: case 0x25: case 0x26: case 0x27:
                case 0x28: case 0x29: case 0x2A: case 0x2B:
                case 0x2C: case 0x2D: case 0x2E: case 0x2F:
                case 0x30: case 0x31: case 0x32: case 0x33:
                case 0x34: case 0x35: case 0x36: case 0x37:
                case 0x38: case 0x39: case 0x3A: case 0x3B:
                case 0x3C: case 0x3D: case 0x3E: case 0x3F:
                case 0x40: case 0x41: case 0x42: case 0x43:
                case 0x44: case 0x45: case 0x46: case 0x47:
                case 0x48: case 0x49: case 0x4A: case 0x4B:
                case 0x4C: case 0x4D: case 0x4E: case 0x4F:
                case 0x50: case 0x51: case 0x52: case 0x53:
                case 0x54: case 0x55: case 0x56: case 0x57:
                case 0x58: case 0x59: case 0x5A: case 0x5B:
                case 0x5C: case 0x5D: case 0x5E: case 0x5F:
                case 0x60: case 0x61: case 0x62: case 0x63:
                case 0x64: case 0x65: case 0x66: case 0x67:
                case 0x68: case 0x69: case 0x6A: case 0x6B:
                case 0x6C: case 0x6D: case 0x6E: case 0x6F:
                case 0x70: case 0x71: case 0x72: case 0x73:
                case 0x74: case 0x75: case 0x76: case 0x77:
                case 0x78: case 0x79: case 0x7A: case 0x7B:
                case 0x7C: case 0x7D: case 0x7E: case 0x7F:
//                if (cs!=0xF0000) printf("Write high mem %06X %04X:%04X\n",addr,CS,pc);
                ram[addr]=val;
                return;
        }
/*        if (addr>0x801000 && addr<0xFC0000)
        {
                printf("Writeb to bad address %08X %02X!\n",addr,val);
                dumpregs();
                exit(-1);
        }*/
//        printf("Bad write addr %05X %02X\n",addr,val);
}

void cpu_writemem20(unsigned long addr, unsigned char val) { writememb(addr,val); }

unsigned short readmemwl(unsigned long seg, unsigned long addr)
{
        unsigned long addr2=seg+addr;
        if (seg==-1)
        {
                printf("NULL segment!\n");
                dumpregs();
                exit(-1);
        }
        if (cr0>>31)
        {
//                if (output==3) pclog("Translate readmemwl %08X:%08X %08X\n",seg,addr,addr2);
                addr2=mmutranslate(addr2,0);
                if (addr2==0xFFFFFFFF) return 0xFFFF;
        }
//        if (addr2>0x800000) printf("Readmemwl %08X:%08X %08X\n",seg,addr,rammask);
        if (isram[(addr2&rammask)>>16])
        {
                addreadlookup(seg+addr,addr2&rammask);
//                if (*(unsigned short *)(&ram[addr2&rammask])==0x4157) printf("Read 4157 %08X %08X\n",addr2,rammask);
                return *(unsigned short *)(&ram[addr2&rammask]);
        }
//        if (addr2>0x800000) printf("Not isram Readmemwl %08X:%08X\n",seg,addr);
//        if (isram[(addr2>>16)&255])
//           return *(unsigned short *)(&ram[addr2&0xFFFFFF]);
        if (!cpuspeed) cycles-=4;
        if (slowega && EGA && ((seg+addr)&0xFE0000)==0xA0000) cycles+=egacycles;
//        printf("Reading %08X %08X\n",seg+addr,readlookup2[(seg+addr)>>12]);
//        if (addr==0x2DADE) printf("Read 2DADE\n");
        if (AT) return readmemb(seg+addr)|(readmemb(seg+addr+1)<<8);
        return readmemb(seg+addr)|(readmemb(seg+((addr+1)&0xFFFF))<<8);
}

void writememwl(unsigned long seg, unsigned long addr, unsigned short val)
{
        unsigned long addr2=seg+addr;
//        if ((addr&~3)==0xC01D59E8) printf("Writeb C01D59E8+%i %08X %04X:%08X\n",addr&3,val,CS,pc);
        if (seg==-1)
        {
                printf("NULL segment!\n");
                dumpregs();
                exit(-1);
        }
        if (cr0>>31)
        {
//                if (output==3) pclog("Translate writememwl %08X:%08X %08X\n",seg,addr,addr2);
//                if (val==0x4157) printf("Translate %08X to ",addr2);
                addr2=mmutranslate(addr2,1);
//                if (val==0x4157) printf("%08X\n",addr2);
                if (addr2==0xFFFFFFFF) return;
        }
//        if (addr2==0x158138) printf("Writememwl %04X %08X %i\n",val,addr2,cr0>>31);
        if (isram[(addr2&rammask)>>16])
        {
                addwritelookup(seg+addr,addr2&rammask);
                *(unsigned short *)(&ram[addr2&rammask])=val;
                return;
        }
        if (slowega && EGA && ((seg+addr)&0xFE0000)==0xA0000) cycles+=egacycles;
        if (!cpuspeed) cycles-=4;
        writememb(seg+addr,val);
        if (AT) { writememb(seg+addr+1,val>>8); }
        else    { writememb(seg+((addr+1)&0xFFFF),val>>8); }
}

unsigned long readmemll(unsigned long seg, unsigned long addr)
{
        unsigned long temp;
        unsigned long addr2=seg+addr;
//        if (output==3) printf("Readmeml from %08X:%08X %08X\n",seg,addr,addr2);
        if (seg==-1)
        {
                x86gpf(NULL,0);
                return -1;
                printf("NULL segment!\n");
                dumpregs();
                exit(-1);
        }
        if (cr0>>31)
        {
//                if (output==3) pclog("Translate readmemll %08X:%08X %08X\n",seg,addr,addr2);
                addr2=mmutranslate(addr2,1);
                if (addr2==0xFFFFFFFF) return 0xFFFFFFFF;
        }
//        if (output==3) printf("New addr %08X ",addr2);
        addr2&=rammask;
//        if (output==3) printf("%08X\n",addr2);
        if (isram[addr2>>16])
        {
//                if (output==3) printf("ISRAM\n");
                addreadlookup(seg+addr,addr2);
                return *(unsigned long *)(&ram[addr2]);
        }
//        if (output==3) printf("!ISRAM\n");
//        if (isram[(addr2>>16)&255])
//          return *(unsigned long *)(&ram[addr2&0xFFFFFF]);
        temp=readmemb(seg+addr)|(readmemb(seg+addr+1)<<8)|(readmemb(seg+addr+2)<<16)|(readmemb(seg+addr+3)<<24);
        return temp;
}

void writememll(unsigned long seg, unsigned long addr, unsigned long val)
{
        unsigned long addr2=seg+addr;
//        if (output==3) printf("Writememl %08X to %08X:%08X %08X\n",val,seg,addr,addr2);
        if (seg==-1)
        {
                x86gpf(NULL,0);
                return;
                printf("NULL segment!\n");
                dumpregs();
                exit(-1);
        }
        if (cr0>>31)
        {
//                if (output==3) pclog("Translate writememll %08X:%08X %08X\n",seg,addr,addr2);
                addr2=mmutranslate(addr2,1);
                if (addr2==0xFFFFFFFF) return;
//                if (addr2==0x158138) printf("Writememll %08X %08X\n",val,addr);
        }
//        if (addr2==0x158138) printf("Writememll %08X %08X %i\n",val,addr2,cr0>>31);
//        if (output==3) printf("New addr %08X ",addr2);
        addr2&=rammask;
//        if (output==3) printf("%08X\n",addr2);
        if (isram[addr2>>16])
        {
//                if (output==3) printf("ISRAM\n");
                addwritelookup(seg+addr,addr2);
                *(unsigned long *)(&ram[addr2])=val;
                return;
        }
//        if (val==0x35B1C4) printf("Write 35B1C4 to %08X %04X(%06X):%08X\n",addr,CS,cs,pc);
//        if (val==0x3A7214) printf("Write 3A7214 to %08X %04X(%06X):%08X\n",addr,CS,cs,pc);
//        if (!cpuspeed) cycles-=4;
//        if (output==3) printf("!ISRAM\n");
        writememb(seg+addr,val);
        writememb(seg+addr+1,val>>8);
        writememb(seg+addr+2,val>>16);
        writememb(seg+addr+3,val>>24);
}

unsigned short getword()
{
        unsigned char temp=FETCH();
        return temp|(FETCH()<<8);
//        pc+=2;
//        return readmemw(cs,(pc-2));
}

unsigned short getword286()
{
        unsigned short temp=readmemw(cs,pc); pc+=2;
        return temp;
}

int ratio1=0,ratio2=0;

unsigned long rmbmask(int i)
{
        if (i) ratio1++;
        else   ratio2++;
        return 0xFFFFFFFF;
}

void dumpregs()
{
        FILE *f;
        int c,d=0,e=0;
        return;
        output=0;
//        return;
//        savenvr();
/*        printf("The ratio is %i %i\n",ratio1,ratio2);
        for (c=0;c<256;c++)
        {
                printf("ISRAM : %06X %i\n",c<<16,isram[c]);
        }*/
//        return;
        nopageerrors=1;
        f=fopen("ram.dmp","wb");
        fwrite(ram,0x800000,1,f);
        fclose(f);
        f=fopen("rram.dmp","wb");
        for (c=0;c<0x800000;c++) putc(readmemb(c),f);
        fclose(f);
        f=fopen("ram6.bin","wb");
        fwrite(ram+0x10100,0xA000,1,f);
        fclose(f);
        f=fopen("boot.bin","wb");
        fwrite(ram+0x7C00,0x200,1,f);
        fclose(f);
        f=fopen("ram7.bin","wb");
        fwrite(ram+0x11100,0x2000,1,f);
        fclose(f);
        f=fopen("ram8.bin","wb");
        fwrite(ram+0x3D210,0x200,1,f);
        fclose(f);        
        f=fopen("vram.dmp","wb");
        fwrite(vram,0x100000,1,f);
        fclose(f);
        f=fopen("bios.dmp","wb");
        fwrite(rom,0x10000,1,f);
        fclose(f);
/*        f=fopen("kernel.dmp","wb");
        for (c=0;c<0x200000;c++) putc(readmemb(c+0xC0000000),f);
        fclose(f);*/
/*        f=fopen("rram.dmp","wb");
        for (c=0;c<0x1500000;c++) putc(readmemb(c),f);
        fclose(f);
        if (!times)
        {
                f=fopen("thing.dmp","wb");
                fwrite(ram+0x11E50,0x1000,1,f);
                fclose(f);
        }*/
        if (is386)
           printf("EAX=%08X EBX=%08X ECX=%08X EDX=%08X\nEDI=%08X ESI=%08X EBP=%08X ESP=%08X\n",EAX,EBX,ECX,EDX,EDI,ESI,EBP,ESP);
        else
           printf("AX=%04X BX=%04X CX=%04X DX=%04X DI=%04X SI=%04X BP=%04X SP=%04X\n",AX,BX,CX,DX,DI,SI,BP,SP);
        printf("PC=%04X CS=%04X DS=%04X ES=%04X SS=%04X FLAGS=%04X\n",pc,CS,DS,ES,SS,flags);
        printf("%04X:%04X %08X %08X %08X\n",oldcs,oldpc,old8,old82,old83);
        printf("%i ins\n",ins);
        if (is386)
           printf("In %s mode\n",(msw&1)?((eflags&VM_FLAG)?"V86":"protected"):"real");
        else
           printf("In %s mode\n",(msw&1)?"protected":"real");
        printf("CS : base=%06X limit=%04X access=%02X\n",cs,_cs.limit,_cs.access);
        printf("DS : base=%06X limit=%04X access=%02X\n",ds,_ds.limit,_ds.access);
        printf("ES : base=%06X limit=%04X access=%02X\n",es,_es.limit,_es.access);
        if (is386)
        {
                printf("FS : base=%06X limit=%04X access=%02X\n",fs,_fs.limit,_fs.access);
                printf("GS : base=%06X limit=%04X access=%02X\n",gs,_gs.limit,_gs.access);
        }
        printf("SS : base=%06X limit=%04X access=%02X\n",ss,_ss.limit,_ss.access);
        printf("GDT : base=%06X limit=%04X\n",gdt.base,gdt.limit);
        printf("LDT : base=%06X limit=%04X\n",ldt.base,ldt.limit);
        printf("IDT : base=%06X limit=%04X\n",idt.base,idt.limit);
        printf("TR  : base=%06X limit=%04X\n", tr.base, tr.limit);
        if (is386)
        {
                printf("386 in %s mode   stack in %s mode\n",(use32)?"32-bit":"16-bit",(stack32)?"32-bit":"16-bit");
                printf("CR0=%08X CR2=%08X CR3=%08X\n",cr0,cr2,cr3);
        }
        printf("Entries in readlookup : %i    writelookup : %i\n",readlnum,writelnum);
        for (c=0;c<1024*1024;c++)
        {
                if (readlookup2[c]!=0xFFFFFFFF) d++;
                if (writelookup2[c]!=0xFFFFFFFF) e++;
        }
        printf("Entries in readlookup : %i    writelookup : %i\n",d,e);
        d=0;
        for (c=0;c<1024*1024;c++)
        {
                if (mmucache[c]!=0xFFFFFFFF) d++;
        }
        printf("Entries in MMU cache : %i\n",d);
}

int isAT;
void resetx86()
{
        use32=0;
        stack32=0;
//        i86_Reset();
//        cs=0xFFFF0;
        pc=0;
        msw=0;
        eflags=0;
        loadcs(0xFFFF);
        rammask=0xFFFFFF;
        flags=2;
        initmmucache();
        resetreadlookup();
        makemod1table();
        resetmcr();
        isAT=AT;
        FETCHCLEAR();
}

void softresetx86()
{
        use32=0;
        stack32=0;
//        i86_Reset();
//        cs=0xFFFF0;
        pc=0;
        msw=0;
        eflags=0;
        loadcs(0xFFFF);
        rammask=0xFFFFFF;
        flags=2;
}

#undef AT
#define AT isAT

void initmem()
{
        ram=malloc(0x800000);
        rom=malloc(0x10000);
        vram=malloc(0x200000);
        vrom=malloc(0x8000);
        readlookup2=malloc(1024*1024*4);
        writelookup2=malloc(1024*1024*4);
        biosmask=65535;
        makeznptable();
        memset(ram,0,0x800000);
}

FILE *romfopen(char *fn, char *mode)
{
        char s[512];
        strcpy(s,pcempath);
        put_backslash(s);
        strcat(s,fn);
        return fopen(s,mode);
}
extern int is486;
int loadbios()
{
        FILE *f=NULL,*ff=NULL;
        int c;
        memset(vrom,0x63,0x8000);
//        printf("Loadrom - VGA %i\n",VGA);
        if (VGA)
        {
                f=romfopen("roms/trident.bin","rb");
                if (f)
                {
                        fread(vrom,32768,1,f);
                        fclose(f);
                }
        }
        if (SVGA)
        {
                f=romfopen("roms/et4000.bin","rb");
                if (f)
                {
                        fread(vrom,32768,1,f);
                        fclose(f);
                }
        }

        memset(romext,0x63,0x8000);
        f=romfopen("roms/romext.bin","rb");
        
        is486=0;
        if (f)
        {
                fread(romext,16384,1,f);
                fclose(f);
        }
        switch (romset)
        {
                case ROM_PC1512:
                f=romfopen("roms/pc1512/40043.v1","rb");
                ff=romfopen("roms/pc1512/40044.v1","rb");
                if (!f || !ff) break;
                for (c=0xC000;c<0x10000;c+=2)
                {
                        rom[c]=getc(f);
                        rom[c+1]=getc(ff);
                }
                fclose(ff);
                fclose(f);
                memset(vrom,0x63,0x8000);
                return 1;
                case ROM_PC1640:
                f=romfopen("roms/pc1640/40044.v3","rb");
                ff=romfopen("roms/pc1640/40043.v3","rb");
                if (!f || !ff) break;
                for (c=0xC000;c<0x10000;c+=2)
                {
                        rom[c]=getc(f);
                        rom[c+1]=getc(ff);
                }
                fclose(ff);
                fclose(f);
                f=romfopen("roms/pc1640/40100","rb");
                if (!f) break;
                fread(vrom,0x8000,1,f);
                fclose(f);
                return 1;
                case ROM_PC200:
                f=romfopen("roms/pc200/pc20v2.1","rb");
                ff=romfopen("roms/pc200/pc20v2.0","rb");
                if (!f || !ff) break;
                for (c=0xC000;c<0x10000;c+=2)
                {
                        rom[c]=getc(f);
                        rom[c+1]=getc(ff);
                }
                fclose(ff);
                fclose(f);
                memset(vrom,0x63,0x8000);
                return 1;
                case ROM_TANDY:
                f=romfopen("roms/tandy/tandy1t1.020","rb");
                if (!f) break;
                fread(rom,65536,1,f);
                fclose(f);
                memset(vrom,0x63,0x8000);
                return 1;
/*                case ROM_IBMPCJR:
                f=fopen("pcjr/bios.rom","rb");
                fread(rom+0xE000,8192,1,f);
                fclose(f);
                f=fopen("pcjr/basic.rom","rb");
                fread(rom+0x6000,32768,1,f);
                fclose(f);
                break;*/
                case ROM_IBMXT:
                f=romfopen("roms/ibmxt/xt.rom","rb");
                if (!f)
                {
                        f=romfopen("roms/ibmxt/xt050986.0","rb");
                        ff=romfopen("roms/ibmxt/xt050986.1","rb");
                        if (!f || !ff) break;
                        for (c=0x0000;c<0x10000;c+=2)
                        {
                                rom[c]=getc(f);
                                rom[c+1]=getc(ff);
                        }
                        fclose(ff);
                        fclose(f);
                        return 1;
                }
                else
                {
                        fread(rom,65536,1,f);
                        fclose(f);
                        return 1;
                }
                break;
                case ROM_GENXT:
                f=romfopen("roms/genxt/pcxt.rom","rb");
                if (!f) break;
                fread(rom+0xE000,8192,1,f);
                fclose(f);
//                memset(romext,0x63,0x8000);
                return 1;
                case ROM_IBMAT:
/*                f=romfopen("roms/AMIC206.BIN","rb");
                if (!f) break;
                fread(rom,65536,1,f);
                fclose(f);
                return 1;*/
                case ROM_IBMAT386:
                f=romfopen("roms/ibmat/at111585.0","rb");
                ff=romfopen("roms/ibmat/at111585.1","rb");
                if (!f || !ff) break;
                for (c=0x0000;c<0x10000;c+=2)
                {
                        rom[c]=getc(f);
                        rom[c+1]=getc(ff);
                }
                fclose(ff);
                fclose(f);
                return 1;
/*                case ROM_IBMAT386:
                f=romfopen("roms/at386/at386.bin","rb");
                if (!f) break;
                fread(rom,65536,1,f);
                fclose(f);
                return 1;*/
                case ROM_AMI386: /*This uses the OPTi 82C495 chipset*/
//                f=romfopen("roms/at386/at386.bin","rb");
                f=romfopen("roms/ami386/ami386.bin","rb");
                if (!f) break;
                fread(rom,65536,1,f);
                fclose(f);
                return 1;

                return 0; /*This doesn't work!*/
                
                case ROM_AMI286:
                /*f=romfopen("roms/amic21-1.bin","rb");
                ff=romfopen("roms/amic21-2.bin","rb");
                if (!f || !ff) break;
                for (c=0x0000;c<0x10000;c+=2)
                {
                        rom[c]=getc(f);
                        rom[c+1]=getc(ff);
                }
                fclose(ff);
                fclose(f);*/
                f=romfopen("roms/ami286/amic206.bin","rb");
                if (!f) break;
                fread(rom,65536,1,f);
                fclose(f);
//                memset(romext,0x63,0x8000);
                return 1;
//                f=romfopen("roms/isa.x","rb");
//                f=romfopen("roms/ami386/bios.bin","rb");
//                f=romfopen("roms/OPT495SL.AMI","rb");
//                f=romfopen("roms/at486/at486.bin","rb");
//                if (!f) break;
//                fread(rom,65536,1,f);
//                fclose(f);
                #if 0
                if (rom[0xDC0E]==0x74) rom[0xDC0E]=0xEB; /*Turn JE to JMP - skip checksum*/
                if (rom[0x26D6]==0xF7)
                {
                        rom[0x26D6]=0xEB; /*JMP 0x273B*/
                        rom[0x26D7]=0x63;
                }
                #endif
                return 1;
                
                case ROM_EUROPC:
//                return 0;
                f=romfopen("roms/europc/50145","rb");
                if (!f) break;
                fread(rom+0x8000,32768,1,f);
                fclose(f);
//                memset(romext,0x63,0x8000);
                return 1;
                
                case ROM_IBMPC:
                f=romfopen("roms/ibmpc/pc102782.bin","rb");
                if (!f) break;
//                f=fopen("pc081682.bin","rb");
                fread(rom+0xE000,8192,1,f);
                fclose(f);
                f=romfopen("roms/ibmpc/basicc11.f6","rb");
                if (!f) return 1; /*I don't really care if BASIC is there or not*/
                fread(rom+0x6000,8192,1,f);
                fclose(f);
                f=romfopen("roms/ibmpc/basicc11.f8","rb");
                if (!f) break; /*But if some of it is there, then all of it must be*/
                fread(rom+0x8000,8192,1,f);
                fclose(f);
                f=romfopen("roms/ibmpc/basicc11.fa","rb");
                if (!f) break;
                fread(rom+0xA000,8192,1,f);
                fclose(f);
                f=romfopen("roms/ibmpc/basicc11.fc","rb");
                if (!f) break;
                fread(rom+0xC000,8192,1,f);
                fclose(f);
                return 1;
                
                case ROM_AMI486:
                f=romfopen("roms/ami486/ami486.BIN","rb");
                if (!f) break;
                fread(rom,65536,1,f);
                fclose(f);
                is486=1;
                return 1;
        }
        printf("Failed to load ROM!\n");
        if (f) fclose(f);
        if (ff) fclose(ff);
        return 0;
}

void setznp8(unsigned char val)
{
        flags&=~0xC4;
        flags|=znptable8[val];
}

#define setznp168 setznp16
void setznp16(unsigned short val)
{
        flags&=~0xC4;
//        flags|=((val&0x8000)?N_FLAG:((!val)?Z_FLAG:0));
//        flags|=(((znptable8[val&0xFF]&P_FLAG)==(znptable8[val>>8]&P_FLAG))?P_FLAG:0);
        flags|=znptable16[val];
}

/*void setznp168(unsigned short val)
{
        flags&=~0xC4;
        flags|=(znptable16[val]&0xC0)|(znptable8[val&0xFF]&4);
}*/

void setadd8(unsigned char a, unsigned char b)
{
        unsigned short c=(unsigned short)a+(unsigned short)b;
        flags&=~0x8D5;
        flags|=znptable8[c&0xFF];
        if (c&0x100) flags|=C_FLAG;
        if (!((a^b)&0x80)&&((a^c)&0x80)) flags|=V_FLAG;
        if (((a&0xF)+(b&0xF))&0x10)      flags|=A_FLAG;
}
void setadd8nc(unsigned char a, unsigned char b)
{
        unsigned short c=(unsigned short)a+(unsigned short)b;
        flags&=~0x8D4;
        flags|=znptable8[c&0xFF];
        if (!((a^b)&0x80)&&((a^c)&0x80)) flags|=V_FLAG;
        if (((a&0xF)+(b&0xF))&0x10)      flags|=A_FLAG;
}
void setadc8(unsigned char a, unsigned char b)
{
        unsigned short c=(unsigned short)a+(unsigned short)b+tempc;
        flags&=~0x8D5;
        flags|=znptable8[c&0xFF];
        if (c&0x100) flags|=C_FLAG;
        if (!((a^b)&0x80)&&((a^c)&0x80)) flags|=V_FLAG;
        if (((a&0xF)+(b&0xF))&0x10)      flags|=A_FLAG;
}
void setadd16(unsigned short a, unsigned short b)
{
        unsigned long c=(unsigned long)a+(unsigned long)b;
        flags&=~0x8D5;
        flags|=znptable16[c&0xFFFF];
        if (c&0x10000) flags|=C_FLAG;
        if (!((a^b)&0x8000)&&((a^c)&0x8000)) flags|=V_FLAG;
        if (((a&0xF)+(b&0xF))&0x10)      flags|=A_FLAG;
}
void setadd16nc(unsigned short a, unsigned short b)
{
        unsigned long c=(unsigned long)a+(unsigned long)b;
        flags&=~0x8D4;
        flags|=znptable16[c&0xFFFF];
        if (!((a^b)&0x8000)&&((a^c)&0x8000)) flags|=V_FLAG;
        if (((a&0xF)+(b&0xF))&0x10)      flags|=A_FLAG;
}
void setadc16(unsigned short a, unsigned short b)
{
        unsigned long c=(unsigned long)a+(unsigned long)b+tempc;
        flags&=~0x8D5;
        flags|=znptable16[c&0xFFFF];
        if (c&0x10000) flags|=C_FLAG;
        if (!((a^b)&0x8000)&&((a^c)&0x8000)) flags|=V_FLAG;
        if (((a&0xF)+(b&0xF))&0x10)      flags|=A_FLAG;
}

void setsub8(unsigned char a, unsigned char b)
{
        unsigned short c=(unsigned short)a-(unsigned short)b;
        flags&=~0x8D5;
        flags|=znptable8[c&0xFF];
        if (c&0x100) flags|=C_FLAG;
        if ((a^b)&(a^c)&0x80) flags|=V_FLAG;
        if (((a&0xF)-(b&0xF))&0x10)      flags|=A_FLAG;
}
void setsub8nc(unsigned char a, unsigned char b)
{
        unsigned short c=(unsigned short)a-(unsigned short)b;
        flags&=~0x8D4;
        flags|=znptable8[c&0xFF];
        if ((a^b)&(a^c)&0x80) flags|=V_FLAG;
        if (((a&0xF)-(b&0xF))&0x10)      flags|=A_FLAG;
}
void setsbc8(unsigned char a, unsigned char b)
{
        unsigned short c=(unsigned short)a-(((unsigned short)b)+tempc);
        flags&=~0x8D5;
        flags|=znptable8[c&0xFF];
        if (c&0x100) flags|=C_FLAG;
        if ((a^b)&(a^c)&0x80) flags|=V_FLAG;
        if (((a&0xF)-(b&0xF))&0x10)      flags|=A_FLAG;
}
void setsub16(unsigned short a, unsigned short b)
{
        unsigned long c=(unsigned long)a-(unsigned long)b;
        flags&=~0x8D5;
        flags|=znptable16[c&0xFFFF];
        if (c&0x10000) flags|=C_FLAG;
        if ((a^b)&(a^c)&0x8000) flags|=V_FLAG;
//        if (output) printf("%04X %04X %i\n",a^b,a^c,flags&V_FLAG);
        if (((a&0xF)-(b&0xF))&0x10)      flags|=A_FLAG;
}
void setsub16nc(unsigned short a, unsigned short b)
{
        unsigned long c=(unsigned long)a-(unsigned long)b;
        flags&=~0x8D4;
        flags|=(znptable16[c&0xFFFF]&~4);
        flags|=(znptable8[c&0xFF]&4);
        if ((a^b)&(a^c)&0x8000) flags|=V_FLAG;
        if (((a&0xF)-(b&0xF))&0x10)      flags|=A_FLAG;
}
void setsbc16(unsigned short a, unsigned short b)
{
        unsigned long c=(unsigned long)a-(((unsigned long)b)+tempc);
        flags&=~0x8D5;
        flags|=(znptable16[c&0xFFFF]&~4);
        flags|=(znptable8[c&0xFF]&4);
        if (c&0x10000) flags|=C_FLAG;
        if ((a^b)&(a^c)&0x8000) flags|=V_FLAG;
        if (((a&0xF)-(b&0xF))&0x10)      flags|=A_FLAG;
}

unsigned char lpt2dat;
int sw9;
unsigned char inb(unsigned short port)
{
        unsigned char temp;
        if (port&0x80) sw9=2;
//        if ((port&0x3F0)==0x3D0) printf("Video access read %03X %04X:%04X\n",port,cs>>4,pc);
//        if (cs<0xF0000) printf("IN %04X\n",port);
//        /*if (output) */if (CS<0xA000 && !(cr0&1)) printf("IN %04X %04X:%04X\n",port,CS,pc);
        switch (port)
        {
                case 0x00: case 0x01: case 0x02: case 0x03: /*DMA*/
                case 0x04: case 0x05: case 0x06: case 0x07:
                case 0x08: case 0x09: case 0x0A: case 0x0B:
                case 0x0C: case 0x0D: case 0x0E: case 0x0F:
                return readdma(port);
                case 0x20: case 0x21: /*PIC*/
                return readpic(port);
                case 0x22: case 0x23: /*Chipset*/
                if (romset==ROM_AMI286) return read82c206(port);
                case 0x24: case 0x25: 
//                printf("Reading chipset %04X\n",port);
                if (romset==ROM_AMI386) return readopti(port);
                return 0;
                case 0x40: case 0x41: case 0x42: case 0x43: /*PIT*/
                temp=readpit(port);
//                printf("Reading %02X from %04X\n",temp,port);
                return temp;
                case 0x60: case 0x61: case 0x62: case 0x63: case 0x64: case 0x65: /*PPI*/
                return readppi(port);
                case 0x70: case 0x71: /*NVR*/
                return readnvr(port);
                case 0x78: case 0x7A: /*Amstrad mouse*/
                return readmouse(port);
                case 0x80: case 0x81: case 0x82: case 0x83: /*DMA paging*/
                case 0x84: case 0x85: case 0x86: case 0x87:
                case 0x88: case 0x89: case 0x8A: case 0x8B:
                case 0x8C: case 0x8D: case 0x8E: case 0x8F:
                return readpage(port);
                case 0xA0: case 0xA1:
                if (AT) return readpic2(port);
//                        printf("Read A0 %04X:%04X\n",cs>>4,pc);
                return 0;
                case 0xC0: case 0xC1: case 0xC2: case 0xC3:
                case 0xC4: case 0xC5: case 0xC6: case 0xC7:
                case 0xC8: case 0xC9: case 0xCA: case 0xCB:
                case 0xCC: case 0xCD: case 0xCE: case 0xCF:
                case 0xD0: case 0xD1: case 0xD2: case 0xD3:
                case 0xD4: case 0xD5: case 0xD6: case 0xD7:
                case 0xD8: case 0xD9: case 0xDA: case 0xDB:
                case 0xDC: case 0xDD: case 0xDE: case 0xDF:
                if (AT) return readdma16(port);
                break;
                case 0x201: /*Joystick?*/
                return 0xFF;//xFF;
                case 0x210: case 0x211: case 0x212: case 0x213: /*XT expansion*/
                case 0x214: case 0x215: case 0x216: case 0x217:
                return 0;
                case 0x21E: /*???*/
                return 0xFF;
                case 0x220: case 0x221: case 0x222: case 0x223: /*Gameblaster*/
                if (GAMEBLASTER) return readcms(port);
                return 0xFF;
                case 0x224: case 0x225: case 0x226: case 0x227: /*Soundblaster*/
                case 0x228: case 0x229: case 0x22A: case 0x22B:
                case 0x22C: case 0x22D: case 0x22E: case 0x22F:
                return readsb(port);
                case 0x250: case 0x251: case 0x252: case 0x253: /*EuroPC JIM*/
                case 0x254: case 0x255: case 0x256: case 0x257:
                case 0x258: case 0x259: case 0x25A: case 0x25B:
                case 0x25C: case 0x25D: case 0x25E: case 0x25F:
                case 0x2E0:
                if (romset==ROM_EUROPC) return readjim(port);
                return 0;
                case 0x278: /*LPT?*/
                return 0;
                case 0x279: return readdacfifo();
                case 0x27A: sw9=1; return 0xFF;
                case 0x427A: sw9=0; return 0xFF;
                case 0x2CB: case 0x2D2: /*??*/
                return 0;
                case 0x240: case 0x241: case 0x242: case 0x243: /*GUS*/
                case 0x244: case 0x245: case 0x246: case 0x247:
                case 0x248: case 0x249: case 0x24A: case 0x24B:
                case 0x24C: case 0x24D: case 0x24E: case 0x24F:
                case 0x340: case 0x341: case 0x342: case 0x343:
                case 0x344: case 0x345: case 0x346: case 0x347:
                case 0x348: case 0x349: case 0x34A: case 0x34B:
                case 0x34C: case 0x34D: case 0x34E: case 0x34F:
                return readgus(port);
                case 0x378: /*LPT2*/
//                printf("Read LPT2 %04X:%04X\n",cs>>4,pc);
                return lpt2dat;
                case 0x379:
                if (romset==ROM_PC1512) return 7|readdacfifo();
                if (romset==ROM_PC1640) return 7|readdacfifo();
                if (romset==ROM_PC200) return 7|readdacfifo();
                return 0;
                case 0x37A:
                if (romset==ROM_PC1640)
                {
                        if (sw9==1) return 0;
                        else if (sw9==2) return 0x20;
                        else     return 0;
                }
//                        printf("Read 37A %04X:%04X\n",cs>>4,pc);
                return 0x80;
                case 0x388: case 0x389: /*Adlib*/
                return readadlib(port);
                return 0xFF;
                        
                case 0x3B4: case 0x3B5: /*MDA*/
                return readcrtcm(port);
                case 0x3C0: case 0x3C1: case 0x3C2: case 0x3C3:
                case 0x3C4: case 0x3C5: case 0x3C6: case 0x3C7:
                case 0x3C8: case 0x3C9: case 0x3CA: case 0x3CB:
                case 0x3CC: case 0x3CD: case 0x3CE: case 0x3CF:
                case 0x3D0: case 0x3D1: case 0x3D2: case 0x3D3:
                /*case 0x3D4: case 0x3D5:*/ case 0x3D6: case 0x3D7:
                case 0x3D8: case 0x3D9: /*case 0x3DA:*/ case 0x3DB:
                case 0x3DC: case 0x3DD: case 0x3DE: case 0x3DF:
                if (EGA) return inega(port);
//                printf("Read video %04X\n",port);
                if (port==0x3D8 && romset==ROM_PC200) return read3d8();
                if (port==0x3DD && romset==ROM_PC200) return read3dd();
                if (port==0x3DE && romset==ROM_PC200) return read3de();
                if (port==0x3DF && romset==ROM_PC200) return read3df();
                return 0;
                case 0x3D4: case 0x3D5: /*CGA CRTC*/
                if (MDA) return 0xFF;
                return readcrtc(port);
                case 0x3BA: //case 0x3DA:
//                        return cgastat;
//                hsync++;
//                hsync&=31;
                if (HERCULES) return cgastat|(hsync>>4)|(cgastat<<4);
//                if (cgastat&8) return cgastat|1;
                return cgastat;//|(hsync>>4);
                case 0x3DA: if (MDA) return 0xFF;
                hsync++;
                hsync&=31;
                if (EGA) return inega(port);
//                printf("Read CGAstat %02X %04X:%04X %04X\n",cgastat,CS,pc,CX);
//                printf("Read 3DA %04X:%04X %i %04X %04X %02X\n",cs>>4,pc,ins,BX,SI,cgastat);
//                cgastat^=1;
                return cgastat;
                case 0x3BC: /*LPT1*/
                return 0;
//                case 0x3DE:
//                        printf("Read 3DE %04X:%04X\n",cs>>4,pc);
//                return 0x00;
//                case 0x3FA: /*case 0x2FA:*/ /*Serial*/
//                return 0xFF;
                case 0x3F0: case 0x3F1: case 0x3F2: case 0x3F3: /*FDC*/
                case 0x3F4: case 0x3F5: case 0x3F6: case 0x3F7:
                return readfdc(port);
                case 0x2F8: case 0x2F9: case 0x2FA: case 0x2FB:
                case 0x2FC: case 0x2FD: case 0x2FE: case 0x2FF:
                if (TANDY) return readserial(port);
                if (AT) return readserial2(port);
                return 0xFF;
                case 0x3F8: case 0x3F9: case 0x3FA: case 0x3FB:
                case 0x3FC: case 0x3FD: case 0x3FE: case 0x3FF:
                if (!TANDY) return readserial(port);
                return 0xFF;
                case 0x746: return 0xFF;
        }
//        printf("Bad IN port %04X %04X:%04X\n",port,cs>>4,pc);
        return 0;
        dumpregs();
        exit(-1);
}

unsigned char cpu_readport(unsigned long port) { return inb(port); }

int speshul;

void outb(unsigned short port, unsigned char val)
{
//        if ((port&0x3F0)==0x3D0) printf("Video access %03X %02X %04X:%04X\n",port,val,cs>>4,pc);
//        if (cs<0xF0000) printf("OUT %04X\n",port);
//        /*if (output) */if (CS<0xA000 && !(cr0&1)) printf("OUT %04X %02X %04X:%04X\n",port,val,CS,pc);
        switch (port)
        {
                case 0x00: case 0x01: case 0x02: case 0x03: /*DMA*/
                case 0x04: case 0x05: case 0x06: case 0x07:
                case 0x08: case 0x09: case 0x0A: case 0x0B:
                case 0x0C: case 0x0D: case 0x0E: case 0x0F:
                writedma(port,val);
                return;
                case 0x20: case 0x21: /*PIC*/
//                pclog("Write PIC %02X %02X %04X(%08X):%08X\n",port,val,CS,cs,pc);
                writepic(port,val);
                return;
                case 0x22: case 0x23: /*MCR*/
                if (romset==ROM_AMI286) write82c206(port,val);
         //       if (romset==ROM_IBMAT386) writemcr(port,val);
                case 0x24: case 0x25: /*MCR*/
                if (romset==ROM_AMI386) writeopti(port,val);
//                printf("Write chipset %04X %02X\n",port,val);
                return;
                case 0x40: case 0x41: case 0x42: case 0x43: /*PIT*/
                writepit(port,val);
                return;
                case 0x60: case 0x61: case 0x62: case 0x63: case 0x64: case 0x65: /*PPI*/
                writeppi(port,val);
                return;
                case 0x66:
                        printf("RESET at %04X:%04X\n",CS,pc);
                        dumpregs();
                        exit(-1);
                case 0x70: case 0x71: /*NVR*/
                writenvr(port,val);
                return;
                case 0x78: case 0x7A: /*Amstrad mouse*/
                writemouse(port,val);
                return;
                case 0x80: case 0x81: case 0x82: case 0x83: /*DMA paging*/
                case 0x84: case 0x85: case 0x86: case 0x87:
                case 0x88: case 0x89: case 0x8A: case 0x8B:
                case 0x8C: case 0x8D: case 0x8E: case 0x8F:
                writepage(port,val);
                return;
                case 0xA0: case 0xA1: /*PIC2*/
//                pclog("Write PIC2 %02X %02X %04X:%08X\n",port,val,CS,pc);
                if (AT) writepic2(port,val);
                return;
                case 0xC0: case 0xC1:
                /*if (TANDY) */writepsg(val);
                case 0xC2: case 0xC3:
                case 0xC4: case 0xC5: case 0xC6: case 0xC7:
                case 0xC8: case 0xC9: case 0xCA: case 0xCB:
                case 0xCC: case 0xCD: case 0xCE: case 0xCF:
                case 0xD0: case 0xD1: case 0xD2: case 0xD3:
                case 0xD4: case 0xD5: case 0xD6: case 0xD7:
                case 0xD8: case 0xD9: case 0xDA: case 0xDB:
                case 0xDC: case 0xDD: case 0xDE: case 0xDF:
                if (AT) writedma16(port,val);
                return;
                case 0x210: case 0x211: case 0x212: case 0x213: /*XT expansion*/
                case 0x214: case 0x215: case 0x216: case 0x217:
                return;
                case 0x220: case 0x221: case 0x222: case 0x223: /*Gameblaster*/
                if (sbtype==SBPRO) writesb(port,val);
                else if (GAMEBLASTER) writecms(port,val);
                return;
                case 0x224: case 0x225: case 0x226: case 0x227: /*Soundblaster*/
                case 0x228: case 0x229: case 0x22A: case 0x22B:
                case 0x22C: case 0x22D: case 0x22E: case 0x22F:
                writesb(port,val);
                return;
                case 0x250: case 0x251: case 0x252: case 0x253: /*EuroPC JIM*/
                case 0x254: case 0x255: case 0x256: case 0x257:
                case 0x258: case 0x259: case 0x25A: case 0x25B:
                case 0x25C: case 0x25D: case 0x25E: case 0x25F:
                if (romset==ROM_EUROPC) writejim(port,val);
                return;
                case 0x3F0: case 0x3F1: case 0x3F2: case 0x3F3: /*FDC*/
                case 0x3F4: case 0x3F5: case 0x3F6: case 0x3F7:
                writefdc(port,val);
                return;
                case 0x2D2: /*??*/
                return;
                case 0x378: lpt2dat=val; writedac(val); return;
                case 0x37A: writedacctrl(val); return;
                case 0x278: writedac(val); return;
                case 0x27A: writedacctrl(val); return;
                case 0x240: case 0x241: case 0x242: case 0x243: /*GUS*/
                case 0x244: case 0x245: case 0x246: case 0x247:
                case 0x248: case 0x249: case 0x24A: case 0x24B:
                case 0x24C: case 0x24D: case 0x24E: case 0x24F:
                case 0x340: case 0x341: case 0x342: case 0x343:
                case 0x344: case 0x345: case 0x346: case 0x347:
                case 0x348: case 0x349: case 0x34A: case 0x34B:
                case 0x34C: case 0x34D: case 0x34E: case 0x34F:
                writegus(port,val);
                return;
                case 0x388: case 0x389: /*Adlib*/
                writeadlib(port,val);
                if (!(port&1)) writegus(port,val);
                return;
                case 0x3B4: case 0x3B5: /*MDA CRTC*/
                writecrtcm(port,val);
                return;
                case 0x3B8: case 0x3BF:
                writemda(port,val);
                return;
                case 0x3C0: case 0x3C1: case 0x3C2: case 0x3C3:
                case 0x3C4: case 0x3C5: case 0x3C6: case 0x3C7:
                case 0x3C8: case 0x3C9: case 0x3CA: case 0x3CB:
                case 0x3CC: case 0x3CD: case 0x3CE: case 0x3CF:
                case 0x3D0: case 0x3D1: case 0x3D2: case 0x3D3:
                /*case 0x3D4: case 0x3D5:*/ case 0x3D6: case 0x3D7:
                /*case 0x3D8: case 0x3D9:*/ /*case 0x3DA:*/ case 0x3DB:
                case 0x3DC: /*case 0x3DD: case 0x3DE: case 0x3DF:*/
//                printf("Write video %04X %02X\n",port,val);
                if (EGA) outega(port,val);
                return;
                case 0x3D4: case 0x3D5: /*CGA CRTC*/
//                printf("Write video %04X %02X\n",port,val);
                writecrtc(port,val);
                return;
//                case 0x3DA: case 0x3DE: /*PCjr/Tandy video*/
//                writearray(port,val);
//                return;
                case 0x3D8:
//                        printf("Write CGAMODE %02X %04X:%04X\n",val,cs>>4,pc);
//                printf("Write video %04X %02X\n",port,val);
                if (!EGA || incga) writecgamode(val);
                else               outega(port,val);
                return;
                case 0x3D9:
//                printf("Write video %04X %02X\n",port,val);
                if (!EGA || incga) cgacol=val;
                else               outega(port,val);
//                printf("CGACOL %02X\n",val);
                return;
                case 0x3DA: case 0x3DD: case 0x3DE: case 0x3DF:
//                printf("Write video %04X %02X\n",port,val);
                if (AMSTRAD) writeams(port,val);
                if (TANDY) writetandy(port,val);
                if (EGA) outega(port,val);
                if (port==0x3DE && romset==ROM_PC200) write3de(val);
                        return;
                case 0x2F8: case 0x2F9: case 0x2FA: case 0x2FB:
                case 0x2FC: case 0x2FD: case 0x2FE: case 0x2FF:
                if (TANDY) writeserial(port,val);
                if (AT) writeserial2(port,val);
                return;
                case 0x3F8: case 0x3F9: case 0x3FA: case 0x3FB:
                case 0x3FC: case 0x3FD: case 0x3FE: case 0x3FF:
                if (!TANDY) writeserial(port,val);
                return;
                case 0x0208: case 0x0209: case 0x4208: case 0x4209:
                case 0x8208: case 0x8209: case 0xC208: case 0xC209:
                if (romset==ROM_AMI286) write82c206ems(port,val);
                return;
//                case 0x3DE:
//                        printf("3DE write %02X\n",val);
//                speshul=val&1;
//                return;
        }
        pclog("OUT %04X %02X %04X:%08X\n",port,val,CS,pc);
}

int cycdiff;
void clockhardware()
{
                cycdiff-=cycles;
                if (keyboardtimer)
                {
                        keyboardtimer-=cycdiff;
                        if (keyboardtimer<1)
                        {
                                keyboardtimer=0;
                                keyboardtimeout();
                        }
                }

                if (!pit.delay[0]) pit.c[0]-=cycdiff;
                if (!pit.delay[1]) pit.c[1]-=cycdiff;
                if (!pit.delay[2]) pit.c[2]-=cycdiff;

                if ((pit.c[0]<1)||(pit.c[1]<1)||(pit.c[2]<1)) pollpit();

                spktime-=cycdiff;
                if (spktime<=0.0)
                {
                        spktime+=SPKCONST;
                        pollspk();
                        pollgussamp();
                        getsbsamp();
                        getdacsamp();
                }
                soundtime-=cycdiff;
                if (soundtime<=0.0)
                {
                        soundtime+=SOUNDCONST;
                        pollsound60hz();
                }
                gustime-=cycdiff;
                while (gustime<=0.0)
                {
                        gustime+=GUSCONST;
//                        printf("1Poll GUS %f %f\n",gustime,GUSCONST);
                        pollgus();
//                        printf("2Poll GUS\n");
                }
                vidtime-=cycdiff;
                if (vidtime<=0.0)
                {
                        pollvideo();
//                        polltandy();
//                        pollmda();
//                        pollcga();
                }
                if (disctime)
                {
                        disctime-=(cycdiff/2);
                        if (disctime<=0)
                        {
                                disctime=0;
                                polldisc();
                        }
                }
                if (mousedelay)
                {
                        mousedelay--;
                        if (!mousedelay)
                           mousecallback();
                }
                if (sbenable)
                {
                        sbcount-=cycdiff;
                        if (sbcount<0)
                        {
                                sbcount+=sblatch;
                                pollsb();
                        }
                }
                cycdiff=cycles;
}

#define IRQTEST ((flags&I_FLAG) && (pic.pend&~pic.mask) && !ssegs && !noint)
                int firstrepcycle=1;
void cpu_writeport(unsigned long port, unsigned char val) { outb(port,val); }
void rep(int fv)
{
        unsigned char temp;
        int c=CX;
        unsigned char temp2;
        unsigned short tempw,tempw2,tempw3;
        unsigned short ipc=oldpc;//pc-1;
        int changeds=0;
        unsigned long oldds;
        startrep:
        temp=FETCH();
//        if (firstrepcycle && temp==0xA5) printf("REP MOVSW %06X:%04X %06X:%04X\n",ds,SI,es,DI);
//        if (output) printf("REP %02X %04X\n",temp,ipc);
        switch (temp)
        {
                case 0x08:
                pc=ipc+1;
                cycles-=2;
                FETCHCLEAR();
                break;
                case 0x26: /*ES:*/
                oldds=ds;
                ds=es;
                changeds=1;
                cycles-=2;
                goto startrep;
                break;
                case 0x2E: /*CS:*/
                oldds=ds;
                ds=cs;
                changeds=1;
                cycles-=2;
                goto startrep;
                break;
                case 0x36: /*SS:*/
                oldds=ds;
                ds=ss;
                changeds=1;
                cycles-=2;
                goto startrep;
                break;
                case 0x6E: /*REP OUTSB*/
                if (c>0)
                {
                        temp2=readmemb(ds+SI);
                        outb(DX,temp2);
                        if (flags&D_FLAG) SI--;
                        else              SI++;
                        c--;
                        cycles-=5;
                }
                if (c>0) { firstrepcycle=0; pc=ipc; if (ssegs) ssegs++; FETCHCLEAR(); }
                else firstrepcycle=1;
                break;
                case 0xA4: /*REP MOVSB*/
                while (c>0 && !IRQTEST)
                {
                        temp2=readmemb(ds+SI);
                        writememb(es+DI,temp2);
//                        if (output) printf("Moved %02X from %04X:%04X to %04X:%04X\n",temp2,ds>>4,SI,es>>4,DI);
                        if (flags&D_FLAG) { DI--; SI--; }
                        else              { DI++; SI++; }
                        c--;
                        cycles-=((AT)?4:17);
                        clockhardware();
                        FETCHADD(((AT)?4:17)-memcycs);
                }
                if (IRQTEST && c>0) pc=ipc;
//                if (c>0) { firstrepcycle=0; pc=ipc; if (ssegs) ssegs++; FETCHCLEAR(); }
//                else firstrepcycle=1;
//                }
                break;
                case 0xA5: /*REP MOVSW*/
                while (c>0 && !IRQTEST)
                {
                        memcycs=0;
                        tempw=readmemw(ds,SI);
                        writememw(es,DI,tempw);
                        if (flags&D_FLAG) { DI-=2; SI-=2; }
                        else              { DI+=2; SI+=2; }
                        c--;
                        cycles-=((AT)?4:17);
                        clockhardware();
                        FETCHADD(((AT)?4:17)-memcycs);
                }
                if (IRQTEST && c>0) pc=ipc;
//                if (c>0) { firstrepcycle=0; pc=ipc; if (ssegs) ssegs++; FETCHCLEAR(); }
//                else firstrepcycle=1;
//                }
                break;
                case 0xA6: /*REP CMPSB*/
                if (fv) flags|=Z_FLAG;
                else    flags&=~Z_FLAG;
                while ((c>0) && (fv==((flags&Z_FLAG)?1:0)) && !IRQTEST)
                {
                        memcycs=0;
                        temp=readmemb(ds+SI);
                        temp2=readmemb(es+DI);
//                        printf("CMPSB %c %c %i %05X %05X %04X:%04X\n",temp,temp2,c,ds+SI,es+DI,cs>>4,pc);
                        if (flags&D_FLAG) { DI--; SI--; }
                        else              { DI++; SI++; }
                        c--;
                        if (!AT) cycles-=30;
                        else     cycles-=9;
                        setsub8(temp,temp2);
                        clockhardware();
                        FETCHADD(((AT)?9:30)-memcycs);
                }
                if (IRQTEST && c>0 && (fv==((flags&Z_FLAG)?1:0))) pc=ipc;
//                if ((c>0) && (fv==((flags&Z_FLAG)?1:0))) { pc=ipc; firstrepcycle=0; if (ssegs) ssegs++; FETCHCLEAR(); }
//                else firstrepcycle=1;
                break;
                case 0xA7: /*REP CMPSW*/
                if (fv) flags|=Z_FLAG;
                else    flags&=~Z_FLAG;
                while ((c>0) && (fv==((flags&Z_FLAG)?1:0)) && !IRQTEST)
                {
                        memcycs=0;
                        tempw=readmemw(ds,SI);
                        tempw2=readmemw(es,DI);
                        if (flags&D_FLAG) { DI-=2; SI-=2; }
                        else              { DI+=2; SI+=2; }
                        c--;
                        if (!AT) cycles-=30;
                        else     cycles-=9;
                        setsub16(tempw,tempw2);
                        clockhardware();
                        FETCHADD(((AT)?9:30)-memcycs);
                }
                if (IRQTEST && c>0 && (fv==((flags&Z_FLAG)?1:0))) pc=ipc;
//                if ((c>0) && (fv==((flags&Z_FLAG)?1:0))) { pc=ipc; firstrepcycle=0; if (ssegs) ssegs++; FETCHCLEAR(); }
//                else firstrepcycle=1;
//                if (firstrepcycle) printf("REP CMPSW  %06X:%04X %06X:%04X %04X %04X\n",ds,SI,es,DI,tempw,tempw2);
                break;
                case 0xAA: /*REP STOSB*/
                while (c>0 && !IRQTEST)
                {
                        memcycs=0;
                        writememb(es+DI,AL);
                        if (flags&D_FLAG) DI--;
                        else              DI++;
                        c--;
                        cycles-=((AT)?3:10);
                        clockhardware();
                        FETCHADD(((AT)?3:10)-memcycs);
                }
                if (IRQTEST && c>0) pc=ipc;
//                if (c>0) { firstrepcycle=0; pc=ipc; if (ssegs) ssegs++; FETCHCLEAR(); }
//                else firstrepcycle=1;
                break;
                case 0xAB: /*REP STOSW*/
                while (c>0 && !IRQTEST)
                {
                        memcycs=0;
                        writememw(es,DI,AX);
                        if (flags&D_FLAG) DI-=2;
                        else              DI+=2;
                        c--;
                        cycles-=((AT)?3:10);
                        clockhardware();
                        FETCHADD(((AT)?3:10)-memcycs);
                }
                if (IRQTEST && c>0) pc=ipc;
//                if (c>0) { firstrepcycle=0; pc=ipc; if (ssegs) ssegs++; FETCHCLEAR(); }
//                else firstrepcycle=1;
//                printf("REP STOSW %04X:%04X %04X:%04X %04X %04X\n",CS,pc,ES,DI,AX,CX); }
                break;
                case 0xAC: /*REP LODSB*/
                if (c>0)
                {
                        temp2=readmemb(ds+SI);
                        if (flags&D_FLAG) SI--;
                        else              SI++;
                        c--;
                        cycles-=4;
                }
                if (c>0) { firstrepcycle=0; pc=ipc; if (ssegs) ssegs++; FETCHCLEAR(); }
                else firstrepcycle=1;
                break;
                case 0xAD: /*REP LODSW*/
                if (c>0)
                {
                        tempw2=readmemw(ds,SI);
                        if (flags&D_FLAG) SI-=2;
                        else              SI+=2;
                        c--;
                        cycles-=4;
                }
                if (c>0) { firstrepcycle=0; pc=ipc; if (ssegs) ssegs++; FETCHCLEAR(); }
                else firstrepcycle=1;
                break;
                case 0xAE: /*REP SCASB*/
                if (fv) flags|=Z_FLAG;
                else    flags&=~Z_FLAG;
                if ((c>0) && (fv==((flags&Z_FLAG)?1:0)))
                {
                        temp2=readmemb(es+DI);
//                        if (output) printf("SCASB %02X %c %02X %05X  ",temp2,temp2,AL,es+DI);
                        setsub8(AL,temp2);
//                        if (output && flags&Z_FLAG) printf("Match %02X %02X\n",AL,temp2);
                        if (flags&D_FLAG) DI--;
                        else              DI++;
                        c--;
                        cycles-=((AT)?8:15);
                }
//if (output)                printf("%i %i %i %i\n",c,(c>0),(fv==((flags&Z_FLAG)?1:0)),((c>0) && (fv==((flags&Z_FLAG)?1:0))));
                if ((c>0) && (fv==((flags&Z_FLAG)?1:0)))  { pc=ipc; firstrepcycle=0; if (ssegs) ssegs++; FETCHCLEAR(); }
                else firstrepcycle=1;
//                cycles-=120;
                break;
                case 0xAF: /*REP SCASW*/
                if (fv) flags|=Z_FLAG;
                else    flags&=~Z_FLAG;
                if ((c>0) && (fv==((flags&Z_FLAG)?1:0)))
                {
                        tempw=readmemw(es,DI);
                        setsub16(AX,tempw);
                        if (flags&D_FLAG) DI-=2;
                        else              DI+=2;
                        c--;
                        cycles-=((AT)?8:15);
                }
                if ((c>0) && (fv==((flags&Z_FLAG)?1:0)))  { pc=ipc; firstrepcycle=0; if (ssegs) ssegs++; FETCHCLEAR(); }
                else firstrepcycle=1;
                break;
                default:
                        pc=ipc;
                        cycles-=20;
                        FETCHCLEAR();
//                printf("Bad REP %02X\n",temp);
//                dumpregs();
//                exit(-1);
        }
        CX=c;
        if (changeds) ds=oldds;
//        if (pc==ipc) FETCHCLEAR();
}

void clockstuff(int cycdiff)
{
                if (pit0 && !pit.delay[0]) pit.c[0]-=cycdiff;
                if (!pit.delay[1])         pit.c[1]-=cycdiff;
                if (!pit.delay[2])         pit.c[2]-=cycdiff;
                if (pit.delay[0]) pit.delay[0]--;
                if (pit.delay[1]) pit.delay[1]--;
                if (pit.delay[2]) pit.delay[2]--;
                if ((pit.c[0]<1)||(pit.c[1]<1)||(pit.c[2]<1)) pollpit();
                if (disctime)
                {
                        disctime-=cycdiff;
                        if (disctime<=0)
                        {
                                disctime=0;
                                polldisc();
                        }
                }
}

int inhlt=0;
unsigned short lastpc,lastcs;
int firstrepcycle;
int skipnextprint=0;


//#if 0
void execx86(int cycs)
{
        unsigned char temp,temp2;
        unsigned short addr,tempw,tempw2,tempw3,tempw4;
        signed char offset;
        int tempws;
        unsigned long templ;
        int c;
        int tempi;
        int trap;
        FILE *f;
//        printf("Run x86! %i %i\n",cycles,cycs);
        cycles+=cycs;
//        i86_Execute(cycs);
//        return;
        while (cycles>0)
        {
//                old83=old82;
//                old82=old8;
//                old8=oldpc|(oldcs<<16);
//                if (pc==0x96B && cs==0x9E040) { printf("Hit it\n"); output=1; timetolive=150; }
//                if (pc<0x8000) printf("%04X : %04X %04X %04X %04X %04X %04X %04X %04X %04X %04X %04X %04X %02X %04X %i\n",pc,AX,BX,CX,DX,cs>>4,ds>>4,es>>4,ss>>4,DI,SI,BP,SP,opcode,flags,disctime);
                cycdiff=cycles;
//        if (output) printf("CLOCK %i %i\n",cycdiff,cycles);
                fetchclocks=0;
                oldcs=CS;
                oldpc=pc;
                opcodestart:
                opcode=FETCH();
                tempc=flags&C_FLAG;
                trap=flags&T_FLAG;
                pc--;
//                if (output) printf("%04X:%04X : %04X %04X %04X %04X %04X %04X %04X %04X %04X %04X %04X %04X %02X %04X\n",cs>>4,pc,AX,BX,CX,DX,cs>>4,ds>>4,es>>4,ss>>4,DI,SI,BP,SP,opcode,flags&~0x200,rmdat);
//#if 0
                if (output && /*cs<0xF0000 && */!ssegs && (pc<0x43A || pc>0x44A))//opcode!=0x26 && opcode!=0x36 && opcode!=0x2E && opcode!=0x3E)
                {
                        if ((opcode!=0xF2 && opcode!=0xF3) || firstrepcycle)
                        {
                                if (!skipnextprint) printf("%04X:%04X : %04X %04X %04X %04X %04X %04X %04X %04X %04X %04X %04X %04X %02X %04X  %f %f\n",cs,pc,AX,BX,CX,DX,CS,DS,ES,SS,DI,SI,BP,SP,opcode,flags,vidtime,pit.c[0]);
                                skipnextprint=0;
//                                ins++;
/*                                if (ins==50000)
                                {
                                        dumpregs();
                                        exit(-1);
                                }*/
/*                                if (ins==500000)
                                {
                                        dumpregs();
                                        exit(-1);
                                }*/
                        }
                }
//#endif
                pc++;
                inhlt=0;
//                if (ins==500000) { dumpregs(); exit(0); }*/
                switch (opcode)
                {
                        case 0x00: /*ADD 8,reg*/
                        fetchea();
//                        if (!rmdat) pc--;
/*                        if (!rmdat)
                        {
                                printf("Crashed\n");
//                                clear_keybuf();
//                                readkey();
                                dumpregs();
                                exit(-1);
                        }*/
                        temp=geteab();
                        setadd8(temp,getr8(reg));
                        temp+=getr8(reg);
                        seteab(temp);
                        cycles-=((mod==3)?3:24);
                        break;
                        case 0x01: /*ADD 16,reg*/
                        fetchea();
                        tempw=geteaw();
                        setadd16(tempw,regs[reg].w);
                        tempw+=regs[reg].w;
                        seteaw(tempw);
                        cycles-=((mod==3)?3:24);
                        break;
                        case 0x02: /*ADD reg,8*/
                        fetchea();
                        temp=geteab();
                        setadd8(getr8(reg),temp);
                        setr8(reg,getr8(reg)+temp);
                        cycles-=((mod==3)?3:13);
                        break;
                        case 0x03: /*ADD reg,16*/
                        fetchea();
                        tempw=geteaw();
                        setadd16(regs[reg].w,tempw);
                        regs[reg].w+=tempw;
                        cycles-=((mod==3)?3:13);
                        break;
                        case 0x04: /*ADD AL,#8*/
                        temp=FETCH();
                        setadd8(AL,temp);
                        AL+=temp;
                        cycles-=4;
                        break;
                        case 0x05: /*ADD AX,#16*/
                        tempw=getword();
                        setadd16(AX,tempw);
                        AX+=tempw;
                        cycles-=4;
                        break;

                        case 0x06: /*PUSH ES*/
                        if (ssegs) ss=oldss;
                        writememw(ss,((SP-2)&0xFFFF),ES);
                        SP-=2;
                        cycles-=14;
                        break;
                        case 0x07: /*POP ES*/
                        if (ssegs) ss=oldss;
                        tempw=readmemw(ss,SP);
                        loadseg(tempw,&_es);
                        SP+=2;
                        cycles-=12;
                        break;

                        case 0x08: /*OR 8,reg*/
                        fetchea();
                        temp=geteab();
                        temp|=getr8(reg);
                        setznp8(temp);
                        flags&=~(C_FLAG|V_FLAG|A_FLAG);
                        seteab(temp);
                        cycles-=((mod==3)?3:24);
                        break;
                        case 0x09: /*OR 16,reg*/
                        fetchea();
                        tempw=geteaw();
                        tempw|=regs[reg].w;
                        setznp16(tempw);
                        flags&=~(C_FLAG|V_FLAG|A_FLAG);
                        seteaw(tempw);
                        cycles-=((mod==3)?3:24);
                        break;
                        case 0x0A: /*OR reg,8*/
                        fetchea();
                        temp=geteab();
                        temp|=getr8(reg);
                        setznp8(temp);
                        flags&=~(C_FLAG|V_FLAG|A_FLAG);
                        setr8(reg,temp);
                        cycles-=((mod==3)?3:13);
                        break;
                        case 0x0B: /*OR reg,16*/
                        fetchea();
                        tempw=geteaw();
                        tempw|=regs[reg].w;
                        setznp16(tempw);
                        flags&=~(C_FLAG|V_FLAG|A_FLAG);
                        regs[reg].w=tempw;
                        cycles-=((mod==3)?3:13);
                        break;
                        case 0x0C: /*OR AL,#8*/
                        AL|=FETCH();
                        setznp8(AL);
                        flags&=~(C_FLAG|V_FLAG|A_FLAG);
                        cycles-=4;
                        break;
                        case 0x0D: /*OR AX,#16*/
                        AX|=getword();
                        setznp16(AX);
                        flags&=~(C_FLAG|V_FLAG|A_FLAG);
                        cycles-=4;
                        break;

                        case 0x0E: /*PUSH CS*/
                        if (ssegs) ss=oldss;
                        writememw(ss,((SP-2)&0xFFFF),CS);
                        SP-=2;
                        cycles-=14;
                        break;
                        case 0x0F: /*POP CS - 8088/8086 only*/
                        if (ssegs) ss=oldss;
                        tempw=readmemw(ss,SP);
                        loadseg(tempw,&_cs);
                        SP+=2;
                        cycles-=12;
                        break;

                        case 0x66:
                        pc--;
                                        if (ssegs) ss=oldss;
                                        writememw(ss,((SP-2)&0xFFFF),flags|0xF000);
                                        writememw(ss,((SP-4)&0xFFFF),CS);
                                        writememw(ss,((SP-6)&0xFFFF),pc);
                                        SP-=6;
                                        flags&=~T_FLAG;
                                        addr=6<<2;
//                                        flags&=~I_FLAG;
                                        pc=readmemw(0,addr);
//                                        printf("0x66\n");
                                        loadcs(readmemw(0,addr+2));
                                        if (!pc && !cs)
                                        {
                                                printf("Bad int %02X %04X:%04X\n",temp,oldcs,oldpc);
                                                dumpregs();
                                                exit(-1);
                                        }
                                cycles-=70;
                                FETCHCLEAR();
                                break;

                        case 0x10: /*ADC 8,reg*/
                        fetchea();
                        temp=geteab();
                        temp2=getr8(reg);
                        setadc8(temp,temp2);
                        temp+=temp2+tempc;
                        seteab(temp);
                        cycles-=((mod==3)?3:24);
                        break;
                        case 0x11: /*ADC 16,reg*/
                        fetchea();
                        tempw=geteaw();
                        tempw2=regs[reg].w;
                        setadc16(tempw,tempw2);
                        tempw+=tempw2+tempc;
                        seteaw(tempw);
                        cycles-=((mod==3)?3:24);
                        break;
                        case 0x12: /*ADC reg,8*/
                        fetchea();
                        temp=geteab();
                        setadc8(getr8(reg),temp);
                        setr8(reg,getr8(reg)+temp+tempc);
                        cycles-=((mod==3)?3:13);
                        break;
                        case 0x13: /*ADC reg,16*/
                        fetchea();
                        tempw=geteaw();
                        setadc16(regs[reg].w,tempw);
                        regs[reg].w+=tempw+tempc;
                        cycles-=((mod==3)?3:13);
                        break;
                        case 0x14: /*ADC AL,#8*/
                        tempw=FETCH();
                        setadc8(AL,tempw);
                        AL+=tempw+tempc;
                        cycles-=4;
                        break;
                        case 0x15: /*ADC AX,#16*/
                        tempw=getword();
                        setadc16(AX,tempw);
                        AX+=tempw+tempc;
                        cycles-=4;
                        break;

                        case 0x16: /*PUSH SS*/
                        if (ssegs) ss=oldss;
                        writememw(ss,((SP-2)&0xFFFF),SS);
                        SP-=2;
                        cycles-=14;
                        break;
                        case 0x17: /*POP SS*/
                        if (ssegs) ss=oldss;
                        tempw=readmemw(ss,SP);
                        loadseg(tempw,&_ss);
                        SP+=2;
                        noint=1;
                        cycles-=12;
//                        output=1;
                        break;

                        case 0x18: /*SBB 8,reg*/
                        fetchea();
                        temp=geteab();
                        temp2=getr8(reg);
                        setsbc8(temp,temp2);
                        temp-=(temp2+tempc);
                        seteab(temp);
                        cycles-=((mod==3)?3:24);
                        break;
                        case 0x19: /*SBB 16,reg*/
                        fetchea();
                        tempw=geteaw();
                        tempw2=regs[reg].w;
//                        printf("%04X:%04X SBB %04X-%04X,%i\n",cs>>4,pc,tempw,tempw2,tempc);
                        setsbc16(tempw,tempw2);
                        tempw-=(tempw2+tempc);
                        seteaw(tempw);
                        cycles-=((mod==3)?3:24);
                        break;
                        case 0x1A: /*SBB reg,8*/
                        fetchea();
                        temp=geteab();
                        setsbc8(getr8(reg),temp);
                        setr8(reg,getr8(reg)-(temp+tempc));
                        cycles-=((mod==3)?3:13);
                        break;
                        case 0x1B: /*SBB reg,16*/
                        fetchea();
                        tempw=geteaw();
                        tempw2=regs[reg].w;
//                        printf("%04X:%04X SBB %04X-%04X,%i\n",cs>>4,pc,tempw,tempw2,tempc);
                        setsbc16(tempw2,tempw);
                        tempw2-=(tempw+tempc);
                        regs[reg].w=tempw2;
                        cycles-=((mod==3)?3:13);
                        break;
                        case 0x1C: /*SBB AL,#8*/
                        temp=FETCH();
                        setsbc8(AL,temp);
                        AL-=(temp+tempc);
                        cycles-=4;
                        break;
                        case 0x1D: /*SBB AX,#16*/
                        tempw=getword();
                        setsbc16(AX,tempw);
                        AX-=(tempw+tempc);
                        cycles-=4;
                        break;

                        case 0x1E: /*PUSH DS*/
                        if (ssegs) ss=oldss;
                        writememw(ss,((SP-2)&0xFFFF),DS);
                        SP-=2;
                        cycles-=14;
                        break;
                        case 0x1F: /*POP DS*/
                        if (ssegs) ss=oldss;
                        tempw=readmemw(ss,SP);
                        loadseg(tempw,&_ds);
                        if (ssegs) oldds=ds;
                        SP+=2;
                        cycles-=12;
                        break;

                        case 0x20: /*AND 8,reg*/
                        fetchea();
                        temp=geteab();
                        temp&=getr8(reg);
                        setznp8(temp);
                        flags&=~(C_FLAG|V_FLAG|A_FLAG);
                        seteab(temp);
                        cycles-=((mod==3)?3:24);
                        break;
                        case 0x21: /*AND 16,reg*/
                        fetchea();
                        tempw=geteaw();
                        tempw&=regs[reg].w;
                        setznp16(tempw);
                        flags&=~(C_FLAG|V_FLAG|A_FLAG);
                        seteaw(tempw);
                        cycles-=((mod==3)?3:24);
                        break;
                        case 0x22: /*AND reg,8*/
                        fetchea();
                        temp=geteab();
                        temp&=getr8(reg);
                        setznp8(temp);
                        flags&=~(C_FLAG|V_FLAG|A_FLAG);
                        setr8(reg,temp);
                        cycles-=((mod==3)?3:13);
                        break;
                        case 0x23: /*AND reg,16*/
                        fetchea();
                        tempw=geteaw();
                        tempw&=regs[reg].w;
                        setznp16(tempw);
                        flags&=~(C_FLAG|V_FLAG|A_FLAG);
                        regs[reg].w=tempw;
                        cycles-=((mod==3)?3:13);
                        break;
                        case 0x24: /*AND AL,#8*/
                        AL&=FETCH();
                        setznp8(AL);
                        flags&=~(C_FLAG|V_FLAG|A_FLAG);
                        cycles-=4;
                        break;
                        case 0x25: /*AND AX,#16*/
                        AX&=getword();
                        setznp16(AX);
                        flags&=~(C_FLAG|V_FLAG|A_FLAG);
                        cycles-=4;
                        break;

                        case 0x26: /*ES:*/
                        oldss=ss;
                        oldds=ds;
                        ds=ss=es;
                        ssegs=2;
                        cycles-=4;
                        goto opcodestart;
//                        break;

                        case 0x27: /*DAA*/
                        if ((flags&A_FLAG) || ((AL&0xF)>9))
                        {
                                tempi=((unsigned short)AL)+6;
                                AL+=6;
                                flags|=A_FLAG;
                                if (tempi&0x100) flags|=C_FLAG;
                        }
//                        else
//                           flags&=~A_FLAG;
                        if ((flags&C_FLAG) || (AL>0x9F))
                        {
                                AL+=0x60;
                                flags|=C_FLAG;
                        }
//                        else
//                           flags&=~C_FLAG;
                        setznp8(AL);
                        cycles-=4;
                        break;

                        case 0x28: /*SUB 8,reg*/
                        fetchea();
                        temp=geteab();
                        setsub8(temp,getr8(reg));
                        temp-=getr8(reg);
                        seteab(temp);
                        cycles-=((mod==3)?3:24);
                        break;
                        case 0x29: /*SUB 16,reg*/
                        fetchea();
                        tempw=geteaw();
//                        printf("%04X:%04X  %04X-%04X\n",cs>>4,pc,tempw,regs[reg].w);
                        setsub16(tempw,regs[reg].w);
                        tempw-=regs[reg].w;
                        seteaw(tempw);
                        cycles-=((mod==3)?3:24);
                        break;
                        case 0x2A: /*SUB reg,8*/
                        fetchea();
                        temp=geteab();
                        setsub8(getr8(reg),temp);
                        setr8(reg,getr8(reg)-temp);
                        cycles-=((mod==3)?3:13);
                        break;
                        case 0x2B: /*SUB reg,16*/
                        fetchea();
                        tempw=geteaw();
//                        printf("%04X:%04X  %04X-%04X\n",cs>>4,pc,regs[reg].w,tempw);
                        setsub16(regs[reg].w,tempw);
                        regs[reg].w-=tempw;
                        cycles-=((mod==3)?3:13);
                        break;
                        case 0x2C: /*SUB AL,#8*/
                        temp=FETCH();
                        setsub8(AL,temp);
                        AL-=temp;
                        cycles-=4;
                        break;
                        case 0x2D: /*SUB AX,#16*/
//                        printf("INS %i\n",ins);
//                        output=1;
                        tempw=getword();
                        setsub16(AX,tempw);
                        AX-=tempw;
                        cycles-=4;
                        break;
                        case 0x2E: /*CS:*/
                        oldss=ss;
                        oldds=ds;
                        ds=ss=cs;
                        ssegs=2;
                        cycles-=4;
                        goto opcodestart;
                        case 0x2F: /*DAS*/
                        if ((flags&A_FLAG)||((AL&0xF)>9))
                        {
                                tempi=((unsigned short)AL)-6;
                                AL-=6;
                                flags|=A_FLAG;
                                if (tempi&0x100) flags|=C_FLAG;
                        }
//                        else
//                           flags&=~A_FLAG;
                        if ((flags&C_FLAG)||(AL>0x9F))
                        {
                                AL-=0x60;
                                flags|=C_FLAG;
                        }
//                        else
//                           flags&=~C_FLAG;
                        setznp8(AL);
                        cycles-=4;
                        break;
                        case 0x30: /*XOR 8,reg*/
                        fetchea();
                        temp=geteab();
                        temp^=getr8(reg);
                        setznp8(temp);
                        flags&=~(C_FLAG|V_FLAG|A_FLAG);
                        seteab(temp);
                        cycles-=((mod==3)?3:24);
                        break;
                        case 0x31: /*XOR 16,reg*/
                        fetchea();
                        tempw=geteaw();
                        tempw^=regs[reg].w;
                        setznp16(tempw);
                        flags&=~(C_FLAG|V_FLAG|A_FLAG);
                        seteaw(tempw);
                        cycles-=((mod==3)?3:24);
                        break;
                        case 0x32: /*XOR reg,8*/
                        fetchea();
                        temp=geteab();
                        temp^=getr8(reg);
                        setznp8(temp);
                        flags&=~(C_FLAG|V_FLAG|A_FLAG);
                        setr8(reg,temp);
                        cycles-=((mod==3)?3:13);
                        break;
                        case 0x33: /*XOR reg,16*/
                        fetchea();
                        tempw=geteaw();
                        tempw^=regs[reg].w;
                        setznp16(tempw);
                        flags&=~(C_FLAG|V_FLAG|A_FLAG);
                        regs[reg].w=tempw;
                        cycles-=((mod==3)?3:13);
                        break;
                        case 0x34: /*XOR AL,#8*/
                        AL^=FETCH();
                        setznp8(AL);
                        flags&=~(C_FLAG|V_FLAG|A_FLAG);
                        cycles-=4;
                        break;
                        case 0x35: /*XOR AX,#16*/
                        AX^=getword();
                        setznp16(AX);
                        flags&=~(C_FLAG|V_FLAG|A_FLAG);
                        cycles-=4;
                        break;

                        case 0x36: /*SS:*/
                        oldss=ss;
                        oldds=ds;
                        ds=ss=ss;
                        ssegs=2;
                        cycles-=4;
                        goto opcodestart;
//                        break;

                        case 0x37: /*AAA*/
                        if ((flags&A_FLAG)||((AL&0xF)>9))
                        {
                                AL+=6;
                                AH++;
                                flags|=(A_FLAG|C_FLAG);
                        }
                        else
                           flags&=~(A_FLAG|C_FLAG);
                        AL&=0xF;
                        cycles-=8;
                        break;

                        case 0x38: /*CMP 8,reg*/
                        fetchea();
                        temp=geteab();
//                        if (output) printf("CMP %02X-%02X\n",temp,getr8(reg));
                        setsub8(temp,getr8(reg));
                        cycles-=((mod==3)?3:13);
                        break;
                        case 0x39: /*CMP 16,reg*/
                        fetchea();
                        tempw=geteaw();
//                        if (output) printf("CMP %04X-%04X\n",tempw,regs[reg].w);
                        setsub16(tempw,regs[reg].w);
                        cycles-=((mod==3)?3:13);
                        break;
                        case 0x3A: /*CMP reg,8*/
                        fetchea();
                        temp=geteab();
//                        if (output) printf("CMP %02X-%02X\n",getr8(reg),temp);
                        setsub8(getr8(reg),temp);
                        cycles-=((mod==3)?3:13);
                        break;
                        case 0x3B: /*CMP reg,16*/
                        fetchea();
                        tempw=geteaw();
//                        printf("CMP %04X-%04X\n",regs[reg].w,tempw);
                        setsub16(regs[reg].w,tempw);
                        cycles-=((mod==3)?3:13);
                        break;
                        case 0x3C: /*CMP AL,#8*/
                        temp=FETCH();
                        setsub8(AL,temp);
                        cycles-=4;
                        break;
                        case 0x3D: /*CMP AX,#16*/
                        tempw=getword();
                        setsub16(AX,tempw);
                        cycles-=4;
                        break;

                        case 0x3E: /*DS:*/
                        oldss=ss;
                        oldds=ds;
                        ds=ss=ds;
                        ssegs=2;
                        cycles-=4;
                        goto opcodestart;
//                        break;

                        case 0x3F: /*AAS*/
                        if ((flags&A_FLAG)||((AL&0xF)>9))
                        {
                                AL-=6;
                                AH--;
                                flags|=(A_FLAG|C_FLAG);
                        }
                        else
                           flags&=~(A_FLAG|C_FLAG);
                        AL&=0xF;
                        cycles-=8;
                        break;

                        case 0x40: case 0x41: case 0x42: case 0x43: /*INC r16*/
                        case 0x44: case 0x45: case 0x46: case 0x47:
                        setadd16nc(regs[opcode&7].w,1);
                        regs[opcode&7].w++;
                        cycles-=3;
                        break;
                        case 0x48: case 0x49: case 0x4A: case 0x4B: /*DEC r16*/
                        case 0x4C: case 0x4D: case 0x4E: case 0x4F:
                        setsub16nc(regs[opcode&7].w,1);
                        regs[opcode&7].w--;
                        cycles-=3;
                        break;

                        case 0x50: case 0x51: case 0x52: case 0x53: /*PUSH r16*/
                        case 0x54: case 0x55: case 0x56: case 0x57:
                        if (ssegs) ss=oldss;
                        SP-=2;
                        writememw(ss,SP,regs[opcode&7].w);
                        cycles-=15;
                        break;
                        case 0x58: case 0x59: case 0x5A: case 0x5B: /*POP r16*/
                        case 0x5C: case 0x5D: case 0x5E: case 0x5F:
                        if (ssegs) ss=oldss;
                        SP+=2;
                        regs[opcode&7].w=readmemw(ss,(SP-2)&0xFFFF);
                        cycles-=12;
                        break;


                        case 0x70: /*JO*/
                        offset=(signed char)FETCH();
                        if (flags&V_FLAG) { pc+=offset; cycles-=12; FETCHCLEAR(); }
                        cycles-=4;
                        break;
                        case 0x71: /*JNO*/
                        offset=(signed char)FETCH();
                        if (!(flags&V_FLAG)) { pc+=offset; cycles-=12; FETCHCLEAR(); }
                        cycles-=4;
                        break;
                        case 0x72: /*JB*/
                        offset=(signed char)FETCH();
                        if (flags&C_FLAG) { pc+=offset; cycles-=12; FETCHCLEAR(); }
                        cycles-=4;
                        break;
                        case 0x73: /*JNB*/
                        offset=(signed char)FETCH();
                        if (!(flags&C_FLAG)) { pc+=offset; cycles-=12; FETCHCLEAR(); }
                        cycles-=4;
                        break;
                        case 0x74: /*JZ*/
                        offset=(signed char)FETCH();
                        if (flags&Z_FLAG) { pc+=offset; cycles-=12; FETCHCLEAR(); }
                        cycles-=4;
                        break;
                        case 0x75: /*JNZ*/
                        offset=(signed char)FETCH();
                        if (!(flags&Z_FLAG)) { pc+=offset; cycles-=12; FETCHCLEAR(); }
                        cycles-=4;
                        break;
                        case 0x76: /*JBE*/
                        offset=(signed char)FETCH();
                        if (flags&(C_FLAG|Z_FLAG)) { pc+=offset; cycles-=12; FETCHCLEAR(); }
                        cycles-=4;
                        break;
                        case 0x77: /*JNBE*/
                        offset=(signed char)FETCH();
                        if (!(flags&(C_FLAG|Z_FLAG))) { pc+=offset; cycles-=12; FETCHCLEAR(); }
                        cycles-=4;
                        break;
                        case 0x78: /*JS*/
                        offset=(signed char)FETCH();
                        if (flags&N_FLAG)  { pc+=offset; cycles-=12; FETCHCLEAR(); }
                        cycles-=4;
                        break;
                        case 0x79: /*JNS*/
                        offset=(signed char)FETCH();
                        if (!(flags&N_FLAG))  { pc+=offset; cycles-=12; FETCHCLEAR(); }
                        cycles-=4;
                        break;
                        case 0x7A: /*JP*/
                        offset=(signed char)FETCH();
                        if (flags&P_FLAG)  { pc+=offset; cycles-=12; FETCHCLEAR(); }
                        cycles-=4;
                        break;
                        case 0x7B: /*JNP*/
                        offset=(signed char)FETCH();
                        if (!(flags&P_FLAG))  { pc+=offset; cycles-=12; FETCHCLEAR(); }
                        cycles-=4;
                        break;
                        case 0x7C: /*JL*/
                        offset=(signed char)FETCH();
                        temp=(flags&N_FLAG)?1:0;
                        temp2=(flags&V_FLAG)?1:0;
                        if (temp!=temp2)  { pc+=offset; cycles-=12; FETCHCLEAR(); }
                        cycles-=4;
                        break;
                        case 0x7D: /*JNL*/
                        offset=(signed char)FETCH();
                        temp=(flags&N_FLAG)?1:0;
                        temp2=(flags&V_FLAG)?1:0;
                        if (temp==temp2)  { pc+=offset; cycles-=12; FETCHCLEAR(); }
                        cycles-=4;
                        break;
                        case 0x7E: /*JLE*/
                        offset=(signed char)FETCH();
                        temp=(flags&N_FLAG)?1:0;
                        temp2=(flags&V_FLAG)?1:0;
                        if ((flags&Z_FLAG) || (temp!=temp2))  { pc+=offset; cycles-=12; FETCHCLEAR(); }
                        cycles-=4;
                        break;
                        case 0x7F: /*JNLE*/
                        offset=(signed char)FETCH();
                        temp=(flags&N_FLAG)?1:0;
                        temp2=(flags&V_FLAG)?1:0;
                        if (!((flags&Z_FLAG) || (temp!=temp2)))  { pc+=offset; cycles-=12; FETCHCLEAR(); }
                        cycles-=4;
                        break;

                        case 0x80: case 0x82:
                        fetchea();
                        temp=geteab();
                        temp2=FETCH();
                        switch (rmdat&0x38)
                        {
                                case 0x00: /*ADD b,#8*/
                                setadd8(temp,temp2);
                                seteab(temp+temp2);
                                cycles-=((mod==3)?4:23);
                                break;
                                case 0x08: /*OR b,#8*/
                                temp|=temp2;
                                setznp8(temp);
                                flags&=~(C_FLAG|V_FLAG|A_FLAG);
                                seteab(temp);
                                cycles-=((mod==3)?4:23);
                                break;
                                case 0x10: /*ADC b,#8*/
//                                temp2+=(flags&C_FLAG);
                                setadc8(temp,temp2);
                                seteab(temp+temp2+tempc);
                                cycles-=((mod==3)?4:23);
                                break;
                                case 0x18: /*SBB b,#8*/
//                                temp2+=(flags&C_FLAG);
                                setsbc8(temp,temp2);
                                seteab(temp-(temp2+tempc));
                                cycles-=((mod==3)?4:23);
                                break;
                                case 0x20: /*AND b,#8*/
                                temp&=temp2;
                                setznp8(temp);
                                flags&=~(C_FLAG|V_FLAG|A_FLAG);
                                seteab(temp);
                                cycles-=((mod==3)?4:23);
                                break;
                                case 0x28: /*SUB b,#8*/
                                setsub8(temp,temp2);
                                seteab(temp-temp2);
                                cycles-=((mod==3)?4:23);
                                break;
                                case 0x30: /*XOR b,#8*/
                                temp^=temp2;
                                setznp8(temp);
                                flags&=~(C_FLAG|V_FLAG|A_FLAG);
                                seteab(temp);
                                cycles-=((mod==3)?4:23);
                                break;
                                case 0x38: /*CMP b,#8*/
                                setsub8(temp,temp2);
                                cycles-=((mod==3)?4:14);
                                break;

                                default:
                                printf("Bad 80 opcode %02X\n",rmdat&0x38);
//                                dumpregs();
//                                exit(-1);
                        }
                        break;

                        case 0x81:
                        fetchea();
                        tempw=geteaw();
                        tempw2=getword();
                        switch (rmdat&0x38)
                        {
                                case 0x00: /*ADD w,#16*/
                                setadd16(tempw,tempw2);
                                tempw+=tempw2;
                                seteaw(tempw);
                                cycles-=((mod==3)?4:23);
                                break;
                                case 0x08: /*OR w,#16*/
                                tempw|=tempw2;
                                setznp16(tempw);
                                flags&=~(C_FLAG|V_FLAG|A_FLAG);
                                seteaw(tempw);
                                cycles-=((mod==3)?4:23);
                                break;
                                case 0x10: /*ADC w,#16*/
//                                tempw2+=(flags&C_FLAG);
                                setadc16(tempw,tempw2);
                                tempw+=tempw2+tempc;
                                seteaw(tempw);
                                cycles-=((mod==3)?4:23);
                                break;
                                case 0x20: /*AND w,#16*/
                                tempw&=tempw2;
                                setznp16(tempw);
                                flags&=~(C_FLAG|V_FLAG|A_FLAG);
                                seteaw(tempw);
                                cycles-=((mod==3)?4:23);
                                break;
                                case 0x18: /*SBB w,#16*/
//                                tempw2+=(flags&C_FLAG);
                                setsbc16(tempw,tempw2);
                                seteaw(tempw-(tempw2+tempc));
                                cycles-=((mod==3)?4:23);
                                break;
                                case 0x28: /*SUB w,#16*/
                                setsub16(tempw,tempw2);
                                tempw-=tempw2;
                                seteaw(tempw);
                                cycles-=((mod==3)?4:23);
                                break;
                                case 0x30: /*XOR w,#16*/
                                tempw^=tempw2;
                                setznp16(tempw);
                                flags&=~(C_FLAG|V_FLAG|A_FLAG);
                                seteaw(tempw);
                                cycles-=((mod==3)?4:23);
                                break;
                                case 0x38: /*CMP w,#16*/
//                                printf("CMP %04X %04X\n",tempw,tempw2);
                                setsub16(tempw,tempw2);
                                cycles-=((mod==3)?4:14);
                                break;

                                default:
                                printf("Bad 81 opcode %02X\n",rmdat&0x38);
//                                dumpregs();
//                                exit(-1);
                        }
                        break;

                        case 0x83:
                        fetchea();
                        tempw=geteaw();
                        tempw2=FETCH();
                        if (tempw2&0x80) tempw2|=0xFF00;
                        switch (rmdat&0x38)
                        {
                                case 0x00: /*ADD w,#8*/
                                setadd16(tempw,tempw2);
                                tempw+=tempw2;
                                seteaw(tempw);
                                cycles-=((mod==3)?4:23);
                                break;
                                case 0x08: /*OR w,#8*/
                                tempw|=tempw2;
                                setznp16(tempw);
                                seteaw(tempw);
                                flags&=~(C_FLAG|A_FLAG|V_FLAG);
                                cycles-=((mod==3)?4:23);
                                break;
                                case 0x10: /*ADC w,#8*/
//                                tempw2+=(flags&C_FLAG);
                                setadc16(tempw,tempw2);
                                tempw+=tempw2+tempc;
                                seteaw(tempw);
                                cycles-=((mod==3)?4:23);
                                break;
                                case 0x18: /*SBB w,#8*/
//                                tempw2+=(flags&C_FLAG);
                                setsbc16(tempw,tempw2);
                                tempw-=(tempw2+tempc);
                                seteaw(tempw);
                                cycles-=((mod==3)?4:23);
                                break;
                                case 0x20: /*AND w,#8*/
                                tempw&=tempw2;
                                setznp16(tempw);
                                seteaw(tempw);
                                cycles-=((mod==3)?4:23);
                                flags&=~(C_FLAG|A_FLAG|V_FLAG);
                                break;
                                case 0x28: /*SUB w,#8*/
                                setsub16(tempw,tempw2);
                                tempw-=tempw2;
                                seteaw(tempw);
                                cycles-=((mod==3)?4:23);
                                break;
                                case 0x30: /*XOR w,#8*/
                                tempw^=tempw2;
                                setznp16(tempw);
                                seteaw(tempw);
                                cycles-=((mod==3)?4:23);
                                flags&=~(C_FLAG|A_FLAG|V_FLAG);
                                break;
                                case 0x38: /*CMP w,#8*/
                                setsub16(tempw,tempw2);
                                cycles-=((mod==3)?4:14);
                                break;

                                default:
                                printf("Bad 83 opcode %02X\n",rmdat&0x38);
//                                dumpregs();
//                                exit(-1);
                        }
                        break;

                        case 0x84: /*TEST b,reg*/
                        fetchea();
                        temp=geteab();
                        temp2=getr8(reg);
                        setznp8(temp&temp2);
                        flags&=~(C_FLAG|V_FLAG|A_FLAG);
                        cycles-=((mod==3)?3:13);
                        break;
                        case 0x85: /*TEST w,reg*/
                        fetchea();
                        tempw=geteaw();
                        tempw2=regs[reg].w;
                        setznp16(tempw&tempw2);
                        flags&=~(C_FLAG|V_FLAG|A_FLAG);
                        cycles-=((mod==3)?3:13);
                        break;
                        case 0x86: /*XCHG b,reg*/
                        fetchea();
                        temp=geteab();
                        seteab(getr8(reg));
                        setr8(reg,temp);
                        cycles-=((mod==3)?4:25);
                        break;
                        case 0x87: /*XCHG w,reg*/
                        fetchea();
                        tempw=geteaw();
                        seteaw(regs[reg].w);
                        regs[reg].w=tempw;
                        cycles-=((mod==3)?4:25);
                        break;

                        case 0x88: /*MOV b,reg*/
                        fetchea();
                        seteab(getr8(reg));
                        cycles-=((mod==3)?2:13);
                        break;
                        case 0x89: /*MOV w,reg*/
                        fetchea();
                        seteaw(regs[reg].w);
                        cycles-=((mod==3)?2:13);
                        break;
                        case 0x8A: /*MOV reg,b*/
                        fetchea();
                        temp=geteab();
                        setr8(reg,temp);
                        cycles-=((mod==3)?2:12);
                        break;
                        case 0x8B: /*MOV reg,w*/
                        fetchea();
                        tempw=geteaw();
                        regs[reg].w=tempw;
                        cycles-=((mod==3)?2:12);
                        break;

                        case 0x8C: /*MOV w,sreg*/
                        fetchea();
                        switch (rmdat&0x38)
                        {
                                case 0x00: /*ES*/
                                seteaw(ES);
                                break;
                                case 0x08: /*CS*/
                                seteaw(CS);
                                break;
                                case 0x18: /*DS*/
                                if (ssegs) ds=oldds;
                                seteaw(DS);
                                break;
                                case 0x10: /*SS*/
                                if (ssegs) ss=oldss;
                                seteaw(SS);
                                break;
                        }
                        cycles-=((mod==3)?2:13);
                        break;

                        case 0x8D: /*LEA*/
                        fetchea();
                        regs[reg].w=eaaddr;
                        cycles-=2;
                        break;

                        case 0x8E: /*MOV sreg,w*/
//                        if (output) printf("MOV %04X  ",pc);
                        fetchea();
//                        if (output) printf("%04X %02X\n",pc,rmdat);
                        switch (rmdat&0x38)
                        {
                                case 0x00: /*ES*/
                                tempw=geteaw();
                                loadseg(tempw,&_es);
                                break;
                                case 0x08: /*CS - 8088/8086 only*/
                                tempw=geteaw();
                                loadseg(tempw,&_cs);
                                break;
                                case 0x18: /*DS*/
                                tempw=geteaw();
                                loadseg(tempw,&_ds);
                                if (ssegs) oldds=ds;
                                break;
                                case 0x10: /*SS*/
                                tempw=geteaw();
                                loadseg(tempw,&_ss);
                                if (ssegs) oldss=ss;
//                                printf("LOAD SS %04X %04X\n",tempw,SS);
//				printf("SS loaded with %04X %04X:%04X %04X %04X %04X\n",ss>>4,cs>>4,pc,CX,DX,es>>4);
                                break;
                        }
                        cycles-=((mod==3)?2:12);
                                skipnextprint=1;
				noint=1;
                        break;

                        case 0x8F: /*POPW*/
                        fetchea();
                        if (ssegs) ss=oldss;
                        tempw=readmemw(ss,SP);
                        SP+=2;
                        seteaw(tempw);
                        cycles-=25;
                        break;

                        case 0x90: /*NOP*/
                        cycles-=3;
                        break;

                        case 0x91: case 0x92: case 0x93: /*XCHG AX*/
                        case 0x94: case 0x95: case 0x96: case 0x97:
                        tempw=AX;
                        AX=regs[opcode&7].w;
                        regs[opcode&7].w=tempw;
                        cycles-=3;
                        break;

                        case 0x98: /*CBW*/
                        AH=(AL&0x80)?0xFF:0;
                        cycles-=2;
                        break;
                        case 0x99: /*CWD*/
                        DX=(AX&0x8000)?0xFFFF:0;
                        cycles-=5;
                        break;
                        case 0x9A: /*CALL FAR*/
                        tempw=getword();
                        tempw2=getword();
                        tempw3=CS;
                        tempw4=pc;
                        if (ssegs) ss=oldss;
                        pc=tempw;
//                        printf("0x9a");
                        loadcs(tempw2);
                        writememw(ss,(SP-2)&0xFFFF,tempw3);
                        writememw(ss,(SP-4)&0xFFFF,tempw4);
                        SP-=4;
                        cycles-=36;
                        FETCHCLEAR();
                        break;
                        case 0x9B: /*WAIT*/
                        cycles-=4;
                        break;
                        case 0x9C: /*PUSHF*/
                        if (ssegs) ss=oldss;
                        writememw(ss,((SP-2)&0xFFFF),flags|0xF000);
                        SP-=2;
                        cycles-=14;
                        break;
                        case 0x9D: /*POPF*/
                        if (ssegs) ss=oldss;
                        flags=readmemw(ss,SP)&0xFFF;
                        SP+=2;
                        cycles-=12;
                        break;
                        case 0x9E: /*SAHF*/
                        flags=(flags&0xFF00)|AH;
                        cycles-=4;
                        break;
                        case 0x9F: /*LAHF*/
                        AH=flags&0xFF;
                        cycles-=4;
                        break;

                        case 0xA0: /*MOV AL,(w)*/
                        addr=getword();
                        AL=readmemb(ds+addr);
                        cycles-=14;
                        break;
                        case 0xA1: /*MOV AX,(w)*/
                        addr=getword();
//                        printf("Reading AX from %05X %04X:%04X\n",ds+addr,ds>>4,addr);
                        AX=readmemw(ds,addr);
                        cycles-=!4;
                        break;
                        case 0xA2: /*MOV (w),AL*/
                        addr=getword();
                        writememb(ds+addr,AL);
                        cycles-=14;
                        break;
                        case 0xA3: /*MOV (w),AX*/
                        addr=getword();
//                        if (!addr) printf("Write !addr %04X:%04X\n",cs>>4,pc);
                        writememw(ds,addr,AX);
                        cycles-=14;
                        break;

                        case 0xA4: /*MOVSB*/
                        temp=readmemb(ds+SI);
                        writememb(es+DI,temp);
                        if (flags&D_FLAG) { DI--; SI--; }
                        else              { DI++; SI++; }
                        cycles-=18;
                        break;
                        case 0xA5: /*MOVSW*/
                        tempw=readmemw(ds,SI);
                        writememw(es,DI,tempw);
                        if (flags&D_FLAG) { DI-=2; SI-=2; }
                        else              { DI+=2; SI+=2; }
                        cycles-=18;
                        break;
                        case 0xA6: /*CMPSB*/
                        temp =readmemb(ds+SI);
                        temp2=readmemb(es+DI);
                        setsub8(temp,temp2);
                        if (flags&D_FLAG) { DI--; SI--; }
                        else              { DI++; SI++; }
                        cycles-=30;
                        break;
                        case 0xA7: /*CMPSW*/
                        tempw =readmemw(ds,SI);
                        tempw2=readmemw(es,DI);
//                        printf("CMPSW %04X %04X\n",tempw,tempw2);
                        setsub16(tempw,tempw2);
                        if (flags&D_FLAG) { DI-=2; SI-=2; }
                        else              { DI+=2; SI+=2; }
                        cycles-=30;
                        break;
                        case 0xA8: /*TEST AL,#8*/
                        temp=FETCH();
                        setznp8(AL&temp);
                        flags&=~(C_FLAG|V_FLAG|A_FLAG);
                        cycles-=5;
                        break;
                        case 0xA9: /*TEST AX,#16*/
                        tempw=getword();
                        setznp16(AX&tempw);
                        flags&=~(C_FLAG|V_FLAG|A_FLAG);
                        cycles-=5;
                        break;
                        case 0xAA: /*STOSB*/
                        writememb(es+DI,AL);
                        if (flags&D_FLAG) DI--;
                        else              DI++;
                        cycles-=11;
                        break;
                        case 0xAB: /*STOSW*/
                        writememw(es,DI,AX);
                        if (flags&D_FLAG) DI-=2;
                        else              DI+=2;
                        cycles-=11;
                        break;
                        case 0xAC: /*LODSB*/
                        AL=readmemb(ds+SI);
//                        printf("LODSB %04X:%04X %02X %04X:%04X\n",cs>>4,pc,AL,ds>>4,SI);
                        if (flags&D_FLAG) SI--;
                        else              SI++;
                        cycles-=16;
                        break;
                        case 0xAD: /*LODSW*/
//                        if (times) printf("LODSW %04X:%04X\n",cs>>4,pc);
                        AX=readmemw(ds,SI);
                        if (flags&D_FLAG) SI-=2;
                        else              SI+=2;
                        cycles-=16;
                        break;
                        case 0xAE: /*SCASB*/
                        temp=readmemb(es+DI);
                        setsub8(AL,temp);
                        if (flags&D_FLAG) DI--;
                        else              DI++;
                        cycles-=19;
                        break;
                        case 0xAF: /*SCASW*/
                        tempw=readmemw(es,DI);
                        setsub16(AX,tempw);
                        if (flags&D_FLAG) DI-=2;
                        else              DI+=2;
                        cycles-=19;
                        break;

                        case 0xB0: /*MOV AL,#8*/
                        AL=FETCH();
                        cycles-=4;
                        break;
                        case 0xB1: /*MOV CL,#8*/
                        CL=FETCH();
                        cycles-=4;
                        break;
                        case 0xB2: /*MOV DL,#8*/
                        DL=FETCH();
                        cycles-=4;
                        break;
                        case 0xB3: /*MOV BL,#8*/
                        BL=FETCH();
                        cycles-=4;
                        break;
                        case 0xB4: /*MOV AH,#8*/
                        AH=FETCH();
                        cycles-=4;
                        break;
                        case 0xB5: /*MOV CH,#8*/
                        CH=FETCH();
                        cycles-=4;
                        break;
                        case 0xB6: /*MOV DH,#8*/
                        DH=FETCH();
                        cycles-=4;
                        break;
                        case 0xB7: /*MOV BH,#8*/
                        BH=FETCH();
                        cycles-=4;
                        break;
                        case 0xB8: case 0xB9: case 0xBA: case 0xBB: /*MOV reg,#16*/
                        case 0xBC: case 0xBD: case 0xBE: case 0xBF:
                        regs[opcode&7].w=getword();
                        cycles-=4;
                        break;

                        case 0xC2: /*RET*/
                        tempw=getword();
                        if (ssegs) ss=oldss;
                        pc=readmemw(ss,SP);
//                        printf("C2\n");
//                        printf("RET to %04X\n",pc);
                        SP+=2+tempw;
                        cycles-=24;
                        FETCHCLEAR();
                        break;
                        case 0xC3: /*RET*/
                        if (ssegs) ss=oldss;
                        pc=readmemw(ss,SP);
//                        printf("C3\n");
//                        if (output) printf("RET to %04X %05X\n",pc,ss+SP);
                        SP+=2;
                        cycles-=20;
                        FETCHCLEAR();
                        break;
                        case 0xC4: /*LES*/
                        fetchea();
                        regs[reg].w=readmemw(easeg,eaaddr); //geteaw();
                        tempw=readmemw(easeg,(eaaddr+2)&0xFFFF); //geteaw2();
                        loadseg(tempw,&_es);
                        cycles-=24;
                        break;
                        case 0xC5: /*LDS*/
                        fetchea();
                        regs[reg].w=readmemw(easeg,eaaddr);
                        tempw=readmemw(easeg,(eaaddr+2)&0xFFFF);
                        loadseg(tempw,&_ds);
                        if (ssegs) oldds=ds;
                        cycles-=24;
                        break;
                        case 0xC6: /*MOV b,#8*/
                        fetchea();
                        temp=FETCH();
                        seteab(temp);
                        cycles-=((mod==3)?4:14);
                        break;
                        case 0xC7: /*MOV w,#16*/
                        fetchea();
                        tempw=getword();
                        seteaw(tempw);
                        cycles-=((mod==3)?4:14);
                        break;

                        case 0xCA: /*RETF*/
                        tempw=getword();
                        if (ssegs) ss=oldss;
                        pc=readmemw(ss,SP);
//                        printf("CA\n");
                        loadcs(readmemw(ss,SP+2));
                        SP+=4;
                        SP+=tempw;
                        cycles-=33;
                        FETCHCLEAR();
                        break;
                        case 0xCB: /*RETF*/
                        if (ssegs) ss=oldss;
                        pc=readmemw(ss,SP);
//                        printf("CB\n");
                        loadcs(readmemw(ss,SP+2));
                        SP+=4;
                        cycles-=34;
                        FETCHCLEAR();
                        break;
                        case 0xCC: /*INT 3*/
                        if (ssegs) ss=oldss;
                        writememw(ss,((SP-2)&0xFFFF),flags|0xF000);
                        writememw(ss,((SP-4)&0xFFFF),CS);
                        writememw(ss,((SP-6)&0xFFFF),pc);
                        SP-=6;
                        addr=3<<2;
                        flags&=~I_FLAG;
                        flags&=~T_FLAG;
                        printf("CC %04X:%04X  ",CS,pc);
                        pc=readmemw(0,addr);
                        loadcs(readmemw(0,addr+2));
                        FETCHCLEAR();
                        printf("%04X:%04X\n",CS,pc);
                        cycles-=72;
                        break;
                        case 0xCD: /*INT*/
                        lastpc=pc;
                        lastcs=CS;
                        temp=FETCH();
//                        if (temp==0x10 && !AH) printf("Entering mode %02X\n",AL);
//                        if (temp==0x18 || temp==0x19) { printf("INT %02X\n",temp); output=1; }
//                        printf("INT %02X %04X %04X %04X %04X %04X:%04X\n",temp,AX,BX,CX,DX,CS,pc);
/*                        if (output)
                        {
                                dumpregs();
                                exit(-1);
                        }*/
/*                        if (temp==0x21) printf("INT 21 %04X %04X %04X %04X %04X:%04X %06X %06X\n",AX,BX,CX,DX,cs>>4,pc,ds,ds+DX);
                        if (temp==0x21 && AH==9)
                        {
                                addr=0;
                                while (ram[ds+DX+addr]!='$')
                                {
                                        printf("%c",ram[ds+DX+addr]);
                                        addr++;
                                }
                                printf("\n");
                                printf("Called from %04X\n",readmemw(ss,SP));
                        }*/
//                        output=0;
//                        if (temp==0x13 && AH==3) printf("Write sector %04X:%04X %05X\n",es>>4,BX,es+BX);
                        if (temp==0x13 && (DL==0x80 || DL==0x81) && AH>0)
                        {
                                int13hdc();
                        }
                        else if (temp==0x13 && AH==2 && DL<2 && FASTDISC)
                        {
                                int13read();
                                //output=1;
                        }
                        else if (temp==0x13 && AH==3 && DL<2 && FASTDISC)
                        {
                                int13write();
                        }
                        else if (temp==0x13 && AH==4 && DL<2 && FASTDISC)
                        {
                                AH=0;
                                flags&=~C_FLAG;
                        }
                        else
                        {
                                if (ssegs) ss=oldss;
                                writememw(ss,((SP-2)&0xFFFF),flags|0xF000);
                                writememw(ss,((SP-4)&0xFFFF),CS);
                                writememw(ss,((SP-6)&0xFFFF),pc);
                                flags&=~T_FLAG;
                                SP-=6;
                                addr=temp<<2;
                                pc=readmemw(0,addr);
//                        printf("CD\n");
                                loadcs(readmemw(0,addr+2));
                                if (!pc && !cs)
                                {
                                        printf("Bad int %02X %04X:%04X\n",temp,oldcs,oldpc);
                                        dumpregs();
                                        exit(-1);
                                }
                                FETCHCLEAR();
                        }
                        cycles-=71;
                        break;
                        case 0xCF: /*IRET*/
                        if (ssegs) ss=oldss;
                        tempw=CS;
                        tempw2=pc;
                        inint=0;
                        pc=readmemw(ss,SP);
//                        printf("CF\n");
                        loadcs(readmemw(ss,((SP+2)&0xFFFF)));
                        flags=readmemw(ss,((SP+4)&0xFFFF))&0xFFF;
                        SP+=6;
                        cycles-=44;
                        FETCHCLEAR();
                        break;
                        case 0xD0:
                        fetchea();
                        temp=geteab();
                        switch (rmdat&0x38)
                        {
                                case 0x00: /*ROL b,1*/
                                if (temp&0x80) flags|=C_FLAG;
                                else           flags&=~C_FLAG;
                                temp<<=1;
                                if (flags&C_FLAG) temp|=1;
                                seteab(temp);
//                                setznp8(temp);
                                if ((flags&C_FLAG)^(temp>>7)) flags|=V_FLAG;
                                else                          flags&=~V_FLAG;
                                cycles-=((mod==3)?2:23);
                                break;
                                case 0x08: /*ROR b,1*/
                                if (temp&1) flags|=C_FLAG;
                                else        flags&=~C_FLAG;
                                temp>>=1;
                                if (flags&C_FLAG) temp|=0x80;
                                seteab(temp);
//                                setznp8(temp);
                                if ((temp^(temp>>1))&0x40) flags|=V_FLAG;
                                else                       flags&=~V_FLAG;
                                cycles-=((mod==3)?2:23);
                                break;
                                case 0x10: /*RCL b,1*/
                                temp2=flags&C_FLAG;
                                if (temp&0x80) flags|=C_FLAG;
                                else           flags&=~C_FLAG;
                                temp<<=1;
                                if (temp2) temp|=1;
                                seteab(temp);
//                                setznp8(temp);
                                if ((flags&C_FLAG)^(temp>>7)) flags|=V_FLAG;
                                else                          flags&=~V_FLAG;
                                cycles-=((mod==3)?2:23);
                                break;
                                case 0x18: /*RCR b,1*/
                                temp2=flags&C_FLAG;
                                if (temp&1) flags|=C_FLAG;
                                else        flags&=~C_FLAG;
                                temp>>=1;
                                if (temp2) temp|=0x80;
                                seteab(temp);
//                                setznp8(temp);
                                if ((temp^(temp>>1))&0x40) flags|=V_FLAG;
                                else                       flags&=~V_FLAG;
                                cycles-=((mod==3)?2:23);
                                break;
                                case 0x20: /*SHL b,1*/
                                if (temp&0x80) flags|=C_FLAG;
                                else           flags&=~C_FLAG;
                                if ((temp^(temp<<1))&0x80) flags|=V_FLAG;
                                else                       flags&=~V_FLAG;
                                temp<<=1;
                                seteab(temp);
                                setznp8(temp);
                                cycles-=((mod==3)?2:23);
                                flags|=A_FLAG;
                                break;
                                case 0x28: /*SHR b,1*/
                                if (temp&1) flags|=C_FLAG;
                                else        flags&=~C_FLAG;
                                if (temp&0x80) flags|=V_FLAG;
                                else           flags&=~V_FLAG;
                                temp>>=1;
                                seteab(temp);
                                setznp8(temp);
                                cycles-=((mod==3)?2:23);
                                flags|=A_FLAG;
                                break;
                                case 0x38: /*SAR b,1*/
                                if (temp&1) flags|=C_FLAG;
                                else        flags&=~C_FLAG;
                                temp>>=1;
                                if (temp&0x40) temp|=0x80;
                                seteab(temp);
                                setznp8(temp);
                                cycles-=((mod==3)?2:23);
                                flags|=A_FLAG;
                                flags&=~V_FLAG;
                                break;

                                default:
                                printf("Bad D0 opcode %02X\n",rmdat&0x38);
//                                dumpregs();
//                                exit(-1);
                        }
                        break;

                        case 0xD1:
                        fetchea();
                        tempw=geteaw();
                        switch (rmdat&0x38)
                        {
                                case 0x00: /*ROL w,1*/
                                if (tempw&0x8000) flags|=C_FLAG;
                                else              flags&=~C_FLAG;
                                tempw<<=1;
                                if (flags&C_FLAG) tempw|=1;
                                seteaw(tempw);
//                                setznp16(tempw);
                                if ((flags&C_FLAG)^(tempw>>15)) flags|=V_FLAG;
                                else                            flags&=~V_FLAG;
                                cycles-=((mod==3)?2:23);
                                break;
                                case 0x08: /*ROR w,1*/
                                if (tempw&1) flags|=C_FLAG;
                                else         flags&=~C_FLAG;
                                tempw>>=1;
                                if (flags&C_FLAG) tempw|=0x8000;
                                seteaw(tempw);
//                                setznp16(tempw);
                                if ((tempw^(tempw>>1))&0x4000) flags|=V_FLAG;
                                else                           flags&=~V_FLAG;
                                cycles-=((mod==3)?2:23);
                                break;
                                case 0x10: /*RCL w,1*/
                                temp2=flags&C_FLAG;
                                if (tempw&0x8000) flags|=C_FLAG;
                                else              flags&=~C_FLAG;
                                tempw<<=1;
                                if (temp2) tempw|=1;
                                seteaw(tempw);
                                if ((flags&C_FLAG)^(tempw>>15)) flags|=V_FLAG;
                                else                            flags&=~V_FLAG;
                                cycles-=((mod==3)?2:23);
                                break;
                                case 0x18: /*RCR w,1*/
                                temp2=flags&C_FLAG;
                                if (tempw&1) flags|=C_FLAG;
                                else         flags&=~C_FLAG;
                                tempw>>=1;
                                if (temp2) tempw|=0x8000;
                                seteaw(tempw);
//                                setznp16(tempw);
                                if ((tempw^(tempw>>1))&0x4000) flags|=V_FLAG;
                                else                           flags&=~V_FLAG;
                                cycles-=((mod==3)?2:23);
                                break;
                                case 0x20: /*SHL w,1*/
                                if (tempw&0x8000) flags|=C_FLAG;
                                else              flags&=~C_FLAG;
                                if ((tempw^(tempw<<1))&0x8000) flags|=V_FLAG;
                                else                           flags&=~V_FLAG;
                                tempw<<=1;
                                seteaw(tempw);
                                setznp16(tempw);
                                cycles-=((mod==3)?2:23);
                                flags|=A_FLAG;
                                break;
                                case 0x28: /*SHR w,1*/
                                if (tempw&1) flags|=C_FLAG;
                                else         flags&=~C_FLAG;
                                if (tempw&0x8000) flags|=V_FLAG;
                                else              flags&=~V_FLAG;
                                tempw>>=1;
                                seteaw(tempw);
                                setznp16(tempw);
                                cycles-=((mod==3)?2:23);
                                flags|=A_FLAG;
                                break;

                                case 0x38: /*SAR w,1*/
                                if (tempw&1) flags|=C_FLAG;
                                else         flags&=~C_FLAG;
                                tempw>>=1;
                                if (tempw&0x4000) tempw|=0x8000;
                                seteaw(tempw);
                                setznp16(tempw);
                                cycles-=((mod==3)?2:23);
                                flags|=A_FLAG;
                                flags&=~V_FLAG;
                                break;

                                default:
                                printf("Bad D1 opcode %02X\n",rmdat&0x38);
//                                dumpregs();
//                                exit(-1);
                        }
                        break;

                        case 0xD2:
                        fetchea();
                        temp=geteab();
                        c=CL;
//                        cycles-=c;
                        if (!c) break;
//                        if (c>7) printf("Shiftb %i %02X\n",rmdat&0x38,c);
                        switch (rmdat&0x38)
                        {
                                case 0x00: /*ROL b,CL*/
                                while (c>0)
                                {
                                        temp2=(temp&0x80)?1:0;
                                        temp=(temp<<1)|temp2;
                                        c--;
                                        cycles-=4;
                                }
                                if (temp2) flags|=C_FLAG;
                                else       flags&=~C_FLAG;
                                seteab(temp);
//                                setznp8(temp);
                                if ((flags&C_FLAG)^(temp>>7)) flags|=V_FLAG;
                                else                          flags&=~V_FLAG;
                                cycles-=((mod==3)?8:28);
                                break;
                                case 0x08: /*ROR b,CL*/
                                while (c>0)
                                {
                                        temp2=temp&1;
                                        temp>>=1;
                                        if (temp2) temp|=0x80;
                                        c--;
                                        cycles-=4;
                                }
                                if (temp2) flags|=C_FLAG;
                                else       flags&=~C_FLAG;
                                seteab(temp);
                                if ((temp^(temp>>1))&0x40) flags|=V_FLAG;
                                else                       flags&=~V_FLAG;
                                cycles-=((mod==3)?8:28);
                                break;
                                case 0x10: /*RCL b,CL*/
//                                printf("RCL %i %02X %02X\n",c,CL,temp);
                                while (c>0)
                                {
                                        templ=flags&C_FLAG;
                                        temp2=temp&0x80;
                                        temp<<=1;
                                        if (temp2) flags|=C_FLAG;
                                        else       flags&=~C_FLAG;
                                        if (templ) temp|=1;
                                        c--;
                                        cycles-=4;
                                }
//                                printf("Now %02X\n",temp);
                                seteab(temp);
                                if ((flags&C_FLAG)^(temp>>7)) flags|=V_FLAG;
                                else                          flags&=~V_FLAG;
                                cycles-=((mod==3)?8:28);
                                break;
                                case 0x18: /*RCR b,CL*/
                                while (c>0)
                                {
                                        templ=flags&C_FLAG;
                                        temp2=temp&1;
                                        temp>>=1;
                                        if (temp2) flags|=C_FLAG;
                                        else       flags&=~C_FLAG;
                                        if (templ) temp|=0x80;
                                        c--;
                                        cycles-=4;
                                }
//                                if (temp2) flags|=C_FLAG;
//                                else       flags&=~C_FLAG;
                                seteab(temp);
                                if ((temp^(temp>>1))&0x40) flags|=V_FLAG;
                                else                       flags&=~V_FLAG;
                                cycles-=((mod==3)?8:28);
                                break;
                                case 0x20: case 0x30: /*SHL b,CL*/
                                if ((temp<<(c-1))&0x80) flags|=C_FLAG;
                                else                    flags&=~C_FLAG;
                                temp<<=c;
                                seteab(temp);
                                setznp8(temp);
                                cycles-=(c*4);
                                cycles-=((mod==3)?8:28);
                                flags|=A_FLAG;
                                break;
                                case 0x28: /*SHR b,CL*/
                                if ((temp>>(c-1))&1) flags|=C_FLAG;
                                else                 flags&=~C_FLAG;
                                temp>>=c;
                                seteab(temp);
                                setznp8(temp);
                                cycles-=(c*4);
                                cycles-=((mod==3)?8:28);
                                flags|=A_FLAG;
                                break;
                                case 0x38: /*SAR b,CL*/
                                if ((temp>>(c-1))&1) flags|=C_FLAG;
                                else                 flags&=~C_FLAG;
                                while (c>0)
                                {
                                        temp>>=1;
                                        if (temp&0x40) temp|=0x80;
                                        c--;
                                        cycles-=4;
                                }
                                seteab(temp);
                                setznp8(temp);
                                cycles-=((mod==3)?8:28);
                                flags|=A_FLAG;
                                break;

                                default:
                                printf("Bad D2 opcode %02X\n",rmdat&0x38);
//                                dumpregs();
//                                exit(-1);
                        }
                        break;

                        case 0xD3:
                        fetchea();
                        tempw=geteaw();
                        c=CL;
//                      cycles-=c;
                        if (!c) break;
//                        if (c>15) printf("Shiftw %i %02X\n",rmdat&0x38,c);
                        switch (rmdat&0x38)
                        {
                                case 0x00: /*ROL w,CL*/
                                while (c>0)
                                {
                                        temp=(tempw&0x8000)?1:0;
                                        tempw=(tempw<<1)|temp;
                                        c--;
                                        cycles-=4;
                                }
                                if (temp) flags|=C_FLAG;
                                else      flags&=~C_FLAG;
                                seteaw(tempw);
                                if ((flags&C_FLAG)^(tempw>>15)) flags|=V_FLAG;
                                else                            flags&=~V_FLAG;
                                cycles-=((mod==3)?8:28);
                                break;
                                case 0x08: /*ROR w,CL*/
                                while (c>0)
                                {
                                        tempw2=(tempw&1)?0x8000:0;
                                        tempw=(tempw>>1)|tempw2;
                                        c--;
                                        cycles-=4;
                                }
                                if (tempw2) flags|=C_FLAG;
                                else        flags&=~C_FLAG;
                                seteaw(tempw);
                                if ((tempw^(tempw>>1))&0x4000) flags|=V_FLAG;
                                else                           flags&=~V_FLAG;
                                cycles-=((mod==3)?8:28);
                                break;
                                case 0x10: /*RCL w,CL*/
                                while (c>0)
                                {
                                        templ=flags&C_FLAG;
                                        if (tempw&0x8000) flags|=C_FLAG;
                                        else              flags&=~C_FLAG;
                                        tempw=(tempw<<1)|templ;
                                        c--;
                                        cycles-=4;
                                }
                                if (temp) flags|=C_FLAG;
                                else      flags&=~C_FLAG;
                                seteaw(tempw);
                                if ((flags&C_FLAG)^(tempw>>15)) flags|=V_FLAG;
                                else                            flags&=~V_FLAG;
                                cycles-=((mod==3)?8:28);
                                break;
                                case 0x18: /*RCR w,CL*/
                                while (c>0)
                                {
                                        templ=flags&C_FLAG;
                                        tempw2=(templ&1)?0x8000:0;
                                        if (tempw&1) flags|=C_FLAG;
                                        else         flags&=~C_FLAG;
                                        tempw=(tempw>>1)|tempw2;
                                        c--;
                                        cycles-=4;
                                }
                                if (tempw2) flags|=C_FLAG;
                                else        flags&=~C_FLAG;
                                seteaw(tempw);
                                if ((tempw^(tempw>>1))&0x4000) flags|=V_FLAG;
                                else                           flags&=~V_FLAG;
                                cycles-=((mod==3)?8:28);
                                break;

                                case 0x20: case 0x30: /*SHL w,CL*/
                                if (c>16)
                                {
                                        tempw=0;
                                        flags&=~C_FLAG;
                                }
                                else
                                {
                                        if ((tempw<<(c-1))&0x8000) flags|=C_FLAG;
                                        else                       flags&=~C_FLAG;
                                        tempw<<=c;
                                }
                                seteaw(tempw);
                                setznp16(tempw);
                                cycles-=(c*4);
                                cycles-=((mod==3)?8:28);
                                flags|=A_FLAG;
                                break;

                                case 0x28:            /*SHR w,CL*/
                                if ((tempw>>(c-1))&1) flags|=C_FLAG;
                                else                  flags&=~C_FLAG;
                                tempw>>=c;
                                seteaw(tempw);
                                setznp16(tempw);
                                cycles-=(c*4);
                                cycles-=((mod==3)?8:28);
                                flags|=A_FLAG;
                                break;

                                case 0x38:            /*SAR w,CL*/
                                tempw2=tempw&0x8000;
                                if ((tempw>>(c-1))&1) flags|=C_FLAG;
                                else                  flags&=~C_FLAG;
                                while (c>0)
                                {
                                        tempw=(tempw>>1)|tempw2;
                                        c--;
                                        cycles-=4;
                                }
                                seteaw(tempw);
                                setznp16(tempw);
                                cycles-=((mod==3)?8:28);
                                flags|=A_FLAG;
                                break;

                                default:
                                printf("Bad D3 opcode %02X\n",rmdat&0x38);
//                                dumpregs();
//                                exit(-1);
                        }
                        break;

                        case 0xD4: /*AAM*/
                        tempws=FETCH();
                        AH=AL/tempws;
                        AL%=tempws;
                        setznp168(AX);
                        cycles-=83;
                        break;
                        case 0xD5: /*AAD*/
                        tempws=FETCH();
                        AL=(AH*tempws)+AL;
                        AH=0;
                        setznp168(AX);
                        cycles-=60;
                        break;
                        case 0xD7: /*XLAT*/
                        addr=BX+AL;
                        AL=readmemb(ds+addr);
                        cycles-=11;
                        break;
                        case 0xD9: case 0xDA: case 0xDB: case 0xDD: /*ESCAPE*/
                        case 0xDC: case 0xDE: case 0xDF: case 0xD8:
                        fetchea();
                        geteab();
                        break;

                        case 0xE0: /*LOOPNE*/
                        offset=(signed char)FETCH();
                        CX--;
                        if (CX && !(flags&Z_FLAG)) { pc+=offset; cycles-=12; FETCHCLEAR(); }
                        cycles-=6;
                        break;
                        case 0xE1: /*LOOPE*/
                        offset=(signed char)FETCH();
                        CX--;
                        if (CX && (flags&Z_FLAG)) { pc+=offset; cycles-=12; FETCHCLEAR(); }
                        cycles-=6;
                        break;
                        case 0xE2: /*LOOP*/
//                        printf("LOOP start\n");
                        offset=(signed char)FETCH();
                        CX--;
                        if (CX) { pc+=offset; cycles-=12; FETCHCLEAR(); }
                        cycles-=5;
//                        printf("LOOP end!\n");
                        break;
                        case 0xE3: /*JCXZ*/
                        offset=(signed char)FETCH();
                        if (!CX) { pc+=offset; cycles-=12; FETCHCLEAR(); }
                        cycles-=6;
                        break;

                        case 0xE4: /*IN AL*/
                        temp=FETCH();
                        AL=inb(temp);
                        cycles-=14;
                        break;
                        case 0xE5: /*IN AX*/
                        temp=FETCH();
                        AL=inb(temp);
                        AH=inb(temp+1);
                        cycles-=14;
                        break;
                        case 0xE6: /*OUT AL*/
                        temp=FETCH();
                        outb(temp,AL);
                        cycles-=14;
                        break;
                        case 0xE7: /*OUT AX*/
                        temp=FETCH();
                        outb(temp,AL);
                        outb(temp+1,AH);
                        cycles-=14;
                        break;

                        case 0xE8: /*CALL rel 16*/
                        tempw=getword();
                        if (ssegs) ss=oldss;
//                        writememb(ss+((SP-1)&0xFFFF),pc>>8);
                        writememw(ss,((SP-2)&0xFFFF),pc);
                        SP-=2;
                        pc+=tempw;
                        cycles-=23;
                        FETCHCLEAR();
                        break;
                        case 0xE9: /*JMP rel 16*/
//                        printf("PC was %04X\n",pc);
                        pc+=getword();
//                        printf("PC now %04X\n",pc);
                        cycles-=15;
                        FETCHCLEAR();
                        break;
                        case 0xEA: /*JMP far*/
                        addr=getword();
                        tempw=getword();
                        pc=addr;
//                        printf("EA\n");
                        loadcs(tempw);
//                        cs=loadcs(CS);
//                        cs=CS<<4;
                        cycles-=15;
                        FETCHCLEAR();
                        break;
                        case 0xEB: /*JMP rel*/
                        offset=(signed char)FETCH();
                        pc+=offset;
                        cycles-=15;
                        FETCHCLEAR();
                        break;
                        case 0xEC: /*IN AL,DX*/
                        AL=inb(DX);
                        cycles-=12;
                        break;
                        case 0xED: /*IN AX,DX*/
                        AL=inb(DX);
                        AH=inb(DX+1);
                        cycles-=12;
                        break;
                        case 0xEE: /*OUT DX,AL*/
                        outb(DX,AL);
                        cycles-=12;
                        break;
                        case 0xEF: /*OUT DX,AX*/
                        outb(DX,AL);
                        outb(DX+1,AH);
                        cycles-=12;
                        break;

                        case 0xF0: /*LOCK*/
                        cycles-=4;
                        break;

                        case 0xF2: /*REPNE*/
                        rep(0);
                        break;
                        case 0xF3: /*REPE*/
                        rep(1);
                        break;

                        case 0xF4: /*HLT*/
//                        printf("IN HLT!!!! %04X:%04X %08X %08X %08X\n",oldcs,oldpc,old8,old82,old83);
//                        dumpregs();
//                        exit(-1);
                        inhlt=1;
                        pc--;
                        cycles-=2;
                        break;
                        case 0xF5: /*CMC*/
                        flags^=C_FLAG;
                        cycles-=2;
                        break;

                        case 0xF6:
                        fetchea();
                        temp=geteab();
                        switch (rmdat&0x38)
                        {
                                case 0x00: /*TEST b,#8*/
                                temp2=FETCH();
                                temp&=temp2;
                                setznp8(temp);
                                flags&=~(C_FLAG|V_FLAG|A_FLAG);
                                cycles-=((mod==3)?5:11);
                                break;
                                case 0x10: /*NOT b*/
                                temp=~temp;
                                seteab(temp);
                                cycles-=((mod==3)?3:24);
                                break;
                                case 0x18: /*NEG b*/
                                setsub8(0,temp);
                                temp=0-temp;
                                seteab(temp);
                                cycles-=((mod==3)?3:24);
                                break;
                                case 0x20: /*MUL AL,b*/
                                setznp8(AL);
                                AX=AL*temp;
                                if (AX) flags&=~Z_FLAG;
                                else    flags|=Z_FLAG;
                                if (AH) flags|=(C_FLAG|V_FLAG);
                                else    flags&=~(C_FLAG|V_FLAG);
                                cycles-=70;
                                break;
                                case 0x28: /*IMUL AL,b*/
                                setznp8(AL);
                                tempws=(int)((signed char)AL)*(int)((signed char)temp);
                                AX=tempws&0xFFFF;
                                if (AX) flags&=~Z_FLAG;
                                else    flags|=Z_FLAG;
                                if (AH) flags|=(C_FLAG|V_FLAG);
                                else    flags&=~(C_FLAG|V_FLAG);
                                cycles-=80;
                                break;
                                case 0x30: /*DIV AL,b*/
                                tempw=AX;
                                if (temp)
                                {
                                        tempw2=tempw%temp;
/*                                        if (!tempw)
                                        {
                                                writememw((ss+SP)-2,flags|0xF000);
                                                writememw((ss+SP)-4,cs>>4);
                                                writememw((ss+SP)-6,pc);
                                                SP-=6;
                                                flags&=~I_FLAG;
                                                pc=readmemw(0);
                                                cs=readmemw(2)<<4;
                                                printf("Div by zero %04X:%04X\n",cs>>4,pc);
//                                                dumpregs();
//                                                exit(-1);
                                        }
                                        else
                                        {*/
                                                AH=tempw2;
                                                tempw/=temp;
                                                AL=tempw&0xFF;
//                                        }
                                }
                                else
                                {
                                        printf("DIVb BY 0 %04X:%04X\n",cs>>4,pc);
                                        writememw(ss,(SP-2)&0xFFFF,flags|0xF000);
                                        writememw(ss,(SP-4)&0xFFFF,CS);
                                        writememw(ss,(SP-6)&0xFFFF,pc);
                                        SP-=6;
                                        flags&=~I_FLAG;
                                        flags&=~T_FLAG;
                                        pc=readmemw(0,0);
//                        printf("F6 30\n");
                                        loadcs(readmemw(0,2));
                                        FETCHCLEAR();
//                                                cs=loadcs(CS);
//                                                cs=CS<<4;
//                                        printf("Div by zero %04X:%04X %02X %02X\n",cs>>4,pc,0xf6,0x30);
//                                        dumpregs();
//                                        exit(-1);
                                }
                                cycles-=80;
                                break;
                                case 0x38: /*IDIV AL,b*/
                                tempws=(int)AX;
                                if (temp)
                                {
                                        tempw2=tempws%(int)((signed char)temp);
/*                                        if (!tempw)
                                        {
                                                writememw((ss+SP)-2,flags|0xF000);
                                                writememw((ss+SP)-4,cs>>4);
                                                writememw((ss+SP)-6,pc);
                                                SP-=6;
                                                flags&=~I_FLAG;
                                                pc=readmemw(0);
                                                cs=readmemw(2)<<4;
                                                printf("Div by zero %04X:%04X\n",cs>>4,pc);
                                        }
                                        else
                                        {*/
                                                AH=tempw2&0xFF;
                                                tempws/=(int)((signed char)temp);
                                                AL=tempws&0xFF;
//                                        }
                                }
                                else
                                {
                                        printf("IDIVb BY 0 %04X:%04X\n",cs>>4,pc);
                                        writememw(ss,(SP-2)&0xFFFF,flags|0xF000);
                                        writememw(ss,(SP-4)&0xFFFF,CS);
                                        writememw(ss,(SP-6)&0xFFFF,pc);
                                        SP-=6;
                                        flags&=~I_FLAG;
                                        flags&=~T_FLAG;
                                        pc=readmemw(0,0);
//                        printf("F6 38\n");
                                        loadcs(readmemw(0,2));
                                        FETCHCLEAR();
//                                                cs=loadcs(CS);
//                                                cs=CS<<4;
//                                        printf("Div by zero %04X:%04X %02X %02X\n",cs>>4,pc,0xf6,0x38);
                                }
                                cycles-=101;
                                break;

                                default:
                                printf("Bad F6 opcode %02X\n",rmdat&0x38);
//                                dumpregs();
//                                exit(-1);
                        }
                        break;

                        case 0xF7:
                        fetchea();
                        tempw=geteaw();
                        switch (rmdat&0x38)
                        {
                                case 0x00: /*TEST w*/
                                tempw2=getword();
                                setznp16(tempw&tempw2);
                                flags&=~(C_FLAG|V_FLAG|A_FLAG);
                                cycles-=((mod==3)?5:11);
                                break;
                                case 0x10: /*NOT w*/
                                seteaw(~tempw);
                                cycles-=((mod==3)?3:24);
                                break;
                                case 0x18: /*NEG w*/
                                setsub16(0,tempw);
                                tempw=0-tempw;
                                seteaw(tempw);
                                cycles-=((mod==3)?3:24);
                                break;
                                case 0x20: /*MUL AX,w*/
                                setznp16(AX);
                                templ=AX*tempw;
//                                if (output) printf("%04X*%04X=%08X\n",AX,tempw,templ);
                                AX=templ&0xFFFF;
                                DX=templ>>16;
                                if (AX|DX) flags&=~Z_FLAG;
                                else       flags|=Z_FLAG;
                                if (DX)    flags|=(C_FLAG|V_FLAG);
                                else       flags&=~(C_FLAG|V_FLAG);
                                cycles-=118;
                                break;
                                case 0x28: /*IMUL AX,w*/
                                setznp16(AX);
//                                printf("IMUL %i %i ",(int)((signed short)AX),(int)((signed short)tempw));
                                tempws=(int)((signed short)AX)*(int)((signed short)tempw);
                                if ((tempws>>15) && ((tempws>>15)!=-1)) flags|=(C_FLAG|V_FLAG);
                                else                                    flags&=~(C_FLAG|V_FLAG);
//                                printf("%i ",tempws);
                                AX=tempws&0xFFFF;
                                tempws=(unsigned short)(tempws>>16);
                                DX=tempws&0xFFFF;
//                                printf("%04X %04X\n",AX,DX);
//                                dumpregs();
//                                exit(-1);
                                if (AX|DX) flags&=~Z_FLAG;
                                else       flags|=Z_FLAG;
                                cycles-=128;
                                break;
                                case 0x30: /*DIV AX,w*/
                                templ=(DX<<16)|AX;
//                                printf("DIV %08X/%04X\n",templ,tempw);
                                if (tempw)
                                {
                                        tempw2=templ%tempw;
                                        DX=tempw2;
                                        templ/=tempw;
                                        AX=templ&0xFFFF;
                                }
                                else
                                {
                                        printf("DIVw BY 0 %04X:%04X\n",cs>>4,pc);
                                        writememw(ss,(SP-2)&0xFFFF,flags|0xF000);
                                        writememw(ss,(SP-4)&0xFFFF,CS);
                                        writememw(ss,(SP-6)&0xFFFF,pc);
                                        SP-=6;
                                        flags&=~I_FLAG;
                                        flags&=~T_FLAG;
                                        pc=readmemw(0,0);
//                        printf("F7 30\n");
                                        loadcs(readmemw(0,2));
                                        FETCHCLEAR();
                                }
                                cycles-=144;
                                break;
                                case 0x38: /*IDIV AX,w*/
                                tempws=(int)((DX<<16)|AX);
//                                printf("IDIV %i %i ",tempws,tempw);
                                if (tempw)
                                {
                                        tempw2=tempws%(int)((signed short)tempw);
//                                        printf("%04X ",tempw2);
                                                DX=tempw2;
                                                tempws/=(int)((signed short)tempw);
                                                AX=tempws&0xFFFF;
                                }
                                else
                                {
                                        printf("IDIVw BY 0 %04X:%04X\n",cs>>4,pc);
                                        writememw(ss,(SP-2)&0xFFFF,flags|0xF000);
                                        writememw(ss,(SP-4)&0xFFFF,CS);
                                        writememw(ss,(SP-6)&0xFFFF,pc);
                                        SP-=6;
                                        flags&=~I_FLAG;
                                        flags&=~T_FLAG;
                                        pc=readmemw(0,0);
//                        printf("F7 38\n");
                                        loadcs(readmemw(0,2));
                                        FETCHCLEAR();
                                }
                                cycles-=165;
                                break;

                                default:
                                printf("Bad F7 opcode %02X\n",rmdat&0x38);
//                                dumpregs();
//                                exit(-1);
                        }
                        break;

                        case 0xF8: /*CLC*/
                        flags&=~C_FLAG;
                        cycles-=2;
                        break;
                        case 0xF9: /*STC*/
//                        printf("STC %04X\n",pc);
                        flags|=C_FLAG;
                        cycles-=2;
                        break;
                        case 0xFA: /*CLI*/
                        flags&=~I_FLAG;
//                        printf("CLI at %04X:%04X\n",cs>>4,pc);
                        cycles-=3;
                        break;
                        case 0xFB: /*STI*/
                        flags|=I_FLAG;
//                        printf("STI at %04X:%04X\n",cs>>4,pc);
                        cycles-=2;
                        break;
                        case 0xFC: /*CLD*/
                        flags&=~D_FLAG;
                        cycles-=2;
                        break;
                        case 0xFD: /*STD*/
                        flags|=D_FLAG;
                        cycles-=2;
                        break;

                        case 0xFE: /*INC/DEC b*/
                        fetchea();
                        temp=geteab();
                        flags&=~V_FLAG;
                        if (rmdat&0x38)
                        {
                                setsub8nc(temp,1);
                                temp2=temp-1;
                                if ((temp&0x80) && !(temp2&0x80)) flags|=V_FLAG;
                        }
                        else
                        {
                                setadd8nc(temp,1);
                                temp2=temp+1;
                                if ((temp2&0x80) && !(temp&0x80)) flags|=V_FLAG;
                        }
//                        setznp8(temp2);
                        seteab(temp2);
                        cycles-=((mod==3)?3:23);
                        break;

                        case 0xFF:
                        fetchea();
                        switch (rmdat&0x38)
                        {
                                case 0x00: /*INC w*/
                                tempw=geteaw();
                                setadd16nc(tempw,1);
//                                setznp16(tempw+1);
                                seteaw(tempw+1);
                                cycles-=((mod==3)?3:23);
                                break;
                                case 0x08: /*DEC w*/
                                tempw=geteaw();
//                                setsub16(tempw,1);
                                setsub16nc(tempw,1);
//                                setznp16(tempw-1);
                                seteaw(tempw-1);
//                                if (output) printf("DEC - %04X\n",tempw);
                                cycles-=((mod==3)?3:23);
                                break;
                                case 0x10: /*CALL*/
                                tempw=geteaw();
                                if (ssegs) ss=oldss;
                                writememw(ss,(SP-2)&0xFFFF,pc);
                                SP-=2;
                                pc=tempw;
//                        printf("FF 10\n");
                                cycles-=((mod==3)?20:29);
                                FETCHCLEAR();
                                break;
                                case 0x18: /*CALL far*/
                                tempw=readmemw(easeg,eaaddr);
                                tempw2=readmemw(easeg,(eaaddr+2)&0xFFFF); //geteaw2();
                                tempw3=CS;
                                tempw4=pc;
                                if (ssegs) ss=oldss;
                                pc=tempw;
//                        printf("FF 18\n");
                                loadcs(tempw2);
                                writememw(ss,(SP-2)&0xFFFF,tempw3);
                                writememw(ss,((SP-4)&0xFFFF),tempw4);
                                SP-=4;
                                cycles-=53;
                                FETCHCLEAR();
                                break;
                                case 0x20: /*JMP*/
                                pc=geteaw();
//                        printf("FF 20\n");
                                cycles-=((mod==3)?11:18);
                                FETCHCLEAR();
                                break;
                                case 0x28: /*JMP far*/
                                pc=readmemw(easeg,eaaddr); //geteaw();
//                        printf("FF 28\n");
                                loadcs(readmemw(easeg,(eaaddr+2)&0xFFFF)); //geteaw2();
//                                cs=loadcs(CS);
//                                cs=CS<<4;
                                cycles-=24;
                                FETCHCLEAR();
                                break;
                                case 0x30: /*PUSH w*/
                                tempw=geteaw();
//                                if (output) printf("PUSH %04X %i %02X %04X %04X %02X %02X\n",tempw,rm,rmdat,easeg,eaaddr,ram[0x22340+0x5638],ram[0x22340+0x5639]);
                                if (ssegs) ss=oldss;
                                writememw(ss,((SP-2)&0xFFFF),tempw);
                                SP-=2;
                                cycles-=((mod==3)?15:24);
                                break;

                                default:
                                printf("Bad FF opcode %02X\n",rmdat&0x38);
//                                dumpregs();
//                                exit(-1);
                        }
                        break;

                        default:
                        FETCH();
                        cycles-=8;
                        break;

                        printf("Bad opcode %02X at %04X:%04X from %04X:%04X %08X\n",opcode,cs>>4,pc,old8>>16,old8&0xFFFF,old82);
                        dumpregs();
                        exit(-1);
                }
                pc&=0xFFFF;
                if ((cs+pc)==0xFC2C2) printf("C2C2 - %04X\n",CX);
                if ((cs+pc)==0xFC2BC) printf("C2BC - %04X %04X\n",SI,CX);
                if (((cs+pc)&0xF0000)==0xD0000)
                {
                        printf("Out of here!\n");
                        dumpregs();
                        exit(-1);
                }
                if (ssegs)
                {
                        ds=oldds;
                        ss=oldss;
                        ssegs=0;
                }
//                if (output) printf("%i %i %i %i\n",cycdiff,cycles,memcycs,fetchclocks);
                FETCHADD(((cycdiff-cycles)-memcycs)-fetchclocks);
                if ((cycdiff-cycles)<memcycs) cycles-=(memcycs-(cycdiff-cycles));
//                if (CS==0x14A0 && pc==0x100) output=1;
//                if (output) printf("%i\n",cycles);
/*                if (CS==0x2F79 && pc==0x36DB) output=1;
                if (CS==0x2F79 && pc==0x36F9)
                {
                        dumpregs();
                        exit(-1);
                }*/
                if (romset==ROM_IBMPC)
                {
                        if ((cs+pc)==0xFE4A7) /*You didn't seriously think I was going to emulate the cassette, did you?*/
                        {
                                CX=1;
                                BX=0x500;
                        }
                }
                memcycs=0;

//                output=(CS==0xEB9);
                clockhardware();


                if (trap && (flags&T_FLAG) && !noint)
                {
//                        printf("TRAP!!! %04X:%04X\n",CS,pc);
                        writememw(ss,(SP-2)&0xFFFF,flags|0xF000);
                        writememw(ss,(SP-4)&0xFFFF,CS);
                        writememw(ss,(SP-6)&0xFFFF,pc);
                        SP-=6;
                        addr=1<<2;
                        flags&=~I_FLAG;
                        flags&=~T_FLAG;
                        pc=readmemw(0,addr);
                        loadcs(readmemw(0,addr+2));
                        FETCHCLEAR();
                }
                else if ((flags&I_FLAG) && (pic.pend&~pic.mask) && !ssegs && !noint)
                {
                        temp=picinterrupt();
                        if (temp!=0xFF)
                        {
                                if (inhlt) pc++;
                                writememw(ss,(SP-2)&0xFFFF,flags|0xF000);
                                writememw(ss,(SP-4)&0xFFFF,CS);
                                writememw(ss,(SP-6)&0xFFFF,pc);
                                SP-=6;
                                addr=temp<<2;
                                flags&=~I_FLAG;
                                flags&=~T_FLAG;
                                pc=readmemw(0,addr);
//                        printf("INT INT INT\n");
                                loadcs(readmemw(0,addr+2));
                                FETCHCLEAR();
                                inint=1;
//                                printf("INTERRUPT\n");
                        }
                }

/*                if (pc==0xCC32 && es>0x180000)
                {
                        pc=0xCBEB;
//                        output=1;
//                        timetolive=500000;
                }*/

                if (noint) noint=0;
                ins++;
                if (timetolive)
                {
                        timetolive--;
                        if (!timetolive) exit(-1); //output=0;
                }
                if (keybsenddelay)
                {
                        keybsenddelay-=10;
                        if (keybsenddelay<1)
                        {
                                keybsenddelay=0;
                                keybsendcallback();
                        }
                }
        }
}

#undef fetchea
#define fetchea()   { rmdat=readmemb(cs+pc); pc++; \
                    reg=(rmdat>>3)&7;             \
                    mod=rmdat>>6;                 \
                    rm=rmdat&7;                   \
                    if (mod!=3) fetcheal286(); }

#define readmemb(a) ((readlookup2[(a)>>12]==0xFFFFFFFF)?readmembl(a):ram[readlookup2[(a)>>12]+((a)&0xFFF)])
#define readmemw(s,a) ((readlookup2[((s)+(a))>>12]==0xFFFFFFFF || (s)==0xFFFFFFFF)?readmemwl(s,a):*((unsigned short *)(&ram[readlookup2[((s)+(a))>>12]+(((s)+(a))&0xFFF)])))

void fetcheal286()
{
        if (!mod && rm==6) { eaaddr=getword(); easeg=ds; }
        else
        {
                switch (mod)
                {
                        case 0:
                        eaaddr=0;
                        break;
                        case 1:
                        eaaddr=(unsigned short)(signed char)readmemb(cs+pc); pc++;
                        break;
                        case 2:
                        eaaddr=getword();
                        break;
                }
                eaaddr+=(*mod1add[0][rm])+(*mod1add[1][rm]);
                easeg=*mod1seg[rm];
                eaaddr&=0xFFFF;
        }
}

void rep286(int fv)
{
        unsigned char temp;
        int c=CX;
        unsigned char temp2;
        unsigned short tempw,tempw2,tempw3;
        unsigned short ipc=oldpc;//pc-1;
        int changeds=0;
        unsigned long oldds;
        startrep:
        temp=readmemb(cs+pc); pc++;
//        if (firstrepcycle && temp==0xA5) printf("REP MOVSW %06X:%04X %06X:%04X\n",ds,SI,es,DI);
//        if (output) printf("REP %02X %04X\n",temp,ipc);
        switch (temp)
        {
                case 0x08:
                pc=ipc+1;
                cycles-=2;
                break;
                case 0x26: /*ES:*/
                oldds=ds;
                ds=es;
                changeds=1;
                cycles-=2;
                goto startrep;
                break;
                case 0x2E: /*CS:*/
                oldds=ds;
                ds=cs;
                changeds=1;
                cycles-=2;
                goto startrep;
                break;
                case 0x36: /*SS:*/
                oldds=ds;
                ds=ss;
                changeds=1;
                cycles-=2;
                goto startrep;
                break;
                case 0x6E: /*REP OUTSB*/
                if (c>0)
                {
                        temp2=readmemb(ds+SI);
                        outb(DX,temp2);
                        if (flags&D_FLAG) SI--;
                        else              SI++;
                        c--;
                        cycles-=5;
                }
                if (c>0) { firstrepcycle=0; pc=ipc; if (ssegs) ssegs++; }
                else firstrepcycle=1;
                break;
                case 0xA4: /*REP MOVSB*/
                while (c>0 && !IRQTEST)
                {
                        temp2=readmemb(ds+SI);
                        writememb(es+DI,temp2);
//                        if (output) printf("Moved %02X from %04X:%04X to %04X:%04X\n",temp2,ds>>4,SI,es>>4,DI);
                        if (flags&D_FLAG) { DI--; SI--; }
                        else              { DI++; SI++; }
                        c--;
                        cycles-=4;
                }
                if (IRQTEST && c>0) pc=ipc;
                break;
                case 0xA5: /*REP MOVSW*/
                while (c>0 && !IRQTEST)
                {
                        tempw=readmemw(ds,SI);
                        writememw(es,DI,tempw);
                        if (flags&D_FLAG) { DI-=2; SI-=2; }
                        else              { DI+=2; SI+=2; }
                        c--;
                        cycles-=4;
                        clockhardware();
                }
                if (IRQTEST && c>0) pc=ipc;
                break;
                case 0xA6: /*REP CMPSB*/
                if (fv) flags|=Z_FLAG;
                else    flags&=~Z_FLAG;
                while ((c>0) && (fv==((flags&Z_FLAG)?1:0)) && !IRQTEST)
                {
                        memcycs=0;
                        temp=readmemb(ds+SI);
                        temp2=readmemb(es+DI);
//                        printf("CMPSB %c %c %i %05X %05X %04X:%04X\n",temp,temp2,c,ds+SI,es+DI,cs>>4,pc);
                        if (flags&D_FLAG) { DI--; SI--; }
                        else              { DI++; SI++; }
                        c--;
                        cycles-=9;
                        setsub8(temp,temp2);
                        clockhardware();
                }
                if (IRQTEST && c>0 && (fv==((flags&Z_FLAG)?1:0))) pc=ipc;
                break;
                case 0xA7: /*REP CMPSW*/
                if (fv) flags|=Z_FLAG;
                else    flags&=~Z_FLAG;
                while ((c>0) && (fv==((flags&Z_FLAG)?1:0)) && !IRQTEST)
                {
                        memcycs=0;
                        tempw=readmemw(ds,SI);
                        tempw2=readmemw(es,DI);
                        if (flags&D_FLAG) { DI-=2; SI-=2; }
                        else              { DI+=2; SI+=2; }
                        c--;
                        cycles-=9;
                        setsub16(tempw,tempw2);
                        clockhardware();
                }
                if (IRQTEST && c>0 && (fv==((flags&Z_FLAG)?1:0))) pc=ipc;
                break;
                case 0xAA: /*REP STOSB*/
                while (c>0 && !IRQTEST)
                {
                        memcycs=0;
                        writememb(es+DI,AL);
                        if (flags&D_FLAG) DI--;
                        else              DI++;
                        c--;
                        cycles-=3;
                        clockhardware();
                }
                if (IRQTEST && c>0) pc=ipc;
                break;
                case 0xAB: /*REP STOSW*/
                while (c>0 && !IRQTEST)
                {
                        writememw(es,DI,AX);
                        if (flags&D_FLAG) DI-=2;
                        else              DI+=2;
                        c--;
                        cycles-=3;
                        clockhardware();
                }
                if (IRQTEST && c>0) pc=ipc;
                break;
                case 0xAC: /*REP LODSB*/
                if (c>0)
                {
                        temp2=readmemb(ds+SI);
                        if (flags&D_FLAG) SI--;
                        else              SI++;
                        c--;
                        cycles-=4;
                }
                if (c>0) { firstrepcycle=0; pc=ipc; if (ssegs) ssegs++; }
                else firstrepcycle=1;
                break;
                case 0xAD: /*REP LODSW*/
                if (c>0)
                {
                        tempw2=readmemw(ds,SI);
                        if (flags&D_FLAG) SI-=2;
                        else              SI+=2;
                        c--;
                        cycles-=4;
                }
                if (c>0) { firstrepcycle=0; pc=ipc; if (ssegs) ssegs++; }
                else firstrepcycle=1;
                break;
                case 0xAE: /*REP SCASB*/
                if (fv) flags|=Z_FLAG;
                else    flags&=~Z_FLAG;
                if ((c>0) && (fv==((flags&Z_FLAG)?1:0)))
                {
                        temp2=readmemb(es+DI);
//                        if (output) printf("SCASB %02X %c %02X %05X  ",temp2,temp2,AL,es+DI);
                        setsub8(AL,temp2);
//                        if (output && flags&Z_FLAG) printf("Match %02X %02X\n",AL,temp2);
                        if (flags&D_FLAG) DI--;
                        else              DI++;
                        c--;
                        cycles-=8;
                }
//if (output)                printf("%i %i %i %i\n",c,(c>0),(fv==((flags&Z_FLAG)?1:0)),((c>0) && (fv==((flags&Z_FLAG)?1:0))));
                if ((c>0) && (fv==((flags&Z_FLAG)?1:0)))  { pc=ipc; firstrepcycle=0; if (ssegs) ssegs++; }
                else firstrepcycle=1;
//                cycles-=120;
                break;
                case 0xAF: /*REP SCASW*/
                if (fv) flags|=Z_FLAG;
                else    flags&=~Z_FLAG;
                if ((c>0) && (fv==((flags&Z_FLAG)?1:0)))
                {
                        tempw=readmemw(es,DI);
                        setsub16(AX,tempw);
                        if (flags&D_FLAG) DI-=2;
                        else              DI+=2;
                        c--;
                        cycles-=8;
                }
                if ((c>0) && (fv==((flags&Z_FLAG)?1:0)))  { pc=ipc; firstrepcycle=0; if (ssegs) ssegs++; }
                else firstrepcycle=1;
                break;
                default:
                        pc=ipc;
                        cycles-=20;
//                printf("Bad REP %02X\n",temp);
//                dumpregs();
//                exit(-1);
        }
        CX=c;
        if (changeds) ds=oldds;
}

//#endif
//#if 0
/*Conditional jump timing is WRONG*/
void exec286(int cycs)
{
        unsigned char temp,temp2;
        unsigned short addr,tempw,tempw2,tempw3,tempw4;
        signed char offset;
        int tempws;
        unsigned long templ;
        int c,cycdiff;
        int tempi;
        FILE *f;
//        printf("Run 286! %i %i\n",cycles,cycs);
        cycles+=cycs;
//        i86_Execute(cycs);
//        return;
        while (cycles>0)
        {
//                old83=old82;
//                old82=old8;
//                old8=oldpc|(oldcs<<16);
//                if (pc==0x96B && cs==0x9E040) { printf("Hit it\n"); output=1; timetolive=150; }
//                if (pc<0x8000) printf("%04X : %04X %04X %04X %04X %04X %04X %04X %04X %04X %04X %04X %04X %02X %04X %i\n",pc,AX,BX,CX,DX,cs>>4,ds>>4,es>>4,ss>>4,DI,SI,BP,SP,opcode,flags,disctime);
                cycdiff=cycles;
                oldcs=CS;
                oldpc=pc;
                oldcpl=CPL;
                opcodestart:
                opcode=readmemb(cs+pc);
                tempc=flags&C_FLAG;
//                /*if (output) */printf("%04X:%04X : %04X %04X %04X %04X %04X %04X %04X %04X %04X %04X %04X %04X %02X %04X\n",cs>>4,pc,AX,BX,CX,DX,cs>>4,ds>>4,es>>4,ss>>4,DI,SI,BP,SP,opcode,flags&~0x200,rmdat);
//#if 0
output=0;
                if (output && /*cs<0xF0000 && */!ssegs)//opcode!=0x26 && opcode!=0x36 && opcode!=0x2E && opcode!=0x3E)
                {
                        if ((opcode!=0xF2 && opcode!=0xF3) || firstrepcycle)
                        {
                                if (!skipnextprint) printf("%04X:%04X : %04X %04X %04X %04X %04X %04X %04X %04X %04X %04X %04X %04X %02X %04X  %f %f\n",cs,pc,AX,BX,CX,DX,CS,DS,ES,SS,DI,SI,BP,SP,opcode,flags,vidtime,pit.c[0]);
                                skipnextprint=0;
//                                ins++;
/*                                if (ins==50000)
                                {
                                        dumpregs();
                                        exit(-1);
                                }*/
/*                                if (ins==500000)
                                {
                                        dumpregs();
                                        exit(-1);
                                }*/
                        }
                }
//#endif
                pc++;
                inhlt=0;
//                if (ins==500000) { dumpregs(); exit(0); }*/
                switch (opcode)
                {
                        case 0x00: /*ADD 8,reg*/
                        fetchea();
//                        if (!rmdat) pc--;
/*                        if (!rmdat)
                        {
                                printf("Crashed\n");
//                                clear_keybuf();
//                                readkey();
                                dumpregs();
                                exit(-1);
                        }*/
                        temp=geteab();
                        setadd8(temp,getr8(reg));
                        temp+=getr8(reg);
                        seteab(temp);
                        if (!AT) cycles-=((mod==3)?3:24);
                        else    cycles-=((mod==3)?2:7);
                        break;
                        case 0x01: /*ADD 16,reg*/
                        fetchea();
                        tempw=geteaw();
                        setadd16(tempw,regs[reg].w);
                        tempw+=regs[reg].w;
                        seteaw(tempw);
                        if (!AT) cycles-=((mod==3)?3:24);
                        else    cycles-=((mod==3)?2:7);
                        break;
                        case 0x02: /*ADD reg,8*/
                        fetchea();
                        temp=geteab();
                        setadd8(getr8(reg),temp);
                        setr8(reg,getr8(reg)+temp);
                        if (!AT) cycles-=((mod==3)?3:13);
                        else     cycles-=((mod==3)?2:7);
                        break;
                        case 0x03: /*ADD reg,16*/
                        fetchea();
                        tempw=geteaw();
                        setadd16(regs[reg].w,tempw);
                        regs[reg].w+=tempw;
                        if (!AT) cycles-=((mod==3)?3:13);
                        else     cycles-=((mod==3)?2:7);
                        break;
                        case 0x04: /*ADD AL,#8*/
                        temp=readmemb(cs+pc); pc++;
                        setadd8(AL,temp);
                        AL+=temp;
                        if (!AT) cycles-=4;
                        else     cycles-=3;
                        break;
                        case 0x05: /*ADD AX,#16*/
                        tempw=getword286();
                        setadd16(AX,tempw);
                        AX+=tempw;
                        if (!AT) cycles-=4;
                        else     cycles-=3;
                        break;

                        case 0x06: /*PUSH ES*/
                        if (ssegs) ss=oldss;
                        writememw(ss,((SP-2)&0xFFFF),ES);
                        SP-=2;
                        cycles-=((AT)?3:14);
                        break;
                        case 0x07: /*POP ES*/
                        if (ssegs) ss=oldss;
                        tempw=readmemw(ss,SP);
                        loadseg(tempw,&_es);
                        SP+=2;
                        cycles-=((AT)?5:12);
                        break;

                        case 0x08: /*OR 8,reg*/
                        fetchea();
                        temp=geteab();
                        temp|=getr8(reg);
                        setznp8(temp);
                        flags&=~(C_FLAG|V_FLAG|A_FLAG);
                        seteab(temp);
                        if (!AT) cycles-=((mod==3)?3:24);
                        else    cycles-=((mod==3)?2:7);
                        break;
                        case 0x09: /*OR 16,reg*/
                        fetchea();
                        tempw=geteaw();
                        tempw|=regs[reg].w;
                        setznp16(tempw);
                        flags&=~(C_FLAG|V_FLAG|A_FLAG);
                        seteaw(tempw);
                        if (!AT) cycles-=((mod==3)?3:24);
                        else    cycles-=((mod==3)?2:7);
                        break;
                        case 0x0A: /*OR reg,8*/
                        fetchea();
                        temp=geteab();
                        temp|=getr8(reg);
                        setznp8(temp);
                        flags&=~(C_FLAG|V_FLAG|A_FLAG);
                        setr8(reg,temp);
                        if (!AT) cycles-=((mod==3)?3:13);
                        else     cycles-=((mod==3)?2:7);
                        break;
                        case 0x0B: /*OR reg,16*/
                        fetchea();
                        tempw=geteaw();
                        tempw|=regs[reg].w;
                        setznp16(tempw);
                        flags&=~(C_FLAG|V_FLAG|A_FLAG);
                        regs[reg].w=tempw;
                        if (!AT) cycles-=((mod==3)?3:13);
                        else     cycles-=((mod==3)?2:7);
                        break;
                        case 0x0C: /*OR AL,#8*/
                        AL|=readmemb(cs+pc); pc++;
                        setznp8(AL);
                        flags&=~(C_FLAG|V_FLAG|A_FLAG);
                        if (!AT) cycles-=4;
                        else     cycles-=3;
                        break;
                        case 0x0D: /*OR AX,#16*/
                        AX|=getword286();
                        setznp16(AX);
                        flags&=~(C_FLAG|V_FLAG|A_FLAG);
                        if (!AT) cycles-=4;
                        else     cycles-=3;
                        break;

                        case 0x0E: /*PUSH CS*/
                        if (ssegs) ss=oldss;
                        writememw(ss,((SP-2)&0xFFFF),CS);
                        SP-=2;
                        cycles-=((AT)?3:14);
                        break;

                        case 0x0F:
                        temp=readmemb(cs+pc); pc++;
                        switch (temp)
                        {
                                case 0:
                                fetchea();
                                switch (rmdat&0x38)
                                {
                                        case 0x10: /*LLDT*/
                                        if (!lldt)
                                        {
                                                lldt=1;
                                                //ins=0;
//                                                output=1;
                                        }
                                        ldt.seg=geteaw();
                                        templ=(ldt.seg&~7)+gdt.base;
                                        ldt.limit=readmemw(0,templ);
                                        ldt.base=(readmemw(0,templ+2))|(readmemb(templ+4)<<16);
                                        cycles-=20;
                                        break;
                                        case 0x18: /*LTR*/
                                        tr.seg=geteaw();
                                        templ=(tr.seg&~7)+gdt.base;
                                        tr.limit=readmemw(0,templ);
                                        tr.base=(readmemw(0,templ+2))|(readmemb(templ+4)<<16);
                                        tr.access=readmemb(templ+5);
                                        cycles-=20;
                                        break;
                                        case 0x20: /*VERR*/
                                        tempw=geteaw();
                                        flags&=~Z_FLAG;
                                        if (!(tempw&0xFFFC)) break; /*Null selector*/
                                        tempi=(tempw&~7)<((tempw&4)?ldt.limit:gdt.limit);
                                        tempw2=readmemw(0,((tempw&4)?ldt.base:gdt.base)+(tempw&~7)+4);
                                        if (!(tempw2&0x1000)) tempi=0;
                                        if ((tempw2&0xC00)!=0xC00) /*Exclude conforming code segments*/
                                        {
                                                tempw3=(tempw2>>13)&3; /*Check permissions*/
                                                if (tempw3<CPL || tempw3<(tempw&3)) tempi=0;
                                        }
                                        if ((tempw2&0x0800) && !(tempw2&0x0200)) tempi=0; /*Non-readable code*/
                                        if (tempi) flags|=Z_FLAG;
                                        cycles-=20;
                                        break;
                                        case 0x28: /*VERW*/
//                                        printf("VERW at %04X(%06X):%04X\n",CS,cs,pc);
                                        tempw=geteaw();
                                        flags&=~Z_FLAG;
                                        if (!(tempw&0xFFFC)) break; /*Null selector*/
                                        tempi=(tempw&~7)<((tempw&4)?ldt.limit:gdt.limit);
                                        tempw2=readmemw(0,((tempw&4)?ldt.base:gdt.base)+(tempw&~7)+4);
                                        if (!(tempw2&0x1000)) tempi=0;
//                                        printf("SEGDAT2 %04X %i\n",tempw2,tempi);
                                        tempw3=(tempw2>>13)&3; /*Check permissions*/
                                        if (tempw3<CPL || tempw3<(tempw&3)) tempi=0;
//                                        printf("Permissions %i\n",tempi);
                                        if (tempw2&0x0800) tempi=0; /*Code*/
                                        else if (!(tempw2&0x0200)) tempi=0; /*Read-only data*/
//                                        printf("Final %i\n",tempi);
                                        if (tempi) flags|=Z_FLAG;
                                        cycles-=20;
                                        break;


                                        default:
                                        printf("Bad 0F 00 opcode %02X\n",rmdat&0x38);
                                        pc-=3;
                                        dumpregs();
                                        exit(-1);
                                }
                                break;
                                case 1:
                                fetchea();
                                switch (rmdat&0x38)
                                {
                                        case 0x00: /*SGDT*/
                                        seteaw(gdt.limit);
                                        writememw(easeg,eaaddr+2,gdt.base);
                                        writememb(easeg+eaaddr+4,gdt.base>>16);
                                        cycles-=7; //less seteaw time
//                                        if (msw&1) writememb(easeg+eaaddr+5,gdt.access);
                                        /*else*/       writememb(easeg+eaaddr+5,0xFF);
                                        break;
                                        case 0x08: /*SIDT*/
                                        seteaw(idt.limit);
                                        writememw(easeg,eaaddr+2,idt.base);
                                        writememb(easeg+eaaddr+4,idt.base>>16);
                                        if (msw&1) { writememb(easeg+eaaddr+5,idt.access); }
                                        else       { writememb(easeg+eaaddr+5,0xFF); }
                                        cycles-=7;
                                        break;
                                        case 0x10: /*LGDT*/
                                        gdt.limit=geteaw();
                                        gdt.base=(geteaw2())|(readmemb(easeg+eaaddr+4)<<16);
                                        gdt.access=readmemb(easeg+eaaddr+5);
                                        cycles-=11;
                                        break;
                                        case 0x18: /*LIDT*/
                                        idt.limit=geteaw();
                                        idt.base=(geteaw2())|(readmemb(easeg+eaaddr+4)<<16);
                                        idt.access=readmemb(easeg+eaaddr+5);
                                        cycles-=11;
                                        break;

                                        case 0x20: /*SMSW*/
                                        seteaw(msw);
                                        cycles-=2;
                                        break;
                                        case 0x30: /*LMSW*/
                                        if (CPL && (msw&1))
                                        {
                                                printf("LMSW - ring not zero!\n");
                                                dumpregs();
                                                exit(-1);
                                        }
                                        tempw=geteaw();
//                                        if ((tempw&1) && !(msw&1)) printf("Entering protected mode at %04X:%04X\n",CS,pc);
                                        if (!(tempw&1) && (msw&1))
                                        {
                                                printf("Can't leave protected mode on 286!\n");
                                                dumpregs();
                                                exit(-1);
                                        }
                                        msw=tempw;
                                        break;

                                        default:
                                        printf("Bad 0F 01 opcode %02X\n",rmdat&0x38);
                                        pc-=3;
                                        dumpregs();
                                        exit(-1);
                                }
                                break;

                                case 2: /*LAR*/
                                fetchea();
                                tempw=geteaw();
                                flags&=~Z_FLAG;
                                if (!(tempw&0xFFFC)) break; /*Null selector*/
                                tempi=(tempw&~7)<((tempw&4)?ldt.limit:gdt.limit);
                                tempw2=readmemw(0,((tempw&4)?ldt.base:gdt.base)+(tempw&~7)+4);
                                if ((tempw2&0xE00)==0x600) tempi=0; /*Interrupt or trap gate*/
                                if ((tempw2&0xC00)!=0xC00) /*Exclude conforming code segments*/
                                {
                                        tempw3=(tempw2>>13)&3;
                                        if (tempw3<CPL || tempw3<(tempw&3)) tempi=0;
                                }
                                if (tempi)
                                {
                                        flags|=Z_FLAG;
                                        regs[reg].w=readmemb(((tempw&4)?ldt.base:gdt.base)+(tempw&~7)+5)<<8;
                                }
                                cycles-=11;
                                break;

                                case 3: /*LSL*/
                                fetchea();
                                tempw=geteaw();
                                flags&=~Z_FLAG;
                                if (!(tempw&0xFFFC)) break; /*Null selector*/
                                tempi=(tempw&~7)<((tempw&4)?ldt.limit:gdt.limit);
                                tempw2=readmemw(0,((tempw&4)?ldt.base:gdt.base)+(tempw&~7)+4);
                                if ((tempw2&0xE00)==0x600) tempi=0; /*Interrupt or trap gate*/
                                if ((tempw2&0xC00)!=0xC00) /*Exclude conforming code segments*/
                                {
                                        tempw3=(tempw2>>13)&3;
                                        if (tempw3<CPL || tempw3<(tempw&3)) tempi=0;
                                }
                                if (tempi)
                                {
                                        flags|=Z_FLAG;
                                        regs[reg].w=readmemw(0,((tempw&4)?ldt.base:gdt.base)+(tempw&~7));
                                }
                                cycles-=10;
                                break;

                                case 5: /*LOADALL*/
//                                printf("At %04X:%04X  ",CS,pc);
                                flags=readmemw(0,0x818);
                                pc=readmemw(0,0x81A);
                                DS=readmemw(0,0x81E);
                                SS=readmemw(0,0x820);
                                CS=readmemw(0,0x822);
                                ES=readmemw(0,0x824);
                                DI=readmemw(0,0x826);
                                SI=readmemw(0,0x828);
                                BP=readmemw(0,0x82A);
                                SP=readmemw(0,0x82C);
                                BX=readmemw(0,0x82E);
                                DX=readmemw(0,0x830);
                                CX=readmemw(0,0x832);
                                AX=readmemw(0,0x834);
                                if (readmemw(0,0x806))
                                {
                                        printf("Something in LOADALL!\n");
                                        dumpregs();
                                        exit(-1);
                                }
                                es=readmemw(0,0x836)|(readmemb(0x838)<<16);
                                cs=readmemw(0,0x83C)|(readmemb(0x83E)<<16);
                                ss=readmemw(0,0x842)|(readmemb(0x844)<<16);
                                ds=readmemw(0,0x848)|(readmemb(0x84A)<<16);
                                cycles-=195;
//                                printf("LOADALL - %06X:%04X %06X:%04X %04X\n",ds,SI,es,DI,DX);
                                break;

                                case 6: /*CLTS*/
                                msw&=~8;
                                cycles-=5;
                                break;

                                case 0x84: /*JE*/
                                tempw=getword286();
                                if (flags&Z_FLAG) pc+=tempw;
                                cycles-=4;
                                break;
                                case 0x85: /*JNE*/
                                tempw=getword286();
                                if (!(flags&Z_FLAG)) pc+=tempw;
                                cycles-=4;
                                break;

                                case 0xFF: /*Invalid - Windows 3.1 syscall trap?*/
                                pc-=2;
                                if (msw&1)
                                {
                                        pmodeint(6,0);
                                }
                                else
                                {
                                        if (ssegs) ss=oldss;
                                        if (AT) writememw(ss,((SP-2)&0xFFFF),flags&~0xF000);
                                        else    writememw(ss,((SP-2)&0xFFFF),flags|0xF000);
                                        writememw(ss,((SP-4)&0xFFFF),CS);
                                        writememw(ss,((SP-6)&0xFFFF),pc);
                                        SP-=6;
                                        addr=6<<2;
//                                        flags&=~I_FLAG;
                                        pc=readmemw(0,addr);
                                        loadcs(readmemw(0,addr+2));
                                        if (!pc && !cs)
                                        {
                                                printf("Bad int %02X %04X:%04X\n",temp,oldcs,oldpc);
                                                dumpregs();
                                                exit(-1);
                                        }
                                }
                                cycles-=70;
                                break;

                                default:
                                printf("Bad 0F opcode %02X\n",temp);
                                pc-=2;
                                dumpregs();
                                exit(-1);
                        }
                        break;

                        case 0x66:
                        pc--;
                                if (msw&1)
                                {
                                        pmodeint(6,0);
                                }
                                else
                                {
                                        if (ssegs) ss=oldss;
                                        if (AT) writememw(ss,((SP-2)&0xFFFF),flags&~0xF000);
                                        else    writememw(ss,((SP-2)&0xFFFF),flags|0xF000);
                                        writememw(ss,((SP-4)&0xFFFF),CS);
                                        writememw(ss,((SP-6)&0xFFFF),pc);
                                        SP-=6;
                                        addr=6<<2;
//                                        flags&=~I_FLAG;
                                        pc=readmemw(0,addr);
                                        loadcs(readmemw(0,addr+2));
                                        if (!pc && !cs)
                                        {
                                                printf("Bad int %02X %04X:%04X\n",temp,oldcs,oldpc);
                                                dumpregs();
                                                exit(-1);
                                        }
                                }
                                cycles-=70;
                                break;

                        case 0x10: /*ADC 8,reg*/
                        fetchea();
                        temp=geteab();
                        temp2=getr8(reg);
                        setadc8(temp,temp2);
                        temp+=temp2+tempc;
                        seteab(temp);
                        if (!AT) cycles-=((mod==3)?3:24);
                        else    cycles-=((mod==3)?2:7);
                        break;
                        case 0x11: /*ADC 16,reg*/
                        fetchea();
                        tempw=geteaw();
                        tempw2=regs[reg].w;
                        setadc16(tempw,tempw2);
                        tempw+=tempw2+tempc;
                        seteaw(tempw);
                        if (!AT) cycles-=((mod==3)?3:24);
                        else    cycles-=((mod==3)?2:7);
                        break;
                        case 0x12: /*ADC reg,8*/
                        fetchea();
                        temp=geteab();
                        setadc8(getr8(reg),temp);
                        setr8(reg,getr8(reg)+temp+tempc);
                        if (!AT) cycles-=((mod==3)?3:13);
                        else     cycles-=((mod==3)?2:7);
                        break;
                        case 0x13: /*ADC reg,16*/
                        fetchea();
                        tempw=geteaw();
                        setadc16(regs[reg].w,tempw);
                        regs[reg].w+=tempw+tempc;
                        if (!AT) cycles-=((mod==3)?3:13);
                        else     cycles-=((mod==3)?2:7);
                        break;
                        case 0x14: /*ADC AL,#8*/
                        tempw=readmemb(cs+pc); pc++;
                        setadc8(AL,tempw);
                        AL+=tempw+tempc;
                        if (!AT) cycles-=4;
                        else     cycles-=3;
                        break;
                        case 0x15: /*ADC AX,#16*/
                        tempw=getword286();
                        setadc16(AX,tempw);
                        AX+=tempw+tempc;
                        if (!AT) cycles-=4;
                        else     cycles-=3;
                        break;

                        case 0x16: /*PUSH SS*/
                        if (ssegs) ss=oldss;
                        writememw(ss,((SP-2)&0xFFFF),SS);
                        SP-=2;
                        cycles-=((AT)?3:14);
                        break;
                        case 0x17: /*POP SS*/
                        if (ssegs) ss=oldss;
                        tempw=readmemw(ss,SP);
                        loadseg(tempw,&_ss);
                        SP+=2;
                        noint=1;
                        cycles-=((AT)?5:12);
//                        output=1;
                        break;

                        case 0x18: /*SBB 8,reg*/
                        fetchea();
                        temp=geteab();
                        temp2=getr8(reg);
                        setsbc8(temp,temp2);
                        temp-=(temp2+tempc);
                        seteab(temp);
                        if (!AT) cycles-=((mod==3)?3:24);
                        else    cycles-=((mod==3)?2:7);
                        break;
                        case 0x19: /*SBB 16,reg*/
                        fetchea();
                        tempw=geteaw();
                        tempw2=regs[reg].w;
//                        printf("%04X:%04X SBB %04X-%04X,%i\n",cs>>4,pc,tempw,tempw2,tempc);
                        setsbc16(tempw,tempw2);
                        tempw-=(tempw2+tempc);
                        seteaw(tempw);
                        if (!AT) cycles-=((mod==3)?3:24);
                        else    cycles-=((mod==3)?2:7);
                        break;
                        case 0x1A: /*SBB reg,8*/
                        fetchea();
                        temp=geteab();
                        setsbc8(getr8(reg),temp);
                        setr8(reg,getr8(reg)-(temp+tempc));
                        if (!AT) cycles-=((mod==3)?3:13);
                        else     cycles-=((mod==3)?2:7);
                        break;
                        case 0x1B: /*SBB reg,16*/
                        fetchea();
                        tempw=geteaw();
                        tempw2=regs[reg].w;
//                        printf("%04X:%04X SBB %04X-%04X,%i\n",cs>>4,pc,tempw,tempw2,tempc);
                        setsbc16(tempw2,tempw);
                        tempw2-=(tempw+tempc);
                        regs[reg].w=tempw2;
                        if (!AT) cycles-=((mod==3)?3:13);
                        else     cycles-=((mod==3)?2:7);
                        break;
                        case 0x1C: /*SBB AL,#8*/
                        temp=readmemb(cs+pc); pc++;
                        setsbc8(AL,temp);
                        AL-=(temp+tempc);
                        if (!AT) cycles-=4;
                        else     cycles-=3;
                        break;
                        case 0x1D: /*SBB AX,#16*/
                        tempw=getword286();
                        setsbc16(AX,tempw);
                        AX-=(tempw+tempc);
                        if (!AT) cycles-=4;
                        else     cycles-=3;
                        break;

                        case 0x1E: /*PUSH DS*/
                        if (ssegs) ss=oldss;
                        writememw(ss,((SP-2)&0xFFFF),DS);
                        SP-=2;
                        cycles-=((AT)?3:14);
                        break;
                        case 0x1F: /*POP DS*/
                        if (ssegs) ss=oldss;
                        tempw=readmemw(ss,SP);
                        loadseg(tempw,&_ds);
                        if (ssegs) oldds=ds;
                        SP+=2;
                        cycles-=((AT)?5:12);
                        break;

                        case 0x20: /*AND 8,reg*/
                        fetchea();
                        temp=geteab();
                        temp&=getr8(reg);
                        setznp8(temp);
                        flags&=~(C_FLAG|V_FLAG|A_FLAG);
                        seteab(temp);
                        if (!AT) cycles-=((mod==3)?3:24);
                        else    cycles-=((mod==3)?2:7);
                        break;
                        case 0x21: /*AND 16,reg*/
                        fetchea();
                        tempw=geteaw();
                        tempw&=regs[reg].w;
                        setznp16(tempw);
                        flags&=~(C_FLAG|V_FLAG|A_FLAG);
                        seteaw(tempw);
                        if (!AT) cycles-=((mod==3)?3:24);
                        else    cycles-=((mod==3)?2:7);
                        break;
                        case 0x22: /*AND reg,8*/
                        fetchea();
                        temp=geteab();
                        temp&=getr8(reg);
                        setznp8(temp);
                        flags&=~(C_FLAG|V_FLAG|A_FLAG);
                        setr8(reg,temp);
                        if (!AT) cycles-=((mod==3)?3:13);
                        else     cycles-=((mod==3)?2:7);
                        break;
                        case 0x23: /*AND reg,16*/
                        fetchea();
                        tempw=geteaw();
                        tempw&=regs[reg].w;
                        setznp16(tempw);
                        flags&=~(C_FLAG|V_FLAG|A_FLAG);
                        regs[reg].w=tempw;
                        if (!AT) cycles-=((mod==3)?3:13);
                        else     cycles-=((mod==3)?2:7);
                        break;
                        case 0x24: /*AND AL,#8*/
                        AL&=readmemb(cs+pc); pc++;
                        setznp8(AL);
                        flags&=~(C_FLAG|V_FLAG|A_FLAG);
                        if (!AT) cycles-=4;
                        else     cycles-=3;
                        break;
                        case 0x25: /*AND AX,#16*/
                        AX&=getword286();
                        setznp16(AX);
                        flags&=~(C_FLAG|V_FLAG|A_FLAG);
                        if (!AT) cycles-=4;
                        else     cycles-=3;
                        break;

                        case 0x26: /*ES:*/
                        oldss=ss;
                        oldds=ds;
                        ds=ss=es;
                        ssegs=2;
                        cycles-=4;
                        goto opcodestart;
//                        break;

                        case 0x27: /*DAA*/
                        if ((flags&A_FLAG) || ((AL&0xF)>9))
                        {
                                tempi=((unsigned short)AL)+6;
                                AL+=6;
                                flags|=A_FLAG;
                                if (tempi&0x100) flags|=C_FLAG;
                        }
//                        else
//                           flags&=~A_FLAG;
                        if ((flags&C_FLAG) || (AL>0x9F))
                        {
                                AL+=0x60;
                                flags|=C_FLAG;
                        }
//                        else
//                           flags&=~C_FLAG;
                        setznp8(AL);
                        if (!AT) cycles-=4;
                        else     cycles-=3;
                        break;

                        case 0x28: /*SUB 8,reg*/
                        fetchea();
                        temp=geteab();
                        setsub8(temp,getr8(reg));
                        temp-=getr8(reg);
                        seteab(temp);
                        if (!AT) cycles-=((mod==3)?3:24);
                        else    cycles-=((mod==3)?2:7);
                        break;
                        case 0x29: /*SUB 16,reg*/
                        fetchea();
                        tempw=geteaw();
//                        printf("%04X:%04X  %04X-%04X\n",cs>>4,pc,tempw,regs[reg].w);
                        setsub16(tempw,regs[reg].w);
                        tempw-=regs[reg].w;
                        seteaw(tempw);
                        if (!AT) cycles-=((mod==3)?3:24);
                        else    cycles-=((mod==3)?2:7);
                        break;
                        case 0x2A: /*SUB reg,8*/
                        fetchea();
                        temp=geteab();
                        setsub8(getr8(reg),temp);
                        setr8(reg,getr8(reg)-temp);
                        if (!AT) cycles-=((mod==3)?3:13);
                        else     cycles-=((mod==3)?2:7);
                        break;
                        case 0x2B: /*SUB reg,16*/
                        fetchea();
                        tempw=geteaw();
//                        printf("%04X:%04X  %04X-%04X\n",cs>>4,pc,regs[reg].w,tempw);
                        setsub16(regs[reg].w,tempw);
                        regs[reg].w-=tempw;
                        if (!AT) cycles-=((mod==3)?3:13);
                        else     cycles-=((mod==3)?2:7);
                        break;
                        case 0x2C: /*SUB AL,#8*/
                        temp=readmemb(cs+pc); pc++;
                        setsub8(AL,temp);
                        AL-=temp;
                        if (!AT) cycles-=4;
                        else     cycles-=3;
                        break;
                        case 0x2D: /*SUB AX,#16*/
//                        printf("INS %i\n",ins);
//                        output=1;
                        tempw=getword286();
                        setsub16(AX,tempw);
                        AX-=tempw;
                        if (!AT) cycles-=4;
                        else     cycles-=3;
                        break;
                        case 0x2E: /*CS:*/
                        oldss=ss;
                        oldds=ds;
                        ds=ss=cs;
                        ssegs=2;
                        cycles-=4;
                        goto opcodestart;
                        case 0x2F: /*DAS*/
                        if ((flags&A_FLAG)||((AL&0xF)>9))
                        {
                                tempi=((unsigned short)AL)-6;
                                AL-=6;
                                flags|=A_FLAG;
                                if (tempi&0x100) flags|=C_FLAG;
                        }
//                        else
//                           flags&=~A_FLAG;
                        if ((flags&C_FLAG)||(AL>0x9F))
                        {
                                AL-=0x60;
                                flags|=C_FLAG;
                        }
//                        else
//                           flags&=~C_FLAG;
                        setznp8(AL);
                        if (!AT) cycles-=4;
                        else     cycles-=3;
                        break;
                        case 0x30: /*XOR 8,reg*/
                        fetchea();
                        temp=geteab();
                        temp^=getr8(reg);
                        setznp8(temp);
                        flags&=~(C_FLAG|V_FLAG|A_FLAG);
                        seteab(temp);
                        if (!AT) cycles-=((mod==3)?3:24);
                        else    cycles-=((mod==3)?2:7);
                        break;
                        case 0x31: /*XOR 16,reg*/
                        fetchea();
                        tempw=geteaw();
                        tempw^=regs[reg].w;
                        setznp16(tempw);
                        flags&=~(C_FLAG|V_FLAG|A_FLAG);
                        seteaw(tempw);
                        if (!AT) cycles-=((mod==3)?3:24);
                        else    cycles-=((mod==3)?2:7);
                        break;
                        case 0x32: /*XOR reg,8*/
                        fetchea();
                        temp=geteab();
                        temp^=getr8(reg);
                        setznp8(temp);
                        flags&=~(C_FLAG|V_FLAG|A_FLAG);
                        setr8(reg,temp);
                        if (!AT) cycles-=((mod==3)?3:13);
                        else     cycles-=((mod==3)?2:7);
                        break;
                        case 0x33: /*XOR reg,16*/
                        fetchea();
                        tempw=geteaw();
                        tempw^=regs[reg].w;
                        setznp16(tempw);
                        flags&=~(C_FLAG|V_FLAG|A_FLAG);
                        regs[reg].w=tempw;
                        if (!AT) cycles-=((mod==3)?3:13);
                        else     cycles-=((mod==3)?2:7);
                        break;
                        case 0x34: /*XOR AL,#8*/
                        AL^=readmemb(cs+pc); pc++;
                        setznp8(AL);
                        flags&=~(C_FLAG|V_FLAG|A_FLAG);
                        if (!AT) cycles-=4;
                        else     cycles-=3;
                        break;
                        case 0x35: /*XOR AX,#16*/
                        AX^=getword286();
                        setznp16(AX);
                        flags&=~(C_FLAG|V_FLAG|A_FLAG);
                        if (!AT) cycles-=4;
                        else     cycles-=3;
                        break;

                        case 0x36: /*SS:*/
                        oldss=ss;
                        oldds=ds;
                        ds=ss=ss;
                        ssegs=2;
                        cycles-=4;
                        goto opcodestart;
//                        break;

                        case 0x37: /*AAA*/
                        if ((flags&A_FLAG)||((AL&0xF)>9))
                        {
                                AL+=6;
                                AH++;
                                flags|=(A_FLAG|C_FLAG);
                        }
                        else
                           flags&=~(A_FLAG|C_FLAG);
                        AL&=0xF;
                        cycles-=8;
                        break;

                        case 0x38: /*CMP 8,reg*/
                        fetchea();
                        temp=geteab();
//                        if (output) printf("CMP %02X-%02X\n",temp,getr8(reg));
                        setsub8(temp,getr8(reg));
                        if (!AT) cycles-=((mod==3)?3:13);
                        else     cycles-=((mod==3)?2:7);
                        break;
                        case 0x39: /*CMP 16,reg*/
                        fetchea();
                        tempw=geteaw();
//                        if (output) printf("CMP %04X-%04X\n",tempw,regs[reg].w);
                        setsub16(tempw,regs[reg].w);
                        if (!AT) cycles-=((mod==3)?3:13);
                        else     cycles-=((mod==3)?2:7);
                        break;
                        case 0x3A: /*CMP reg,8*/
                        fetchea();
                        temp=geteab();
//                        if (output) printf("CMP %02X-%02X\n",getr8(reg),temp);
                        setsub8(getr8(reg),temp);
                        if (!AT) cycles-=((mod==3)?3:13);
                        else     cycles-=((mod==3)?2:6);
                        break;
                        case 0x3B: /*CMP reg,16*/
                        fetchea();
                        tempw=geteaw();
//                        printf("CMP %04X-%04X\n",regs[reg].w,tempw);
                        setsub16(regs[reg].w,tempw);
                        if (!AT) cycles-=((mod==3)?3:13);
                        else     cycles-=((mod==3)?2:6);
                        break;
                        case 0x3C: /*CMP AL,#8*/
                        temp=readmemb(cs+pc); pc++;
                        setsub8(AL,temp);
                        if (!AT) cycles-=4;
                        else     cycles-=3;
                        break;
                        case 0x3D: /*CMP AX,#16*/
                        tempw=getword286();
                        setsub16(AX,tempw);
                        if (!AT) cycles-=4;
                        else     cycles-=3;
                        break;

                        case 0x3E: /*DS:*/
                        oldss=ss;
                        oldds=ds;
                        ds=ss=ds;
                        ssegs=2;
                        cycles-=4;
                        goto opcodestart;
//                        break;

                        case 0x3F: /*AAS*/
                        if ((flags&A_FLAG)||((AL&0xF)>9))
                        {
                                AL-=6;
                                AH--;
                                flags|=(A_FLAG|C_FLAG);
                        }
                        else
                           flags&=~(A_FLAG|C_FLAG);
                        AL&=0xF;
                        cycles-=8;
                        break;

                        case 0x40: case 0x41: case 0x42: case 0x43: /*INC r16*/
                        case 0x44: case 0x45: case 0x46: case 0x47:
                        setadd16nc(regs[opcode&7].w,1);
                        regs[opcode&7].w++;
//                        setznp16(regs[opcode&7].w);
                        if (!AT) cycles-=3;
                        else     cycles-=2;
                        break;
                        case 0x48: case 0x49: case 0x4A: case 0x4B: /*DEC r16*/
                        case 0x4C: case 0x4D: case 0x4E: case 0x4F:
                        setsub16nc(regs[opcode&7].w,1);
                        regs[opcode&7].w--;
//                        setznp16(regs[opcode&7].w);
                        if (!AT) cycles-=3;
                        else     cycles-=2;
                        break;

                        case 0x50: case 0x51: case 0x52: case 0x53: /*PUSH r16*/
                        case 0x54: case 0x55: case 0x56: case 0x57:
                        if (ssegs) ss=oldss;
                        if (AT)
                        {
                                writememw(ss,(SP-2)&0xFFFF,regs[opcode&7].w);
                                SP-=2;
                        }
                        else
                        {
                                SP-=2;
                                writememw(ss,SP,regs[opcode&7].w);
                        }
                        cycles-=((AT)?3:15);
                        break;
                        case 0x58: case 0x59: case 0x5A: case 0x5B: /*POP r16*/
                        case 0x5C: case 0x5D: case 0x5E: case 0x5F:
                        if (ssegs) ss=oldss;
                        SP+=2;
                        regs[opcode&7].w=readmemw(ss,(SP-2)&0xFFFF);
                        cycles-=((AT)?5:12);
                        break;

                        case 0x60: /*PUSHA*/
                        writememw(ss,((SP-2)&0xFFFF),AX);
                        writememw(ss,((SP-4)&0xFFFF),CX);
                        writememw(ss,((SP-6)&0xFFFF),DX);
                        writememw(ss,((SP-8)&0xFFFF),BX);
                        writememw(ss,((SP-10)&0xFFFF),SP);
                        writememw(ss,((SP-12)&0xFFFF),BP);
                        writememw(ss,((SP-14)&0xFFFF),SI);
                        writememw(ss,((SP-16)&0xFFFF),DI);
                        SP-=16;
                        cycles-=17;
                        break;
                        case 0x61: /*POPA*/
                        DI=readmemw(ss,((SP)&0xFFFF));
                        SI=readmemw(ss,((SP+2)&0xFFFF));
                        BP=readmemw(ss,((SP+4)&0xFFFF));
                        BX=readmemw(ss,((SP+8)&0xFFFF));
                        DX=readmemw(ss,((SP+10)&0xFFFF));
                        CX=readmemw(ss,((SP+12)&0xFFFF));
                        AX=readmemw(ss,((SP+14)&0xFFFF));
                        SP+=16;
                        cycles-=19;
                        break;
//                        case 0x66: /*BIOS trap*/
//                        callbios();
//                        cycles-=16;
//                        break;
//#if 0
                        case 0x68: /*PUSH #w*/
                        tempw=getword286();
                        writememw(ss,((SP-2)&0xFFFF),tempw);
                        SP-=2;
                        cycles-=3;
                        break;
                        case 0x69: /*IMUL r16*/
                        fetchea();
                        tempw=geteaw();
                        tempw2=getword286();
                        templ=((int)(signed short)tempw)*((int)(signed short)tempw2);
//                        printf("%04X*%04X = %08X\n",tempw,tempw2,templ);
                        if ((templ>>16)!=0 && (templ>>16)!=0xFFFF) flags|=C_FLAG|V_FLAG;
                        else                                       flags&=~(C_FLAG|V_FLAG);
                        regs[reg].w=templ&0xFFFF;
//                        seteaw(templ&0xFFFF);
                        cycles-=((mod==3)?24:21);
                        break;
                        case 0x6A: /*PUSH #eb*/
                        tempw=readmemb(cs+pc); pc++;
                        if (tempw&0x80) tempw|=0xFF00;
                        writememw(ss,((SP-2)&0xFFFF),tempw);
                        SP-=2;
                        cycles-=3;
                        break;
//                        #if 0
                        case 0x6B: /*IMUL r8*/
                        fetchea();
                        tempw=geteaw();
                        tempw2=readmemb(cs+pc); pc++;
                        if (tempw2&0x80) tempw2|=0xFF00;
//                        printf("%04X * %04X = ",tempw,tempw2);
                        templ=((int)(signed short)tempw)*((int)(signed short)tempw2);
//                        printf("%08X\n",templ);
                        if ((templ>>16)!=0 && (templ>>16)!=0xFFFF) flags|=C_FLAG|V_FLAG;
                        else                                       flags&=~(C_FLAG|V_FLAG);
                        regs[reg].w=templ&0xFFFF;
//                        seteaw(templ&0xFFFF);
                        cycles-=((mod==3)?24:21);
                        break;
//#endif
                        case 0x6C: /*INSB*/
                        temp=inb(DX);
                        writememb(es+DI,temp);
                        if (flags&D_FLAG) DI--;
                        else              DI++;
                        cycles-=5;
                        break;
                        case 0x6E: /*OUTSB*/
                        temp=readmemb(ds+SI);
                        if (flags&D_FLAG) SI--;
                        else              SI++;
                        outb(DX,temp);
                        cycles-=5;
                        break;
//                        #endif

                        case 0x70: /*JO*/
                        offset=(signed char)readmemb(cs+pc); pc++;
                        if (flags&V_FLAG) { pc+=offset; cycles-=12; }
                        cycles-=4;
                        break;
                        case 0x71: /*JNO*/
                        offset=(signed char)readmemb(cs+pc); pc++;
                        if (!(flags&V_FLAG)) { pc+=offset; cycles-=12; }
                        cycles-=4;
                        break;
                        case 0x72: /*JB*/
                        offset=(signed char)readmemb(cs+pc); pc++;
                        if (flags&C_FLAG) { pc+=offset; cycles-=12; }
                        cycles-=4;
                        break;
                        case 0x73: /*JNB*/
                        offset=(signed char)readmemb(cs+pc); pc++;
                        if (!(flags&C_FLAG)) { pc+=offset; cycles-=12; }
                        cycles-=4;
                        break;
                        case 0x74: /*JZ*/
                        offset=(signed char)readmemb(cs+pc); pc++;
                        if (flags&Z_FLAG) { pc+=offset; cycles-=12; }
                        cycles-=4;
                        break;
                        case 0x75: /*JNZ*/
                        offset=(signed char)readmemb(cs+pc); pc++;
                        if (!(flags&Z_FLAG)) { pc+=offset; cycles-=12; }
                        cycles-=4;
                        break;
                        case 0x76: /*JBE*/
                        offset=(signed char)readmemb(cs+pc); pc++;
                        if (flags&(C_FLAG|Z_FLAG)) { pc+=offset; cycles-=12; }
                        cycles-=4;
                        break;
                        case 0x77: /*JNBE*/
                        offset=(signed char)readmemb(cs+pc); pc++;
                        if (!(flags&(C_FLAG|Z_FLAG))) { pc+=offset; cycles-=12; }
                        cycles-=4;
                        break;
                        case 0x78: /*JS*/
                        offset=(signed char)readmemb(cs+pc); pc++;
                        if (flags&N_FLAG)  { pc+=offset; cycles-=12; }
                        cycles-=4;
                        break;
                        case 0x79: /*JNS*/
                        offset=(signed char)readmemb(cs+pc); pc++;
                        if (!(flags&N_FLAG))  { pc+=offset; cycles-=12; }
                        cycles-=4;
                        break;
                        case 0x7A: /*JP*/
                        offset=(signed char)readmemb(cs+pc); pc++;
                        if (flags&P_FLAG)  { pc+=offset; cycles-=12; }
                        cycles-=4;
                        break;
                        case 0x7B: /*JNP*/
                        offset=(signed char)readmemb(cs+pc); pc++;
                        if (!(flags&P_FLAG))  { pc+=offset; cycles-=12; }
                        cycles-=4;
                        break;
                        case 0x7C: /*JL*/
                        offset=(signed char)readmemb(cs+pc); pc++;
                        temp=(flags&N_FLAG)?1:0;
                        temp2=(flags&V_FLAG)?1:0;
                        if (temp!=temp2)  { pc+=offset; cycles-=12; }
                        cycles-=4;
                        break;
                        case 0x7D: /*JNL*/
                        offset=(signed char)readmemb(cs+pc); pc++;
                        temp=(flags&N_FLAG)?1:0;
                        temp2=(flags&V_FLAG)?1:0;
                        if (temp==temp2)  { pc+=offset; cycles-=12; }
                        cycles-=4;
                        break;
                        case 0x7E: /*JLE*/
                        offset=(signed char)readmemb(cs+pc); pc++;
                        temp=(flags&N_FLAG)?1:0;
                        temp2=(flags&V_FLAG)?1:0;
                        if ((flags&Z_FLAG) || (temp!=temp2))  { pc+=offset; cycles-=12; }
                        cycles-=4;
                        break;
                        case 0x7F: /*JNLE*/
                        offset=(signed char)readmemb(cs+pc); pc++;
                        temp=(flags&N_FLAG)?1:0;
                        temp2=(flags&V_FLAG)?1:0;
                        if (!((flags&Z_FLAG) || (temp!=temp2)))  { pc+=offset; cycles-=12; }
                        cycles-=4;
                        break;

                        case 0x80: case 0x82:
                        fetchea();
                        temp=geteab();
                        temp2=readmemb(cs+pc); pc++;
                        switch (rmdat&0x38)
                        {
                                case 0x00: /*ADD b,#8*/
                                setadd8(temp,temp2);
                                seteab(temp+temp2);
                                if (!AT) cycles-=((mod==3)?4:23);
                                else    cycles-=((mod==3)?3:7);
                                break;
                                case 0x08: /*OR b,#8*/
                                temp|=temp2;
                                setznp8(temp);
                                flags&=~(C_FLAG|V_FLAG|A_FLAG);
                                seteab(temp);
                                if (!AT) cycles-=((mod==3)?4:23);
                                else    cycles-=((mod==3)?3:7);
                                break;
                                case 0x10: /*ADC b,#8*/
//                                temp2+=(flags&C_FLAG);
                                setadc8(temp,temp2);
                                seteab(temp+temp2+tempc);
                                if (!AT) cycles-=((mod==3)?4:23);
                                else    cycles-=((mod==3)?3:7);
                                break;
                                case 0x18: /*SBB b,#8*/
//                                temp2+=(flags&C_FLAG);
                                setsbc8(temp,temp2);
                                seteab(temp-(temp2+tempc));
                                if (!AT) cycles-=((mod==3)?4:23);
                                else    cycles-=((mod==3)?3:7);
                                break;
                                case 0x20: /*AND b,#8*/
                                temp&=temp2;
                                setznp8(temp);
                                flags&=~(C_FLAG|V_FLAG|A_FLAG);
                                seteab(temp);
                                if (!AT) cycles-=((mod==3)?4:23);
                                else    cycles-=((mod==3)?3:7);
                                break;
                                case 0x28: /*SUB b,#8*/
                                setsub8(temp,temp2);
                                seteab(temp-temp2);
                                if (!AT) cycles-=((mod==3)?4:23);
                                else    cycles-=((mod==3)?3:7);
                                break;
                                case 0x30: /*XOR b,#8*/
                                temp^=temp2;
                                setznp8(temp);
                                flags&=~(C_FLAG|V_FLAG|A_FLAG);
                                seteab(temp);
                                if (!AT) cycles-=((mod==3)?4:23);
                                else    cycles-=((mod==3)?3:7);
                                break;
                                case 0x38: /*CMP b,#8*/
//                                printf("CMP %02X,%02X\n",temp,temp2);
//                                if (output) printf("83CMP %02X-%02X\n",temp,temp2);
                                setsub8(temp,temp2);
                                if (!AT) cycles-=((mod==3)?4:14);
                                else     cycles-=((mod==3)?3:6);
                                break;

                                default:
                                printf("Bad 80 opcode %02X\n",rmdat&0x38);
//                                dumpregs();
//                                exit(-1);
                        }
                        break;

                        case 0x81:
                        fetchea();
                        tempw=geteaw();
                        tempw2=getword286();
                        switch (rmdat&0x38)
                        {
                                case 0x00: /*ADD w,#16*/
                                setadd16(tempw,tempw2);
                                tempw+=tempw2;
                                seteaw(tempw);
                                if (!AT) cycles-=((mod==3)?4:23);
                                else    cycles-=((mod==3)?3:7);
                                break;
                                case 0x08: /*OR w,#16*/
                                tempw|=tempw2;
                                setznp16(tempw);
                                flags&=~(C_FLAG|V_FLAG|A_FLAG);
                                seteaw(tempw);
                                if (!AT) cycles-=((mod==3)?4:23);
                                else    cycles-=((mod==3)?3:7);
                                break;
                                case 0x10: /*ADC w,#16*/
//                                tempw2+=(flags&C_FLAG);
                                setadc16(tempw,tempw2);
                                tempw+=tempw2+tempc;
                                seteaw(tempw);
                                if (!AT) cycles-=((mod==3)?4:23);
                                else    cycles-=((mod==3)?3:7);
                                break;
                                case 0x20: /*AND w,#16*/
                                tempw&=tempw2;
                                setznp16(tempw);
                                flags&=~(C_FLAG|V_FLAG|A_FLAG);
                                seteaw(tempw);
                                if (!AT) cycles-=((mod==3)?4:23);
                                else    cycles-=((mod==3)?3:7);
                                break;
                                case 0x18: /*SBB w,#16*/
//                                tempw2+=(flags&C_FLAG);
                                setsbc16(tempw,tempw2);
                                seteaw(tempw-(tempw2+tempc));
                                if (!AT) cycles-=((mod==3)?4:23);
                                else    cycles-=((mod==3)?3:7);
                                break;
                                case 0x28: /*SUB w,#16*/
                                setsub16(tempw,tempw2);
                                tempw-=tempw2;
                                seteaw(tempw);
                                if (!AT) cycles-=((mod==3)?4:23);
                                else    cycles-=((mod==3)?3:7);
                                break;
                                case 0x30: /*XOR w,#16*/
                                tempw^=tempw2;
                                setznp16(tempw);
                                flags&=~(C_FLAG|V_FLAG|A_FLAG);
                                seteaw(tempw);
                                if (!AT) cycles-=((mod==3)?4:23);
                                else    cycles-=((mod==3)?3:7);
                                break;
                                case 0x38: /*CMP w,#16*/
//                                printf("CMP %04X %04X\n",tempw,tempw2);
                                setsub16(tempw,tempw2);
                                if (!AT) cycles-=((mod==3)?4:14);
                                else     cycles-=((mod==3)?3:6);
                                break;

                                default:
                                printf("Bad 81 opcode %02X\n",rmdat&0x38);
//                                dumpregs();
//                                exit(-1);
                        }
                        break;

                        case 0x83:
                        fetchea();
                        tempw=geteaw();
                        tempw2=readmemb(cs+pc); pc++;
                        if (tempw2&0x80) tempw2|=0xFF00;
                        switch (rmdat&0x38)
                        {
                                case 0x00: /*ADD w,#8*/
                                setadd16(tempw,tempw2);
                                tempw+=tempw2;
                                seteaw(tempw);
                                if (!AT) cycles-=((mod==3)?4:23);
                                else    cycles-=((mod==3)?3:7);
                                break;
                                case 0x08: /*OR w,#8*/
                                tempw|=tempw2;
                                setznp16(tempw);
                                seteaw(tempw);
                                flags&=~(C_FLAG|A_FLAG|V_FLAG);
                                if (!AT) cycles-=((mod==3)?4:23);
                                else    cycles-=((mod==3)?3:7);
                                break;
                                case 0x10: /*ADC w,#8*/
//                                tempw2+=(flags&C_FLAG);
                                setadc16(tempw,tempw2);
                                tempw+=tempw2+tempc;
                                seteaw(tempw);
                                if (!AT) cycles-=((mod==3)?4:23);
                                else    cycles-=((mod==3)?3:7);
                                break;
                                case 0x18: /*SBB w,#8*/
//                                tempw2+=(flags&C_FLAG);
                                setsbc16(tempw,tempw2);
                                tempw-=(tempw2+tempc);
                                seteaw(tempw);
                                if (!AT) cycles-=((mod==3)?4:23);
                                else    cycles-=((mod==3)?3:7);
                                break;
                                case 0x20: /*AND w,#8*/
                                tempw&=tempw2;
                                setznp16(tempw);
                                seteaw(tempw);
                                if (!AT) cycles-=((mod==3)?4:23);
                                else     cycles-=((mod==3)?3:7);
                                flags&=~(C_FLAG|A_FLAG|V_FLAG);
                                break;
                                case 0x28: /*SUB w,#8*/
                                setsub16(tempw,tempw2);
                                tempw-=tempw2;
                                seteaw(tempw);
                                if (!AT) cycles-=((mod==3)?4:23);
                                else     cycles-=((mod==3)?3:7);
                                break;
                                case 0x30: /*XOR w,#8*/
                                tempw^=tempw2;
                                setznp16(tempw);
                                seteaw(tempw);
                                if (!AT) cycles-=((mod==3)?4:23);
                                else     cycles-=((mod==3)?3:7);
                                flags&=~(C_FLAG|A_FLAG|V_FLAG);
                                break;
                                case 0x38: /*CMP w,#8*/
                                setsub16(tempw,tempw2);
                                if (!AT) cycles-=((mod==3)?4:14);
                                else     cycles-=((mod==3)?3:6);
                                break;

                                default:
                                printf("Bad 83 opcode %02X\n",rmdat&0x38);
//                                dumpregs();
//                                exit(-1);
                        }
                        break;

                        case 0x84: /*TEST b,reg*/
                        fetchea();
                        temp=geteab();
                        temp2=getr8(reg);
                        setznp8(temp&temp2);
                        flags&=~(C_FLAG|V_FLAG|A_FLAG);
                        if (!AT) cycles-=((mod==3)?3:13);
                        else     cycles-=((mod==3)?2:7);
                        break;
                        case 0x85: /*TEST w,reg*/
                        fetchea();
                        tempw=geteaw();
                        tempw2=regs[reg].w;
                        setznp16(tempw&tempw2);
                        flags&=~(C_FLAG|V_FLAG|A_FLAG);
                        if (!AT) cycles-=((mod==3)?3:13);
                        else     cycles-=((mod==3)?2:7);
                        break;
                        case 0x86: /*XCHG b,reg*/
                        fetchea();
                        temp=geteab();
                        seteab(getr8(reg));
                        setr8(reg,temp);
                        if (!AT) cycles-=((mod==3)?4:25);
                        else     cycles-=((mod==3)?3:5);
                        break;
                        case 0x87: /*XCHG w,reg*/
                        fetchea();
                        tempw=geteaw();
                        seteaw(regs[reg].w);
                        regs[reg].w=tempw;
                        if (!AT) cycles-=((mod==3)?4:25);
                        else     cycles-=((mod==3)?3:5);
                        break;

                        case 0x88: /*MOV b,reg*/
                        fetchea();
                        seteab(getr8(reg));
                        if (!AT) cycles-=((mod==3)?2:13);
                        else     cycles-=((mod==3)?2:3);
                        break;
                        case 0x89: /*MOV w,reg*/
                        fetchea();
                        seteaw(regs[reg].w);
                        if (!AT) cycles-=((mod==3)?2:13);
                        else     cycles-=((mod==3)?2:3);
                        break;
                        case 0x8A: /*MOV reg,b*/
                        fetchea();
                        temp=geteab();
                        setr8(reg,temp);
                        if (!AT) cycles-=((mod==3)?2:12);
                        else     cycles-=((mod==3)?2:5);
                        break;
                        case 0x8B: /*MOV reg,w*/
                        fetchea();
                        tempw=geteaw();
                        regs[reg].w=tempw;
                        if (!AT) cycles-=((mod==3)?2:12);
                        else     cycles-=((mod==3)?2:5);
                        break;

                        case 0x8C: /*MOV w,sreg*/
                        fetchea();
                        switch (rmdat&0x38)
                        {
                                case 0x00: /*ES*/
                                seteaw(ES);
                                break;
                                case 0x08: /*CS*/
                                seteaw(CS);
                                break;
                                case 0x18: /*DS*/
                                if (ssegs) ds=oldds;
                                seteaw(DS);
                                break;
                                case 0x10: /*SS*/
                                if (ssegs) ss=oldss;
                                seteaw(SS);
                                break;
                        }
                        if (!AT) cycles-=((mod==3)?2:13);
                        else     cycles-=((mod==3)?2:3);
                        break;

                        case 0x8D: /*LEA*/
                        fetchea();
                        regs[reg].w=eaaddr;
                        if (!AT) cycles-=2;
                        else     cycles-=3;
                        break;

                        case 0x8E: /*MOV sreg,w*/
//                        if (output) printf("MOV %04X  ",pc);
                        fetchea();
//                        if (output) printf("%04X %02X\n",pc,rmdat);
                        switch (rmdat&0x38)
                        {
                                case 0x00: /*ES*/
                                tempw=geteaw();
                                loadseg(tempw,&_es);
                                break;
                                case 0x18: /*DS*/
                                tempw=geteaw();
                                loadseg(tempw,&_ds);
                                if (ssegs) oldds=ds;
                                break;
                                case 0x10: /*SS*/
                                tempw=geteaw();
                                loadseg(tempw,&_ss);
                                if (ssegs) oldss=ss;
                                skipnextprint=1;
				noint=1;
//                                printf("LOAD SS %04X %04X\n",tempw,SS);
//				printf("SS loaded with %04X %04X:%04X %04X %04X %04X\n",ss>>4,cs>>4,pc,CX,DX,es>>4);
                                break;
                        }
                        if (!AT) cycles-=((mod==3)?2:12);
                        else     cycles-=((mod==3)?2:5);
                        break;

                        case 0x8F: /*POPW*/
                        fetchea();
                        if (ssegs) ss=oldss;
                        tempw=readmemw(ss,SP);
                        SP+=2;
                        //if (output) printf("POPW - %04X\n",tempw);
                        seteaw(tempw);
                        cycles-=((mod==3)?12:25);
                        break;

                        case 0x90: /*NOP*/
                        cycles-=3;
                        break;

                        case 0x91: case 0x92: case 0x93: /*XCHG AX*/
                        case 0x94: case 0x95: case 0x96: case 0x97:
                        tempw=AX;
                        AX=regs[opcode&7].w;
                        regs[opcode&7].w=tempw;
                        cycles-=3;
                        break;

                        case 0x98: /*CBW*/
                        AH=(AL&0x80)?0xFF:0;
                        cycles-=2;
                        break;
                        case 0x99: /*CWD*/
                        DX=(AX&0x8000)?0xFFFF:0;
                        if (!AT) cycles-=5;
                        else     cycles-=2;
                        break;
                        case 0x9A: /*CALL FAR*/
                        tempw=getword286();
                        tempw2=getword286();
                        tempw3=CS;
                        tempw4=pc;
//                        printf("Call FAR %04X:%04X %04X:%04X\n",CS,pc,tempw,tempw2);
                        if (ssegs) ss=oldss;
                        pc=tempw;
                        if (msw&1) loadcscall(tempw2);
                        else       loadcs(tempw2);
                        if (notpresent) break;
/*                        if ((msw&1) && !(_cs.access&4) && ((CS&3)<(tempw3&3)))
                        {
                                printf("Call to non-confirming inner segment!\n");
                                dumpregs();
                                exit(-1);
                        }*/
                        writememw(ss,(SP-2)&0xFFFF,tempw3);
                        writememw(ss,(SP-4)&0xFFFF,tempw4);
                        SP-=4;
                        if (!AT) cycles-=36;
                        else     cycles-=13;
                        break;
                        case 0x9B: /*WAIT*/
                        cycles-=4;
                        break;
                        case 0x9C: /*PUSHF*/
//                        printf("PUSHF %04X:%04X\n",CS,pc);
                        if (ssegs) ss=oldss;
                        if (AT) writememw(ss,((SP-2)&0xFFFF),flags&~0xF000);
                        else    writememw(ss,((SP-2)&0xFFFF),flags|0xF000);
                        SP-=2;
                        cycles-=((AT)?3:14);
                        break;
                        case 0x9D: /*POPF*/
//                        printf("POPF %04X:%04X\n",CS,pc);
/*                        if (CS==0xFFFF)
                        {
                                dumpregs();
                                exit(-1);
                        }*/
                        if (ssegs) ss=oldss;
                        flags=readmemw(ss,SP)&0xFFF;
                        SP+=2;
                        cycles-=((AT)?5:12);
                        break;
                        case 0x9E: /*SAHF*/
                        flags=(flags&0xFF00)|AH;
                        if (!AT) cycles-=4;
                        else     cycles-=2;
                        break;
                        case 0x9F: /*LAHF*/
                        AH=flags&0xFF;
                        if (!AT) cycles-=4;
                        else     cycles-=2;
                        break;

                        case 0xA0: /*MOV AL,(w)*/
                        addr=getword286();
                        AL=readmemb(ds+addr);
                        cycles-=((AT)?5:14);
                        break;
                        case 0xA1: /*MOV AX,(w)*/
                        addr=getword286();
//                        printf("Reading AX from %05X %04X:%04X\n",ds+addr,ds>>4,addr);
                        AX=readmemw(ds,addr);
                        cycles-=((AT)?5:14);
                        break;
                        case 0xA2: /*MOV (w),AL*/
                        addr=getword286();
                        writememb(ds+addr,AL);
                        cycles-=((AT)?3:14);
                        break;
                        case 0xA3: /*MOV (w),AX*/
                        addr=getword286();
//                        if (!addr) printf("Write !addr %04X:%04X\n",cs>>4,pc);
                        writememw(ds,addr,AX);
                        cycles-=((AT)?3:14);
                        break;

                        case 0xA4: /*MOVSB*/
                        temp=readmemb(ds+SI);
                        writememb(es+DI,temp);
                        if (flags&D_FLAG) { DI--; SI--; }
                        else              { DI++; SI++; }
                        cycles-=((AT)?5:18);
                        break;
                        case 0xA5: /*MOVSW*/
                        tempw=readmemw(ds,SI);
                        writememw(es,DI,tempw);
                        if (flags&D_FLAG) { DI-=2; SI-=2; }
                        else              { DI+=2; SI+=2; }
                        cycles-=((AT)?5:18);
                        break;
                        case 0xA6: /*CMPSB*/
                        temp =readmemb(ds+SI);
                        temp2=readmemb(es+DI);
                        setsub8(temp,temp2);
                        if (flags&D_FLAG) { DI--; SI--; }
                        else              { DI++; SI++; }
                        if (!AT) cycles-=30;
                        else     cycles-=8;
                        break;
                        case 0xA7: /*CMPSW*/
                        tempw =readmemw(ds,SI);
                        tempw2=readmemw(es,DI);
//                        printf("CMPSW %04X %04X\n",tempw,tempw2);
                        setsub16(tempw,tempw2);
                        if (flags&D_FLAG) { DI-=2; SI-=2; }
                        else              { DI+=2; SI+=2; }
                        if (!AT) cycles-=30;
                        else     cycles-=8;
                        break;
                        case 0xA8: /*TEST AL,#8*/
                        temp=readmemb(cs+pc); pc++;
                        setznp8(AL&temp);
                        flags&=~(C_FLAG|V_FLAG|A_FLAG);
                        cycles-=((AT)?3:5);
                        break;
                        case 0xA9: /*TEST AX,#16*/
                        tempw=getword286();
                        setznp16(AX&tempw);
                        flags&=~(C_FLAG|V_FLAG|A_FLAG);
                        cycles-=((AT)?3:5);
                        break;
                        case 0xAA: /*STOSB*/
                        writememb(es+DI,AL);
                        if (flags&D_FLAG) DI--;
                        else              DI++;
                        cycles-=((AT)?3:11);
                        break;
                        case 0xAB: /*STOSW*/
                        writememw(es,DI,AX);
                        if (flags&D_FLAG) DI-=2;
                        else              DI+=2;
                        cycles-=((AT)?3:11);
                        break;
                        case 0xAC: /*LODSB*/
                        AL=readmemb(ds+SI);
//                        printf("LODSB %04X:%04X %02X %04X:%04X\n",cs>>4,pc,AL,ds>>4,SI);
                        if (flags&D_FLAG) SI--;
                        else              SI++;
                        cycles-=((AT)?5:16);
                        break;
                        case 0xAD: /*LODSW*/
//                        if (times) printf("LODSW %04X:%04X\n",cs>>4,pc);
                        AX=readmemw(ds,SI);
                        if (flags&D_FLAG) SI-=2;
                        else              SI+=2;
                        cycles-=((AT)?5:16);
                        break;
                        case 0xAE: /*SCASB*/
                        temp=readmemb(es+DI);
                        setsub8(AL,temp);
                        if (flags&D_FLAG) DI--;
                        else              DI++;
                        cycles-=((AT)?7:19);
                        break;
                        case 0xAF: /*SCASW*/
                        tempw=readmemw(es,DI);
                        setsub16(AX,tempw);
                        if (flags&D_FLAG) DI-=2;
                        else              DI+=2;
                        cycles-=((AT)?7:19);
                        break;

                        case 0xB0: /*MOV AL,#8*/
                        AL=readmemb(cs+pc),pc++;
                        cycles-=((AT)?2:4);
                        break;
                        case 0xB1: /*MOV CL,#8*/
                        CL=readmemb(cs+pc),pc++;
                        cycles-=((AT)?2:4);
                        break;
                        case 0xB2: /*MOV DL,#8*/
                        DL=readmemb(cs+pc),pc++;
                        cycles-=((AT)?2:4);
                        break;
                        case 0xB3: /*MOV BL,#8*/
                        BL=readmemb(cs+pc),pc++;
                        cycles-=((AT)?2:4);
                        break;
                        case 0xB4: /*MOV AH,#8*/
                        AH=readmemb(cs+pc),pc++;
                        cycles-=((AT)?2:4);
                        break;
                        case 0xB5: /*MOV CH,#8*/
                        CH=readmemb(cs+pc),pc++;
                        cycles-=((AT)?2:4);
                        break;
                        case 0xB6: /*MOV DH,#8*/
                        DH=readmemb(cs+pc),pc++;
                        cycles-=((AT)?2:4);
                        break;
                        case 0xB7: /*MOV BH,#8*/
                        BH=readmemb(cs+pc),pc++;
                        cycles-=((AT)?2:4);
                        break;
                        case 0xB8: case 0xB9: case 0xBA: case 0xBB: /*MOV reg,#16*/
                        case 0xBC: case 0xBD: case 0xBE: case 0xBF:
                        regs[opcode&7].w=getword286();
                        cycles-=((AT)?2:4);
                        break;

                        case 0xC0:
                        fetchea();
                        c=readmemb(cs+pc); pc++;
                        temp=geteab();
                        if (AT) c&=31;
                        if (!c) break;
                        switch (rmdat&0x38)
                        {
                                case 0x00: /*ROL b,CL*/
                                while (c>0)
                                {
                                        temp2=(temp&0x80)?1:0;
                                        temp=(temp<<1)|temp2;
                                        c--;
                                        cycles-=((AT)?1:4);
                                }
                                if (temp2) flags|=C_FLAG;
                                else       flags&=~C_FLAG;
                                seteab(temp);
                                if ((flags&C_FLAG)^(temp>>7)) flags|=V_FLAG;
                                else                          flags&=~V_FLAG;
//                                setznp8(temp);
                                if (!AT) cycles-=((mod==3)?8:28);
                                else     cycles-=((mod==3)?5:8);
                                break;
                                case 0x08: /*ROR b,CL*/
                                while (c>0)
                                {
                                        temp2=temp&1;
                                        temp>>=1;
                                        if (temp2) temp|=0x80;
                                        c--;
                                        cycles-=((AT)?1:4);
                                }
                                if (temp2) flags|=C_FLAG;
                                else       flags&=~C_FLAG;
                                seteab(temp);
                                if ((temp^(temp>>1))&0x40) flags|=V_FLAG;
                                else                       flags&=~V_FLAG;
                                if (!AT) cycles-=((mod==3)?8:28);
                                else     cycles-=((mod==3)?5:8);
                                break;
                                case 0x10: /*RCL b,CL*/
                                while (c>0)
                                {
                                        tempc=(flags&C_FLAG)?1:0;
                                        if (temp&0x80) flags|=C_FLAG;
                                        else           flags&=~C_FLAG;
                                        temp=(temp<<1)|tempc;
                                        c--;
                                        cycles-=((AT)?1:4);
                                }
                                seteab(temp);
                                if ((flags&C_FLAG)^(temp>>7)) flags|=V_FLAG;
                                else                          flags&=~V_FLAG;
                                if (!AT) cycles-=((mod==3)?8:28);
                                else     cycles-=((mod==3)?5:8);
                                break;
                                case 0x18: /*RCR b,CL*/
                                while (c>0)
                                {
                                        tempc=(flags&C_FLAG)?0x80:0;
                                        if (temp&1) flags|=C_FLAG;
                                        else        flags&=~C_FLAG;
                                        temp=(temp>>1)|tempc;
                                        c--;
                                        cycles-=((AT)?1:4);
                                }
                                seteab(temp);
                                if ((temp^(temp>>1))&0x40) flags|=V_FLAG;
                                else                       flags&=~V_FLAG;
                                if (!AT) cycles-=((mod==3)?8:28);
                                else     cycles-=((mod==3)?5:8);
                                break;
                                case 0x20: case 0x30: /*SHL b,CL*/
                                if ((temp<<(c-1))&0x80) flags|=C_FLAG;
                                else                    flags&=~C_FLAG;
                                temp<<=c;
                                seteab(temp);
                                setznp8(temp);
                                cycles-=(c*((AT)?1:4));
                                if (!AT) cycles-=((mod==3)?8:28);
                                else     cycles-=((mod==3)?5:8);
                                flags|=A_FLAG;
                                break;
                                case 0x28: /*SHR b,CL*/
                                if ((temp>>(c-1))&1) flags|=C_FLAG;
                                else                 flags&=~C_FLAG;
                                temp>>=c;
                                seteab(temp);
                                setznp8(temp);
                                cycles-=(c*((AT)?1:4));
                                if (!AT) cycles-=((mod==3)?8:28);
                                else     cycles-=((mod==3)?5:8);
                                flags|=A_FLAG;
                                break;
                                case 0x38: /*SAR b,CL*/
                                if ((temp>>(c-1))&1) flags|=C_FLAG;
                                else                 flags&=~C_FLAG;
                                while (c>0)
                                {
                                        temp>>=1;
                                        if (temp&0x40) temp|=0x80;
                                        c--;
                                        cycles-=((AT)?1:4);
                                }
                                seteab(temp);
                                setznp8(temp);
                                if (!AT) cycles-=((mod==3)?8:28);
                                else     cycles-=((mod==3)?5:8);
                                flags|=A_FLAG;
                                break;

                                default:
                                printf("Bad C0 opcode %02X\n",rmdat&0x38);
//                                dumpregs();
//                                exit(-1);
                        }
                        break;

                        case 0xC1:
                        fetchea();
                        c=readmemb(cs+pc); pc++;
                        if (AT) c&=31;
                        tempw=geteaw();
                        if (!c) break;
                        switch (rmdat&0x38)
                        {
                                case 0x00: /*ROL w,CL*/
                                while (c>0)
                                {
                                        temp=(tempw&0x8000)?1:0;
                                        tempw=(tempw<<1)|temp;
                                        c--;
                                        cycles-=((AT)?1:4);
                                }
                                if (temp) flags|=C_FLAG;
                                else      flags&=~C_FLAG;
                                seteaw(tempw);
                                if ((flags&C_FLAG)^(tempw>>15)) flags|=V_FLAG;
                                else                            flags&=~V_FLAG;
                                if (!AT) cycles-=((mod==3)?8:28);
                                else     cycles-=((mod==3)?5:8);
                                break;
                                case 0x08: /*ROR w,CL*/
                                while (c>0)
                                {
                                        tempw2=(tempw&1)?0x8000:0;
                                        tempw=(tempw>>1)|tempw2;
                                        c--;
                                        cycles-=((AT)?1:4);
                                }
                                if (tempw2) flags|=C_FLAG;
                                else        flags&=~C_FLAG;
                                seteaw(tempw);
                                if ((tempw^(tempw>>1))&0x4000) flags|=V_FLAG;
                                else                           flags&=~V_FLAG;
//                                setznp16(tempw);
                                if (!AT) cycles-=((mod==3)?8:28);
                                else     cycles-=((mod==3)?5:8);
                                break;
                                case 0x10: /*RCL w,CL*/
                                while (c>0)
                                {
                                        tempc=(flags&C_FLAG)?1:0;
                                        if (tempw&0x8000) flags|=C_FLAG;
                                        else              flags&=~C_FLAG;
                                        tempw=(tempw<<1)|tempc;
                                        c--;
                                        cycles-=((AT)?1:4);
                                }
                                seteaw(tempw);
                                if ((flags&C_FLAG)^(tempw>>15)) flags|=V_FLAG;
                                else                            flags&=~V_FLAG;
                                if (!AT) cycles-=((mod==3)?8:28);
                                else     cycles-=((mod==3)?5:8);
                                break;
                                case 0x18: /*RCR w,CL*/
                                while (c>0)
                                {
                                        tempc=(flags&C_FLAG)?0x8000:0;
                                        if (tempw&1) flags|=C_FLAG;
                                        else         flags&=~C_FLAG;
                                        tempw=(tempw>>1)|tempc;
                                        c--;
                                        cycles-=((AT)?1:4);
                                }
                                seteaw(tempw);
                                if ((tempw^(tempw>>1))&0x4000) flags|=V_FLAG;
                                else                           flags&=~V_FLAG;
                                if (!AT) cycles-=((mod==3)?8:28);
                                else     cycles-=((mod==3)?5:8);
                                break;

                                case 0x20: case 0x30: /*SHL w,CL*/
                                if ((tempw<<(c-1))&0x8000) flags|=C_FLAG;
                                else                       flags&=~C_FLAG;
                                tempw<<=c;
                                seteaw(tempw);
                                setznp16(tempw);
                                cycles-=(c*((AT)?1:4));
                                if (!AT) cycles-=((mod==3)?8:28);
                                else     cycles-=((mod==3)?5:8);
                                flags|=A_FLAG;
                                break;

                                case 0x28:            /*SHR w,CL*/
                                if ((tempw>>(c-1))&1) flags|=C_FLAG;
                                else                  flags&=~C_FLAG;
                                tempw>>=c;
                                seteaw(tempw);
                                setznp16(tempw);
                                cycles-=(c*((AT)?1:4));
                                if (!AT) cycles-=((mod==3)?8:28);
                                else     cycles-=((mod==3)?5:8);
                                flags|=A_FLAG;
                                break;

                                case 0x38:            /*SAR w,CL*/
                                tempw2=tempw&0x8000;
                                if ((tempw>>(c-1))&1) flags|=C_FLAG;
                                else                  flags&=~C_FLAG;
                                while (c>0)
                                {
                                        tempw=(tempw>>1)|tempw2;
                                        c--;
                                        cycles-=((AT)?1:4);
                                }
                                seteaw(tempw);
                                setznp16(tempw);
                                if (!AT) cycles-=((mod==3)?8:28);
                                else     cycles-=((mod==3)?5:8);
                                flags|=A_FLAG;
                                break;

                                default:
                                printf("Bad C1 opcode %02X\n",rmdat&0x38);
//                                dumpregs();
//                                exit(-1);
                        }
                        break;

                        case 0xC2: /*RET*/
                        tempw=getword286();
                        if (ssegs) ss=oldss;
                        pc=readmemw(ss,SP);
//                        printf("RET to %04X\n",pc);
                        SP+=2+tempw;
                        cycles-=((AT)?11:24);
                        break;
                        case 0xC3: /*RET*/
                        if (ssegs) ss=oldss;
                        pc=readmemw(ss,SP);
//                        if (output) printf("RET to %04X %05X\n",pc,ss+SP);
                        SP+=2;
                        cycles-=((AT)?11:20);
                        break;
                        case 0xC4: /*LES*/
                        fetchea();
                        regs[reg].w=readmemw(easeg,eaaddr); //geteaw();
                        tempw=readmemw(easeg,(eaaddr+2)&0xFFFF); //geteaw2();
                        loadseg(tempw,&_es);
                        if (!AT) cycles-=24;
                        else     cycles-=7;
                        break;
                        case 0xC5: /*LDS*/
                        fetchea();
                        regs[reg].w=readmemw(easeg,eaaddr);
                        tempw=readmemw(easeg,(eaaddr+2)&0xFFFF);
                        loadseg(tempw,&_ds);
                        if (ssegs) oldds=ds;
                        if (!AT) cycles-=24;
                        else     cycles-=7;
                        break;
                        case 0xC6: /*MOV b,#8*/
                        fetchea();
                        temp=readmemb(cs+pc); pc++;
                        seteab(temp);
                        if (!AT) cycles-=((mod==3)?4:14);
                        else     cycles-=((mod==3)?2:3);
                        break;
                        case 0xC7: /*MOV w,#16*/
                        fetchea();
                        tempw=getword286();
                        seteaw(tempw);
                        if (!AT) cycles-=((mod==3)?4:14);
                        else     cycles-=((mod==3)?2:3);
                        break;
                        case 0xC8: /*ENTER*/
                        tempw3=getword286();
                        tempi=readmemb(cs+pc); pc++;
                        writememw(ss,((SP-2)&0xFFFF),BP); SP-=2;
                        tempw2=SP;
                        if (tempi>0)
                        {
                                while (--tempi)
                                {
                                        BP-=2;
                                        tempw=readmemw(ss,BP);
                                        writememw(ss,((SP-2)&0xFFFF),tempw); SP-=2;
                                }
                                writememw(ss,((SP-2)&0xFFFF),tempw2); SP-=2;
                        }
                        BP=tempw2;  SP-=tempw3;
                        cycles-=15;
                        break;
                        case 0xC9: /*LEAVE*/
                        SP=BP;
                        BP=readmemw(ss,SP);
                        SP+=2;
                        cycles-=5;
                        break;
                        case 0xCA: /*RETF*/
                        tempw=getword286();
                        tempw2=CPL;
                        if (ssegs) ss=oldss;
                        pc=readmemw(ss,SP);
                        loadcs(readmemw(ss,SP+2));
                        if (notpresent) break;
                        SP+=4;
                        SP+=tempw;
                        if ((msw&1) && CPL>tempw2)
                        {
                                tempw=readmemw(ss,SP);
                                loadseg(readmemw(ss,SP+2),&_ss);
                                SP=tempw;
/*                                printf("RET to outer level! %04X\n",tempw2);
                                dumpregs();
                                exit(-1);*/
                        }
//                        cs=CS<<4;
                        cycles-=((AT)?15:33);
                        break;
                        case 0xCB: /*RETF*/
                        tempw2=CPL;
                        if (ssegs) ss=oldss;
                        pc=readmemw(ss,SP);
                        loadcs(readmemw(ss,SP+2));
                        if (notpresent) break;
                        SP+=4;
                        if ((msw&1) && CPL>tempw2)
                        {
                                tempw=readmemw(ss,SP);
                                loadseg(readmemw(ss,SP+2),&_ss);
                                SP=tempw;
//                                printf("RET to outer level! %04X\n",tempw2);
//                                dumpregs();
//                                exit(-1);
                        }
//                        cs=CS<<4;
                        cycles-=((AT)?15:34);
                        break;
                        case 0xCC: /*INT 3*/
                        if (msw&1) pmodeint(3,1);
                        else
                        {
                                if (ssegs) ss=oldss;
                                if (AT) writememw(ss,((SP-2)&0xFFFF),flags&~0xF000);
                                else    writememw(ss,((SP-2)&0xFFFF),flags|0xF000);
                                writememw(ss,((SP-4)&0xFFFF),CS);
                                writememw(ss,((SP-6)&0xFFFF),pc);
                                SP-=6;
                                addr=3<<2;
                                flags&=~I_FLAG;
                                pc=readmemw(0,addr);
                                loadcs(readmemw(0,addr+2));
                        }
                        if (!AT) cycles-=72;
                        else     cycles-=23;
                        break;
                        case 0xCD: /*INT*/
                        lastpc=pc;
                        lastcs=CS;
                        temp=readmemb(cs+pc); pc++;
//                        if (temp==0x10 && !AH) printf("Entering mode %02X\n",AL);
//                        if (temp==0x18 || temp==0x19) { printf("INT %02X\n",temp); output=1; }
//                        printf("INT %02X %04X %04X %04X %04X %04X:%04X\n",temp,AX,BX,CX,DX,CS,pc);
/*                        if (output)
                        {
                                dumpregs();
                                exit(-1);
                        }*/
/*                        if (temp==0x21) printf("INT 21 %04X %04X %04X %04X %04X:%04X %06X %06X\n",AX,BX,CX,DX,cs>>4,pc,ds,ds+DX);
                        if (temp==0x21 && AH==9)
                        {
                                addr=0;
                                while (ram[ds+DX+addr]!='$')
                                {
                                        printf("%c",ram[ds+DX+addr]);
                                        addr++;
                                }
                                printf("\n");
                                printf("Called from %04X\n",readmemw(ss,SP));
                        }*/
//                        output=0;
//                        if (temp==0x13 && AH==3) printf("Write sector %04X:%04X %05X\n",es>>4,BX,es+BX);
                        if (temp==0x13 && (DL==0x80 || DL==0x81) && AH>0)
                        {
                                int13hdc();
                        }
                        else if (temp==0x13 && AH==2 && DL<2 && FASTDISC)
                        {
                                int13read();
                                //output=1;
                        }
                        else if (temp==0x13 && AH==3 && DL<2 && FASTDISC)
                        {
                                int13write();
                        }
                        else if (temp==0x13 && AH==4 && DL<2 && FASTDISC)
                        {
                                AH=0;
                                flags&=~C_FLAG;
                        }
                        else
                        {
                                if (msw&1)
                                {
//                                        printf("PMODE int %02X %04X at %04X:%04X  ",temp,AX,CS,pc);
                                        pmodeint(temp,1);
//                                        printf("to %04X:%04X\n",CS,pc);
                                }
                                else
                                {
                                        if (ssegs) ss=oldss;
                                        if (AT) writememw(ss,((SP-2)&0xFFFF),flags&~0xF000);
                                        else    writememw(ss,((SP-2)&0xFFFF),flags|0xF000);
                                        writememw(ss,((SP-4)&0xFFFF),CS);
                                        writememw(ss,((SP-6)&0xFFFF),pc);
                                        SP-=6;
                                        addr=temp<<2;
//                                        flags&=~I_FLAG;
                                        pc=readmemw(0,addr);
                                        loadcs(readmemw(0,addr+2));
                                        if (!pc && !cs)
                                        {
                                                printf("Bad int %02X %04X:%04X\n",temp,oldcs,oldpc);
                                                dumpregs();
                                                exit(-1);
                                        }
                                }
                        }
                        if (!AT) cycles-=71;
                        else     cycles-=23;
                        break;
                        case 0xCF: /*IRET*/
//                        if (inint) printf("IRET %04X %04X:%04X\n",flags,cs>>4,pc,SP);
/*                        if (output)
                        {
                                dumpregs();
                                exit(-1);
                        }*/
//                        if (!inint) output=0;
                        if (ssegs) ss=oldss;
                        if (msw&1) pmodeiret();
                        else
                        {
                                tempw=CS;
                                tempw2=pc;
                                inint=0;
                                pc=readmemw(ss,SP);
                                loadcs(readmemw(ss,((SP+2)&0xFFFF)));
                                if (notpresent) break;
                                flags=readmemw(ss,((SP+4)&0xFFFF))&0xFFF;
                                SP+=6;
                        }
                        if (!AT) cycles-=44;
                        else     cycles-=17;
//                        printf("%04X %04X\n",flags,SP);
                        break;
                        case 0xD0:
                        fetchea();
                        temp=geteab();
                        switch (rmdat&0x38)
                        {
                                case 0x00: /*ROL b,1*/
                                if (temp&0x80) flags|=C_FLAG;
                                else           flags&=~C_FLAG;
                                temp<<=1;
                                if (flags&C_FLAG) temp|=1;
                                seteab(temp);
//                                setznp8(temp);
                                if ((flags&C_FLAG)^(temp>>7)) flags|=V_FLAG;
                                else                          flags&=~V_FLAG;
                                if (!AT) cycles-=((mod==3)?2:23);
                                else     cycles-=((mod==3)?2:7);
                                break;
                                case 0x08: /*ROR b,1*/
                                if (temp&1) flags|=C_FLAG;
                                else        flags&=~C_FLAG;
                                temp>>=1;
                                if (flags&C_FLAG) temp|=0x80;
                                seteab(temp);
//                                setznp8(temp);
                                if ((temp^(temp>>1))&0x40) flags|=V_FLAG;
                                else                       flags&=~V_FLAG;
                                if (!AT) cycles-=((mod==3)?2:23);
                                else     cycles-=((mod==3)?2:7);
                                break;
                                case 0x10: /*RCL b,1*/
                                temp2=flags&C_FLAG;
                                if (temp&0x80) flags|=C_FLAG;
                                else           flags&=~C_FLAG;
                                temp<<=1;
                                if (temp2) temp|=1;
                                seteab(temp);
//                                setznp8(temp);
                                if ((flags&C_FLAG)^(temp>>7)) flags|=V_FLAG;
                                else                          flags&=~V_FLAG;
                                if (!AT) cycles-=((mod==3)?2:23);
                                else     cycles-=((mod==3)?2:7);
                                break;
                                case 0x18: /*RCR b,1*/
                                temp2=flags&C_FLAG;
                                if (temp&1) flags|=C_FLAG;
                                else        flags&=~C_FLAG;
                                temp>>=1;
                                if (temp2) temp|=0x80;
                                seteab(temp);
//                                setznp8(temp);
                                if ((temp^(temp>>1))&0x40) flags|=V_FLAG;
                                else                       flags&=~V_FLAG;
                                if (!AT) cycles-=((mod==3)?2:23);
                                else     cycles-=((mod==3)?2:7);
                                break;
                                case 0x20: /*SHL b,1*/
                                if (temp&0x80) flags|=C_FLAG;
                                else           flags&=~C_FLAG;
                                if ((temp^(temp<<1))&0x80) flags|=V_FLAG;
                                else                       flags&=~V_FLAG;
                                temp<<=1;
                                seteab(temp);
                                setznp8(temp);
                                if (!AT) cycles-=((mod==3)?2:23);
                                else     cycles-=((mod==3)?2:7);
                                flags|=A_FLAG;
                                break;
                                case 0x28: /*SHR b,1*/
                                if (temp&1) flags|=C_FLAG;
                                else        flags&=~C_FLAG;
                                if (temp&0x80) flags|=V_FLAG;
                                else           flags&=~V_FLAG;
                                temp>>=1;
                                seteab(temp);
                                setznp8(temp);
                                if (!AT) cycles-=((mod==3)?2:23);
                                else     cycles-=((mod==3)?2:7);
                                flags|=A_FLAG;
                                break;
                                case 0x38: /*SAR b,1*/
                                if (temp&1) flags|=C_FLAG;
                                else        flags&=~C_FLAG;
                                temp>>=1;
                                if (temp&0x40) temp|=0x80;
                                seteab(temp);
                                setznp8(temp);
                                if (!AT) cycles-=((mod==3)?2:23);
                                else     cycles-=((mod==3)?2:7);
                                flags|=A_FLAG;
                                flags&=~V_FLAG;
                                break;

                                default:
                                printf("Bad D0 opcode %02X\n",rmdat&0x38);
//                                dumpregs();
//                                exit(-1);
                        }
                        break;

                        case 0xD1:
                        fetchea();
                        tempw=geteaw();
                        switch (rmdat&0x38)
                        {
                                case 0x00: /*ROL w,1*/
                                if (tempw&0x8000) flags|=C_FLAG;
                                else              flags&=~C_FLAG;
                                tempw<<=1;
                                if (flags&C_FLAG) tempw|=1;
                                seteaw(tempw);
//                                setznp16(tempw);
                                if ((flags&C_FLAG)^(tempw>>15)) flags|=V_FLAG;
                                else                            flags&=~V_FLAG;
                                if (!AT) cycles-=((mod==3)?2:23);
                                else     cycles-=((mod==3)?2:7);
                                break;
                                case 0x08: /*ROR w,1*/
                                if (tempw&1) flags|=C_FLAG;
                                else         flags&=~C_FLAG;
                                tempw>>=1;
                                if (flags&C_FLAG) tempw|=0x8000;
                                seteaw(tempw);
//                                setznp16(tempw);
                                if ((tempw^(tempw>>1))&0x4000) flags|=V_FLAG;
                                else                           flags&=~V_FLAG;
                                if (!AT) cycles-=((mod==3)?2:23);
                                else     cycles-=((mod==3)?2:7);
                                break;
                                case 0x10: /*RCL w,1*/
                                temp2=flags&C_FLAG;
                                if (tempw&0x8000) flags|=C_FLAG;
                                else              flags&=~C_FLAG;
                                tempw<<=1;
                                if (temp2) tempw|=1;
                                seteaw(tempw);
                                if ((flags&C_FLAG)^(tempw>>15)) flags|=V_FLAG;
                                else                            flags&=~V_FLAG;
                                if (!AT) cycles-=((mod==3)?2:23);
                                else     cycles-=((mod==3)?2:7);
                                break;
                                case 0x18: /*RCR w,1*/
                                temp2=flags&C_FLAG;
                                if (tempw&1) flags|=C_FLAG;
                                else         flags&=~C_FLAG;
                                tempw>>=1;
                                if (temp2) tempw|=0x8000;
                                seteaw(tempw);
//                                setznp16(tempw);
                                if ((tempw^(tempw>>1))&0x4000) flags|=V_FLAG;
                                else                           flags&=~V_FLAG;
                                if (!AT) cycles-=((mod==3)?2:23);
                                else     cycles-=((mod==3)?2:7);
                                break;
                                case 0x20: /*SHL w,1*/
                                if (tempw&0x8000) flags|=C_FLAG;
                                else              flags&=~C_FLAG;
                                if ((tempw^(tempw<<1))&0x8000) flags|=V_FLAG;
                                else                           flags&=~V_FLAG;
                                tempw<<=1;
                                seteaw(tempw);
                                setznp16(tempw);
                                if (!AT) cycles-=((mod==3)?2:23);
                                else     cycles-=((mod==3)?2:7);
                                flags|=A_FLAG;
                                break;
                                case 0x28: /*SHR w,1*/
                                if (tempw&1) flags|=C_FLAG;
                                else         flags&=~C_FLAG;
                                if (tempw&0x8000) flags|=V_FLAG;
                                else              flags&=~V_FLAG;
                                tempw>>=1;
                                seteaw(tempw);
                                setznp16(tempw);
                                if (!AT) cycles-=((mod==3)?2:23);
                                else     cycles-=((mod==3)?2:7);
                                flags|=A_FLAG;
                                break;

                                case 0x38: /*SAR w,1*/
                                if (tempw&1) flags|=C_FLAG;
                                else         flags&=~C_FLAG;
                                tempw>>=1;
                                if (tempw&0x4000) tempw|=0x8000;
                                seteaw(tempw);
                                setznp16(tempw);
                                if (!AT) cycles-=((mod==3)?2:23);
                                else     cycles-=((mod==3)?2:7);
                                flags|=A_FLAG;
                                flags&=~V_FLAG;
                                break;

                                default:
                                printf("Bad D1 opcode %02X\n",rmdat&0x38);
//                                dumpregs();
//                                exit(-1);
                        }
                        break;

                        case 0xD2:
                        fetchea();
                        temp=geteab();
                        if (AT) c=CL&31;
                        else    c=CL;
//                        cycles-=c;
                        if (!c) break;
//                        if (c>7) printf("Shiftb %i %02X\n",rmdat&0x38,c);
                        switch (rmdat&0x38)
                        {
                                case 0x00: /*ROL b,CL*/
                                while (c>0)
                                {
                                        temp2=(temp&0x80)?1:0;
                                        temp=(temp<<1)|temp2;
                                        c--;
                                        cycles-=((AT)?1:4);
                                }
                                if (temp2) flags|=C_FLAG;
                                else       flags&=~C_FLAG;
                                seteab(temp);
//                                setznp8(temp);
                                if ((flags&C_FLAG)^(temp>>7)) flags|=V_FLAG;
                                else                          flags&=~V_FLAG;
                                if (!AT) cycles-=((mod==3)?8:28);
                                else     cycles-=((mod==3)?5:8);
                                break;
                                case 0x08: /*ROR b,CL*/
                                while (c>0)
                                {
                                        temp2=temp&1;
                                        temp>>=1;
                                        if (temp2) temp|=0x80;
                                        c--;
                                        cycles-=((AT)?1:4);
                                }
                                if (temp2) flags|=C_FLAG;
                                else       flags&=~C_FLAG;
                                seteab(temp);
                                if ((temp^(temp>>1))&0x40) flags|=V_FLAG;
                                else                       flags&=~V_FLAG;
                                if (!AT) cycles-=((mod==3)?8:28);
                                else     cycles-=((mod==3)?5:8);
                                break;
                                case 0x10: /*RCL b,CL*/
//                                printf("RCL %i %02X %02X\n",c,CL,temp);
                                while (c>0)
                                {
                                        templ=flags&C_FLAG;
                                        temp2=temp&0x80;
                                        temp<<=1;
                                        if (temp2) flags|=C_FLAG;
                                        else       flags&=~C_FLAG;
                                        if (templ) temp|=1;
                                        c--;
                                        cycles-=((AT)?1:4);
                                }
//                                printf("Now %02X\n",temp);
                                seteab(temp);
                                if ((flags&C_FLAG)^(temp>>7)) flags|=V_FLAG;
                                else                          flags&=~V_FLAG;
                                if (!AT) cycles-=((mod==3)?8:28);
                                else     cycles-=((mod==3)?5:8);
                                break;
                                case 0x18: /*RCR b,CL*/
                                while (c>0)
                                {
                                        templ=flags&C_FLAG;
                                        temp2=temp&1;
                                        temp>>=1;
                                        if (temp2) flags|=C_FLAG;
                                        else       flags&=~C_FLAG;
                                        if (templ) temp|=0x80;
                                        c--;
                                        cycles-=((AT)?1:4);
                                }
//                                if (temp2) flags|=C_FLAG;
//                                else       flags&=~C_FLAG;
                                seteab(temp);
                                if ((temp^(temp>>1))&0x40) flags|=V_FLAG;
                                else                       flags&=~V_FLAG;
                                if (!AT) cycles-=((mod==3)?8:28);
                                else     cycles-=((mod==3)?5:8);
                                break;
                                case 0x20: case 0x30: /*SHL b,CL*/
                                if ((temp<<(c-1))&0x80) flags|=C_FLAG;
                                else                    flags&=~C_FLAG;
                                temp<<=c;
                                seteab(temp);
                                setznp8(temp);
                                cycles-=(c*((AT)?1:4));
                                if (!AT) cycles-=((mod==3)?8:28);
                                else     cycles-=((mod==3)?5:8);
                                flags|=A_FLAG;
                                break;
                                case 0x28: /*SHR b,CL*/
                                if ((temp>>(c-1))&1) flags|=C_FLAG;
                                else                 flags&=~C_FLAG;
                                temp>>=c;
                                seteab(temp);
                                setznp8(temp);
                                cycles-=(c*((AT)?1:4));
                                if (!AT) cycles-=((mod==3)?8:28);
                                else     cycles-=((mod==3)?5:8);
                                flags|=A_FLAG;
                                break;
                                case 0x38: /*SAR b,CL*/
                                if ((temp>>(c-1))&1) flags|=C_FLAG;
                                else                 flags&=~C_FLAG;
                                while (c>0)
                                {
                                        temp>>=1;
                                        if (temp&0x40) temp|=0x80;
                                        c--;
                                        cycles-=((AT)?1:4);
                                }
                                seteab(temp);
                                setznp8(temp);
                                if (!AT) cycles-=((mod==3)?8:28);
                                else     cycles-=((mod==3)?5:8);
                                flags|=A_FLAG;
                                break;

                                default:
                                printf("Bad D2 opcode %02X\n",rmdat&0x38);
//                                dumpregs();
//                                exit(-1);
                        }
                        break;

                        case 0xD3:
                        fetchea();
                        tempw=geteaw();
                        if (AT) c=CL&31;
                        else    c=CL;
//                      cycles-=c;
                        if (!c) break;
//                        if (c>15) printf("Shiftw %i %02X\n",rmdat&0x38,c);
                        switch (rmdat&0x38)
                        {
                                case 0x00: /*ROL w,CL*/
                                while (c>0)
                                {
                                        temp=(tempw&0x8000)?1:0;
                                        tempw=(tempw<<1)|temp;
                                        c--;
                                        cycles-=((AT)?1:4);
                                }
                                if (temp) flags|=C_FLAG;
                                else      flags&=~C_FLAG;
                                seteaw(tempw);
                                if ((flags&C_FLAG)^(tempw>>15)) flags|=V_FLAG;
                                else                            flags&=~V_FLAG;
                                if (!AT) cycles-=((mod==3)?8:28);
                                else     cycles-=((mod==3)?5:8);
                                break;
                                case 0x08: /*ROR w,CL*/
                                while (c>0)
                                {
                                        tempw2=(tempw&1)?0x8000:0;
                                        tempw=(tempw>>1)|tempw2;
                                        c--;
                                        cycles-=((AT)?1:4);
                                }
                                if (tempw2) flags|=C_FLAG;
                                else        flags&=~C_FLAG;
                                seteaw(tempw);
                                if ((tempw^(tempw>>1))&0x4000) flags|=V_FLAG;
                                else                           flags&=~V_FLAG;
                                if (!AT) cycles-=((mod==3)?8:28);
                                else     cycles-=((mod==3)?5:8);
                                break;
                                case 0x10: /*RCL w,CL*/
                                while (c>0)
                                {
                                        templ=flags&C_FLAG;
                                        if (tempw&0x8000) flags|=C_FLAG;
                                        else              flags&=~C_FLAG;
                                        tempw=(tempw<<1)|templ;
                                        c--;
                                        cycles-=((AT)?1:4);
                                }
                                if (temp) flags|=C_FLAG;
                                else      flags&=~C_FLAG;
                                seteaw(tempw);
                                if ((flags&C_FLAG)^(tempw>>15)) flags|=V_FLAG;
                                else                            flags&=~V_FLAG;
                                if (!AT) cycles-=((mod==3)?8:28);
                                else     cycles-=((mod==3)?5:8);
                                break;
                                case 0x18: /*RCR w,CL*/
                                while (c>0)
                                {
                                        templ=flags&C_FLAG;
                                        tempw2=(templ&1)?0x8000:0;
                                        if (tempw&1) flags|=C_FLAG;
                                        else         flags&=~C_FLAG;
                                        tempw=(tempw>>1)|tempw2;
                                        c--;
                                        cycles-=((AT)?1:4);
                                }
                                if (tempw2) flags|=C_FLAG;
                                else        flags&=~C_FLAG;
                                seteaw(tempw);
                                if ((tempw^(tempw>>1))&0x4000) flags|=V_FLAG;
                                else                           flags&=~V_FLAG;
                                if (!AT) cycles-=((mod==3)?8:28);
                                else     cycles-=((mod==3)?5:8);
                                break;

                                case 0x20: case 0x30: /*SHL w,CL*/
                                if (c>16)
                                {
                                        tempw=0;
                                        flags&=~C_FLAG;
                                }
                                else
                                {
                                        if ((tempw<<(c-1))&0x8000) flags|=C_FLAG;
                                        else                       flags&=~C_FLAG;
                                        tempw<<=c;
                                }
                                seteaw(tempw);
                                setznp16(tempw);
                                cycles-=(c*((AT)?1:4));
                                if (!AT) cycles-=((mod==3)?8:28);
                                else     cycles-=((mod==3)?5:8);
                                flags|=A_FLAG;
                                break;

                                case 0x28:            /*SHR w,CL*/
                                if ((tempw>>(c-1))&1) flags|=C_FLAG;
                                else                  flags&=~C_FLAG;
                                tempw>>=c;
                                seteaw(tempw);
                                setznp16(tempw);
                                cycles-=(c*((AT)?1:4));
                                if (!AT) cycles-=((mod==3)?8:28);
                                else     cycles-=((mod==3)?5:8);
                                flags|=A_FLAG;
                                break;

                                case 0x38:            /*SAR w,CL*/
                                tempw2=tempw&0x8000;
                                if ((tempw>>(c-1))&1) flags|=C_FLAG;
                                else                  flags&=~C_FLAG;
                                while (c>0)
                                {
                                        tempw=(tempw>>1)|tempw2;
                                        c--;
                                        cycles-=((AT)?1:4);
                                }
                                seteaw(tempw);
                                setznp16(tempw);
                                if (!AT) cycles-=((mod==3)?8:28);
                                else     cycles-=((mod==3)?5:8);
                                flags|=A_FLAG;
                                break;

                                default:
                                printf("Bad D3 opcode %02X\n",rmdat&0x38);
//                                dumpregs();
//                                exit(-1);
                        }
                        break;

                        case 0xD4: /*AAM*/
                        tempws=readmemb(cs+pc); pc++;
                        AH=AL/tempws;
                        AL%=tempws;
                        setznp168(AX);
                        cycles-=83;
                        break;
                        case 0xD5: /*AAD*/
                        tempws=readmemb(cs+pc); pc++;
                        AL=(AH*tempws)+AL;
                        AH=0;
                        setznp168(AX);
                        cycles-=60;
                        break;
                        case 0xD7: /*XLAT*/
                        addr=BX+AL;
                        AL=readmemb(ds+addr);
                        cycles-=((AT)?5:11);
                        break;
                        case 0xD9: case 0xDA: case 0xDB: case 0xDD: /*ESCAPE*/
                        case 0xDC: case 0xDE: case 0xDF: case 0xD8:
                        if (msw&1)
                        {
                                if ((msw&5)==5)
                                {
                                        pc--;
                                        pmodeint(7,0);
                                        cycles-=59;
                                }
                                else
                                {
                                        fetchea();
                                        geteab();
                                }
                        }
                        else
                        {
                                fetchea();
                                geteab();
                        }
                        break;

                        case 0xE0: /*LOOPNE*/
                        offset=(signed char)readmemb(cs+pc); pc++;
                        CX--;
                        if (CX && !(flags&Z_FLAG)) { pc+=offset; cycles-=12; }
                        cycles-=((AT)?4:6);
                        break;
                        case 0xE1: /*LOOPE*/
                        offset=(signed char)readmemb(cs+pc); pc++;
                        CX--;
                        if (CX && (flags&Z_FLAG)) { pc+=offset; cycles-=12; }
                        cycles-=((AT)?4:6);
                        break;
                        case 0xE2: /*LOOP*/
//                        printf("LOOP start\n");
                        offset=(signed char)readmemb(cs+pc); pc++;
                        CX--;
                        if (CX) { pc+=offset; cycles-=12; }
                        cycles-=((AT)?4:5);
//                        printf("LOOP end!\n");
                        break;
                        case 0xE3: /*JCXZ*/
                        offset=(signed char)readmemb(cs+pc); pc++;
                        if (!CX) { pc+=offset; cycles-=12; }
                        cycles-=6;
                        break;

                        case 0xE4: /*IN AL*/
                        temp=readmemb(cs+pc); pc++;
                        AL=inb(temp);
                        if (!AT) cycles-=14;
                        else     cycles-=5;
                        break;
                        case 0xE5: /*IN AX*/
                        temp=readmemb(cs+pc); pc++;
                        AL=inb(temp);
                        AH=inb(temp+1);
                        if (!AT) cycles-=14;
                        else     cycles-=5;
                        break;
                        case 0xE6: /*OUT AL*/
                        temp=readmemb(cs+pc); pc++;
                        outb(temp,AL);
                        if (!AT) cycles-=14;
                        else     cycles-=3;
                        break;
                        case 0xE7: /*OUT AX*/
                        temp=readmemb(cs+pc); pc++;
                        outb(temp,AL);
                        outb(temp+1,AH);
                        if (!AT) cycles-=14;
                        else     cycles-=3;
                        break;

                        case 0xE8: /*CALL rel 16*/
                        tempw=getword286();
                        if (ssegs) ss=oldss;
//                        writememb(ss+((SP-1)&0xFFFF),pc>>8);
                        writememw(ss,((SP-2)&0xFFFF),pc);
                        SP-=2;
                        pc+=tempw;
                        if (!AT) cycles-=23;
                        else     cycles-=7;
                        break;
                        case 0xE9: /*JMP rel 16*/
//                        printf("PC was %04X\n",pc);
                        pc+=getword286();
//                        printf("PC now %04X\n",pc);
                        cycles-=((AT)?7:15);
                        break;
                        case 0xEA: /*JMP far*/
                        addr=getword286();
                        tempw=getword286();
                        pc=addr;
                        loadcs(tempw);
//                        cs=loadcs(CS);
//                        cs=CS<<4;
                        cycles-=((AT)?11:15);
                        break;
                        case 0xEB: /*JMP rel*/
                        offset=(signed char)readmemb(cs+pc); pc++;
                        pc+=offset;
                        cycles-=((AT)?7:15);
                        break;
                        case 0xEC: /*IN AL,DX*/
                        AL=inb(DX);
                        if (!AT) cycles-=12;
                        else     cycles-=5;
                        break;
                        case 0xED: /*IN AX,DX*/
                        AL=inb(DX);
                        AH=inb(DX+1);
                        if (!AT) cycles-=12;
                        else     cycles-=5;
                        break;
                        case 0xEE: /*OUT DX,AL*/
                        outb(DX,AL);
                        if (!AT) cycles-=12;
                        else     cycles-=3;
                        break;
                        case 0xEF: /*OUT DX,AX*/
                        outb(DX,AL);
                        outb(DX+1,AH);
                        if (!AT) cycles-=12;
                        else     cycles-=3;
                        break;

                        case 0xF0: /*LOCK*/
                        cycles-=4;
                        break;

                        case 0xF2: /*rep286NE*/
                        rep286(0);
                        break;
                        case 0xF3: /*rep286E*/
                        rep286(1);
                        break;

                        case 0xF4: /*HLT*/
                        printf("IN HLT!!!! %04X:%04X %08X %08X %08X\n",oldcs,oldpc,old8,old82,old83);
                        dumpregs();
                        exit(-1);
                        inhlt=1;
                        pc--;
                        cycles-=2;
                        break;
                        case 0xF5: /*CMC*/
                        flags^=C_FLAG;
                        cycles-=2;
                        break;

                        case 0xF6:
                        fetchea();
                        temp=geteab();
                        switch (rmdat&0x38)
                        {
                                case 0x00: /*TEST b,#8*/
                                temp2=readmemb(cs+pc); pc++;
//                                printf("TEST %02X,%02X\n",temp,temp2);
/*                        if (cs==0x700 && !temp && temp2==0x10)
                        {
                                dumpregs();
                                exit(-1);
                        }*/
                                temp&=temp2;
                                setznp8(temp);
                                flags&=~(C_FLAG|V_FLAG|A_FLAG);
                                if (!AT) cycles-=((mod==3)?5:11);
                                else     cycles-=((mod==3)?3:6);
                                break;
                                case 0x10: /*NOT b*/
                                temp=~temp;
                                seteab(temp);
                                if (!AT) cycles-=((mod==3)?3:24);
                                else     cycles-=((mod==3)?2:7);
                                break;
                                case 0x18: /*NEG b*/
                                setsub8(0,temp);
                                temp=0-temp;
                                seteab(temp);
                                if (!AT) cycles-=((mod==3)?3:24);
                                else     cycles-=((mod==3)?2:7);
                                break;
                                case 0x20: /*MUL AL,b*/
                                setznp8(AL);
                                AX=AL*temp;
                                if (AX) flags&=~Z_FLAG;
                                else    flags|=Z_FLAG;
                                if (AH) flags|=(C_FLAG|V_FLAG);
                                else    flags&=~(C_FLAG|V_FLAG);
                                cycles-=((AT)?13:70);
                                break;
                                case 0x28: /*IMUL AL,b*/
                                setznp8(AL);
                                tempws=(int)((signed char)AL)*(int)((signed char)temp);
                                AX=tempws&0xFFFF;
                                if (AX) flags&=~Z_FLAG;
                                else    flags|=Z_FLAG;
                                if (AH) flags|=(C_FLAG|V_FLAG);
                                else    flags&=~(C_FLAG|V_FLAG);
                                if (!AT) cycles-=80;
                                else     cycles-=13;
                                break;
                                case 0x30: /*DIV AL,b*/
                                tempw=AX;
                                if (temp)
                                {
                                        tempw2=tempw%temp;
/*                                        if (!tempw)
                                        {
                                                writememw((ss+SP)-2,flags|0xF000);
                                                writememw((ss+SP)-4,cs>>4);
                                                writememw((ss+SP)-6,pc);
                                                SP-=6;
                                                flags&=~I_FLAG;
                                                pc=readmemw(0);
                                                cs=readmemw(2)<<4;
                                                printf("Div by zero %04X:%04X\n",cs>>4,pc);
//                                                dumpregs();
//                                                exit(-1);
                                        }
                                        else
                                        {*/
                                                AH=tempw2;
                                                tempw/=temp;
                                                AL=tempw&0xFF;
//                                        }
                                }
                                else
                                {
                                        printf("DIVb BY 0 %04X:%04X\n",cs>>4,pc);
                                        if (msw&1) pmodeint(0,1);
                                        else
                                        {
//                                        printf("%04X:%04X\n",cs>>4,pc);
                                                if (AT) writememw(ss,(SP-2)&0xFFFF,flags&~0xF000);
                                                else    writememw(ss,(SP-2)&0xFFFF,flags|0xF000);
                                                writememw(ss,(SP-4)&0xFFFF,CS);
                                                writememw(ss,(SP-6)&0xFFFF,pc);
                                                SP-=6;
                                                flags&=~I_FLAG;
                                                pc=readmemw(0,0);
                                                loadcs(readmemw(0,2));
                                        }
//                                                cs=loadcs(CS);
//                                                cs=CS<<4;
//                                        printf("Div by zero %04X:%04X %02X %02X\n",cs>>4,pc,0xf6,0x30);
//                                        dumpregs();
//                                        exit(-1);
                                }
                                if (!AT) cycles-=80;
                                else     cycles-=14;
                                break;
                                case 0x38: /*IDIV AL,b*/
                                tempws=(int)AX;
                                if (temp)
                                {
                                        tempw2=tempws%(int)((signed char)temp);
/*                                        if (!tempw)
                                        {
                                                writememw((ss+SP)-2,flags|0xF000);
                                                writememw((ss+SP)-4,cs>>4);
                                                writememw((ss+SP)-6,pc);
                                                SP-=6;
                                                flags&=~I_FLAG;
                                                pc=readmemw(0);
                                                cs=readmemw(2)<<4;
                                                printf("Div by zero %04X:%04X\n",cs>>4,pc);
                                        }
                                        else
                                        {*/
                                                AH=tempw2&0xFF;
                                                tempws/=(int)((signed char)temp);
                                                AL=tempws&0xFF;
//                                        }
                                }
                                else
                                {
                                        printf("IDIVb BY 0 %04X:%04X\n",cs>>4,pc);
                                        if (msw&1) pmodeint(0,1);
                                        else
                                        {
                                                if (AT) writememw(ss,(SP-2)&0xFFFF,flags&~0xF000);
                                                else    writememw(ss,(SP-2)&0xFFFF,flags|0xF000);
                                                writememw(ss,(SP-4)&0xFFFF,CS);
                                                writememw(ss,(SP-6)&0xFFFF,pc);
                                                SP-=6;
                                                flags&=~I_FLAG;
                                                pc=readmemw(0,0);
                                                loadcs(readmemw(0,2));
                                        }
//                                                cs=loadcs(CS);
//                                                cs=CS<<4;
//                                        printf("Div by zero %04X:%04X %02X %02X\n",cs>>4,pc,0xf6,0x38);
                                }
                                if (!AT) cycles-=101;
                                else     cycles-=17;
                                break;

                                default:
                                printf("Bad F6 opcode %02X\n",rmdat&0x38);
//                                dumpregs();
//                                exit(-1);
                        }
                        break;

                        case 0xF7:
                        fetchea();
                        tempw=geteaw();
                        switch (rmdat&0x38)
                        {
                                case 0x00: /*TEST w*/
                                tempw2=getword286();
                                setznp16(tempw&tempw2);
                                flags&=~(C_FLAG|V_FLAG|A_FLAG);
                                if (!AT) cycles-=((mod==3)?5:11);
                                else     cycles-=((mod==3)?3:6);
                                break;
                                case 0x10: /*NOT w*/
                                seteaw(~tempw);
                                if (!AT) cycles-=((mod==3)?3:24);
                                else     cycles-=((mod==3)?2:7);
                                break;
                                case 0x18: /*NEG w*/
                                setsub16(0,tempw);
                                tempw=0-tempw;
                                seteaw(tempw);
                                if (!AT) cycles-=((mod==3)?3:24);
                                else     cycles-=((mod==3)?2:7);
                                break;
                                case 0x20: /*MUL AX,w*/
                                setznp16(AX);
                                templ=AX*tempw;
                                if (output) printf("%04X*%04X=%08X\n",AX,tempw,templ);
                                AX=templ&0xFFFF;
                                DX=templ>>16;
                                if (AX|DX) flags&=~Z_FLAG;
                                else       flags|=Z_FLAG;
                                if (DX)    flags|=(C_FLAG|V_FLAG);
                                else       flags&=~(C_FLAG|V_FLAG);
                                cycles-=((AT)?21:118);
                                break;
                                case 0x28: /*IMUL AX,w*/
                                setznp16(AX);
//                                printf("IMUL %i %i ",(int)((signed short)AX),(int)((signed short)tempw));
                                tempws=(int)((signed short)AX)*(int)((signed short)tempw);
                                if ((tempws>>15) && ((tempws>>15)!=-1)) flags|=(C_FLAG|V_FLAG);
                                else                                    flags&=~(C_FLAG|V_FLAG);
//                                printf("%i ",tempws);
                                AX=tempws&0xFFFF;
                                tempws=(unsigned short)(tempws>>16);
                                DX=tempws&0xFFFF;
//                                printf("%04X %04X\n",AX,DX);
//                                dumpregs();
//                                exit(-1);
                                if (AX|DX) flags&=~Z_FLAG;
                                else       flags|=Z_FLAG;
                                if (!AT) cycles-=128;
                                else     cycles-=21;
                                break;
                                case 0x30: /*DIV AX,w*/
                                templ=(DX<<16)|AX;
//                                printf("DIV %08X/%04X\n",templ,tempw);
                                if (tempw)
                                {
                                        tempw2=templ%tempw;
                                        DX=tempw2;
                                        templ/=tempw;
                                        AX=templ&0xFFFF;
                                }
                                else
                                {
                                        printf("DIVw BY 0 %04X:%04X\n",cs>>4,pc);
//                                        dumpregs();
//                                        exit(-1);
                                        if (msw&1) pmodeint(0,1);
                                        else
                                        {
//                                        printf("%04X:%04X\n",cs>>4,pc);
                                                if (AT) writememw(ss,(SP-2)&0xFFFF,flags&~0xF000);
                                                else    writememw(ss,(SP-2)&0xFFFF,flags|0xF000);
                                                writememw(ss,(SP-4)&0xFFFF,CS);
                                                writememw(ss,(SP-6)&0xFFFF,pc);
                                                SP-=6;
                                                flags&=~I_FLAG;
                                                pc=readmemw(0,0);
                                                loadcs(readmemw(0,2));
                                        }
//                                                cs=loadcs(CS);
//                                                cs=CS<<4;
//                                        printf("Div by zero %04X:%04X %02X %02X 1\n",cs>>4,pc,0xf7,0x30);
                                }
                                if (!AT) cycles-=144;
                                else     cycles-=22;
                                break;
                                case 0x38: /*IDIV AX,w*/
                                tempws=(int)((DX<<16)|AX);
//                                printf("IDIV %i %i ",tempws,tempw);
                                if (tempw)
                                {
                                        tempw2=tempws%(int)((signed short)tempw);
//                                        printf("%04X ",tempw2);
                                                DX=tempw2;
                                                tempws/=(int)((signed short)tempw);
                                                AX=tempws&0xFFFF;
                                }
                                else
                                {
                                        printf("IDIVw BY 0 %04X:%04X\n",cs>>4,pc);
                                        if (msw&1) pmodeint(0,1);
                                        else
                                        {
//                                        printf("%04X:%04X\n",cs>>4,pc);
                                                if (AT) writememw(ss,(SP-2)&0xFFFF,flags&~0xF000);
                                                else    writememw(ss,(SP-2)&0xFFFF,flags|0xF000);
                                                writememw(ss,(SP-4)&0xFFFF,CS);
                                                writememw(ss,(SP-6)&0xFFFF,pc);
                                                SP-=6;
                                                flags&=~I_FLAG;
                                                pc=readmemw(0,0);
                                                loadcs(readmemw(0,2));
                                        }
//                                                cs=loadcs(CS);
//                                                cs=CS<<4;
//                                        printf("Div by zero %04X:%04X %02X %02X 1\n",cs>>4,pc,0xf7,0x38);
                                }
                                if (!AT) cycles-=165;
                                else     cycles-=25;
                                break;

                                default:
                                printf("Bad F7 opcode %02X\n",rmdat&0x38);
//                                dumpregs();
//                                exit(-1);
                        }
                        break;

                        case 0xF8: /*CLC*/
                        flags&=~C_FLAG;
                        cycles-=2;
                        break;
                        case 0xF9: /*STC*/
//                        printf("STC %04X\n",pc);
                        flags|=C_FLAG;
                        cycles-=2;
                        break;
                        case 0xFA: /*CLI*/
                        flags&=~I_FLAG;
//                        printf("CLI at %04X:%04X\n",cs>>4,pc);
                        cycles-=3;
                        break;
                        case 0xFB: /*STI*/
                        flags|=I_FLAG;
//                        printf("STI at %04X:%04X\n",cs>>4,pc);
                        cycles-=2;
                        break;
                        case 0xFC: /*CLD*/
                        flags&=~D_FLAG;
                        cycles-=2;
                        break;
                        case 0xFD: /*STD*/
                        flags|=D_FLAG;
                        cycles-=2;
                        break;

                        case 0xFE: /*INC/DEC b*/
                        fetchea();
                        temp=geteab();
                        flags&=~V_FLAG;
                        if (rmdat&0x38)
                        {
                                setsub8nc(temp,1);
                                temp2=temp-1;
                                if ((temp&0x80) && !(temp2&0x80)) flags|=V_FLAG;
                        }
                        else
                        {
                                setadd8nc(temp,1);
                                temp2=temp+1;
                                if ((temp2&0x80) && !(temp&0x80)) flags|=V_FLAG;
                        }
//                        setznp8(temp2);
                        seteab(temp2);
                        if (!AT) cycles-=((mod==3)?3:23);
                        else     cycles-=((mod==3)?2:7);
                        break;

                        case 0xFF:
                        fetchea();
                        switch (rmdat&0x38)
                        {
                                case 0x00: /*INC w*/
                                tempw=geteaw();
                                setadd16nc(tempw,1);
//                                setznp16(tempw+1);
                                seteaw(tempw+1);
                                if (!AT) cycles-=((mod==3)?3:23);
                                else     cycles-=((mod==3)?2:7);
                                break;
                                case 0x08: /*DEC w*/
                                tempw=geteaw();
//                                setsub16(tempw,1);
                                setsub16nc(tempw,1);
//                                setznp16(tempw-1);
                                seteaw(tempw-1);
//                                if (output) printf("DEC - %04X\n",tempw);
                                if (!AT) cycles-=((mod==3)?3:23);
                                else     cycles-=((mod==3)?2:7);
                                break;
                                case 0x10: /*CALL*/
                                tempw=geteaw();
                                if (ssegs) ss=oldss;
                                writememw(ss,(SP-2)&0xFFFF,pc);
                                SP-=2;
                                pc=tempw;
                                if (!AT) cycles-=((mod==3)?20:29);
                                else     cycles-=((mod==3)?7:11);
                                break;
                                case 0x18: /*CALL far*/
                                tempw=readmemw(easeg,eaaddr);
                                tempw2=readmemw(easeg,(eaaddr+2)&0xFFFF); //geteaw2();
//                                printf("Call FAR %04X:%04X %04X:%04X\n",CS,pc,tempw2,tempw);
                                tempw3=CS;
                                tempw4=pc;
                                if (ssegs) ss=oldss;
                                pc=tempw;
                                if (msw&1) loadcscall(tempw2);
                                else       loadcs(tempw2);
                                if (notpresent) break;
                                writememw(ss,(SP-2)&0xFFFF,tempw3);
                                writememw(ss,((SP-4)&0xFFFF),tempw4);
                                SP-=4;
                                if (!AT) cycles-=53;
                                else     cycles-=16;
                                break;
                                case 0x20: /*JMP*/
                                pc=geteaw();
                                if (!AT) cycles-=((mod==3)?11:18);
                                else     cycles-=((mod==3)?7:11);
                                break;
                                case 0x28: /*JMP far*/
                                pc=readmemw(easeg,eaaddr); //geteaw();
                                loadcs(readmemw(easeg,(eaaddr+2)&0xFFFF)); //geteaw2();
//                                cs=loadcs(CS);
//                                cs=CS<<4;
                                if (!AT) cycles-=24;
                                else     cycles-=15;
                                break;
                                case 0x30: /*PUSH w*/
                                tempw=geteaw();
//                                if (output) printf("PUSH %04X %i %02X %04X %04X %02X %02X\n",tempw,rm,rmdat,easeg,eaaddr,ram[0x22340+0x5638],ram[0x22340+0x5639]);
                                if (ssegs) ss=oldss;
                                writememw(ss,((SP-2)&0xFFFF),tempw);
                                SP-=2;
                                if (!AT) cycles-=((mod==3)?15:24);
                                else     cycles-=((mod==3)?3:5);
                                break;

                                default:
                                printf("Bad FF opcode %02X\n",rmdat&0x38);
//                                dumpregs();
//                                exit(-1);
                        }
                        break;

                        default:
                        if (!AT)
                        {
                                pc++;
                                cycles-=8;
                        }
                        else
                        {
                                printf("Bad opcode %02X at %04X:%04X from %04X:%04X %08X\n",opcode,cs>>4,pc,old8>>16,old8&0xFFFF,old82);
                                dumpregs();
                                exit(-1);
                        }
                        break;

                        pc--;
                        cycles-=8;
                        break;
                        printf("Bad opcode %02X at %04X:%04X from %04X:%04X %08X\n",opcode,cs>>4,pc,old8>>16,old8&0xFFFF,old82);
                        dumpregs();
                        exit(-1);
                }
                pc&=0xFFFF;
                
/*                if (CS<0xC000)
                {
                        printf("Low CS!\n");
                        dumpregs();
                        exit(-1);
                }*/
                
/*                if (CS==0x4CA9 && pc==0x000006BC) output=1;
                if (CS==0x4CA9 && pc==0x0000071C) output=1;

                if (CS==0x4CA9 && pc==0x0000075E) output=0;*/
//                if (pc==0x7C00 && !cs) output=1;

//                if (pc==0x1616 && CS==0x10C1) output=1;
//                if (pc==0x1643 && CS==0x10C1) output=0;

                if (((cs+pc)&0xF0000)==0xD0000)
                {
                        printf("Out of here!\n");
                        dumpregs();
                        exit(-1);
                }
                if (ssegs)
                {
                        ds=oldds;
                        ss=oldss;
                        ssegs=0;
                }
                if (notpresent)
                {
                        CS=oldcs;
                        pc=oldpc;
                        _cs.access=oldcpl<<5;
                        notpresent=0;
                        x86np();
                }
                cycdiff-=cycles;
                if (keyboardtimer)
                {
                        keyboardtimer-=cycdiff;
                        if (keyboardtimer<1)
                        {
                                keyboardtimer=0;
                                keyboardtimeout();
                        }
                }

                if (!pit.delay[0]) pit.c[0]-=cycdiff;
                if (!pit.delay[1])         pit.c[1]-=(cycdiff<<1);
                if (!pit.delay[2])         pit.c[2]-=cycdiff;

                if ((pit.c[0]<1)||(pit.c[1]<1)||(pit.c[2]<1)) pollpit();

                if (romset==ROM_IBMPC)
                {
                        if ((cs+pc)==0xFE4A7) /*You didn't seriously think I was going to emulate the cassette, did you?*/
                        {
                                CX=1;
                                BX=0x500;
                        }
                }
                spktime-=cycdiff;
                if (spktime<=0.0)
                {
                        spktime+=SPKCONST;
                        pollspk();
                        pollgussamp();
                        getsbsamp();
                        getdacsamp();
                }
                soundtime-=cycdiff;
                if (soundtime<=0.0)
                {
                        soundtime+=SOUNDCONST;
                        pollsound60hz();
                }
                gustime-=cycdiff;
                while (gustime<=0.0)
                {
                        gustime+=GUSCONST;
//                        printf("1Poll GUS %f %f\n",gustime,GUSCONST);
                        pollgus();
//                        printf("2Poll GUS\n");
                }
                vidtime-=cycdiff;
                if (vidtime<=0.0)
                {
                        pollvideo();
//                        polltandy();
//                        pollmda();
//                        pollcga();
                }
                if (disctime)
                {
                        disctime-=(cycdiff/2);
                        if (disctime<=0)
                        {
                                disctime=0;
                                polldisc();
                        }
                }
                if (mousedelay)
                {
                        mousedelay--;
                        if (!mousedelay)
                           mousecallback();
                }
                if (sbenable)
                {
                        sbcount-=cycdiff;
                        if (sbcount<0)
                        {
                                sbcount+=sblatch;
                                pollsb();
                        }
                }

                if ((flags&I_FLAG) && (pic.pend&~pic.mask) && !ssegs && !noint)
                {
                        temp=picinterrupt();
                        if (temp!=0xFF)
                        {
                                if (inhlt) pc++;
//                                intcount++;
                                if (msw&1)
                                {
                                        pmodeint(temp,0);
                                }
                                else
                                {
                                        if (AT) writememw(ss,(SP-2)&0xFFFF,flags&~0xF000);
                                        else    writememw(ss,(SP-2)&0xFFFF,flags|0xF000);
                                        writememw(ss,(SP-4)&0xFFFF,CS);
                                        writememw(ss,(SP-6)&0xFFFF,pc);
                                        SP-=6;
                                        addr=temp<<2;
                                        flags&=~I_FLAG;
                                        pc=readmemw(0,addr);
                                        loadcs(readmemw(0,addr+2));
                                }
                                inint=1;
                        }
                }

/*                if (pc==0xCC32 && es>0x180000)
                {
                        pc=0xCBEB;
//                        output=1;
//                        timetolive=500000;
                }*/

                if (noint) noint=0;
                ins++;
                if (timetolive)
                {
                        timetolive--;
                        if (!timetolive) exit(-1); //output=0;
                }
                if (keybsenddelay)
                {
                        keybsenddelay-=10;
                        if (keybsenddelay<1)
                        {
                                keybsenddelay=0;
                                keybsendcallback();
                        }
                }
        }
}
//#endif
