#include "ibm.h"

typedef struct
{
        unsigned char linestat,thr,mctrl,rcr,iir,ier,lcr;
        unsigned char dlab1,dlab2;
} SERIAL;

SERIAL serial,serial2;

unsigned char mousedat[5];
int mousepos=-1;

void resetserial()
{
        serial.iir=serial.ier=serial.lcr=0;
        serial2.iir=serial2.ier=serial2.lcr=0;
        mousedelay=0;
}

void sendserial(unsigned char dat)
{
        serial.rcr=dat;
        serial.linestat|=1;
        picint(0x10);
        serial.iir=4;
}

void writeserial(unsigned short addr, unsigned char val)
{
//        printf("Write serial %03X %02X %04X:%04X\n",addr,val,cs>>4,pc);
        switch (addr&7)
        {
                case 0:
                if (serial.lcr&0x80 && !AMSTRADIO)
                {
                        serial.dlab1=val;
                        return;
                }
                serial.thr=val;
                serial.linestat|=0x20;
                if (serial.mctrl&0x10)
                {
                        serial.rcr=val;
                        serial.linestat|=1;
                }
                break;
                case 1:
                if (serial.lcr&0x80 && !AMSTRADIO)
                {
                        serial.dlab2=val;
                        return;
                }
                serial.ier=val;
                break;
                case 3: serial.lcr=val; break;
                case 4:
                if ((val&2) && !(serial.mctrl&2))
                {
//                        printf("RCR raised! sending M\n");
                        mousepos=-1;
                        mousedelay=1000;
                }
                serial.mctrl=val;
                break;
        }
}

void mousecallback()
{
        mousepos=-1;
        sendserial('M');
//        printf("Mouse callback\n");
}

unsigned char readserial(unsigned short addr)
{
        unsigned char temp;
//        printf("Read serial %03X %04X:%04X\n",addr,cs>>4,pc);
        switch (addr&7)
        {
                case 0:
                if (serial.lcr&0x80 && !AMSTRADIO) return serial.dlab1;
//                picintc(0x10);
                serial.iir=1;
                serial.linestat&=~1;
                temp=serial.rcr;
                if (mousepos==0)
                {
//                        printf("Sending serial 1\n");
                        sendserial(mousedat[1]);
                        mousepos=1;
                }
                else if (mousepos==1)
                {
//                        printf("Sending serial 2\n");
                        sendserial(mousedat[2]);
                        mousepos=-1;
                }
/*                else if (mousepos==2)
                {
                        sendserial(mousedat[3]);
                        mousepos=3;
                }
                else if (mousepos==3)
                {
                        sendserial(mousedat[4]);
                        mousepos=-1;
                }*/
                break;
                case 1:
                if (serial.lcr&0x80 && !AMSTRADIO) return serial.dlab2;
                temp=0;
                break;
                case 2: temp=serial.iir; break;
                case 3: temp=serial.lcr; break;
                case 4: temp=serial.mctrl; break;
                case 5: temp=serial.linestat; break;
                default: temp=0;
        }
//        printf("%02X\n",temp);
        return temp;
}

void writeserial2(unsigned short addr, unsigned char val)
{
//        printf("Write serial2 %03X %02X %04X:%04X\n",addr,val,cs>>4,pc);
        switch (addr&7)
        {
                case 0:
                if (serial2.lcr&0x80 && !AMSTRADIO)
                {
                        serial2.dlab1=val;
                        return;
                }
                serial2.thr=val;
                serial2.linestat|=0x20;
                if (serial2.mctrl&0x10)
                {
                        serial2.rcr=val;
                        serial2.linestat|=1;
                }
                break;
                case 1:
                if (serial2.lcr&0x80 && !AMSTRADIO)
                {
                        serial2.dlab2=val;
                        return;
                }
                serial2.ier=val;
                break;
                case 3: serial2.lcr=val; break;
                case 4:
                serial2.mctrl=val;
                break;
        }
}

unsigned char readserial2(unsigned short addr)
{
        unsigned char temp;
//        printf("Read serial2 %03X %04X:%04X\n",addr,cs>>4,pc);
        switch (addr&7)
        {
                case 0:
                if (serial2.lcr&0x80 && !AMSTRADIO) return serial2.dlab1;
                serial2.iir=1;
                serial2.linestat&=~1;
                temp=serial2.rcr;
                break;
                case 1:
                if (serial2.lcr&0x80 && !AMSTRADIO) return serial2.dlab2;
                temp=0;
                break;
                case 2: temp=serial2.iir; break;
                case 3: temp=serial2.lcr; break;
                case 4: temp=serial2.mctrl; break;
                case 5: temp=serial2.linestat; break;
                default: temp=0;
        }
//        printf("%02X\n",temp);
        return temp;
}

int oldb=0;
void reportmouse(int x, int y, int b)
{
//        printf("reportmouse - %02X %i %i %i %i\n",serial.ier,x,y,b,oldb);
        if (!(serial.ier&1)) return;
        if (!x && !y && b==oldb) return;
        return;
//        printf("Reportmouse! %02X %i\n",serial.mctrl,mousepos);
//        y=-y;
        oldb=b;
        if (x>127) x=127;
        if (y>127) y=127;
        if (x<-128) x=-128;
        if (y<-128) y=-128;
        /*Use Mouse Systems format*/
//        mousedat[0]=0x80;
//        if (b&1) mousedat[0]|=4;
//        if (b&2) mousedat[0]|=1;
//        mousedat[1]=x&255;
//        mousedat[2]=y&255;
//        mousedat[3]=mousedat[4]=0;

        /*Use Microsoft format*/
        mousedat[0]=0x40;
        mousedat[0]|=(((y>>6)&3)<<2);
        mousedat[0]|=((x>>6)&3);
        if (b&1) mousedat[0]|=0x20;
        if (b&2) mousedat[0]|=0x10;
        mousedat[1]=x&0x3F;
        mousedat[2]=y&0x3F;
        
//        printf("Sending mouse data - %02X %02X %02X %02X %02X\n",mousedat[0],mousedat[1],mousedat[2],mousedat[3],mousedat[4]);
        if (!(serial.mctrl&0x10) && mousepos==-1)
        {
//                printf("Sending serial!\n");
                sendserial(mousedat[0]);
                mousepos=0;
        }
//        else
//           printf("Failed to send!\n");
}

