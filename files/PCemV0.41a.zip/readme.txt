PCem v0.41a

Changes since v0.41:

- Fixed disc corruption bug
- Placeholder CGA Composite emulation


PCem emulates the following machines:

IBM 5150 PC (1981) 
The original PC. This shipped in 1981 with a 4.77mhz 8088, 64k of RAM, and a cassette port.
Disc drives quickly became standard, along with more memory.

ROM files needed:

pc102782.bin
basicc11.f6
basicc11.f8
basicc11.fa
basicc11.fc


IBM 5160 XT (1983)
From a hardware perspective, this is a minor tweak of the original PC. It originally shipped
with 128k of RAM and a 10mb hard disc, both of which could be easily fitted to the 1981 machine.
However, this was targetted as businesses and was more successful than the original.

ROM files needed:

xt050986.0
xt050986.1


IBM AT (1984)
This was the 'next generation' PC, fully 16-bit with an 80286. The original model came with a 6mhz
286, which ran three times as fast as the XT. This model also introduced EGA.

ROM files needed:

at111585.0
at111585.1


Tandy 1000 (1985)
This is a clone of the unsuccessful IBM PCjr, which added better graphics and sound to the XT,
but removed much expandability plus some other hardware (such as the DMA controller). The Tandy
puts back the DMA controller and ISA slots, making it a much more useful machine. Many games
from the late 80s support the Tandy.

ROM files needed:

tandy1t1.020


Amstrad PC1512 (1986)
This was Amstrad's first entry into the PC clone market (after the CPC and PCW machines), and
was the first cheap PC available in the UK, selling for only �500. It was a 'turbo' clone, 
having an 8mhz 8086, as opposed to an 8088, and had 512k RAM as standard. It also had a 
perculiar modification to its onboard CGA controller - the 640x200 mode had 16 colours instead
of the usual 2. This was put to good use by GEM, which shipped with the machine.

Amstrad's CGA implementation has a few oddities, these are emulated as best as possible. This
mainly affects games defining unusual video modes, though 160x100x16 still works (as on the real
machine).

ROM files needed:

40043.v1
40044.v2


Amstrad PC1640 (1987)
Amstrad's followup to the PC1512, the PC1640 had 640k of RAM and onboard EGA, but was otherwise
mostly the same.

ROM files needed:

40043.v3
40044.v3
40100


Sinclair PC200/Amstrad PC20 (1988)
This was Amstrad's entry to the 16-bit home computer market, intended to compete with the Atari
ST and Commodore Amiga. It's similar to the PC1512, but is based on Amstrad's portable PPC512
system. With stock CGA and PC speaker, it couldn't compare with the ST or Amiga.

ROM files needed:

pc20v2.0
pc20v2.1


Schneider Euro PC (1988)
A German XT clone. An 'all-in-one' system like the Sinclair PC200. I don't know much about this
machine to be honest!

ROM files needed:

50145
50146


(c)Anonymous Generic Turbo XT BIOS (1988?)
This is a BIOS whose source code was made available on Usenet in 1988. It appears to be an 
anonymous BIOS from an XT clone board. It was then heavily modified to fix bugs. The history of
this BIOS (and the source code) is at http://dizzie.narod.ru/bios.txt

ROM files needed:

pcxt.rom


AMI 286 clone (1990)
This is a generic 286 clone with an AMI BIOS.

ROM files needed:

amic206.bin


AMI 386 clone (1994)
This is a generic 386 clone with an AMI BIOS. The BIOS came from my 386DX/40, the motherboard is
dated June 1994.

ROM files needed:

ami495.bin


AMI 486 clone (1993)
This is a generic 486SX clone with an AMI BIOS. The BIOS came from my 486SX/25, bought in December
1993.

ROM files needed:

ami1429.bin



PCem emulates the following graphics adapters :

MDA - The original PC adapter. This displays 80x25 text in monochrome.

Hercules - A clone of MDA, with the addition of a high-resolution 720x348 graphics mode.

CGA - The most common of the original adapters, supporting 40x25 and 80x25 text, and 
    320x200 in 4 colours, 640x200 in 2 colours, and a composite mode giving 160x200 in 16 colours.

PC1512 - This is a CGA clone with a new mode - 640x200 in 16 colours. To my knowledge, the
    new mode is only used by GEM.

Tandy - This adds all sorts of new modes to CGA - 160x200x16, 320x200x16, 640x200x4.

PC1640 - This is a mostly standard EGA controller, albeit with the ability to fully emulate CGA.

Trident 8900D SVGA - A low cost SVGA board circa 1992/1993. Not the greatest board in it's day, but
    it has a reasonable VESA driver and (buggy) 15/16/24-bit colour modes.

Tseng ET4000AX SVGA - A somewhat better SVGA board than the Trident, here you get better compatibility
    and speed (on the real card, not the emulator) in exchange for being limited to 8-bit colour.

There's also a 'slow video card' option, this reduces video speeds for PC1512,VGA and SVGA to 
somewhat nearer to ISA throughput speed (around 2-4mb/sec).



Pcem emulates the following sound devices :

PC speaker - The standard beeper on all PCs. Supports samples/RealSound.

Tandy PSG - The Texas Instruments chip in the PCjr and Tandy 1000. Supports 3 voices plus
    noise. I reused the emulator in B-em for this (slightly modified).

Gameblaster - The Creative Labs Gameblaster/Creative Music System, Creative's first sound card
    introduced in 1987. Has two Philips SAA1099, giving 12 voices of square waves plus 4 noise
    voices. In stereo!

Adlib - The one the Sound Blaster ripped off. Has a Yamaha YM3812, giving 9 voices of 2 op FM,
    or 6 voices plus a rubbish drum section. PCem uses Ken Silverman's emulator for this.

Sound Blaster - Several Sound Blasters are emulated :
    SB v1.0 - The original. Limited to 22khz, and no auto-init DMA (can cause crackles sometimes).
    SB v2.0 - Upped to 41khz and has auto-init DMA.
    SB Pro v1.0 - Stereo, with twin OPL2 chips.
    All three are set to Address 220, IRQ 7 and DMA 1. The relevant SET line for autoexec.bat is
	SET BLASTER = A220 I7 D1 Tx    - where Tx is T1 for SB v1.0, T3 for SB v2.0 and T4 for SB Pro.

Gravis Ultrasound - 32 voice sample playback. PCem's emulation of this is a bit preliminary :
    - Only older ULTRASND setup programs work, ie text mode instead of graphics
    - MIDI playback is fairly awful
    - No 16-bit sample support (haven't seen anything use it yet)
    - Some games, eg later versions of Epic Pinball, have no music
    - No stereo
    - Some clicking in sound output
    - Does work well in lots of stuff though, eg Worms, Pinball Fantasies, Zone 66 etc.
    - Settings are hardwired to Address 240, IRQ 5, DMA 3. The relevant SET line for autoexec.bat is
	SET ULTRASND=240,3,3,5,12
      This means unlike on a real board, you don't have to run a init program on bootup for sound to work.


Other stuff emulated :

Serial mouse - A Microsoft compatible serial mouse on COM1. Compatible drivers are all over the 
    place for this.

PC1512 mouse - The PC1512's perculiar quadrature mouse. You need Amstrad's actual driver for this
    one.


Options :

Fast disc access - this will bypass the BIOS and FDC for disc accesses, speeding them up 
    somewhat. Recommended for DOS, but most booter games need this turned off.


Notes :

- The AT and AMI 286 both fail part of their self test. This doesn't really affect anything, 
  just puts an irritating message on the screen.

- The time on the PC1512 clock is wrong. The date is correct, though since the PC1512's bios isn't
  Y2k compliant, it thinks it's 1988.

- The envelope system on the Gameblaster isn't emulated. The noise may not be right either.

- Some of the more unusual VGA features are not emulated. I haven't found anything that uses them yet.

- There's an extension BIOS ROM included to make the older PCs boot off hard disc. If it irritates you,
  just rename/delete the file 'romext.bin'.

- The 386/486 emulation has a number of bugs. If you want to run protected mode games, I'd suggest not
  loading EMM386. And quite a few games will make the emulator crash.


Software tested:

Booter games :

Battlezone
Centipede
Commando
Defender
Digger (missing music)
Galaxian
Jumpman (needs fast disc access on)
King's Quest (Tandy)
King's Quest (CGA) (needs fast disc off to start with, then on after title screen)
King's Quest 2 (CGA)
Rollo and the Brush Brothers
Space Strike
Spider Bot
Zaxxon

Boulderdash (hangs)
Cosmic whatever (bombs out or hangs)


DOS stuff :

MS-DOS 3.30
PC-DOS 3.30
PC-DOS 5.02
MS-DOS 6.22
 - Most of the supplied software seems to work, eg Drivespace, Defrag, Scandisk, QBASIC
   etc

DR-DOS 6.0

Minix 2.0.3 (286 version only atm)

Windows 3.0 (CGA, Hercules, EGA, VGA) (real and standard modes only)
Windows 3.1 (VGA, SVGA) (standard mode only)
GEM 2       (CGA, Hercules, PC1512, EGA, VGA)

Word for Windows 2.0 (font menu broken)
Works for Windows 3.0
Breakthru!
Microsoft Arcade

Another World (Tandy)
Arkanoid (CGA, Tandy)
Batman (CGA, Tandy)
Block Out (CGA, Tandy)
Elite
Hoyle (CGA, Tandy)
Jill of the Jungle (CGA,EGA,VGA)
King's Quest 3 (CGA, Composite, Tandy)
King's Quest 4 (Tandy)
Lands of Lore
Lemmings (CGA, Tandy)
Monopoly
Moonbugs
Outrun (CGA, Tandy)
Police Quest (CGA, Composite, Tandy)
Prince of Persia (CGA, Tandy)
Psion Chess (CGA, Hercules)
Road Runner
Secret of Monkey Island (Tandy)
Space Racer
Star Wars
Tetris
The Cycles
Xenon 2 (CGA, Tandy)
Zak McKraken (CGA, Tandy)

Brix (VGA)
Commander Keen (EGA)
Commander Keen 4 (EGA)
Commander Keen 6 (EGA)
Duke Nukem 2 (VGA)
Dune 2 (VGA)
Global Conquest (EGA)
Halloween Harry (VGA)
Heartlight (VGA)
Hexxagon (VGA)
Jetpack (VGA)
Lemmings 2 (VGA)
Llamatron (VGA) - SoundBlaster not detected
Lotus 3 (VGA)
Monkey Island 2 (VGA)
Mystic Towers (VGA)
Pinball Fantasies (VGA)
Race The Nags (EGA)
Revenge of the Mutant Camels (VGA) - SoundBlaster not detected
Scorched Earth (VGA) (tested v1.0 and v1.5)
Super Tetris (VGA)
Tetris Classic (EGA,VGA)
Xargon (VGA)
Wizkid (VGA)
Wolfenstein 3D (VGA)

Cascada - Cronologia (VGA) - first part too fast, 'Time' part doesn't work
Triton - Crystal Dreams (VGA) - doesn't like slower ATs
Ultraforce - Coldcut (EGA) - doesn't work properly on AT, use PC1640 or something
Ultraforce - Vectdemo (VGA)

8088flex - doesn't like EGA much - use CGA (answer Y to 'using real CGA?') or VGA
           (answer N). Runs on EGA, just looks a bit scrambled.
           Also occasional 'run time error' (on AT only I think)

All the stuff that came with the SoundBlaster 2 (except the Windows drivers, which don't quite work
right. Use the Windows 3.1 SB 1.5 drivers instead) (and except SBAITSO2)

386/486 stuff :

Highway Hunter
Cool Spot
Zool 2
Blake Stone
Corridor 7
Epic Pinball
Revenge of the Mutant Camels
Power Drive (EMM386)
Desert Strike (EMM386) - intro only appears sometimes
Jungle Strike (EMM386)
Project-X (EMM386)
Lemmings 3 (EMM386 + SVGA)
Aladdin (EMM386)
Cannon Fodder 2 (EMM386)
Tempest 2000 (EMM386)
Overlord (EMM386) (use ET4000 driver)
Dawn Patrol (EMM386) (use ET4000 driver)

Boppin'
Doom
Doom 2
UFO : Enemy Unknown
Wacky Wheels
X-Com : Terror From The Deep
Psycho Pinball
Mortal Kombat
Mortal Kombat 2
Stargunner
Tube
Syndicate
Zone 66 (doesn't like MS-DOS 6.22, works on DOS 5)
Hexen
Lion King
Micro Machines 2
Duke Nukem 3D
Simcity 2000
Terminal Velocity

EMF - Verses
Renaissance - Amnesia
Witan - Witan House (GUS)

Fasttracker 2

SWOS - crashes at 33mhz, okay at 40?!?!?!?!