extern device_t voodoo_device;
