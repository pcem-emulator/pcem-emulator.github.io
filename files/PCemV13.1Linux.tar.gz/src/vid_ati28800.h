extern device_t ati28800_device;
