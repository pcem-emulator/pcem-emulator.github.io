extern lpt_device_t lpt_dac_device;
extern lpt_device_t lpt_dac_stereo_device;
