extern device_t ps2_nvr_device;
