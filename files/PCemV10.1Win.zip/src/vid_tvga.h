extern device_t tvga8900d_device;
