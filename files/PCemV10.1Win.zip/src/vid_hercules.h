extern device_t hercules_device;
