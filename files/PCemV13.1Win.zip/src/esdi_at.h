extern device_t wd1007vse1_device;
