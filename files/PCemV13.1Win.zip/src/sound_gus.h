extern device_t gus_device;
