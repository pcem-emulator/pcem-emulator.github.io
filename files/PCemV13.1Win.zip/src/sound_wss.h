extern device_t wss_device;
