void wd76c10_init();
