void jim_init();
