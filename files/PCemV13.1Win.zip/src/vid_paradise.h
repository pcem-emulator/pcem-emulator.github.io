extern device_t paradise_pvga1a_pc2086_device;
extern device_t paradise_pvga1a_pc3086_device;
extern device_t paradise_wd90c11_megapc_device;
extern device_t paradise_pvga1a_oli_go481_device;
