void ps2_mca_board_model_50_init();
void ps2_mca_board_model_55sx_init();
void ps2_mca_board_model_80_type2_init();
