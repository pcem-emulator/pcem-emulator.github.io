extern device_t adlib_device;
extern device_t adlib_mca_device;
