extern device_t scsi_lcs6821n_device;
extern device_t scsi_rt1000b_device;
extern device_t scsi_t130b_device;
