extern device_t colorplus_device;
