void i430vx_init();
void i430vx_reset();
