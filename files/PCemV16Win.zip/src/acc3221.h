void acc3221_init();
