void intel_batman_init();
void intel_endeavor_init();
void intel_zappa_init();
