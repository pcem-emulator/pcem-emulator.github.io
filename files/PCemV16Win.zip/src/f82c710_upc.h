#include "device.h"

extern device_t f82c710_upc_device;

