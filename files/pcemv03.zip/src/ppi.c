/*This varies wildly on the XT-compatible models. The 8255/keyboard standard doesn't
  seem to have been very well defined, with contradicting behaviour expected on various
  models. The AT keyboard, by contrast, was very well defined and all AT BIOSes I've
  tried expect the same behaviour*/
  
/*IBM 5150 cassette nonsense
  Calls F979 twice
  Expects CX to be nonzero, BX >$410 and <$540
    CX is loops between bit 4 of $62 changing
    BX is timer difference between calls
  */

#include <allegro.h>
#include "ibm.h"

int casson=0;
void pollkeywaiting();
int keywaiting;
int keyboardtimer=0;
int output;
int keyboardresetcount;

struct
{
        unsigned char stat,dat;
} atkeyb;

unsigned char codeconvert[128]=
{
          0, 30, 48, 46, 32, 18, 33, 34, //0
         35, 23, 36, 37, 38, 50, 49, 24, //8
         25, 16, 19, 31, 20, 22, 47, 17, //16
         45, 21, 44, 11,  2,  3,  4,  5, //24
          6,  7,  8,  9, 10, 82, 79, 80, //32
         81, 75, 76, 77, 71, 72, 73, 59, //40
         60, 61, 62, 63, 64, 65, 66, 67, //48
         68, 87, 88,  1,  0, 12, 13, 14, //56
         15, 26, 27, 28, 39, 40, 43, 86, //64
         51, 52, 53, 57, 82, 83, 71, 79, //72
         73, 81, 75, 77, 72, 80,  0, 55, //80
         74, 78, 83,  0, 84,  0,  0,115, //88
        112,  0,  0,  0,  0,  0,  0, 42, //96
         54, 39,  0, 56,  0, 91, 92, 93, //104
         70, 69, 58, 42, 54, 29, 29, 56, //112
        121,  0,  0,  0,  0,  0,  0,  0, //120
};
/*Just to be difficult, the Tandy keyboard is slightly different*/
unsigned char codeconverttandy[128]=
{
          0, 30, 48, 46, 32, 18, 33, 34, //0
         35, 23, 36, 37, 38, 50, 49, 24, //8
         25, 16, 19, 31, 20, 22, 47, 17, //16
         45, 21, 44, 11,  2,  3,  4,  5, //24
          6,  7,  8,  9, 10, 82, 79, 80, //32
         81, 75, 76, 77, 71, 72, 73, 59, //40
         60, 61, 62, 63, 64, 65, 66, 67, //48
         68, 87, 88,  1,  0, 12, 13, 14, //56
         15, 26, 27, 28, 39, 40, 71, 71, //64
         51, 52, 53, 57,  0,  0,  0,  0, //72
          0,  0, 43, 78, 41, 74,  0, 55, //80
         74, 78, 83,  0, 84,  0,  0,115, //88
        112,  0,  0,  0,  0,  0,  0, 42, //96
         54, 39,  0, 56,  0, 91, 92, 93, //104
         70, 69, 58, 42, 54, 29, 29, 56, //112
        121,  0,  0,  0,  0,  0,  0,  0, //120
};
int oldkey[128];
int keydelay[128];
unsigned char oldmb;

int intclear=0;
unsigned char realkeycode;
void checkkeys()
{
        int c;
        unsigned char d;
        if (pic.pend&pic.ins&2)
        {
//                printf("Interrupt 2 pending!\n");
                return;
        }
        if (keyboardtimer)
        {
//                printf("Keyboardtimer pending!\n");
                return;
        }
        if (keywaiting)
        {
//                printf("Keywaiting pending! %i\n",keywaiting);
                intclear=0;
                pollkeywaiting();
                return;
        }
        for (c=0;c<128;c++)
        {
                if (!key[c]) keydelay[c]=0;
                if (key[c]) keydelay[c]++;
        }
        intclear=0;
        for (c=0;c<128;c++)
        {
//                if (output && c==KEY_LCONTROL) key[c]=1;
                if (key[c]!=oldkey[c] && c!=KEY_PAUSE)
                {
                        oldkey[c]=key[c];
                        if (TANDY) ppi.pa=codeconverttandy[c];
                        else       ppi.pa=atkeyb.dat=codeconvert[c];
                        if (!oldkey[c]) ppi.pa|=0x80;
                        if (!oldkey[c]) atkeyb.dat|=0x80;
//                        printf("Receive keycode %02X\n",ppi.pa);
                        picint(2);
                        if (AT && (c==KEY_UP || c==KEY_DOWN || c==KEY_LEFT || c==KEY_RIGHT))
                        {
//                                printf("It's a special key!\n");
                                realkeycode=ppi.pa;
                                ppi.pa=atkeyb.dat=0xE0;
                                keywaiting=-1;
                                intclear=3;
                        }
                        atkeyb.stat|=1;
//                        printf("Sending key %02X\n",ppi.pa);
                        return;
                }
        }
        d=mouse_b;
        if (d!=oldmb)
        {
                if ((d^oldmb)&1)
                {
                        ppi.pa=0x7E;
                        if (!(d&1)) ppi.pa|=0x80;
//                        printf("Mouse!\n");
                        picint(2);
                        oldmb=(oldmb&~1)|(d&1);
                        return;
                }
                if ((d^oldmb)&2)
                {
                        ppi.pa=0x7D;
                        if (!(d&1)) ppi.pa|=0x80;
//                        printf("Mouse!\n");
                        picint(2);
                        oldmb=(oldmb&~2)|(d&2);
                        return;
                }
        }
        if (key[KEY_PAUSE]!=oldkey[KEY_PAUSE])
        {
                oldkey[KEY_PAUSE]=key[KEY_PAUSE];
                if (key[KEY_PAUSE])
                {
                        ppi.pa=0xE1;
                        picint(2);
                        keywaiting=1;
//                        printf("Oh no KEY_PAUSE!\n");
                }
        }
        for (c=0;c<128;c++)
        {
                if (keydelay[c]) keydelay[c]++;
                if (keydelay[c]>=30)
                {
                        keydelay[c]-=10;
                        if (TANDY) ppi.pa=codeconverttandy[c];
                        else       ppi.pa=atkeyb.dat=codeconvert[c];
                        if (AT && (c==KEY_UP || c==KEY_DOWN || c==KEY_LEFT || c==KEY_RIGHT))
                        {
                                realkeycode=ppi.pa;
                                ppi.pa=atkeyb.dat=0xE0;
                                keywaiting=-1;
                                intclear=3;
                        }
                        atkeyb.stat|=1;
                        picint(2);
                        return;
                }
        }
}

/*This is mainly for Pause/Break, which has a stupidly long scancode (6 bytes!)
  Also for AT extended keycodes, which Pinball Fantasies requires*/
void pollkeywaiting()
{
        if (intclear) return;
//        printf("Keywaiting %i\n",keywaiting);
        switch (keywaiting)
        {
                case 1: ppi.pa=atkeyb.dat=0x1D; break;
                case 2: ppi.pa=atkeyb.dat=0x45; break;
                case 3: ppi.pa=atkeyb.dat=0xE1; break;
                case 4: ppi.pa=atkeyb.dat=0x9D; break;
                case 5: ppi.pa=atkeyb.dat=0xC5; break;
                case -1: ppi.pa=atkeyb.dat=realkeycode; break;
                default:
                keywaiting=0; return;
        }
        atkeyb.stat|=1;
//        printf("pollkeywaiting\n");
        picint(2);
        keywaiting++;
}

void pressa()
{
        ppi.pa=codeconvert[KEY_A];
//        printf("press A\n");
        picint(2);
}

void releasea()
{
        ppi.pa=codeconvert[KEY_A]|0x80;
//        printf("release A\n");
        picint(2);
}

void resetppi()
{
        int c;
        ppi.pa=0x0;//0x1D;
        for (c=0;c<128;c++) oldkey[c]=0;
        ppi.pb=0x40;
        if (AT)
        {
                atkeyb.stat=0xA0;
                atkeyb.dat=0x55;
        }
}

void keybsendcallback()
{
        if (keywaiting)
        {
                pollkeywaiting();
        }
        else
        {
                atkeyb.stat|=1;
//        printf("sendcallback\n");
                picint(2);
        }
}

/*This makes the XT BIOS stop complaining of keyboard failure. I can't imagine
  why the keyboard would operate like this though, or what behaviour would make
  the XT BIOS expect this*/
/*It also makes the floppy drive stop working! Therefore disabled by default*/
void keyboardtimeout()
{
//        printf("Keyboard reset! %04X:%04X\n",cs>>4,pc);
/*        if (keyboardresetcount<2) */ppi.pa=0xAA;
//        else                      ppi.pa=0;
        keyboardresetcount++;
        picint(2);
}

int readin=0;
unsigned char systemstat1,systemstat2;
void writeppi(unsigned short addr, unsigned char val)
{
//        printf("PPI write %04X %02X %04X:%04X %02X\n",addr,val,cs>>4,pc,BL);
//        output=1;
        switch (addr&7)
        {
                case 0:
                if (AT)
                {
//                        printf("Write keyboard controller %02X\n",val);
                        if (val==0x30)
                        {
                                atkeyb.dat=0x52;
                                picint(2);
                                atkeyb.stat|=1;
                        }
                        if (val==0xDD)
                        {
//                                printf("A20 disabled\n");
                                rammask=0xEFFFFF;
                                flushmmucache();
                        }
                        if (val==0xDF)
                        {
//                                printf("A20 enabled\n");
                                rammask=0xFFFFFF;
                                flushmmucache();
                        }
                }
//                printf("Write keyboard %02X\n",val);
                break;
                case 1:
/*                if (TANDY)
                {
                        if ((ppi.pb&0x80) && !(val&0x80))
                           keyboardtimer=500;
                }*/
                if (val&0x80) ppi.pa=0;
                if (!(ppi.pb&0x40) && (val&0x40)) /*Reset keyboard*/
                {
                        if (AMSTRADIO || romset==ROM_EUROPC || romset==ROM_IBMPC) keyboardtimer=10000;
                        else           ppi.pa=0;
                }
                if (AMSTRADIO) ppi.s2=val&4;
                else           ppi.s2=val&8;
                ppi.pb=val;
                gated=((val&3)==3);
//                printf("Write PA %02X %i\n",val,gated);
                break;
                case 4:
//                printf("0064 write %02X %i\n",val,AT);
                if (AT)
                {
                        switch (val)
                        {
                                case 0xAA:
                                atkeyb.dat=0x55;
                                keybsenddelay=1000;
                                keywaiting=0;
//                                atkeyb.stat|=1;
//                                picint(2);
                                break;
                                case 0xC0: /*Read input port*/
//                                atkeyb.dat=0xB0;
                                atkeyb.dat=0xF0|readin;
                                readin^=1;
                                keybsenddelay=1000;
                                keywaiting=0;
                                break;
                                case 0xFE: /*Output*/
                                softresetx86(); /*Pulse reset!*/
//                                printf("Keyboard pulse reset!\n");
                                atkeyb.stat|=4;
                                break;
                        }
                }
                systemstat1=val;
                break;
                case 5:
                systemstat2=val;
                break;
        }
}

int ppicount=0;
unsigned char readppi(unsigned short addr)
{
        unsigned char temp;
//        printf("PPI read %04X %04X:%04X\n",addr,cs>>4,pc);
        switch (addr&7)
        {
                case 0:
                if (AT)
                {
//                        printf("Read keyboard %02X %04X:%04X %02X\n",atkeyb.dat,CS,pc,ram[0x9D90+0x3217]);
                        temp=atkeyb.dat;
                        intclear&=~2;
                        atkeyb.stat&=~1;
                        picintc(2);
                        if (keywaiting)
                        {
                                pollkeywaiting();
                                keybsenddelay=5000;
                        }
                        return temp;
                }
                if (ppi.pb&0x80 && AMSTRADIO)
                {
//                        printf("Read PA with PB7 high %02X\n",systemstat1);
                        return (systemstat1|0xD)&0x7F;
                }
                if (ppi.pb&0x80 && (romset==ROM_IBMPC || romset==ROM_IBMXT))
                {
                        if (VGA) return 0x4D;
                        if (MDA) return 0x7D;
                        return 0x6D;
                }
//                printf("Reading PA %02X %04X:%04X\n",ppi.pa,cs>>4,pc);
/*                if (ppi.pa==0xEA)
                {
                        ppi.pa=0x65;
                        return 0xEA;
                }*/
//                output=1;
                return ppi.pa;
                case 1:
                if (!TANDY)
                {
                        ppicount++;
                        if (ppicount==4)
                        {
                                ppicount=0;
                                ppi.pb^=0x10;
                        }
                        if (AT) return ppi.pb&~0xC0;
                }
//                printf("Read PB %02X\n",ppi.pb);
                return ppi.pb;
                case 2:
                if (romset==ROM_IBMPC)
                {
                        if (ppi.pb&4) temp=0x2;
                        else          temp=0x1;
                }
                else if (AMSTRADIO)
                {
                        if (ppi.s2) temp=systemstat2&0xF;
                        else        temp=systemstat2>>4;
                }
                else if (TANDY)
                {
                        if (ppi.s2)
                        {
                                if (MDA) temp=3|4|0x10;
                                else     temp=2|4|0x10;
                        }
                        else
                            temp=0xD|0x10;
                }
                else
                {
                        if (ppi.s2)
                        {
                                if (VGA)     temp=4;
                                else if (MDA) temp=3|4;
                                else          temp=2|4;
                        }
                        else
                            temp=0xD;
//                        temp|=(spkstat)?0x10:0;
                }
                temp|=((ppispeakon)?0x20:0);
//                if (romset==ROM_IBMPC) temp|=((casson)?0x10:0);
//                printf("Read 62 %02X %02X\n",temp,systemstat2);
                return temp;
                case 4:
//                printf("Read 0064 %i %02X\n",keybsenddelay,atkeyb.stat|0x10);
                if (AT) return atkeyb.stat|0x10;
                break;
        }
        return 0xFF;
        printf("Bad PPI read %04X\n",addr);
        dumpregs();
        exit(-1);
}

void pollcassette()
{
        casson^=1;
}
