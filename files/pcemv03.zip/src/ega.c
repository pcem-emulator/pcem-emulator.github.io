/*ET4000 SVGA nonsense -

  Difference between mode 13h and mode 2eh (640x480x256), other than timing :

  Bit 6 of 3C2 set (480 vs 400)
  Bit 1 of CRTC R11h (retrace)
  Bit 6 of 3C0h R10h clear (pixels are _not_ 8 bits wide)

  And that's it!
  Will use R10 to determine mode*/

#include <allegro.h>
#include "ibm.h"

void redotextlookup();
int output;
int svgaon=0;
unsigned long svgarbank,svgawbank;
unsigned char svgaseg;
unsigned char svga3d8;

unsigned char oldvram=0;
int frames;
int incga=1;
int hsync;
unsigned char cgastat;

unsigned char crtc[64];
unsigned char gdcreg[16];
int gdcaddr;
unsigned char attrregs[32];
int attraddr,attrff=0;

unsigned char rotatevga[8][256];
unsigned char writemask,charset;
int writemode,readmode,readplane,chain4;
unsigned char colourcompare,colournocare;
unsigned char la,lb,lc,ld;

unsigned char *vram;

int egares;

unsigned char seqregs[16];
int seqaddr;

/*3C2 controls default mode on EGA. On VGA, it determines monitor type (mono or colour)*/
int egaswitchread,egaswitches=9; /*7=CGA mode (200 lines), 9=EGA mode (350 lines)*/
/*For VGA non-interlace colour, ID bits should be 1 1 0 or 6*/

PALETTE vgapal;
int dacread,dacwrite,dacpos=0;
int palchange=1;

int fullchange;

void outega(unsigned short addr, unsigned char val)
{
//        printf("Write %03X %02X\n",addr,val);
        switch (addr)
        {
                case 0x3C0:
//                printf("Write 3C0 %i %02X %02X %02X  %02X %04X:%04X\n",attrff,val,attraddr,attrregs[0x10],cgastat,cs>>4,pc);
                if (!attrff) attraddr=val;
                else
                {
                        attrregs[attraddr&31]=val;
                        if (attraddr<16) { redotextlookup(); fullchange=1; } //printf("ATTR %02X = %02X\n",attraddr,val);
                }
                attrff^=1;
                break;
                case 0x3C2: egaswitchread=val&0xC; at70hz=((val&0xC0)!=0xC0); break;
                case 0x3C4: seqaddr=val; break;
                case 0x3C5:
                seqregs[seqaddr&0xF]=val;
//                        printf("Sequencer write %02X %02X\n",val,seqaddr);
                switch (seqaddr&0xF)
                {
                        case 1: egares=val&8; break;
                        case 2: writemask=val&0xF; break;
                        case 3: charset=val&0xF; break;
                        case 4: chain4=val&8; break;
                }
                break;
                case 0x3C7: dacread=val; dacpos=0; break;
                case 0x3C8: dacwrite=val; dacpos=0; break;
                case 0x3C9:
                palchange=1;
                switch (dacpos)
                {
                        case 0: vgapal[dacwrite].r=val&63; dacpos++; break;
                        case 1: vgapal[dacwrite].g=val&63; dacpos++; break;
                        case 2: vgapal[dacwrite].b=val&63; dacpos=0; dacwrite=(dacwrite+1)&255; break;
                }
                break;
                case 0x3CD:
//                printf("Write 3CD %02X\n",val);
                svgawbank=(val&0xF)*65536;
                svgarbank=((val>>4)&0xF)*65536;
                svgaseg=val;
                break;
                case 0x3CE: gdcaddr=val; break;
                case 0x3CF:
                gdcreg[gdcaddr&15]=val;
                switch (gdcaddr&15)
                {
                        case 2: colourcompare=val; break;
                        case 4: readplane=val&3; break;
                        case 5: writemode=val&3; readmode=val&8; break;
                        case 7: colournocare=val; break;
                }
                break;
                case 0x3D8:
                if (val==0xA0) svgaon=1;
                if (val==0x29) svgaon=0;
//                printf("3D8 write %02X\n",val);
//                if (cs==0xC0000) output=1;
                svga3d8=val;
                break;
                case 0x3DB: if (EGA) incga=val&0x40; break;
        }
}

unsigned char inega(unsigned short addr)
{
        switch (addr)
        {
                case 0x3C2:
//                printf("Read egaswitch %02X\n",egaswitchread);
                if (VGA) return 0x10;
                switch (egaswitchread)
                {
                        case 0xC: return (egaswitches&1)?0x10:0;
                        case 0x8: return (egaswitches&2)?0x10:0;
                        case 0x4: return (egaswitches&4)?0x10:0;
                        case 0x0: return (egaswitches&8)?0x10:0;
                }
                break;
                case 0x3C5:
                if ((seqaddr&0xF)==7 && SVGA) return seqregs[seqaddr&0xF]|4;
//                        printf("Sequencer read %02X %02X\n",seqaddr,seqregs[seqaddr&0xF]);
                return seqregs[seqaddr&0xF];
                case 0x3C9:
                palchange=1;
                switch (dacpos)
                {
                        case 0: dacpos++; return vgapal[dacread].r;
                        case 1: dacpos++; return vgapal[dacread].g;
                        case 2: dacpos=0; dacread=(dacread+1)&255; return vgapal[(dacread-1)&255].b;
                }
                break;
                case 0x3CD:
//                        printf("Read 3CD at %04X\n",pc);
//                        output=1;
                return svgaseg;
                case 0x3CF:
                return gdcreg[gdcaddr&0xF];
                case 0x3D8: return svga3d8;
                case 0x3DA:
                attrff=0;
                hsync++;
                hsync&=31;
//                cgastat^=1;
//                printf("Read 3DA %02X\n",(cgastat&8)?(cgastat|1):(cgastat|(hsync)>>4));
                if (cgastat&8) return cgastat|1;
                return cgastat|(hsync>>4);
//                return cgastat;
        }
//        printf("Bad EGA read %04X %04X:%04X\n",addr,cs>>4,pc);
        return 0xFF;
}

unsigned char changedvram[(1024*1024)/512];

void writeega(unsigned long addr, unsigned char val)
{
        int x,y;
        char s[2]={0,0};
        unsigned char vala,valb,valc,vald,wm=writemask;
        int bankaddr;
        addr&=0xFFFF;
        if (SVGA/* && svgaon*/) addr|=svgawbank;
        /*if ((gdcreg[0xF]&5)==5) bankaddr=svgawbank2*65536;
        else if (tridentoldmode) bankaddr=((trident.oldctrl2>>1)&3)*128*1024;
        else *///bankaddr=svgawbank*65536;
//        printf("Write VRAM %04X %i %08X %i  ",addr,chain4,svgawbank,svgaon);
//        if (SVGA) addr+=bankaddr;
//        printf("%04X ",addr);
        if (chain4)
        {
                writemask=1<<(addr&3);
                addr=addr>>2;
//                printf("%05X ",addr);
                if (addr&0x30000)
                {
                        addr=((addr<<2)&~0x3FFFF)|(addr&0xFFFF);
                }
//                printf("%05X\n",addr);
        }
        else
        {
//                addr&=~0x30000;
                if (SVGA) addr=(addr&0xFFFF)|(svgawbank<<2);
                else      addr&=~0x30000;
//                printf(" %05X\n",addr);
        }
        changedvram[(addr&~0x30000)>>9]=1;

//        if (!addr && writemask&1)
//           if (addr<4) printf("Write VRAM %04X %02X %04X(%06X):%04X %i\n",addr,val,CS,cs,pc,writemask);
//        if (!addr && writemask&2)
//           printf("Write VRAM %04X %02X %04X(%06X):%04X %i\n",addr,val,CS,cs,pc,writemask);
//        if (addr==1 && writemask&1) printf("Write to 1 %02X %04X(%06X):%04X\n",val,cs,CS,pc);
        switch (writemode)
                {
                        case 1:
                        if (writemask&1) vram[addr]=la;
                        if (writemask&2) vram[addr|0x10000]=lb;
                        if (writemask&4) vram[addr|0x20000]=lc;
                        if (writemask&8) vram[addr|0x30000]=ld;
                        break;
                        case 0:
                        if (gdcreg[3]&7) val=rotatevga[gdcreg[3]&7][val];
                        if (gdcreg[8]==0xFF && !(gdcreg[3]&0x18) && !gdcreg[1])
                        {
                                if (writemask&1) vram[addr]=val;
                                if (writemask&2) vram[addr|0x10000]=val;
                                if (writemask&4) vram[addr|0x20000]=val;
                                if (writemask&8) vram[addr|0x30000]=val;
                        }
                        else
                        {
                                if (gdcreg[1]&1) vala=(gdcreg[0]&1)?0xFF:0;
                                else             vala=val;
                                if (gdcreg[1]&2) valb=(gdcreg[0]&2)?0xFF:0;
                                else             valb=val;
                                if (gdcreg[1]&4) valc=(gdcreg[0]&4)?0xFF:0;
                                else             valc=val;
                                if (gdcreg[1]&8) vald=(gdcreg[0]&8)?0xFF:0;
                                else             vald=val;
                                switch (gdcreg[3]&0x18)
                                {
                                        case 0: /*Set*/
                                        if (writemask&1) vram[addr]=(vala&gdcreg[8])|(la&~gdcreg[8]);
                                        if (writemask&2) vram[addr|0x10000]=(valb&gdcreg[8])|(lb&~gdcreg[8]);
                                        if (writemask&4) vram[addr|0x20000]=(valc&gdcreg[8])|(lc&~gdcreg[8]);
                                        if (writemask&8) vram[addr|0x30000]=(vald&gdcreg[8])|(ld&~gdcreg[8]);
                                        break;
                                        case 8: /*AND*/
                                        if (writemask&1) vram[addr]=(vala|~gdcreg[8])&la;
                                        if (writemask&2) vram[addr|0x10000]=(valb|~gdcreg[8])&lb;
                                        if (writemask&4) vram[addr|0x20000]=(valc|~gdcreg[8])&lc;
                                        if (writemask&8) vram[addr|0x30000]=(vald|~gdcreg[8])&ld;
                                        break;
                                        case 0x10: /*OR*/
                                        if (writemask&1) vram[addr]=(vala&gdcreg[8])|la;
                                        if (writemask&2) vram[addr|0x10000]=(valb&gdcreg[8])|lb;
                                        if (writemask&4) vram[addr|0x20000]=(valc&gdcreg[8])|lc;
                                        if (writemask&8) vram[addr|0x30000]=(vald&gdcreg[8])|ld;
                                        break;
                                        case 0x18: /*XOR*/
                                        if (writemask&1) vram[addr]=(vala&gdcreg[8])^la;
                                        if (writemask&2) vram[addr|0x10000]=(valb&gdcreg[8])^lb;
                                        if (writemask&4) vram[addr|0x20000]=(valc&gdcreg[8])^lc;
                                        if (writemask&8) vram[addr|0x30000]=(vald&gdcreg[8])^ld;
                                        break;
                                }
                        }
                        break;
                        case 2:
                        if (!(gdcreg[3]&0x18) && !gdcreg[1])
                        {
                                if (writemask&1) vram[addr]=(((val&1)?0xFF:0)&gdcreg[8])|(la&~gdcreg[8]);
                                if (writemask&2) vram[addr|0x10000]=(((val&2)?0xFF:0)&gdcreg[8])|(lb&~gdcreg[8]);
                                if (writemask&4) vram[addr|0x20000]=(((val&4)?0xFF:0)&gdcreg[8])|(lc&~gdcreg[8]);
                                if (writemask&8) vram[addr|0x30000]=(((val&8)?0xFF:0)&gdcreg[8])|(ld&~gdcreg[8]);
                        }
                        else
                        {
                                vala=((val&1)?0xFF:0);
                                valb=((val&2)?0xFF:0);
                                valc=((val&4)?0xFF:0);
                                vald=((val&8)?0xFF:0);
                                switch (gdcreg[3]&0x18)
                                {
                                        case 0: /*Set*/
                                        if (writemask&1) vram[addr]=(vala&gdcreg[8])|(la&~gdcreg[8]);
                                        if (writemask&2) vram[addr|0x10000]=(valb&gdcreg[8])|(lb&~gdcreg[8]);
                                        if (writemask&4) vram[addr|0x20000]=(valc&gdcreg[8])|(lc&~gdcreg[8]);
                                        if (writemask&8) vram[addr|0x30000]=(vald&gdcreg[8])|(ld&~gdcreg[8]);
                                        break;
                                        case 8: /*AND*/
                                        if (writemask&1) vram[addr]=(vala|~gdcreg[8])&la;
                                        if (writemask&2) vram[addr|0x10000]=(valb|~gdcreg[8])&lb;
                                        if (writemask&4) vram[addr|0x20000]=(valc|~gdcreg[8])&lc;
                                        if (writemask&8) vram[addr|0x30000]=(vald|~gdcreg[8])&ld;
                                        break;
                                        case 0x10: /*OR*/
                                        if (writemask&1) vram[addr]=(vala&gdcreg[8])|la;
                                        if (writemask&2) vram[addr|0x10000]=(valb&gdcreg[8])|lb;
                                        if (writemask&4) vram[addr|0x20000]=(valc&gdcreg[8])|lc;
                                        if (writemask&8) vram[addr|0x30000]=(vald&gdcreg[8])|ld;
                                        break;
                                        case 0x18: /*XOR*/
                                        if (writemask&1) vram[addr]=(vala&gdcreg[8])^la;
                                        if (writemask&2) vram[addr|0x10000]=(valb&gdcreg[8])^lb;
                                        if (writemask&4) vram[addr|0x20000]=(valc&gdcreg[8])^lc;
                                        if (writemask&8) vram[addr|0x30000]=(vald&gdcreg[8])^ld;
                                        break;
                                }
                        }
                        break;
                        case 3:
//                        printf("Writemode 3! %02X %02X %02X %04X:%04X\n",gdcreg[3]&0x18,val,gdcreg[0],cs>>4,pc);
                        if (gdcreg[3]&7) val=rotatevga[gdcreg[3]&7][val];
                        wm=gdcreg[8];
                        gdcreg[8]&=val;
//                        printf("Write mask %02X %02X %02X\n",gdcreg[8],val,wm);
//                        printf("Latches %02X %02X %02X %02X\n",la,lb,lc,ld);
/*                        if (!(gdcreg[3]&0x18) && !gdcreg[1])
                        {
                                if (writemask&1) vram[addr]=(((val&1)?0xFF:0)&gdcreg[8])|(la&~gdcreg[8]);
                                if (writemask&2) vram[addr|0x10000]=(((val&2)?0xFF:0)&gdcreg[8])|(lb&~gdcreg[8]);
                                if (writemask&4) vram[addr|0x20000]=(((val&4)?0xFF:0)&gdcreg[8])|(lc&~gdcreg[8]);
                                if (writemask&8) vram[addr|0x30000]=(((val&8)?0xFF:0)&gdcreg[8])|(ld&~gdcreg[8]);
                        }
                        else
                        {*/
                                vala=(gdcreg[0]&1)?0xFF:0;
                                valb=(gdcreg[0]&2)?0xFF:0;
                                valc=(gdcreg[0]&4)?0xFF:0;
                                vald=(gdcreg[0]&8)?0xFF:0;
                                switch (gdcreg[3]&0x18)
                                {
                                        case 0: /*Set*/
                                        if (writemask&1) vram[addr]=(vala&gdcreg[8])|(la&~gdcreg[8]);
                                        if (writemask&2) vram[addr|0x10000]=(valb&gdcreg[8])|(lb&~gdcreg[8]);
                                        if (writemask&4) vram[addr|0x20000]=(valc&gdcreg[8])|(lc&~gdcreg[8]);
                                        if (writemask&8) vram[addr|0x30000]=(vald&gdcreg[8])|(ld&~gdcreg[8]);
                                        break;
                                        case 8: /*AND*/
                                        if (writemask&1) vram[addr]=(vala|~gdcreg[8])&la;
                                        if (writemask&2) vram[addr|0x10000]=(valb|~gdcreg[8])&lb;
                                        if (writemask&4) vram[addr|0x20000]=(valc|~gdcreg[8])&lc;
                                        if (writemask&8) vram[addr|0x30000]=(vald|~gdcreg[8])&ld;
                                        break;
                                        case 0x10: /*OR*/
                                        if (writemask&1) vram[addr]=(vala&gdcreg[8])|la;
                                        if (writemask&2) vram[addr|0x10000]=(valb&gdcreg[8])|lb;
                                        if (writemask&4) vram[addr|0x20000]=(valc&gdcreg[8])|lc;
                                        if (writemask&8) vram[addr|0x30000]=(vald&gdcreg[8])|ld;
                                        break;
                                        case 0x18: /*XOR*/
                                        if (writemask&1) vram[addr]=(vala&gdcreg[8])^la;
                                        if (writemask&2) vram[addr|0x10000]=(valb&gdcreg[8])^lb;
                                        if (writemask&4) vram[addr|0x20000]=(valc&gdcreg[8])^lc;
                                        if (writemask&8) vram[addr|0x30000]=(vald&gdcreg[8])^ld;
                                        break;
                                }
//                        }
                        gdcreg[8]=wm;
                        break;
//                        dumpregs();
//                        exit(-1);
                }
/*        if (vram[1]!=oldvram)
        {
                printf("VRAM 1 changed! %02X %02X %04X(%06X):%04X %i\n",vram[1],oldvram,CS,cs,pc,chain4);
                if (vram[1]==0x1E)
                {
                        printf("itititit 1E\n");
                }
                oldvram=vram[1];
        }*/
}

unsigned char readega(unsigned long addr)
{
        unsigned char temp,temp2,temp3,temp4;
        unsigned long addr2;
        addr&=0xFFFF;
        if (SVGA/* && svgaon*/) addr|=svgarbank;
//        printf("Read VRAM %04X %i %08X\n",addr,chain4,svgarbank);
        if (chain4)
        {
                addr2=addr;
//                printf("Read  %04X  %04X %i %i  ",addr,addr2>>2,addr2&3,svgarbank);
                addr2=(addr2>>2);//|((addr2&3)<<16);
//                printf("%05X  %08X %08X %04X %06X %06X\n",addr2,EDI,EAX,vram[addr2],cs,pc);
                if (addr2&0x30000)
                {
                        addr2=((addr2<<2)&~0x3FFFF)|(addr2&0xFFFF);
                }
                return vram[addr2|((addr&3)<<16)];
        }
        else if (SVGA)
                addr=(addr&0xFFFF)|(svgarbank<<2);
//           addr&=~0x30000;
//        printf("Read VRAM no chain4 %04X %i\n",addr,readplane);
                la=vram[addr];
                lb=vram[addr|0x10000];
                lc=vram[addr|0x20000];
                ld=vram[addr|0x30000];
//                printf("Loaded latches from %04X - %02X %02X %02X %02X  %04X:%04X\n",addr,la,lb,lc,ld,cs>>4,pc);
                if (readmode)
                {
                        temp= (colournocare&1) ?0xFF:0;
                        temp&=la;
                        temp^=(colourcompare&1)?0xFF:0;
                        temp2= (colournocare&2) ?0xFF:0;
                        temp2&=lb;
                        temp2^=(colourcompare&2)?0xFF:0;
                        temp3= (colournocare&4) ?0xFF:0;
                        temp3&=lc;
                        temp3^=(colourcompare&4)?0xFF:0;
                        temp4= (colournocare&8) ?0xFF:0;
                        temp4&=ld;
                        temp4^=(colourcompare&8)?0xFF:0;
                        return ~(temp|temp2|temp3|temp4);
                }
                return vram[addr|(readplane<<16)];
}

unsigned char edatlookup[4][4];

unsigned long textlookup[256][2][16][16];

void redotextlookup()
{
        int c,d,e;
        unsigned long temp;
        int coffset=(VGA)?0:64;
        for (c=0;c<256;c++)
        {
                for (d=0;d<16;d++)
                {
//                        printf("ATTR %i=%02X+%02X\n",d,attrregs[d],coffset);
                        for (e=0;e<16;e++)
                        {
                                temp=0;
                                if (c&0x80) temp|=(attrregs[d]+coffset);
                                else        temp|=(attrregs[e]+coffset);
                                if (c&0x40) temp|=(attrregs[d]+coffset)<<8;
                                else        temp|=(attrregs[e]+coffset)<<8;
                                if (c&0x20) temp|=(attrregs[d]+coffset)<<16;
                                else        temp|=(attrregs[e]+coffset)<<16;
                                if (c&0x10) temp|=(attrregs[d]+coffset)<<24;
                                else        temp|=(attrregs[e]+coffset)<<24;
//                                if (c==0x5) printf("%08X %i %i %02X %02X\n",temp,d,e,attrregs[d],attrregs[e]);
                                textlookup[c][0][d][e]=temp;
                                temp=0;
                                if (c&0x08) temp|=(attrregs[d]+coffset);
                                else        temp|=(attrregs[e]+coffset);
                                if (c&0x04) temp|=(attrregs[d]+coffset)<<8;
                                else        temp|=(attrregs[e]+coffset)<<8;
                                if (c&0x02) temp|=(attrregs[d]+coffset)<<16;
                                else        temp|=(attrregs[e]+coffset)<<16;
                                if (c&0x01) temp|=(attrregs[d]+coffset)<<24;
                                else        temp|=(attrregs[e]+coffset)<<24;
                                textlookup[c][1][d][e]=temp;
                        }
                }
        }
}

void initega()
{
        int c,d,e;
        for (c=0;c<256;c++)
        {
                e=c;
                for (d=0;d<8;d++)
                {
                        rotatevga[d][c]=e;
                        e=(e>>1)|((e&1)?0x80:0);
                }
        }
        crtc[0xC]=crtc[0xD]=0;
        if (romset==ROM_PC1640) incga=1;
        else                    incga=0;
        for (c=0;c<4;c++)
        {
                for (d=0;d<4;d++)
                {
                        edatlookup[c][d]=0;
                        if (c&1) edatlookup[c][d]|=1;
                        if (d&1) edatlookup[c][d]|=2;
                        if (c&2) edatlookup[c][d]|=0x10;
                        if (d&2) edatlookup[c][d]|=0x20;
//                        printf("Edat %i,%i now %02X\n",c,d,edatlookup[c][d]);
                }
        }
        redotextlookup();
}
unsigned long egabase,egaoffset;

void cacheega()
{
        egabase=(crtc[0xC]<<8)|crtc[0xD];
        if (SVGA)
           egabase|=((crtc[0x33]&3)<<18);
//        printf("EGABASE %05X\n",egabase);
//        egaoffset=8-((attrregs[0x13])&7);
//        printf("Cache base!\n");
}
void cacheega2()
{
//        egabase=(crtc[0xC]<<8)|crtc[0xD];
        if (gdcreg[5]&0x40) egaoffset=8-(((attrregs[0x13])&7)>>1);
        else                egaoffset=8-((attrregs[0x13])&7);
//        printf("Cache offset!\n");
}

int olddisplines,oldxsize;

int oldreadflash;
int oldegaaddr,oldegasplit;
void drawscreenega(BITMAP *b, BITMAP *vbuf)
{
        int charseta=((charset>>2)*0x4000)+0x20000;
        int charsetb=((charset&3) *0x4000)+0x20000;
        int x,y,xx,yy;
        int addr=0x8000,addrback;
        unsigned char chr,attr;
        int charaddr;
        unsigned char dat;
        int fg,bg;
        int offset;
        int vtotal=crtc[6];
        int coffset;
        int displines=crtc[0x12];
        int xsize=crtc[1]+1;
        int scans=(crtc[9]&31)+1;
        int split=crtc[0x18];
        int cursoraddr=((crtc[15]|(crtc[14]<<8))<<1)&0xFFE;
        int htotal=crtc[1]+1;
        unsigned char edat[4];
        int modulo=crtc[0x13];
        unsigned long templ;

        int yh=-1,yl=-1;

        if (oldreadflash && !readflash) palchange=1;
        
        if (svgaon && (crtc[0x3F]&0x80)) modulo|=0x100;
//        htotal=(htotal<=40)?1:0;
        if (crtc[7]&1)    vtotal|=0x100;
        if (crtc[7]&2)    displines|=0x100;
        if (crtc[7]&0x40) displines|=0x200;
        if (crtc[0x35]&4) displines|=0x400;
        if (crtc[7]&0x10)    split|=0x100;
        if (crtc[9]&0x40)    split|=0x200;
        if (crtc[0x35]&0x10) split|=0x400;
        if (incga)
        {
                drawscreencga(&vram[0x8000]);
                return;
        }
        displines++;
        xsize*=8;
//        printf("Xsize %i %i %i %02X %i\n",xsize,egares,crtc[1],attrregs[0x10],modulo);
        if (egares&8) xsize*=2;

//        printf("Displines %i\n",displines);
        if (displines!=olddisplines || xsize!=oldxsize)
        {
                olddisplines=displines;
                oldxsize=xsize;
                if (displines>240) updatewindowsize(xsize,displines);
                else               updatewindowsize(xsize,displines<<1);
        }
//        printf("Vtotal %i\n",vtotal);
//        printf("SEQ4 %02X\n",seqregs[4]);
        if (VGA && palchange)
        {
                set_palette(vgapal);
        }
        if (gdcreg[6]&1)//attrregs[0x10]&1)
        {
//                if (egares) xsize/=2;
//printf("Xsize %i\n",xsize);
//                svgaon=1;
                output2++;
                offset=egaoffset;
                if (egabase!=oldegaaddr) fullchange=1;
                if (split!=oldegasplit) fullchange=1;
                if (VGA && palchange) fullchange=1;
                oldegaaddr=addr=egabase;
                oldegasplit=split;
//                printf("%i ",displines);
                displines/=scans;
                if (crtc[9]&0x80) displines/=2;
                if (!(crtc[0x17]&1)) displines*=2;
//                printf("EGABASE %04X %04X %02X %02X %i\n",addr,crtc[0x13],crtc[0x14],crtc[0x17],displines);
//                printf("Displines %i %i\n",displines,split);
                split/=scans;
                if (crtc[9]&0x80) split/=2;
//                if (crtc[0x17]&4) displines/=2;
                coffset=(displines>200)?128:64;
                if (VGA) coffset=0;
//                printf("DRAW! htotal %i colmode %02X egares %i %i vtotal %i R17 %02X  %i\n",htotal,gdcreg[5]&0x60,egares,scans,displines,crtc[0x17],modulo);
//                printf("Before : %i %02X %02X\n",xsize,gdcreg[5],attrregs[0x10]);
//                if ((attrregs[0x10]&0x40)) xsize/=2;
                if (((gdcreg[5]&0x40) && (!SVGA || attrregs[0x10]&0x40))) xsize/=2;
//                if (!(gdcreg[5]&0x60) && (egares || ((gdcreg[5]&0x40) && (!SVGA || attrregs[0x10]&0x40)))) xsize/=2;
//                printf("After : %i\n",xsize);
                for (y=0;y<displines;y++)
                {
                        if (y==(split+1) && (crtc[0x17]&1)) /*This triggers on line 128 of every single CGA game I've tried*/
                        {
                                addr=0;
                                if (VGA && attrregs[0x10]&0x20) offset=8; /*This, bizarrely, isn't supported by EGA!*/
                        }
                        addrback=addr;
                        if (!(crtc[0x17]&1) && (y&1)) addr|=0x2000;
//                        if (svgaon) printf("Line %i addr %05X\n",y,addr);
                        if (changedvram[addr>>9] || changedvram[(addr>>9)+1] || fullchange)
                        {
                                if (yl==-1) yl=y-1;
                                if (yl==-1) yl=0;
                                yh=y+1;
                                switch (gdcreg[5]&0x60)
                                {
                                        case 0x00: /*16 colour EGA*/
//                                        printf("Drawing line %i %i%i\n",y,offset,xsize+4);
                                        for (x=0;x</*((egares)?328:648)*/(xsize+8);x+=8)
                                        {
                                                edat[0]=vram[addr];
                                                edat[1]=vram[addr|0x10000];
                                                edat[2]=vram[addr|0x20000];
                                                edat[3]=vram[addr|0x30000];
                                                dat=edatlookup[edat[0]&3][edat[1]&3]|(edatlookup[edat[2]&3][edat[3]&3]<<2);
                                                b->line[y&2047][(x+7+offset)&2047]=attrregs[dat&0xF]+coffset;
                                                b->line[y&2047][(x+6+offset)&2047]=attrregs[dat>>4]+coffset;
                                                dat=edatlookup[(edat[0]>>2)&3][(edat[1]>>2)&3]|(edatlookup[(edat[2]>>2)&3][(edat[3]>>2)&3]<<2);
                                                b->line[y&2047][(x+5+offset)&2047]=attrregs[dat&0xF]+coffset;
                                                b->line[y&2047][(x+4+offset)&2047]=attrregs[dat>>4]+coffset;
                                                dat=edatlookup[(edat[0]>>4)&3][(edat[1]>>4)&3]|(edatlookup[(edat[2]>>4)&3][(edat[3]>>4)&3]<<2);
                                                b->line[y&2047][(x+3+offset)&2047]=attrregs[dat&0xF]+coffset;
                                                b->line[y&2047][(x+2+offset)&2047]=attrregs[dat>>4]+coffset;
                                                dat=edatlookup[edat[0]>>6][edat[1]>>6]|(edatlookup[edat[2]>>6][edat[3]>>6]<<2);
                                                b->line[y&2047][(x+1+offset)&2047]=attrregs[dat&0xF]+coffset;
                                                b->line[y&2047][(x+offset)&2047]=attrregs[dat>>4]+coffset;
                                                addr++;
                                                if (!SVGA) addr&=0xFFFF;
                                                else
                                                {
                                                        if (addr&0x10000)
                                                        {
                                                                addr-=0x10000;
                                                                addr+=0x40000;
                                                        }
                                                }
                                        }
                                        break;
                                        case 0x20: /*4 colour CGA*/
                                        for (x=0;x</*((egares)?324:644)*/(xsize+4);x+=4)
                                        {
                                                dat=vram[addr+0x8000];
                                                b->line[y&2047][(x+8)&2047]=attrregs[dat>>6];
                                                b->line[y&2047][(x+9)&2047]=attrregs[(dat>>4)&3];
                                                b->line[y&2047][(x+10)&2047]=attrregs[(dat>>2)&3];
                                                b->line[y&2047][(x+11)&2047]=attrregs[dat&3];
                                                addr++;
                                                if (!SVGA) addr&=0xFFFF;
                                                else
                                                {
                                                        if (addr&0x10000)
                                                        {
                                                                addr-=0x10000;
                                                                addr+=0x40000;
                                                        }
                                                }
                                        }
                                        break;
                                        case 0x40: case 0x60: /*256 colour VGA*/
//                                        printf("Drawing line %i %i%i\n",y,offset,xsize+4);
//                                        for (x=0;x<((!egares && SVGA && !(attrregs[0x10]&0x40))?644:324);x+=4)
                                        for (x=0;x<(xsize+4)/*((egares || (SVGA && attrregs[0x10]&0x40))?324:644)*/;x+=4)
                                        {
                                                templ=vram[addr]|(vram[addr|0x10000]<<8)|(vram[addr|0x20000]<<16)|(vram[addr|0x30000]<<24);
                                                *((unsigned long *)&b->line[y&2047][(x+offset)&2047])=templ;
                                                addr++;
                                                if (!SVGA) addr&=0xFFFF;
                                                else
                                                {
                                                        if (addr&0x10000)
                                                        {
                                                                addr-=0x10000;
                                                                addr+=0x40000;
                                                        }
                                                }
                                        }
                                        break;
                                }
                        }
                        if (!(crtc[0x17]&1) && !(y&1))
                           addr=addrback;
                        else
                        {
                                if (svgaon)               addr=addrback+(modulo*2);
                                else if (crtc[0x14]&0x40) addr=addrback+(crtc[0x13]<<1);
                                else if (crtc[0x17]&0x40) addr=addrback+(crtc[0x13]<<1);
                                else                      addr=addrback+(crtc[0x13]<<2);
                                if (!SVGA) addr&=0xFFFF;
                                else
                                {
                                        if (addr&0x10000)
                                        {
                                                addr-=0x10000;
                                                addr+=0x40000;
                                        }
                                }
                        }
                }
//                printf("SVGA render %i %i %i %i %i\n",svgaon,crtc[0x13],crtc[0x14]&0x40,crtc[0x17]&0x40,modulo);
//                printf("Render %i %02X %i  %02X %02X  %i  %i %i %i\n",egares,gdcreg[5],svgaon,attrregs[0x16],crtc[0x36],crtc[1],1,2,3);
                if ((egares || ((gdcreg[5]&0x40) && (!SVGA || attrregs[0x10]&0x40))))
                {
                        if (displines>240)
                        {
//                                printf("BLIT double!\n");
                                blit(b,vbuf,8,0,0,0,xsize,displines);
                                stretch_blit(vbuf,screen,0,0,xsize,displines,0,0,xsize<<1,displines);
                        }
                        else
                        {
//                                printf("Blit %i %i %i\n",yl,yh,displines);
                                if (yl!=-1)
                                {
//                                        printf("Blitit %i %i %i %i %i %i\n",xsize<<1,(yh-yl)<<1,vbuf->w,vbuf->h,screen->w,screen->h);
                                        blit(b,vbuf,8,yl,0,yl,xsize,yh-yl/*displines*/);
                                        stretch_blit(vbuf,screen,0,yl,xsize,yh-yl,0,yl<<1,xsize<<1,(yh-yl)<<1);
//                                        blit(vbuf,screen,0,0,0,0,640,400);
                                }
                        }
                }
                else
                {
                        if (displines>240)
                        {
//                                printf("BLIT single! %i %i %i %i %i %i\n",yh,yl,displines,b->h,vbuf->h,xsize);
//                                yh=displines; yl=0;
                                blit(b,vbuf,8,yl,0,yl,xsize,yh-yl);
                                blit(vbuf,screen,0,yl,0,yl,xsize,yh-yl);
                        }
                        else
                        {
//                                printf("BLIT xsingle! %i %i %i %i %i\n",yh,yl,displines,b->h,vbuf->h);
                                blit(b,vbuf,8,0,0,0,xsize,displines);
                                stretch_blit(vbuf,screen,0,0,xsize,displines,0,0,xsize,displines<<1);
                        }
                }
        }
        else
        {
                if (VGA) coffset=0;
                else     coffset=64;
                if (crtc[9]&0x80) displines/=2;
                addr=0x8000+((egabase<<1)&0x7FFF);
//                printf("EGABASE %08X\n",egabase);
//                printf("Displines %i scans %i\n",displines,scans);
//                displines*=scans;
                for (y=0;y<displines;y+=scans)
                {
                        for (x=0;x<htotal*8;x+=8)
                        {
                                chr=vram[addr];
                                attr=vram[addr+1];
                                if (attr&8) charaddr=charsetb+(chr*32);
                                else        charaddr=charseta+(chr*32);

                                        fg=attr&15; bg=attr>>4;

                                        for (yy=0;yy<scans;yy++)
                                        {
                                                dat=vram[charaddr++];
                                                *((unsigned long *)(&b->line[(y+yy)&511][(x)&2047]))=textlookup[dat][0][fg][bg];
                                                *((unsigned long *)(&b->line[(y+yy)&511][(x+4)&2047]))=textlookup[dat][1][fg][bg];
//                                                if (yy==8) printf("%i %i %02X %08X %i %i %02X %05X %05X\n",y+yy,x,dat,textlookup[dat][1][fg][bg],fg,bg,chr,charaddr,addr);
                                        }
/*                                fg=attrregs[attr&15]+coffset;
                                bg=attrregs[attr>>4]+coffset;
                                for (yy=0;yy<scans;yy++)
                                {
                                        dat=vram[charaddr++];
                                        for (xx=0;xx<8;xx++)
                                        {
                                                b->line[(yy+y)&511][(xx+(x<<3))&2047]=(dat&0x80)?fg:bg;
                                                dat<<=1;
                                        }
                                }*/

                                if ((addr&0xFFE)==cursoraddr && frames&8 && !(crtc[0xA]&0x20))
                                {
                                        if (attr&8) charaddr=charsetb+(chr*32);
                                        else        charaddr=charseta+(chr*32);
                                        charaddr+=(crtc[0xA]&31);
//                                        fg=attr>>4; bg=attr&15;

                                        for (yy=(crtc[0xA]&31);yy<(crtc[0xB]&31);yy++)
                                        {
                                                dat=vram[charaddr++];
                                                *((unsigned long *)&b->line[(y+yy)&511][x&2047])=textlookup[dat][0][bg][fg];
                                                *((unsigned long *)&b->line[(y+yy)&511][(x+4)&2047])=textlookup[dat][1][bg][fg];
                                        }
/*                                        fg=attrregs[attr>>4]+coffset;
                                        bg=attrregs[attr&15]+coffset;
                                        for (yy=(crtc[0xA]&31);yy<(crtc[0xB]&31);yy++)
                                        {
                                                dat=vram[charaddr++];
                                                for (xx=0;xx<8;xx++)
                                                {
                                                        b->line[(y+yy)&511][((x*8)+xx)&2047]=(dat&0x80)?fg:bg;
                                                        dat<<=1;
                                                }
                                        }*/
                                }

                                addr+=2;
                        }
                }
                if (displines>240)
                {
                        if (htotal<=40)
                        {
                                blit(b,vbuf,0,0,0,0,320,displines);
                                stretch_blit(vbuf,screen,0,0,320,displines,0,0,640,displines);
                        }
                        else
                        {
                                blit(b,vbuf,0,0,0,0,640,displines);
                                blit(vbuf,screen,0,0,0,0,640,displines);
                        }
                }
                else
                {
                        if (htotal<=40)
                        {
                                blit(b,vbuf,0,0,0,0,320,displines);
                                stretch_blit(vbuf,screen,0,0,320,200,0,0,640,displines*2);
                        }
                        else
                        {
                                blit(b,vbuf,0,0,0,0,640,displines);
                                stretch_blit(vbuf,screen,0,0,640,200,0,0,640,displines*2);
                        }
                }
        }
        if (readflash) rectfill(screen,600,8,632,14,0xFFFFFFFF);
        oldreadflash=readflash;
        readflash=0;
        memset(changedvram,0,2048);
        fullchange=0;
        if (VGA && palchange) palchange=0;
}
