unsigned long old8,old82,old83;
unsigned short oldcs;
unsigned long oldpc;
int oldcpl;

int tempc;
int cycles,output;
int ssegs;
int firstrepcycle;

unsigned long easeg,eaaddr;
int rm,reg,mod,rmdat;

int skipnextprint;
int inhlt;

unsigned char opcode;
int ins,noint,notpresent;
int inint;

unsigned short lastcs,lastpc;
int lldt;
int timetolive,keyboardtimer;

#define setznp168 setznp16

#define getr8(r)   ((r&4)?regs[r&3].b.h:regs[r&3].b.l)

#define setr8(r,v) if (r&4) regs[r&3].b.h=v; \
                   else     regs[r&3].b.l=v;

unsigned char znptable8[256];

int use32;
int stack32;

#define fetchea()   { rmdat=readmemb(cs+pc); pc++;  \
                    reg=(rmdat>>3)&7;             \
                    mod=rmdat>>6;                 \
                    rm=rmdat&7;                   \
                    if (mod!=3) fetcheal(); }


int optype;
#define JMP 1
#define CALL 2
#define IRET 3

unsigned long oxpc;
