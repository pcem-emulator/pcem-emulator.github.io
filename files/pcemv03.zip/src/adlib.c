#include "ibm.h"
#include "adlibemu.h"

/*Interfaces between PCem and the actual Adlib emulator*/

int adlibaddr,adlibaddr2;
unsigned char adlibstat,adlibstat2;
unsigned char adlibt1,adlibt2;
unsigned short adlibbuf[5488];
int adlibpos=0;

void writeadlib(unsigned short a, unsigned char v)
{
//        printf("Adlib write %04X %02X %i\n",a,v,sbtype);
        if (!sbtype) return;
        if (sbtype!=SBPRO && a<0x224) return;
        switch (a)
        {
                case 0x220: adlibaddr=v; break;
                case 0x222: adlibaddr2=v; break;
                case 0x228: case 0x388:
                adlibaddr=v;
                adlibaddr2=v;
                break;
                case 0x221:
                adlib0(adlibaddr,v);
                switch (adlibaddr)
                {
                        case 4: /*Timer control*/
                        if (v==0x80) adlibstat=0;
                        if (v&1) adlibstat|=0xC0;
                        if (v&2) adlibstat|=0xA0;
                        break;
                }
                break;
                case 0x229: case 0x389:
                adlib0(adlibaddr,v);
                switch (adlibaddr)
                {
                        case 4: /*Timer control*/
                        if (v==0x80) adlibstat=0;
                        if (v&1) adlibstat|=0xC0;
                        if (v&2) adlibstat|=0xA0;
                        break;
                }
                case 0x223:
                adlib1(adlibaddr2,v);
                switch (adlibaddr2)
                {
                        case 4: /*Timer control*/
                        if (v==0x80) adlibstat2=0;
                        if (v&1) adlibstat2|=0xC0;
                        if (v&2) adlibstat2|=0xA0;
                        break;
                }
                break;
        }
}

unsigned char readadlib(unsigned short a)
{
        if (!sbtype) return 0xFF;
        if (sbtype!=SBPRO && a<0x224) return 0xFF;
        if (a==0x222) return adlibstat2;
        if (!(a&1)) return adlibstat;
        return 0;
}

void getadlib(unsigned short *buf, int size)
{
        int c;
        adlibgetsample(buf,size*2);
        for (c=0;c<size;c++)
            buf[c]^=0x8000;
        buf[c]>>=1;
}
void getadlibl(unsigned short *buf, int size)
{
        int c;
        adlibgetsamplel(buf,size*2);
        for (c=0;c<size;c++)
            buf[c]^=0x8000;
        buf[c]>>=1;
}
void getadlibr(unsigned short *buf, int size)
{
        int c;
        adlibgetsampler(buf,size*2);
        for (c=0;c<size;c++)
            buf[c]^=0x8000;
        buf[c]>>=1;
}

void initadlib()
{
        adlibinit(48000,1,2);
}

void polladlib()
{
//        return;
//        printf("Poll adlib %i\n",adlibpos*686);
        getadlib(&adlibbuf[adlibpos*686],686);
        adlibpos++;
}
