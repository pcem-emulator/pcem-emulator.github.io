#include "ibm.h"

int output;
int intclear;
int keywaiting=0;
int pit0;
void resetpic()
{
        pic.icw=0;
        pic.mask=0xFF;
        pic.pend=pic.ins=0;
        pic.vector=8;
        pic2.icw=0;
        pic2.mask=0xFF;
        pic2.pend=pic2.ins=0;
}

void writepic(unsigned short addr, unsigned char val)
{
        int c;
//        printf("Write PIC %04X %02X %04X(%06X):%04X\n",addr,val,CS,cs,pc);
        if (addr&1)
        {
                switch (pic.icw)
                {
                        case 0: /*OCW1*/
//                        printf("Write mask %02X\n",val);
                        pic.mask=val;
                        break;
                        case 1: /*ICW2*/
                        pic.vector=val&0xF8;
//                        printf("PIC vector now %02X\n",pic.vector);
           //             output=1;
                        if (pic.icw1&2) pic.icw=3;
                        else            pic.icw=2;
                        break;
                        case 2: /*ICW3*/
                        if (pic.icw1&1) pic.icw=3;
                        else            pic.icw=0;
                        break;
                        case 3: /*ICW4*/
                        pic.icw=0;
                        break;
                }
        }
        else
        {
                if (val&16) /*ICW1*/
                {
                        pic.mask=0xFF;
                        pic.icw=1;
                        pic.icw1=val;
                }
                else if (!(val&8)) /*OCW2*/
                {
//                        printf("Clear ints - %02X\n",pic.ins);
                        if ((val&0xE0)==0x60)
                        {
//                                printf("Specific EOI - %02X %i\n",pic.ins,1<<(val&7));
                                pic.ins&=~(1<<(val&7));
//                                pic.pend&=(1<<(val&7));
                                if ((val&7)==1) pollkeywaiting();
                        }
                        else
                        {
                                for (c=0;c<8;c++)
                                {
                                        if (pic.ins&(1<<c))
                                        {
                                                pic.ins&=~(1<<c);
//                                                pic.pend&=~(1<<c);
                                                if (c==0) pit0=1;
                                                if (c==1 && keywaiting)
                                                {
                                                        intclear&=~1;
                                                        pollkeywaiting();
                                                }
//                                                printf("Generic EOI - Cleared int %i\n",c);
                                                return;
                                        }
                                }
                        }
                }
                else               /*OCW3*/
                {
                }
        }
}

unsigned char readpic(unsigned short addr)
{
        if (addr&1) return pic.mask;
        return pic.ins;
}

void writepic2(unsigned short addr, unsigned char val)
{
        int c;
        if (addr&1)
        {
                switch (pic2.icw)
                {
                        case 0: /*OCW1*/
//                        printf("Write mask %02X\n",val);
                        pic2.mask=val;
                        break;
                        case 1: /*ICW2*/
                        if (pic2.icw1&2) pic2.icw=3;
                        else            pic2.icw=2;
                        break;
                        case 2: /*ICW3*/
                        if (pic2.icw1&1) pic2.icw=3;
                        else            pic2.icw=0;
                        break;
                        case 3: /*ICW4*/
                        pic2.icw=0;
                        break;
                }
        }
        else
        {
                if (val&16) /*ICW1*/
                {
                        pic2.mask=0xFF;
                        pic2.icw=1;
                        pic2.icw1=val;
                }
                else if (!(val&8)) /*OCW2*/
                {
                        if ((val&0xE0)==0x60)
                        {
                                pic2.ins&=~(1<<(val&7));
                        }
                        else
                        {
                                for (c=0;c<8;c++)
                                {
                                        if (pic2.ins&(1<<c))
                                        {
                                                pic2.ins&=~(1<<c);
                                                return;
                                        }
                                }
                        }
                }
                else               /*OCW3*/
                {
                }
        }
}

unsigned char readpic2(unsigned short addr)
{
        if (addr&1) return pic2.mask;
        return pic2.ins;
}

void updatepicints()
{
        int c;
        unsigned char temp=pic.pend&~pic.mask;        
        for (c=0;c<8;c++)
        {
                if (temp&(1<<c))
                {
                        pic.pend&=~(1<<c);
                        pic.ins|=(1<<c);
//                        printf("Cause interrupt %02X\n",c+8);
//                        i86_Cause_Interrupt(c+8);
                        return;
                }
        }
//        i86_Clear_Pending_Interrupts();
}
        
void clearpic()
{
        pic.pend=pic.ins=0;
}

void picint(int num)
{
        pic.pend|=num;
//        printf("PIC int %02X\n",num);
}
void picintc(int num)
{
        pic.pend&=~num;
//        pic.ins&=~num;
}

unsigned char picinterrupt()
{
        unsigned char temp=pic.pend&~pic.mask;
        int c;
        for (c=0;c<8;c++)
        {
                if (temp&(1<<c))
                {
                        pic.pend&=~(1<<c);
                        pic.ins|=(1<<c);
//                        if (c==1) printf("Keyboard int!\n");
//                        if (c==0) pic.ins&=~1;
                        return c+pic.vector;
                }
        }
        return 0xFF;
}

void picclear(int num)
{
        pic.pend&=~num;
        pic.ins&=~num;
        if (num==1) pit0=1;
}
