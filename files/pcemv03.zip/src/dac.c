#include "ibm.h"

unsigned char dac,dac2;
unsigned char dacctrl;
int lptfifo;
unsigned char dssbuffer[16];
int dssstart=0,dssend=0;
int dssmode=0;

void writedac(unsigned char val)
{
        if (dssmode) dac2=val;
        else         dac=val;
}

void writedacctrl(unsigned char val)
{
//        printf("Write DAC ctrl %02X %i\n",val,lptfifo);
        if (dacctrl&8 && !(val&8) && (lptfifo!=16))
        {
//                dac=dac2;
                dssbuffer[dssend++]=dac2;
                dssend&=15;
                lptfifo++;
        }
        dacctrl=val;
}

unsigned char readdacfifo()
{
        if (lptfifo==16) return 0x40;
        return 0;
}

void pollss()
{
        if (lptfifo)
        {
                dac=dssbuffer[dssstart++];
                dssstart&=15;
                lptfifo--;
        }
}

signed short dacbuffer[SOUNDBUFLEN+20];
int dacbufferpos=0;
void getdacsamp()
{
        dacbuffer[dacbufferpos++]=(((int)(unsigned int)dac)-0x80)*0x20;
}

void adddac(signed short *p)
{
        int c;
        if (dacbufferpos>SOUNDBUFLEN) dacbufferpos=SOUNDBUFLEN;
        for (c=0;c<dacbufferpos;c++)
        {
                p[c<<1]+=(dacbuffer[c]);
                p[(c<<1)+1]+=(dacbuffer[c]);
        }
        for (;c<SOUNDBUFLEN;c++)
        {
                p[c<<1]+=(dacbuffer[dacbufferpos-1]);
                p[(c<<1)+1]+=(dacbuffer[dacbufferpos-1]);
        }
        dacbufferpos=0;
}

