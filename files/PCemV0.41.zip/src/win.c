#include <allegro.h>
#include <winalleg.h>
#include <process.h>

#include <string.h>
#include <stdio.h>
#include <stdarg.h>
#include <stdlib.h>
#include "ibm.h"
#include "resources.h"

int svgapresent;
int wakeups,wokeups;
#undef cs
CRITICAL_SECTION cs;
void waitmain();
void vsyncint();
int vgapresent;

HANDLE soundthreadh;
HANDLE mainthreadh;

void soundthread(LPVOID param);
void endmainthread();
void endsoundthread();
void silencesound();
void restoresound();
static HANDLE soundobject;
AUDIOSTREAM *as;

static HANDLE frameobject;

int infocus=1;

int drawits=0;
void vsyncint()
{
//        if (infocus)
//        {
                        drawits++;
                        wakeups++;
                        SetEvent(frameobject);
//        }
}

int romspresent[14];
int quited=0;

RECT oldclip,pcclip;
int mousecapture=0;
int drawit;
/*  Declare Windows procedure  */
LRESULT CALLBACK WindowProcedure (HWND, UINT, WPARAM, LPARAM);

/*  Make the class name into a global variable  */
char szClassName[ ] = "WindowsApp";

HWND ghwnd;
void updatewindowsize(int x, int y)
{
        RECT r;
        GetWindowRect(ghwnd,&r);
        MoveWindow(ghwnd,r.left,r.top,
                     x+(GetSystemMetrics(SM_CXFIXEDFRAME)*2),
                     y+(GetSystemMetrics(SM_CYFIXEDFRAME)*2)+GetSystemMetrics(SM_CYMENUSIZE)+GetSystemMetrics(SM_CYCAPTION)+1,
                     TRUE);
}

void releasemouse()
{
        if (mousecapture) ClipCursor(&oldclip);
}

static LARGE_INTEGER counter_base;
static LARGE_INTEGER counter_freq;
static LARGE_INTEGER counter_pos;
static LARGE_INTEGER counter_posold;

void setrefresh(int rate)
{
        return;
        remove_int(vsyncint);
        drawit=0;
        install_int_ex(vsyncint,BPS_TO_TIMER(rate));
/*        printf("Vsyncint at %i hz\n",rate);
        counter_freq.QuadPart=counter_base.QuadPart/rate;*/
//        DeleteTimerQueueTimer( &hTimer, hTimerQueue, NULL);
//        CreateTimerQueueTimer( &hTimer, hTimerQueue,
//            mainroutine, NULL , 100, 1000/rate, 0);
}

void startblit()
{
        EnterCriticalSection(&cs);
}

void endblit()
{
        LeaveCriticalSection(&cs);
}

int mainthreadon=0;

void mainthread(LPVOID param)
{
        mainthreadon=1;
//        Sleep(500);
        drawits=0;
        while (!quited)
        {
//                if (infocus)
//                {
                        if (!drawits)
                        {
                                while (!drawits)
                                {
                                        ResetEvent(frameobject);
                                        WaitForSingleObject(frameobject,10);
                                }
                        }
                        while (drawits)
                        {
//                                printf("Drawits %i\n",drawits);
                                drawits--;
                                if (drawits>15) drawits=0;
                                wokeups++;
                                startblit();
                                runpc();
                                endblit();
                                if ((key[KEY_LCONTROL] || key[KEY_RCONTROL]) && key[KEY_END] && mousecapture)
                                {
                                        ClipCursor(&oldclip);
                                        mousecapture=0;
                                }
                        }
//                }
        }
        mainthreadon=0;
}



HINSTANCE hinstance;

int WINAPI WinMain (HINSTANCE hThisInstance,
                    HINSTANCE hPrevInstance,
                    LPSTR lpszArgument,
                    int nFunsterStil)

{
    HWND hwnd;               /* This is the handle for our window */
    MSG messages;            /* Here messages to the application are saved */
    WNDCLASSEX wincl;        /* Data structure for the windowclass */
    int c,d;
    FILE *f;
    int oldinfocus=0;

        hinstance=hThisInstance;
    /* The Window structure */
    wincl.hInstance = hThisInstance;
    wincl.lpszClassName = szClassName;
    wincl.lpfnWndProc = WindowProcedure;      /* This function is called by windows */
    wincl.style = CS_DBLCLKS;                 /* Catch double-clicks */
    wincl.cbSize = sizeof (WNDCLASSEX);

    /* Use default icon and mouse-pointer */
    wincl.hIcon = LoadIcon (NULL, IDI_APPLICATION);
    wincl.hIconSm = LoadIcon (NULL, IDI_APPLICATION);
    wincl.hCursor = LoadCursor (NULL, IDC_ARROW);
    wincl.lpszMenuName = NULL;                 /* No menu */
    wincl.cbClsExtra = 0;                      /* No extra bytes after the window class */
    wincl.cbWndExtra = 0;                      /* structure or the window instance */
    /* Use Windows's default color as the background of the window */
    wincl.hbrBackground = (HBRUSH) COLOR_BACKGROUND;

    /* Register the window class, and if it fails quit the program */
    if (!RegisterClassEx (&wincl))
        return 0;

    /* The class is registered, let's create the program*/
    hwnd = CreateWindowEx (
           0,                   /* Extended possibilites for variation */
           szClassName,         /* Classname */
           "PCem v0.41",       /* Title Text */
           WS_OVERLAPPEDWINDOW&~WS_SIZEBOX, /* default window */
           CW_USEDEFAULT,       /* Windows decides the position */
           CW_USEDEFAULT,       /* where the window ends up on the screen */
           640+(GetSystemMetrics(SM_CXFIXEDFRAME)*2),                 /* The programs width */
           400+(GetSystemMetrics(SM_CYFIXEDFRAME)*2)+GetSystemMetrics(SM_CYMENUSIZE)+GetSystemMetrics(SM_CYCAPTION)+1,                 /* and height in pixels */
           HWND_DESKTOP,        /* The window is a child-window to desktop */
           LoadMenu(hThisInstance,TEXT("MainMenu")),                /* No menu */
           hThisInstance,       /* Program Instance handler */
           NULL                 /* No Window Creation data */
           );

        /* Make the window visible on the screen */
        ShowWindow (hwnd, nFunsterStil);

        win_set_window(hwnd);
        
        ghwnd=hwnd;
        
        initpc();
        
        set_display_switch_mode(SWITCH_BACKGROUND);
        
        d=romset;
        for (c=0;c<13;c++)
        {
                romset=c;
                romspresent[c]=loadbios();
        }
        romset=d;
        c=loadbios();
        
        if (!romspresent[0] && !romspresent[1] && !romspresent[2] && !romspresent[3] && !romspresent[4] && !romspresent[5] && !romspresent[6] && !romspresent[7] && !romspresent[8] && !romspresent[9] && !romspresent[10] && !romspresent[11] && !romspresent[12] && !romspresent[13])
        {
                MessageBox(hwnd,"No ROMs present!\nYou must have at least one romset to use PCem.","PCem fatal error",MB_OK);
                return 0;
        }
        if (!c)
        {
                if (romset!=-1) MessageBox(hwnd,"Configured romset not available.\nDefaulting to available romset.","PCemu error",MB_OK);
                for (c=0;c<12;c++)
                {
                        if (romspresent[c])
                        {
                                romset=c;
                                loadbios();
                                break;
                        }
                }
        }
        
        f=romfopen("roms/trident.bin","rb");
        if (f)
        {
                fclose(f);
                vgapresent=1;
        }
        else
        {
                vgapresent=0;
                if (gfxcard==GFX_SVGA) gfxcard=GFX_CGA;
        }
        f=romfopen("roms/et4000.bin","rb");
        if (f)
        {
                fclose(f);
                svgapresent=1;
        }
        else
        {
                svgapresent=0;
                if (gfxcard==GFX_ET4000) gfxcard=(vgapresent)?GFX_SVGA:GFX_CGA;
        }
//        timeBeginPeriod(1);
//        soundobject=CreateEvent(NULL, FALSE, FALSE, NULL);
//        soundthreadh=CreateThread(NULL,0,soundthread,NULL,NULL,NULL);

        
        atexit(releasemouse);
//        atexit(endsoundthread);
        drawit=0;
//        QueryPerformanceFrequency(&counter_base);
///        QueryPerformanceCounter(&counter_posold);
//        counter_posold.QuadPart*=100;

InitializeCriticalSection(&cs);
        frameobject=CreateEvent(NULL, FALSE, FALSE, NULL);
        mainthreadh=(HANDLE)_beginthread(mainthread,0,NULL);
//        atexit(endmainthread);
//        soundthreadh=(HANDLE)_beginthread(soundthread,0,NULL);
//        atexit(endsoundthread);
        SetThreadPriority(mainthreadh, THREAD_PRIORITY_HIGHEST);
//        SetThreadPriority(soundthreadh, THREAD_PRIORITY_HIGHEST);

        drawit=0;
        install_int_ex(vsyncint,BPS_TO_TIMER(100));
//        setrefresh(100);
        
        /* Run the message loop. It will run until GetMessage() returns 0 */
        while (!quited)
        {
/*                if (infocus)
                {
                        if (drawits)
                        {
                                drawits--;
                                if (drawits>10) drawits=0;
                                runpc();
                        }
//;                        else
//                           sleep(0);
                        if ((key[KEY_LCONTROL] || key[KEY_RCONTROL]) && key[KEY_END] && mousecapture)
                        {
                                ClipCursor(&oldclip);
                                mousecapture=0;
                        }
                }*/

                while (GetMessage(&messages,NULL,0,0) && !quited)
                {
                        if (messages.message==WM_QUIT) quited=1;
                        TranslateMessage(&messages);
                        DispatchMessage(&messages);
                }
                quited=1;
//                else
//                sleep(10);
        }
        
        startblit();
//        pclog("Sleep 1000\n");
        sleep(200);
//        pclog("TerminateThread\n");
        TerminateThread(mainthreadh,0);
//        pclog("Quited? %i\n",quited);
//        pclog("Closepc\n");
        closepc();
//        pclog("dumpregs\n");
//        timeEndPeriod(1);
//        endsoundthread();
//        dumpregs();
        if (mousecapture) ClipCursor(&oldclip);
//        pclog("Ending! %i %i\n",messages.wParam,quited);
        return messages.wParam;
}

char openfilestring[260];
int getfile(HWND hwnd, char *f, char *fn)
{
        OPENFILENAME ofn;       // common dialog box structure
        char szFile[260];       // buffer for file name

        // Initialize OPENFILENAME
        ZeroMemory(&ofn, sizeof(ofn));
        ofn.lStructSize = sizeof(ofn);
        ofn.hwndOwner = hwnd;
        ofn.lpstrFile = openfilestring;
        //
        // Set lpstrFile[0] to '\0' so that GetOpenFileName does not
        // use the contents of szFile to initialize itself.
        //
//        ofn.lpstrFile[0] = '\0';
        strcpy(ofn.lpstrFile,fn);
        ofn.nMaxFile = sizeof(openfilestring);
        ofn.lpstrFilter = f;//"All\0*.*\0Text\0*.TXT\0";
        ofn.nFilterIndex = 1;
        ofn.lpstrFileTitle = NULL;
        ofn.nMaxFileTitle = 0;
        ofn.lpstrInitialDir = NULL;
        ofn.Flags = OFN_PATHMUSTEXIST | OFN_FILEMUSTEXIST;

        // Display the Open dialog box.

        if (GetOpenFileName(&ofn))
           return 0;
        return 1;
}

extern int is486;
int romstolist[13],listtoroms[13];
BOOL CALLBACK configdlgproc(HWND hdlg, UINT message, WPARAM wParam, LPARAM lParam)
{
        HWND h;
        int c;
        int rom,gfx;
//        pclog("Dialog msg %i %08X\n",message,message);
        switch (message)
        {
                case WM_INITDIALOG:
                h=GetDlgItem(hdlg,IDC_COMBO1);
                for (c=0;c<13;c++) romstolist[c]=0;
                c=0;
                if (romspresent[ROM_IBMPC])  { SendMessage(h,CB_ADDSTRING,0,(LPARAM)(LPCSTR)"IBM PC"); romstolist[ROM_IBMPC]=c; listtoroms[c]=ROM_IBMPC; c++; }
                if (romspresent[ROM_IBMXT])  { SendMessage(h,CB_ADDSTRING,0,(LPARAM)(LPCSTR)"IBM XT"); romstolist[ROM_IBMXT]=c; listtoroms[c]=ROM_IBMXT; c++; }
                if (romspresent[ROM_GENXT])  { SendMessage(h,CB_ADDSTRING,0,(LPARAM)(LPCSTR)"Generic Turbo XT"); romstolist[ROM_GENXT]=c; listtoroms[c]=ROM_GENXT; c++; }
                if (romspresent[ROM_TANDY])  { SendMessage(h,CB_ADDSTRING,0,(LPARAM)(LPCSTR)"Tandy 1000"); romstolist[ROM_TANDY]=c; listtoroms[c]=ROM_TANDY; c++; }
                if (romspresent[ROM_PC1512]) { SendMessage(h,CB_ADDSTRING,0,(LPARAM)(LPCSTR)"Amstrad PC1512"); romstolist[ROM_PC1512]=c; listtoroms[c]=ROM_PC1512; c++; }
                if (romspresent[ROM_PC200])  { SendMessage(h,CB_ADDSTRING,0,(LPARAM)(LPCSTR)"Sinclair PC200"); romstolist[ROM_PC200]=c; listtoroms[c]=ROM_PC200; c++; }
                if (romspresent[ROM_EUROPC]) { SendMessage(h,CB_ADDSTRING,0,(LPARAM)(LPCSTR)"Euro PC"); romstolist[ROM_EUROPC]=c; listtoroms[c]=ROM_EUROPC; c++; }
                if (romspresent[ROM_PC1640]) { SendMessage(h,CB_ADDSTRING,0,(LPARAM)(LPCSTR)"Amstrad PC1640"); romstolist[ROM_PC1640]=c; listtoroms[c]=ROM_PC1640; c++; }
                if (romspresent[ROM_IBMAT])  { SendMessage(h,CB_ADDSTRING,0,(LPARAM)(LPCSTR)"IBM AT"); romstolist[ROM_IBMAT]=c; listtoroms[c]=ROM_IBMAT; c++; }
                if (romspresent[ROM_AMI286])  { SendMessage(h,CB_ADDSTRING,0,(LPARAM)(LPCSTR)"AMI 286 clone"); romstolist[ROM_AMI286]=c; listtoroms[c]=ROM_AMI286; c++; }
                if (romspresent[ROM_IBMAT386])  { SendMessage(h,CB_ADDSTRING,0,(LPARAM)(LPCSTR)"IBM AT 386"); romstolist[ROM_IBMAT386]=c; listtoroms[c]=ROM_IBMAT386; c++; }
                if (romspresent[ROM_AMI386])  { SendMessage(h,CB_ADDSTRING,0,(LPARAM)(LPCSTR)"AMI 386 clone"); romstolist[ROM_AMI386]=c; listtoroms[c]=ROM_AMI386; c++; }
                if (romspresent[ROM_AMI486])  { SendMessage(h,CB_ADDSTRING,0,(LPARAM)(LPCSTR)"AMI 486 clone"); romstolist[ROM_AMI486]=c; listtoroms[c]=ROM_AMI486; c++; }
                SendMessage(h,CB_SETCURSEL,romstolist[romset],0);
                
                h=GetDlgItem(hdlg,IDC_COMBO2);
                SendMessage(h,CB_ADDSTRING,0,(LPARAM)(LPCSTR)"CGA");
                SendMessage(h,CB_ADDSTRING,0,(LPARAM)(LPCSTR)"MDA");
                SendMessage(h,CB_ADDSTRING,0,(LPARAM)(LPCSTR)"Hercules");
                if (vgapresent) SendMessage(h,CB_ADDSTRING,0,(LPARAM)(LPCSTR)"Trident SVGA");
                if (svgapresent) SendMessage(h,CB_ADDSTRING,0,(LPARAM)(LPCSTR)"ET4000 SVGA");
                SendMessage(h,CB_SETCURSEL,gfxcard,0);
                if (romset>ROM_EUROPC && romset<ROM_IBMAT) EnableWindow(h,FALSE);

                pclog("Dialog open %i\n",AT);
                h=GetDlgItem(hdlg,IDC_COMBO3);
                SendMessage(h,CB_ADDSTRING,0,(LPARAM)(LPCSTR)"4.77mhz 8088");
                SendMessage(h,CB_ADDSTRING,0,(LPARAM)(LPCSTR)"8mhz 8086");
                SendMessage(h,CB_ADDSTRING,0,(LPARAM)(LPCSTR)"10mhz 8086");
                SendMessage(h,CB_ADDSTRING,0,(LPARAM)(LPCSTR)"12mhz 8086");
                SendMessage(h,CB_ADDSTRING,0,(LPARAM)(LPCSTR)"16mhz 8086");
                SendMessage(h,CB_SETCURSEL,cpuspeed,0);
                if (AT || romset>ROM_TANDY) { EnableWindow(h,FALSE); }
                else                        { pclog("Enable base\n"); EnableWindow(h,TRUE); }

                h=GetDlgItem(hdlg,IDC_COMBO4);
                SendMessage(h,CB_ADDSTRING,0,(LPARAM)(LPCSTR)"8mhz 80286");
                SendMessage(h,CB_ADDSTRING,0,(LPARAM)(LPCSTR)"12mhz 80286");
                SendMessage(h,CB_ADDSTRING,0,(LPARAM)(LPCSTR)"16mhz 80286");
                SendMessage(h,CB_ADDSTRING,0,(LPARAM)(LPCSTR)"20mhz 80286");
                SendMessage(h,CB_ADDSTRING,0,(LPARAM)(LPCSTR)"25mhz 80286");
                SendMessage(h,CB_SETCURSEL,cpuspeed,0);
                if (!AT || is386) ShowWindow(h,SW_HIDE);
                else              { pclog("Enable 80286\n"); ShowWindow(h,SW_SHOW); }

                h=GetDlgItem(hdlg,IDC_COMBO5);
                SendMessage(h,CB_ADDSTRING,0,(LPARAM)(LPCSTR)"8mhz 8086");
                SendMessage(h,CB_ADDSTRING,0,(LPARAM)(LPCSTR)"10mhz 8086");
                SendMessage(h,CB_ADDSTRING,0,(LPARAM)(LPCSTR)"12mhz 8086");
                SendMessage(h,CB_ADDSTRING,0,(LPARAM)(LPCSTR)"16mhz 8086");
                if (cpuspeed) SendMessage(h,CB_SETCURSEL,cpuspeed-1,0);
                else          SendMessage(h,CB_SETCURSEL,0,0);
                if (!AT && romset>ROM_TANDY) ShowWindow(h,SW_SHOW);
                else                         { pclog("Disable 8086\n"); ShowWindow(h,SW_HIDE); }

                h=GetDlgItem(hdlg,IDC_COMBO386);
                SendMessage(h,CB_ADDSTRING,0,(LPARAM)(LPCSTR)"16mhz 80386DX");
                SendMessage(h,CB_ADDSTRING,0,(LPARAM)(LPCSTR)"20mhz 80386DX");
                SendMessage(h,CB_ADDSTRING,0,(LPARAM)(LPCSTR)"25mhz 80386DX");
                SendMessage(h,CB_ADDSTRING,0,(LPARAM)(LPCSTR)"33mhz 80386DX");
                SendMessage(h,CB_ADDSTRING,0,(LPARAM)(LPCSTR)"40mhz 80386DX");
                SendMessage(h,CB_SETCURSEL,cpuspeed,0);
                if (!is386 || is486) ShowWindow(h,SW_HIDE);
                else        { pclog("Enable 80386\n"); ShowWindow(h,SW_SHOW); }

                h=GetDlgItem(hdlg,IDC_COMBO486);
                SendMessage(h,CB_ADDSTRING,0,(LPARAM)(LPCSTR)"16mhz 486SX");
                SendMessage(h,CB_ADDSTRING,0,(LPARAM)(LPCSTR)"20mhz 486SX");
                SendMessage(h,CB_ADDSTRING,0,(LPARAM)(LPCSTR)"25mhz 486SX");
                SendMessage(h,CB_ADDSTRING,0,(LPARAM)(LPCSTR)"33mhz 486SX");
                SendMessage(h,CB_ADDSTRING,0,(LPARAM)(LPCSTR)"40mhz 486SX");
                SendMessage(h,CB_SETCURSEL,cpuspeed,0);
                if (!is486) ShowWindow(h,SW_HIDE);
                else       { pclog("Enable 80486\n"); ShowWindow(h,SW_SHOW); }
                
                pclog("is386 %i is486 %i\n",is386,is486);

                h=GetDlgItem(hdlg,IDC_COMBOSND);
                SendMessage(h,CB_ADDSTRING,0,(LPARAM)(LPCSTR)"None");
                SendMessage(h,CB_ADDSTRING,0,(LPARAM)(LPCSTR)"AdLib");
                SendMessage(h,CB_ADDSTRING,0,(LPARAM)(LPCSTR)"SoundBlaster v1.0");
                SendMessage(h,CB_ADDSTRING,0,(LPARAM)(LPCSTR)"SoundBlaster v2.0");
                SendMessage(h,CB_ADDSTRING,0,(LPARAM)(LPCSTR)"SB Pro v1");
                SendMessage(h,CB_SETCURSEL,sbtype,0);

//                h=GetDlgItem(hdlg,IDC_CHECK2);
//                SendMessage(h,BM_SETCHECK,ADLIB,0);
                
                h=GetDlgItem(hdlg,IDC_CHECK3);
                SendMessage(h,BM_SETCHECK,GAMEBLASTER,0);
                
                h=GetDlgItem(hdlg,IDC_CHECK1);
                SendMessage(h,BM_SETCHECK,FASTDISC,0);

                h=GetDlgItem(hdlg,IDC_CHECK2);
                SendMessage(h,BM_SETCHECK,slowega,0);

                return TRUE;
                case WM_COMMAND:
                switch (LOWORD(wParam))
                {
                        case IDOK:
                        h=GetDlgItem(hdlg,IDC_COMBO1);
                        rom=listtoroms[SendMessage(h,CB_GETCURSEL,0,0)];

                        h=GetDlgItem(hdlg,IDC_COMBO2);
                        gfx=SendMessage(h,CB_GETCURSEL,0,0);

                        if (rom!=romset || gfx!=gfxcard)
                        {
                                if (MessageBox(NULL,"This will reset PCem!\nOkay to continue?","PCem",MB_OKCANCEL)==IDOK)
                                {
                                        romset=rom;
                                        gfxcard=gfx;
                                        loadbios();
                                        resetpchard();
                                }
                                else
                                {
                                        EndDialog(hdlg,0);
                                        return TRUE;
                                }
                        }

                        h=GetDlgItem(hdlg,IDC_CHECK2);
                        slowega=SendMessage(h,BM_GETCHECK,0,0);

                        h=GetDlgItem(hdlg,IDC_CHECK3);
                        GAMEBLASTER=SendMessage(h,BM_GETCHECK,0,0);

                        h=GetDlgItem(hdlg,IDC_CHECK1);
                        FASTDISC=SendMessage(h,BM_GETCHECK,0,0);

                        if (is486)         h=GetDlgItem(hdlg,IDC_COMBO486);
                        else if (is386)    h=GetDlgItem(hdlg,IDC_COMBO386);
                        else if (AT)       h=GetDlgItem(hdlg,IDC_COMBO4);
                        else if (romset>ROM_TANDY) h=GetDlgItem(hdlg,IDC_COMBO5);
                        else               h=GetDlgItem(hdlg,IDC_COMBO3);
                        cpuspeed=SendMessage(h,CB_GETCURSEL,0,0);
                        if (!AT && romset>ROM_TANDY) cpuspeed++;
                        
                        h=GetDlgItem(hdlg,IDC_COMBOSND);
                        sbtype=SendMessage(h,CB_GETCURSEL,0,0);

                        speedchanged();
//                        if (romset>2) cpuspeed=1;
//                        setpitclock(clocks[AT?1:0][cpuspeed][0]);
//                        if (cpuspeed) setpitclock(8000000.0);
//                        else          setpitclock(4772728.0);

                        case IDCANCEL:
                        EndDialog(hdlg,0);
                        return TRUE;
                        case IDC_COMBO1:
                        if (HIWORD(wParam)==CBN_SELCHANGE)
                        {
                                h=GetDlgItem(hdlg,IDC_COMBO1);
                                c=SendMessage(h,CB_GETCURSEL,0,0);
                                h=GetDlgItem(hdlg,IDC_COMBO2);
                                if (listtoroms[c]<ROM_TANDY || listtoroms[c]>=ROM_IBMAT) EnableWindow(h,TRUE);
                                else                                                     EnableWindow(h,FALSE);
                                h=GetDlgItem(hdlg,IDC_COMBO3);
                                if (listtoroms[c]<=ROM_TANDY) EnableWindow(h,TRUE);
                                else                 EnableWindow(h,FALSE);
                                h=GetDlgItem(hdlg,IDC_COMBO4);
                                if (listtoroms[c]==ROM_IBMAT) ShowWindow(h,SW_SHOW);
                                else                          ShowWindow(h,SW_HIDE);
                                h=GetDlgItem(hdlg,IDC_COMBO5);
                                if (listtoroms[c]!=ROM_IBMAT && listtoroms[c]!=ROM_IBMAT386 && listtoroms[c]!=ROM_AMI386 && listtoroms[c]>ROM_TANDY) ShowWindow(h,SW_SHOW);
                                else                                             ShowWindow(h,SW_HIDE);
                                h=GetDlgItem(hdlg,IDC_COMBO386);
                                if (listtoroms[c]==ROM_IBMAT386 || listtoroms[c]==ROM_AMI386) ShowWindow(h,SW_SHOW);
                                else                             ShowWindow(h,SW_HIDE);
                                h=GetDlgItem(hdlg,IDC_COMBO486);
                                if (listtoroms[c]==ROM_AMI486) ShowWindow(h,SW_SHOW);
                                else                           ShowWindow(h,SW_HIDE);
                        }
                        break;
                }
                break;

        }
        return FALSE;
}

BOOL CALLBACK hdconfdlgproc(HWND hdlg, UINT message, WPARAM wParam, LPARAM lParam)
{
        char s[260];
        HWND h;
        int c;
        PcemHDC hd[2];
        int changeddrv=0;
        switch (message)
        {
                case WM_INITDIALOG:
                hd[0]=hdc[0];
                hd[1]=hdc[1];
                
                h=GetDlgItem(hdlg,IDC_EDIT1);
                sprintf(s,"%i",hdc[0].spt);
                SendMessage(h,WM_SETTEXT,0,(LPARAM)s);
                h=GetDlgItem(hdlg,IDC_EDIT2);
                sprintf(s,"%i",hdc[0].hpc);
                SendMessage(h,WM_SETTEXT,0,(LPARAM)s);
                h=GetDlgItem(hdlg,IDC_EDIT3);
                sprintf(s,"%i",hdc[0].tracks);
                SendMessage(h,WM_SETTEXT,0,(LPARAM)s);

                h=GetDlgItem(hdlg,IDC_EDIT4);
                sprintf(s,"%i",hdc[1].spt);
                SendMessage(h,WM_SETTEXT,0,(LPARAM)s);
                h=GetDlgItem(hdlg,IDC_EDIT5);
                sprintf(s,"%i",hdc[1].hpc);
                SendMessage(h,WM_SETTEXT,0,(LPARAM)s);
                h=GetDlgItem(hdlg,IDC_EDIT6);
                sprintf(s,"%i",hdc[1].tracks);
                SendMessage(h,WM_SETTEXT,0,(LPARAM)s);
                
                h=GetDlgItem(hdlg,IDC_TEXT1);
                sprintf(s,"Size : %imb",((((hd[0].tracks*hd[0].hpc)*hd[0].spt)*512)/1024)/1024);
                SendMessage(h,WM_SETTEXT,0,(LPARAM)s);

                h=GetDlgItem(hdlg,IDC_TEXT2);
                sprintf(s,"Size : %imb",((((hd[1].tracks*hd[1].hpc)*hd[1].spt)*512)/1024)/1024);
                SendMessage(h,WM_SETTEXT,0,(LPARAM)s);
                return TRUE;
                case WM_COMMAND:
                switch (LOWORD(wParam))
                {
                        case IDOK:
                        h=GetDlgItem(hdlg,IDC_EDIT1);
                        SendMessage(h,WM_GETTEXT,255,(LPARAM)s);
                        sscanf(s,"%i",&hd[0].spt);
                        h=GetDlgItem(hdlg,IDC_EDIT2);
                        SendMessage(h,WM_GETTEXT,255,(LPARAM)s);
                        sscanf(s,"%i",&hd[0].hpc);
                        h=GetDlgItem(hdlg,IDC_EDIT3);
                        SendMessage(h,WM_GETTEXT,255,(LPARAM)s);
                        sscanf(s,"%i",&hd[0].tracks);

                        h=GetDlgItem(hdlg,IDC_EDIT4);
                        SendMessage(h,WM_GETTEXT,255,(LPARAM)s);
                        sscanf(s,"%i",&hd[1].spt);
                        h=GetDlgItem(hdlg,IDC_EDIT5);
                        SendMessage(h,WM_GETTEXT,255,(LPARAM)s);
                        sscanf(s,"%i",&hd[1].hpc);
                        h=GetDlgItem(hdlg,IDC_EDIT6);
                        SendMessage(h,WM_GETTEXT,255,(LPARAM)s);
                        sscanf(s,"%i",&hd[1].tracks);

                        if ((hd[0].spt != hdc[0].spt) || (hd[0].hpc != hdc[0].hpc) || (hd[0].tracks != hd[0].tracks))
                        {
                                if (hd[0].spt>63)
                                {
                                        MessageBox(ghwnd,"Drive C: has too many sectors (maximum is 63)","PCem error",MB_OK);
                                        return TRUE;
                                }
                                if (hd[0].hpc>16)
                                {
                                        MessageBox(ghwnd,"Drive C: has too many heads (maximum is 16","PCem error",MB_OK);
                                        return TRUE;
                                }
                                if (hd[0].tracks>1023)
                                {
                                        MessageBox(ghwnd,"Drive C: has too many cylinders (maximum is 1023)","PCem error",MB_OK);
                                        return TRUE;
                                }
                                if (MessageBox(ghwnd,"This will wipe everything on the emulated drive C:!\nIt will also reset PCem\nOkay to continue?","PCem",MB_OKCANCEL)==IDOK)
                                {
                                        hdc[0].spt=hd[0].spt;
                                        hdc[0].hpc=hd[0].hpc;
                                        hdc[0].tracks=hd[0].tracks;
                                        resizedrive(0);
                                        resetpchard();
                                        changeddrv=1;
                                }
                        }
                        if ((hd[1].spt != hdc[1].spt) || (hd[1].hpc != hdc[1].hpc) || (hd[1].tracks != hd[1].tracks))
                        {
                                if (hd[1].spt>63)
                                {
                                        MessageBox(ghwnd,"Drive D: has too many sectors (maximum is 63)","PCem error",MB_OK);
                                        return TRUE;
                                }
                                if (hd[1].hpc>16)
                                {
                                        MessageBox(ghwnd,"Drive D: has too many heads (maximum is 16","PCem error",MB_OK);
                                        return TRUE;
                                }
                                if (hd[1].tracks>1023)
                                {
                                        MessageBox(ghwnd,"Drive D: has too many cylinders (maximum is 1023)","PCem error",MB_OK);
                                        return TRUE;
                                }
                                if (MessageBox(ghwnd,"This will wipe everything on the emulated drive D:!\nIt will also reset PCem\nOkay to continue?","PCem",MB_OKCANCEL)==IDOK)
                                {
                                        hdc[1].spt=hd[1].spt;
                                        hdc[1].hpc=hd[1].hpc;
                                        hdc[1].tracks=hd[1].tracks;
                                        resizedrive(1);
                                        resetpchard();
                                        changeddrv=1;
                                }
                        }
                        if (changeddrv)
                           MessageBox(ghwnd,"Remember to partition and format the new drive(s)","PCem",MB_OK);
                        case IDCANCEL:
                        EndDialog(hdlg,0);
                        return TRUE;
                        
                        case IDC_EDIT1: case IDC_EDIT2: case IDC_EDIT3:
                        h=GetDlgItem(hdlg,IDC_EDIT1);
                        SendMessage(h,WM_GETTEXT,255,(LPARAM)s);
                        sscanf(s,"%i",&hd[0].spt);
                        h=GetDlgItem(hdlg,IDC_EDIT2);
                        SendMessage(h,WM_GETTEXT,255,(LPARAM)s);
                        sscanf(s,"%i",&hd[0].hpc);
                        h=GetDlgItem(hdlg,IDC_EDIT3);
                        SendMessage(h,WM_GETTEXT,255,(LPARAM)s);
                        sscanf(s,"%i",&hd[0].tracks);

                        h=GetDlgItem(hdlg,IDC_TEXT1);
                        sprintf(s,"Size : %imb",((((hd[0].tracks*hd[0].hpc)*hd[0].spt)*512)/1024)/1024);
                        SendMessage(h,WM_SETTEXT,0,(LPARAM)s);
                        return TRUE;

                        case IDC_EDIT4: case IDC_EDIT5: case IDC_EDIT6:
                        h=GetDlgItem(hdlg,IDC_EDIT4);
                        SendMessage(h,WM_GETTEXT,255,(LPARAM)s);
                        sscanf(s,"%i",&hd[1].spt);
                        h=GetDlgItem(hdlg,IDC_EDIT5);
                        SendMessage(h,WM_GETTEXT,255,(LPARAM)s);
                        sscanf(s,"%i",&hd[1].hpc);
                        h=GetDlgItem(hdlg,IDC_EDIT6);
                        SendMessage(h,WM_GETTEXT,255,(LPARAM)s);
                        sscanf(s,"%i",&hd[1].tracks);

                        h=GetDlgItem(hdlg,IDC_TEXT2);
                        sprintf(s,"Size : %imb",((((hd[1].tracks*hd[1].hpc)*hd[1].spt)*512)/1024)/1024);
                        SendMessage(h,WM_SETTEXT,0,(LPARAM)s);
                        return TRUE;
                }
                break;

        }
        return FALSE;
}

LRESULT CALLBACK WindowProcedure (HWND hwnd, UINT message, WPARAM wParam, LPARAM lParam)
{
        HMENU hmenu;
//        pclog("Message %i %08X\n",message,message);
        switch (message)
        {
                case WM_COMMAND:
//                        pclog("WM_COMMAND %i\n",LOWORD(wParam));
                hmenu=GetMenu(hwnd);
                switch (LOWORD(wParam))
                {
                        case IDM_FILE_RESET:
                        resetpc();
                        drawit=1;
                        break;
                        case IDM_FILE_HRESET:
                        resetpchard();
                        drawit=1;
                        break;
                        case IDM_FILE_EXIT:
                        PostQuitMessage (0);       /* send a WM_QUIT to the message queue */
                        break;
                        case IDM_DISC_A:
                        if (!getfile(hwnd,"Disc image (*.IMG;*.IMA)\0*.IMG;*.IMA\0All files (*.*)\0*.*\0",discfns[0]))
                        {
                                savedisc();
                                loaddisc(openfilestring);
                        }
                        break;
                        case IDM_DISC_B:
                        if (!getfile(hwnd,"Disc image (*.IMG;*.IMA)\0*.IMG;*.IMA\0All files (*.*)\0*.*\0",discfns[1]))
                        {
                                savedisc2();
                                loaddisc2(openfilestring);
                        }
                        break;
                        case IDM_EJECT_A:
                        ejectdisc();
                        break;
                        case IDM_EJECT_B:
                        ejectdisc2();
                        break;
                        case IDM_HDCONF:
                        DialogBox(hinstance,TEXT("HdConfDlg"),hwnd,hdconfdlgproc);
                        break;
                        case IDM_CONFIG:
                        DialogBox(hinstance,TEXT("ConfigureDlg"),hwnd,configdlgproc);
                        break;
                }
                return 0;
                
                case WM_SETFOCUS:
                infocus=1;
                drawit=0;
 //               QueryPerformanceCounter(&counter_posold);
//                ResetEvent(frameobject);
//                restoresound();
//                pclog("Set focus!\n");
                break;
                case WM_KILLFOCUS:
                infocus=0;
                if (mousecapture)
                {
                        ClipCursor(&oldclip);
                        mousecapture=0;
                }
//                silencesound();
//                pclog("Lost focus!\n");
                break;

                case WM_LBUTTONUP:
                if (!mousecapture)
                {
                        GetClipCursor(&oldclip);
                        GetWindowRect(hwnd,&pcclip);
                        pcclip.left+=GetSystemMetrics(SM_CXFIXEDFRAME)+10;
                        pcclip.right-=GetSystemMetrics(SM_CXFIXEDFRAME)+10;
                        pcclip.top+=GetSystemMetrics(SM_CXFIXEDFRAME)+GetSystemMetrics(SM_CYMENUSIZE)+GetSystemMetrics(SM_CYCAPTION)+10;
                        pcclip.bottom-=GetSystemMetrics(SM_CXFIXEDFRAME)+10;
                        ClipCursor(&pcclip);
                        mousecapture=1;
                }
                break;
                case WM_DESTROY:
                PostQuitMessage (0);       /* send a WM_QUIT to the message queue */
                break;
                default:
//                        pclog("Def %08X %i\n",message,message);
                return DefWindowProc (hwnd, message, wParam, lParam);
        }
        return 0;
}
