#include <stdio.h>
#include <allegro.h>
#include <winalleg.h>
#include "ibm.h"

void fullspeed();

int framecount,fps;
int pitsec;
int intcount;
int wakeups,wokeups;
int output;
int atfullspeed;
void loadconfig();
void saveconfig();
int infocus;
int mousecapture;
FILE *pclogf;
void pclog(const char *format, ...)
{
   char buf[256];
   return;
   if (!pclogf)
      pclogf=fopen("pclog2.txt","wt");
//return;
   va_list ap;
   va_start(ap, format);
   vsprintf(buf, format, ap);
   va_end(ap);
   fputs(buf,pclogf);
   fflush(pclogf);
}
unsigned char cgastat;
int drawit=0;

unsigned char mousex,mousey;

void writemouse(unsigned short addr, unsigned char val)
{
        if (addr==0x78) mousex=0;
        else            mousey=0;
}

unsigned char readmouse(unsigned short addr)
{
        unsigned char temp;
//        printf("Read mouse %04X:%04X\n",cs>>4,pc);
        if (addr==0x78)
        {
                temp=mousex;
                mousex=0;
                return temp;
        }
        temp=mousey;
        mousey=0;
        return temp;
}

void pollmouse()
{
        int x,y;
        get_mouse_mickeys(&x,&y);
        if (AMSTRAD)
        {
                mousex+=x;
                mousey-=y;
        }
//        else
//        {
                reportmouse(x,y,mouse_b);
//        }
        if (mousecapture) position_mouse(64,64);
}

/*PC1512 languages -
  7=English
  6=German
  5=French
  4=Spanish
  3=Danish
  2=Swedish
  1=Italian
        3,2,1 all cause the self test to fail for some reason
  */

int cpuspeed2;

int clocks[3][5][4]=
{
        {
                {4772728,13920,59660,5965},  /*4.77mhz*/
                {8000000,23333,110000,0}, /*8mhz*/
                {10000000,29166,137500,0}, /*10mhz*/
                {12000000,35000,165000,0}, /*12mhz*/
                {16000000,46666,220000,0}, /*16mhz*/
        },
        {
                {8000000,23333,110000,0}, /*8mhz*/
                {12000000,35000,165000,0}, /*12mhz*/
                {16000000,46666,220000,0}, /*16mhz*/
                {20000000,58333,275000,0}, /*20mhz*/
                {25000000,72916,343751,0}, /*25mhz*/
        },
        {
                {16000000, 46666,220000,0}, /*16mhz*/
                {20000000, 58333,275000,0}, /*20mhz*/
                {25000000, 72916,343751,0}, /*25mhz*/
//                {33000000*2, 96000*2,454000*2,0}, /*66mhz*/
                {33000000, 96000,454000,0}, /*33mhz*/
                {40000000,116666,550000,0}, /*40mhz*/
        }
};

void onesec()
{
        fps=framecount;
        framecount=0;
}

void initpc()
{
        char *p;
        allegro_init();
        get_executable_name(pcempath,511);
        p=get_filename(pcempath);
        *p=0;
        cpuspeed=1;
        romset=ROM_IBMXT;
        gfxcard=GFX_CGA;
        ADLIB=FASTDISC=GAMEBLASTER=0;
        install_keyboard();
        install_timer();
        install_mouse();
        loadconfig();
        cpuspeed2=(AT)?2:1;
//        cpuspeed2=cpuspeed;
        atfullspeed=0;
        initvideo();
        initmem();
        loadbios();
        resetx86();
        resetdma();
        resetpic();
        setpitclock(clocks[AT?1:0][cpuspeed2][0]);
//        if (cpuspeed) setpitclock(8000000.0);
//        else          setpitclock(4772728.0);
        resetpit();
        resetppi();
        resetserial();
        loaddisc(discfns[0]);
        loaddisc2(discfns[1]);
        loadfont();
        loadnvr();
        resetvideo();
        initsound();
        initpsg();
        initsb();
        inithdc();
        initega();
        initgus();
        install_int_ex(onesec,BPS_TO_TIMER(1));
//        install_int_ex(vsyncint,BPS_TO_TIMER(60));
        if (romset==ROM_AMI386 || romset==ROM_AMI486) fullspeed();
}

void resetpc()
{
        resetx86();
        resetpit();
        resetppi();
        resetserial();
        resetdma();
        resetpic();
        resetvideo();
        resetfdc();
        savenvr();
        loadnvr();
        cpuspeed2=(AT)?2:1;
        atfullspeed=0;
        setpitclock(clocks[AT?1:0][cpuspeed2][0]);
        memset(vram,0,1024*1024);
        initsb();
        initega();
        if (romset==ROM_EUROPC)
        {
                saveeuropc();
                loadeuropc();
        }
        if (romset==ROM_AMI386 || romset==ROM_AMI486) fullspeed();
}

void resetpchard()
{
        resetpc();
        memset(ram,0,4096*1024);
}

char romsets[13][40]={"IBM PC","IBM XT","Generic Turbo XT","Euro PC","Tandy 1000","Amstrad PC1512","Sinclair PC200","Amstrad PC1640","IBM AT","AMI 286 clone","IBM AT 386","386 clone","486 clone"};
char clockspeeds[3][5][16]=
{
        {"4.77mhz","8mhz","10mhz","12mhz","16mhz"},
        {"8mhz","12mhz","16mhz","20mhz","25mhz"},
        {"16mhz","20mhz","25mhz","33mhz","40mhz"}
};
int framecountx=0;
int sndcount=0;
int oldat70hz;
void runpc()
{
        char s[200];
        int done=0;
//        if (key[KEY_Q]) output=7;
//        if (!drawit) waitmain();
//        if (drawit)
//        {
//                printf("Running!\n");
//                drawit--;
/*                  cgastat|=8;*/
                if (is386)   exec386(clocks[2][cpuspeed2][0]/100);
                else if (AT) exec286(clocks[1][cpuspeed2][0]/100);
                else         execx86(clocks[0][cpuspeed2][0]/100);
/*                {
                        if (at70hz && VGA) exec386((int)((float)clocks[2][cpuspeed2][1]*(60.0f/70.0f)));
                        else               exec386(clocks[2][cpuspeed2][1]);
                }
                else if (AT)
                {
                        if (at70hz && VGA) exec286((int)((float)clocks[2][cpuspeed2][1]*(60.0f/70.0f)));
                        else               exec286(clocks[2][cpuspeed2][1]);
                }
                else
                {
                        if (at70hz && VGA) execx86((int)((float)clocks[AT?1:0][cpuspeed2][1]*(60.0f/70.0f)));
                        else               execx86(clocks[AT?1:0][cpuspeed2][1]);
                }*/
//                execx86((cpuspeed)?23333:13920);
/*                  cgastat&=~8;*/
//                cgastat|=1;
/*                cacheega();
                cacheega2();
                drawscreen();
                if (is386)
                {
                        if (at70hz && VGA) exec386((int)((float)clocks[2][cpuspeed2][3]*(60.0f/70.0f)));
                        else               exec386(clocks[2][cpuspeed2][3]);
                        if (at70hz && VGA) exec386((int)((float)clocks[2][cpuspeed2][2]*(60.0f/70.0f)));
                        else               exec386(clocks[2][cpuspeed2][2]);
                }
                else if (AT)
                {
//                        printf("Exec 286\n");
                        if (at70hz && VGA) exec286((int)((float)clocks[AT?1:0][cpuspeed2][3]*(60.0f/70.0f)));
                        else               exec286(clocks[AT?1:0][cpuspeed2][3]);
                        if (at70hz && VGA) exec286((int)((float)clocks[AT?1:0][cpuspeed2][2]*(60.0f/70.0f)));
                        else               exec286(clocks[AT?1:0][cpuspeed2][2]);
                }
                else
                {
                        if (at70hz && VGA) execx86((int)((float)clocks[AT?1:0][cpuspeed2][3]*(60.0f/70.0f)));
                        else               execx86(clocks[AT?1:0][cpuspeed2][3]);
                        if (at70hz && VGA) execx86((int)((float)clocks[AT?1:0][cpuspeed2][2]*(60.0f/70.0f)));
                        else               execx86(clocks[AT?1:0][cpuspeed2][2]);
                }*/
//                execx86((cpuspeed)?110000:65625);
//                picint(0x20); /*IRQ 5 - vsync*/
//                drawscreen();
                checkkeys();
                pollmouse();
                framecountx++;
                if (framecountx>=100)
                {
                        framecountx=0;
                        sprintf(s,"PCem v0.41 - %s - %s - %s",romsets[romset],clockspeeds[is386?2:(AT?1:0)][cpuspeed],(!mousecapture)?"Click to capture mouse":"Press CTRL-END to release mouse");
                        pitsec=0;
                        intcount=0;
                        wakeups=wokeups=0;
                        set_window_title(s);
                        intcount=pitcount=0;
                }
                done++;
/*                if ((at70hz && VGA)!=oldat70hz)
                {
                        oldat70hz=(at70hz && VGA);
                        if (oldat70hz) setrefresh(70); //install_int_ex(vsyncint,BPS_TO_TIMER(70));
                        else           setrefresh(60); //install_int_ex(vsyncint,BPS_TO_TIMER(60));
                        drawit=0;
                        done=0;
                }*/
//                printf("End of run!\n");
//        }
}

void fullspeed()
{
        cpuspeed2=cpuspeed;
        if (!atfullspeed)
        {
                printf("Set fullspeed - %i %i %i\n",is386,AT,cpuspeed2);
                if (is386) setpitclock(clocks[2][cpuspeed2][0]);
                else       setpitclock(clocks[AT?1:0][cpuspeed2][0]);
        }
        atfullspeed=1;
}

void speedchanged()
{
        if (atfullspeed)
        {
                cpuspeed2=cpuspeed;
                if (is386) setpitclock(clocks[2][cpuspeed2][0]);
                else       setpitclock(clocks[AT?1:0][cpuspeed2][0]);
        }
}

void closepc()
{
        dumpegaregs();
        dumpgus();
//        output=7;
//        setpitclock(clocks[0][0][0]);
//        while (1) runpc();
        saveconfig();
        savenvr();
        savedisc2();
        savedisc();
        dumpregs();
        closevideo();
}

/*int main()
{
        initpc();
        while (!key[KEY_F11])
        {
                runpc();
        }
        closepc();
        return 0;
}

END_OF_MAIN();*/

void loadconfig()
{
        char s[512];
        char *p;
        append_filename(s,pcempath,"pcem.cfg",511);
        set_config_file(s);
        ADLIB=get_config_int(NULL,"adlib",1);
        GAMEBLASTER=get_config_int(NULL,"gameblaster",0);
        FASTDISC=get_config_int(NULL,"fast_disc",1);
        romset=get_config_int(NULL,"romset",-1);
        gfxcard=get_config_int(NULL,"gfxcard",0);
        sbtype=get_config_int(NULL,"sndcard",SB2);
        cpuspeed=get_config_int(NULL,"cpu_speed",1);
        p=get_config_string(NULL,"disc_a","");
        if (p) strcpy(discfns[0],p);
        else   strcpy(discfns[0],"");
        p=get_config_string(NULL,"disc_b","");
        if (p) strcpy(discfns[1],p);
        else   strcpy(discfns[1],"");
        
        slowega=get_config_int(NULL,"slow_video",1);
//        cpuspeed=2;

        hdc[0].spt=get_config_int(NULL,"hdc_sectors",0);
        hdc[0].hpc=get_config_int(NULL,"hdc_heads",0);
        hdc[0].tracks=get_config_int(NULL,"hdc_cylinders",0);
        hdc[1].spt=get_config_int(NULL,"hdd_sectors",0);
        hdc[1].hpc=get_config_int(NULL,"hdd_heads",0);
        hdc[1].tracks=get_config_int(NULL,"hdd_cylinders",0);
}

void saveconfig()
{
        set_config_int(NULL,"adlib",ADLIB);
        set_config_int(NULL,"gameblaster",GAMEBLASTER);
        set_config_int(NULL,"fast_disc",FASTDISC);
        set_config_int(NULL,"romset",romset);
        set_config_int(NULL,"gfxcard",gfxcard);
        set_config_int(NULL,"sndcard",sbtype);
        set_config_int(NULL,"cpu_speed",cpuspeed);
        set_config_string(NULL,"disc_a",discfns[0]);
        set_config_string(NULL,"disc_b",discfns[1]);
        
        set_config_int(NULL,"hdc_sectors",hdc[0].spt);
        set_config_int(NULL,"hdc_heads",hdc[0].hpc);
        set_config_int(NULL,"hdc_cylinders",hdc[0].tracks);
        set_config_int(NULL,"hdd_sectors",hdc[1].spt);
        set_config_int(NULL,"hdd_heads",hdc[1].hpc);
        set_config_int(NULL,"hdd_cylinders",hdc[1].tracks);
}
