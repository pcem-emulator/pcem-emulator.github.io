#include <stdio.h>
#include <allegro.h>
#include <winalleg.h>
#include "ibm.h"
#include "x86.h"

int is486=1;

int cgate32;

/*This is needed for SimCity 2000 and Terminal Velocity. And UFO. And maybe Tube.
  No, what is _actually_ needed is to find out why these games try to access
  through null selectors in the first place.*/
/*v0.41 - not needed any more!*/
int breaknullsegs=0;

int intgatesize;

void taskswitch286(unsigned short seg, unsigned short *segdat);
void taskswitch386(unsigned short seg, unsigned short *segdat);

int notpresent=0;
int output;
void pmodeint(int num, int soft);
/*NOT PRESENT is INT 0B
  GPF is INT 0D*/

FILE *pclogf;
void x86abort(const char *format, ...)
{
   char buf[256];
   return;
   if (!pclogf)
      pclogf=fopen("pclog.txt","wt");
//return;
   va_list ap;
   va_start(ap, format);
   vsprintf(buf, format, ap);
   va_end(ap);
   fputs(buf,pclogf);
   fflush(pclogf);
   dumpregs();
   exit(-1);
}

unsigned char opcode2;

void x86gpf(char *s, unsigned short error)
{
        CS=oldcs;
        pc=oldpc;
        _cs.access=oldcpl<<5;
//        printf("GPF! - error %04X  %04X(%08X):%08X %02X %02X\n",error,CS,cs,pc,opcode,opcode2);
        if (output==3 && !error)
        {
                dumpregs();
                exit(-1);
        }
//        printf("Pre TR %04X\n",tr.seg);
/*        if (output==3)
        {
                dumpregs();
                exit(-1);
        }*/
//        output=3;
        pmodeint(0x0D,0);
//        printf("Post TR %04X\n",tr.seg);
//        printf("GPF %i %i\n",intgatesize,stack32);
        if (intgatesize==16)
        {
                if (stack32)
                {
                        writememw(ss,ESP-2,error);
                        ESP-=2;
                }
                else
                {
                        writememw(ss,((SP-2)&0xFFFF),error);
                        SP-=2;
                }
        }
        else
        {
                if (stack32)
                {
//                        if (output==3) printf("Writing error to %08X\n",ESP-4);
                        writememl(ss,ESP-4,error);
                        ESP-=4;
                }
                else
                {
                        writememl(ss,((SP-4)&0xFFFF),error);
                        SP-=4;
                }
        }
//        dumpregs();
//        exit(-1);
}
int ins;
unsigned short nperror;
void x86np()
{
//        printf("Not present! %04X  ",nperror);
        pmodeint(0x0B,0);
        if (stack32)
        {
                writememw(ss,ESP-2,nperror);
                ESP-=2;
        }
        else
        {
                writememw(ss,((SP-2)&0xFFFF),nperror);
                SP-=2;
        }
//        printf("%04X:%04X %i\n",CS,pc,ins);
/*        if (output)
        {
                dumpregs();
                exit(-1);
        }*/
//        if (!nperror) output=1;
//        output=1;
}
/*void x86abort(char *s)
{
        printf("ABORT : %s\n",s);
        dumpregs();
        exit(-1);
}*/

void loadseg(unsigned short seg, x86seg *s)
{
        unsigned short segdat[4];
        unsigned long addr;
        int dpl;
        if (msw&1 && !(eflags&VM_FLAG))
        {
//                intcount++;
                if (!(seg&~3))
                {
                        if (s==&_ss)
                        {
                                printf("SS selector = NULL!\n");
                                dumpregs();
                                exit(-1);
                        }
//                        if (s->base!=-1) printf("NEW! ");
                        s->seg=0;
                        if (breaknullsegs) s->base=0;
                        else               s->base=-1;
//                        printf("NULL selector %s%s%s%s %04X(%06X):%06X\n",(s==&_ds)?"DS":"",(s==&_es)?"ES":"",(s==&_fs)?"FS":"",(s==&_gs)?"GS":"",CS,cs,pc);
                        return;
                }
//                if (s==&_ss) printf("Load SS %04X\n",seg);
//                printf("Protected mode seg load!\n");
                addr=seg&~7;
                if (seg&4)
                {
                        if (addr>=ldt.limit) x86abort("Bigger than LDT limit %04X %04X\n",seg,ldt.limit);
                        addr+=ldt.base;
                }
                else
                {
                        if (addr>=gdt.limit) x86abort("Bigger than GDT limit %04X %04X\n",seg,gdt.limit);
                        addr+=gdt.base;
                }
                segdat[0]=readmemw(0,addr);
                segdat[1]=readmemw(0,addr+2);
                segdat[2]=readmemw(0,addr+4);
                segdat[3]=readmemw(0,addr+6);
//                printf("Seg %04X read from %06X  %04X %04X %04X %04X\n",seg,addr,segdat[0],segdat[1],segdat[2],segdat[3]);
                if (s==&_ss)
                {
                        if (segdat[3]&0x40) stack32=1;
                        else                stack32=0;
                }
                if ((s==&_cs))
                {
                        if (segdat[3]&0x40) use32=0x300;
                        else                use32=0;
                }
/*                if ((s==&_cs) && (segdat[3]&0x40))
                {
                        printf("32-bit CS! (generic loadseg)\n");
                        dumpregs();
                        exit(-1);
                }*/
//                printf("Data seg - %04X\n",segdat[2]);
                dpl=(segdat[2]>>13)&3;
                #if 0
                if (s==&_ss)
                {
                        if ((seg&3)!=CPL || dpl!=CPL)
                        {
                                printf("Invalid SS permiss\n");
                                x86gpf("Invalid SS permiss for %04X!\n",seg&0xFFFC);
                                return;
                        }
                        switch ((segdat[2]>>8)&0x1F)
                        {
                                case 0x12: case 0x13: case 0x16: case 0x17: /*r/w*/
                                break;
                                default:
                                printf("Invalid SS type\n");
                                x86gpf("Invalid SS segment type for %04X!\n",seg&0xFFFC);
                                return;
                        }
                }
                else if (s!=&_cs)
                {
                        switch ((segdat[2]>>8)&0x1F)
                        {
                                case 0x10: case 0x11: case 0x12: case 0x13: /*Data segments*/
                                case 0x14: case 0x15: case 0x16: case 0x17:
                                case 0x1A: case 0x1B: /*Readable non-conforming code*/
                                if ((seg&3)>dpl || (CS&3)>dpl)
                                {
                                        printf("Data seg fail - %04X:%08X %04X %i %04X\n",CS,pc,seg,dpl,segdat[2]);
                                        x86gpf("Data segment load - level too low!\n",seg&0xFFFC);
                                        return;
                                }
                                break;
                                case 0x1E: case 0x1F: /*Readable conforming code*/
                                break;
                                default:
                                printf("Invalid segment type for %04X! %04X\n",seg&0xFFFC,segdat[2]);
                                x86gpf("Invalid segment type for %04X!\n",seg&0xFFFC);
                                return;
                        }
                }
                else if (s==&_cs)
                {
                }
                #endif
//                }
//                if (!(segdat[2]&0x8000)) x86abort("Data segment not present!\n");
                if (!(segdat[2]&0x800) || !(segdat[2]&0x400))
                {
                        if (!(segdat[2]&0x8000))
                        {
                                notpresent=1;
                                nperror=seg&0xFFFC;
                                return;
                        }
                        s->seg=seg;
                        s->limit=segdat[0];
                        s->base=segdat[1];
                        s->base|=((segdat[2]&0xFF)<<16);
                        if (is386) s->base|=((segdat[3]>>8)<<24);
                        s->access=segdat[2]>>8;
//                        if (s==&_es && s->base>0x180000) s->base=0x180000;
                }
//                printf("base=%06X limit=%04X access=%02X  %06X  %04X %04X %04X  %04X\n",s->base,s->limit,s->access,addr,segdat[0],segdat[1],segdat[2],seg);
//                dumpregs();
//                exit(-1);
        }
        else
        {
                s->base=seg<<4;
                s->limit=0xFFFF;
                s->seg=seg;
                if (eflags&VM_FLAG) s->access=3<<5;
                else                s->access=0<<5;
                use32=0;
                if (s==&_ss) stack32=0;
/*                if (s==&_ds)
                {
                        printf("DS! %04X %06X %04X:%04X\n",DS,ds,CS,pc);
                }*/
        }
}

void loadcs(unsigned short seg)
{
        unsigned short segdat[4];
        unsigned long addr;
        int count;
        unsigned short oldss,oldsp;
        if (msw&1 && !(eflags&VM_FLAG))
        {
//                intcount++;
//                flushmmucache();
//                printf("Load CS %04X\n",seg);
                if (!(seg&~3))
                {
                        printf("Trying to load CS with NULL selector!\n");
                        dumpregs();
                        exit(-1);
                }
//                printf("Protected mode CS load! %04X\n",seg);
                addr=seg&~7;
                if (seg&4)
                {
                        if (addr>=ldt.limit) x86abort("Bigger than LDT limit %04X %04X CS\n",seg,ldt.limit);
                        addr+=ldt.base;
                }
                else
                {
                        if (addr>=gdt.limit) x86abort("Bigger than GDT limit %04X %04X CS\n",seg,gdt.limit);
                        addr+=gdt.base;
                }
                segdat[0]=readmemw(0,addr);
                segdat[1]=readmemw(0,addr+2);
                segdat[2]=readmemw(0,addr+4);
                segdat[3]=readmemw(0,addr+6);
//                if (optype==JMP) printf("Code seg - %04X - %04X %04X %04X %04X\n",seg,segdat[0],segdat[1],segdat[2],segdat[3]);
//                if (!(segdat[2]&0x8000)) x86abort("Code segment not present!\n");
                if (segdat[2]&0x1000)
                {
                        if (segdat[3]&0x40) use32=0x300;
                        else                use32=0;
                        CS=seg;
                        _cs.limit=segdat[0];
                        _cs.base=segdat[1];
                        _cs.base|=((segdat[2]&0xFF)<<16);
                        if (is386) _cs.base|=((segdat[3]>>8)<<24);
                        _cs.access=segdat[2]>>8;
//                        if (output==3) pclog("Load CS %08X\n",_cs.base);
//                        CS=(CS&0xFFFC)|((_cs.access>>5)&3);
                        if (!(segdat[2]&0x8000))
                        {
                                notpresent=1;
                                nperror=seg&0xFFFC;
                                return;
                        }
                }
                else
                {
                        if (!(segdat[2]&0x8000))
                        {
                                notpresent=1;
                                nperror=seg&0xFFFC;
                                return;
                        }
                        switch (segdat[2]&0xF00)
                        {
                                case 0x400: /*Call gate*/
                                count=segdat[2]&31;
                                if (count)
                                {
                                        printf("Call gate - copy %i words\n",count);
                                        dumpregs();
                                        exit(-1);
                                }
//                                output=1;
//                                printf("Call gate! %04X:%04X  Loading code seg %04X\n",SS,SP,segdat[1]);
//                                if (output) { dumpregs(); exit(-1); }
//                                if (SP==0x28F0) output=1;
                                CS&=~3;
                                loadseg(segdat[1],&_cs);
/*                                if (CPL<oldcs)
                                {
                                        printf("Changing stack!\n");
                                        if (stack32)
                                        {
                                                printf("CPL<oldcs loadcs stack32!\n");
                                                dumpregs();
                                                exit(-1);
                                        }
                                        count=segdat[2]&31;
                                        if (count&31)
                                        {
                                                printf("Call gate - copy %i words\n",count);
                                                dumpregs();
                                                exit(-1);
                                        }
                                        oldss=SS;
                                        oldsp=SP;

                                        if (tr.access&8)
                                        {
                                                addr=4+tr.base;
                                                loadseg(readmemw(0,addr+4),&_ss);
                                                ESP=readmeml(0,addr);
                                        }
                                        else
                                        {
                                                addr=2+tr.base;
                                                loadseg(readmemw(0,addr+2),&_ss);
                                                SP=readmemw(0,addr);
                                        }
//                                        addr=2+((CS&3)<<2)+tr.base;

//                                        loadseg(readmemw(0,addr+2),&_ss);
//                                        SP=readmemw(0,addr);

                                        writememw(ss,((SP-2)&0xFFFF),oldss);
                                        writememw(ss,((SP-4)&0xFFFF),oldsp);
                                        SP-=4;
                                }
                                printf("Completed jump\n");*/
                                pc=segdat[0];
                                return;
                                case 0x900: /*386 Task gate*/
//                                case 0xB00: /*386 Busy task gate*/
//                                if (optype==JMP) printf("Task switch!\n");
                                taskswitch386(seg,segdat);
                                return;

                                default:
                                printf("Bad CS %02X %02X %i special descriptor %03X %04X\n",opcode,rmdat,optype,segdat[2]&0xF00,seg);
                                dumpregs();
                                exit(-1);
                        }
                }
//                printf("CS = %04X base=%06X limit=%04X access=%02X  %04X\n",CS,cs,_cs.limit,_cs.access,addr);
//                dumpregs();
//                exit(-1);
        }
        else
        {
                _cs.base=seg<<4;
                _cs.limit=0xFFFF;
                CS=seg;
                if (eflags&VM_FLAG) _cs.access=3<<5;
                else                _cs.access=0<<5;
        }
}


void loadcscall(unsigned short seg)
{
        unsigned short segdat[4];
        unsigned long addr;
        int count;
        unsigned short oldcs=CPL;
        unsigned long oldss,oldsp;
        if (msw&1 && !(eflags&VM_FLAG))
        {
                flushmmucache();
///                printf("Protected mode CS load! %04X\n",seg);
                if (!(seg&~3))
                {
                        printf("Trying to load CS with NULL selector!\n");
                        dumpregs();
                        exit(-1);
                }
                addr=seg&~7;
                if (seg&4)
                {
                        if (addr>=ldt.limit) x86abort("Bigger than LDT limit %04X %04X CSC\n",seg,gdt.limit);
                        addr+=ldt.base;
                }
                else
                {
                        if (addr>=gdt.limit) x86abort("Bigger than GDT limit %04X %04X CSC\n",seg,gdt.limit);
                        addr+=gdt.base;
                }
                segdat[0]=readmemw(0,addr);
                segdat[1]=readmemw(0,addr+2);
                segdat[2]=readmemw(0,addr+4);
                segdat[3]=readmemw(0,addr+6);
//                printf("Code seg call - %04X - %04X %04X %04X\n",seg,segdat[0],segdat[1],segdat[2]);
                if (segdat[2]&0x1000)
                {
                        if (segdat[3]&0x40) use32=0x300;
                        else                use32=0;
                        CS=seg;
                        _cs.limit=segdat[0];
                        _cs.base=segdat[1];
                        _cs.base|=((segdat[2]&0xFF)<<16);
                        if (is386) _cs.base|=((segdat[3]>>8)<<24);
                        _cs.access=segdat[2]>>8;
                        if (!(segdat[2]&0x8000))
                        {
                                notpresent=1;
                                nperror=seg&0xFFFC;
                                return;
                        }
                }
                else
                {
                        switch (segdat[2]&0xF00)
                        {
                                case 0x400: /*Call gate*/
                                if (!(segdat[2]&0x8000))
                                {
                                        notpresent=1;
                                        nperror=seg&0xFFFC;
                                        return;
                                }
                                CS&=~3;
                                loadseg(segdat[1],&_cs);
                                if (CPL<oldcs)
                                {
                                        if (stack32)
                                        {
                                                printf("CPL<oldcs loadcs stack32!\n");
                                                dumpregs();
                                                exit(-1);
                                        }
                                        count=segdat[2]&31;
                                        if (count&31)
                                        {
                                                printf("Call gate - copy %i words\n",count);
                                                dumpregs();
                                                exit(-1);
                                        }
                                        oldss=SS;
                                        oldsp=SP;

                                        if (tr.access&8)
                                        {
                                                //printf("Loading SS - %04X %04X %04X\n",readmemw(0,addr+4),readmeml(0,addr),CS);
                                                addr=4+tr.base;
//                                                printf("16-bit stack %08X\n",addr);
                                                loadseg(readmemw(0,addr+4),&_ss);
                                                ESP=readmeml(0,addr);
                                                //                        printf("Stack segment %08X\n",readmeml(0,addr+4));
                                        }
                                        else
                                        {
                                                //printf("Loading SS - %04X %04X %04X\n",readmemw(0,addr+2),readmemw(0,addr),CS);
//                                                printf("32-bit stack %08X\n",addr);
                                                addr=2+tr.base;
                                                loadseg(readmemw(0,addr+2),&_ss);
                                                SP=readmemw(0,addr);
                                                //                        printf("16Stack segment %04X\n",readmemw(0,addr+2));
                                        }
//                                        addr=2+((CS&3)<<2)+tr.base;

//                                        loadseg(readmemw(0,addr+2),&_ss);
//                                        SP=readmemw(0,addr);

                                        writememw(ss,((SP-2)&0xFFFF),oldss);
                                        writememw(ss,((SP-4)&0xFFFF),oldsp);
                                        SP-=4;
                                }
                                pc=segdat[0];
//                                printf("Now %04X:%04X\n",CS,pc);
                                break;

                                case 0x900: /*386 Task gate*/
//                                case 0xB00: /*386 Busy task gate*/
//                                if (optype==JMP) printf("Task switch!\n");
                                taskswitch386(seg,segdat);
                                return;

                                case 0xC00: /*386 Call gate*/
                                if (!(segdat[2]&0x8000))
                                {
                                        notpresent=1;
                                        nperror=seg&0xFFFC;
                                        return;
                                }
                                cgate32=1;
                                CS&=~3;
                                loadseg(segdat[1],&_cs);
                                if (CPL<oldcs)
                                {
/*                                        if (stack32)
                                        {
                                                printf("CPL<oldcs loadcs stack32!\n");
                                                dumpregs();
                                                exit(-1);
                                        }*/
                                        count=segdat[2]&31;
                                        if (count&31)
                                        {
                                                printf("Call gate - copy %i words\n",count);
                                                dumpregs();
                                                exit(-1);
                                        }
                                        oldss=SS;
                                        oldsp=ESP;

                                        if (tr.access&8)
                                        {
                                                //printf("Loading SS - %04X %04X %04X\n",readmemw(0,addr+4),readmeml(0,addr),CS);
                                                addr=4+tr.base;
//                                                printf("32-bit 32 stack %08X\n",addr);
                                                loadseg(readmemw(0,addr+4),&_ss);
                                                ESP=readmeml(0,addr);
//                                                printf("New stack %04X:%08X\n",ss,ESP);

                                                //                        printf("Stack segment %08X\n",readmeml(0,addr+4));
                                        }
                                        else
                                        {
                                                //printf("Loading SS - %04X %04X %04X\n",readmemw(0,addr+2),readmemw(0,addr),CS);
                                                addr=2+tr.base;
//                                                printf("16-bit 32 stack %08X\n",addr);
                                                loadseg(readmemw(0,addr+2),&_ss);
                                                SP=readmemw(0,addr);
                                                //                        printf("16Stack segment %04X\n",readmemw(0,addr+2));
                                        }
//                                        addr=2+((CS&3)<<2)+tr.base;

//                                        loadseg(readmemw(0,addr+2),&_ss);
//                                        SP=readmemw(0,addr);

                                        if (stack32)
                                        {
                                                writememl(ss,ESP-4,oldss);
                                                writememl(ss,ESP-8,oldsp);
                                                ESP-=8;
                                        }
                                        else
                                        {
                                                writememl(ss,((SP-4)&0xFFFF),oldss);
                                                writememl(ss,((SP-8)&0xFFFF),oldsp);
                                                SP-=8;
                                        }
                                }
                                pc=segdat[0]|(segdat[3]<<16);
//                                printf("Now %04X:%04X\n",CS,pc);
                                break;

                                default:
                                printf("Bad CALL special descriptor %03X\n",segdat[2]&0xF00);
                                dumpregs();
                                exit(-1);
                        }
                }
//                printf("CS = %04X base=%06X limit=%04X access=%02X  %04X\n",CS,cs,_cs.limit,_cs.access,addr);
//                dumpregs();
//                exit(-1);
        }
        else
        {
                _cs.base=seg<<4;
                _cs.limit=0xFFFF;
                CS=seg;
                if (eflags&VM_FLAG) _cs.access=3<<5;
                else                _cs.access=0<<5;
        }
}

void pmodeint(int num, int soft)
{
        unsigned short segdat[4];
        unsigned long addr;
        int dpl;
        unsigned short temp[5];
        unsigned short oldcs=CPL,oldcs2;
        unsigned long oldss,oldsp;
        unsigned char oldaccess;
        int v86int=eflags&VM_FLAG;
//        pclog("Pmode int %02X %i %04X:%08X\n",num,soft,CS,pc);
        if (eflags&VM_FLAG && IOPL!=3 && soft)
        {
                printf("V86 banned int!\n");
                dumpregs();
                exit(-1);
        }
        flushmmucache();
//        printf("PMODE INT %02X %i %04X(%06X):%04X %04X\n",num,soft,CS,cs,pc,AX);
//        if (CS==0x170 && num==0x10 && AX==0x354 && !output) output=1;
/*        if (output)
        {
                output++;
                if (output==6)
                {
                        dumpregs();
                        exit(-1);
                }
        }*/
//        if (output) printf("Tracking!\n");
        addr=(num<<3);
//        if (eflags&VM_FLAG) printf("INT addr %02X %03X\n",num,addr);
        if (addr>=idt.limit)
        {
                if (num==8)
                {
                        /*Triple fault - reset!*/
//                        printf("Triple fault!\n");
                        softresetx86();
                }
                else if (num==0xD)
                {
//                        printf("Double fault!\n");
                        pmodeint(8,0);
                }
                else
                {
                        pclog("INT out of range\n");
                        x86gpf(NULL,(num*8)+2+(soft)?0:1);
                }
//                printf("IDT out of limit - reset?\n");
                return;
//                dumpregs();
//                exit(-1);
        }
        addr+=idt.base;
//        printf("%08X %08X\n",addr,idt.base);
        segdat[0]=readmemw(0,addr);
        segdat[1]=readmemw(2,addr);
        segdat[2]=readmemw(4,addr);
        segdat[3]=readmemw(6,addr);
        dpl=(segdat[2]>>13)&3;
//        if (num==0xD) printf("INT %02X - %04X %04X %04X %04X\n",num,segdat[0],segdat[1],segdat[2],segdat[3]);
/*        if (!(segdat[2]&0x8000))
        {
                printf("IDT descriptor not present!\n");
                notpresent=1;
                nperror=(num*8)|2;
                return;
        }*/
        if (!(segdat[2]&0x1F00))
        {
//                pclog("INT %02X - %04X %04X %04X %04X\n",num,segdat[0],segdat[1],segdat[2],segdat[3]);
//                pclog("Invalid INT segtype? %04X:%08X\n",CS,pc);
                if (num==0xD)
                {
                        pmodeint(8,0); /*Double fault*/
                        return;
                }
                if (num==0x8)
                {
/*                        printf("TRIPLE FAULT!!!!\n");
                        dumpregs();
                        exit(-1);*/
                        softresetx86(); /*Triple fault*/
                        return;
                }
                x86gpf(NULL,(num*8)+2);
                return;
        }
        if (dpl<CPL && soft)
        {
//                pclog("INT : DPL<CPL  %04X:%08X  %i %i\n",CS,pc,dpl,CPL);
                x86gpf(NULL,(num*8)+2);
                return;
        }
        if (eflags&VM_FLAG)
        {
                oldaccess=_cs.access;
                _cs.access=4;
                oldcs2=CS;
                CS=0;
//                printf("V86 INT! %02X %i %04X %04X(%06X):%04X %04X %04X\n",num,soft,AX,CS,cs,pc,SP,flags);
//                output=1;
                oldss=SS; oldsp=SP;
//                CS=0;
                eflags&=~VM_FLAG;
//                printf("Loading new stack...\n");
                if (tr.access&8)
                {
                        addr=4+tr.base;
                        loadseg(readmemw(0,addr+4),&_ss);
                        ESP=readmeml(0,addr);
//                        printf("Stack segment %08X\n",readmeml(0,addr+4));
                }
                else
                {
                        addr=2+tr.base;
                        loadseg(readmemw(0,addr+2),&_ss);
                        SP=readmemw(0,addr);
//                        printf("16Stack segment %04X\n",readmemw(0,addr+2));
                }
//                printf("IDT %08X\n",idt.base);
//                printf("Segdat (from %08X) : %04X %04X %04X %04X\n",addr,segdat[0],segdat[1],segdat[2],segdat[3]);
  //              if (output==3) printf("New stack %08X %04X\n",ESP,SS);
                if (stack32)
                {
                        writememl(ss,ESP-4,GS);
                        writememl(ss,ESP-8,FS);
                        writememl(ss,ESP-12,DS);
                        writememl(ss,ESP-16,ES);
                        ESP-=16;
                }
                else
                {
                        writememl(ss,(SP-4)&0xFFFF,GS);  //printf("Write %08X %04X\n",(SP-4)&0xFFFF,GS);
                        writememl(ss,(SP-8)&0xFFFF,FS);  //printf("Write %08X %04X\n",(SP-8)&0xFFFF,FS);
                        writememl(ss,(SP-12)&0xFFFF,DS); //printf("Write %08X %04X\n",(SP-12)&0xFFFF,DS);
                        writememl(ss,(SP-16)&0xFFFF,ES); //printf("Write %08X %04X\n",(SP-16)&0xFFFF,ES);
                        SP-=16;
                }
//                printf("Clearing segs!\n");
                loadseg(0,&_ds);
                loadseg(0,&_es);
                loadseg(0,&_fs);
                loadseg(0,&_gs);
                if (stack32)
                {
                        writememl(ss,ESP-4,oldss);
                        writememl(ss,ESP-8,oldsp);
                        ESP-=8;
                }
                else
                {
                        writememl(ss,(SP-4)&0xFFFF,oldss); //printf("Write %08X %04X\n",(SP-4)&0xFFFF,oldss);
                        writememl(ss,(SP-8)&0xFFFF,oldsp); //printf("Write %08X %04X\n",(SP-8)&0xFFFF,oldsp);
                        SP-=8;
                }
                eflags|=VM_FLAG;
                CS=oldcs2;
                _cs.access=oldaccess;
                oldcs=0;
//                printf("Finished with the first part\n");
        }
//        else
//           printf("PMODE int %02X\n",num);
        switch (segdat[2]&0xF00)
        {
                case 0x600: /*Interrupt gate*/
//                printf("16-bit interrupt gate\n");
                temp[0]=flags; temp[1]=CS; temp[2]=pc;
//                pclog("Writing %04X %04X %04X\n",temp[0],temp[1],temp[2]);
                flags&=~I_FLAG;
                eflags&=~VM_FLAG;
                CS=0;
                loadseg(segdat[1],&_cs);
                pc=segdat[0];
                if (!(_cs.access&4) && (CPL<oldcs))
                {
                        if (stack32)
                        {
                                printf("Interrupt gate stack32 CPL<oldcs!\n");
                                dumpregs();
                                exit(-1);
                        }
                        oldss=SS;
                        oldsp=SP;

                if (tr.access&8)
                {
//printf("Loading SS - %04X %04X %04X\n",readmemw(0,addr+4),readmeml(0,addr),CS);
                        addr=4+tr.base;
                        loadseg(readmemw(0,addr+4),&_ss);
                        ESP=readmeml(0,addr);
//                        printf("Stack segment %08X\n",readmeml(0,addr+4));
                }
                else
                {
//printf("Loading SS - %04X %04X %04X\n",readmemw(0,addr+2),readmemw(0,addr),CS);
                        addr=2+tr.base;
                        loadseg(readmemw(0,addr+2),&_ss);
                        SP=readmemw(0,addr);
//                        printf("16Stack segment %04X\n",readmemw(0,addr+2));
                }

                        writememw(ss,((SP-2)&0xFFFF),oldss);
                        writememw(ss,((SP-4)&0xFFFF),oldsp);
                        SP-=4;
//                        printf("New stack. again\n");
                }
                if (stack32)
                {
                        writememw(ss,ESP-2,temp[0]);
                        writememw(ss,ESP-4,temp[1]);
                        writememw(ss,ESP-6,temp[2]);
                        ESP-=6;
                }
                else
                {
                        writememw(ss,((SP-2)&0xFFFF),temp[0]);
                        writememw(ss,((SP-4)&0xFFFF),temp[1]);
                        writememw(ss,((SP-6)&0xFFFF),temp[2]);
                        SP-=6;
                }
//                if (output) printf("286 int over %06X\n",SP);
                intgatesize=16;
                return;
                                case 0x500: /*286 Task gate*/
//                                if (optype==JMP) printf("Task switch!\n");
                                loadcscall(segdat[1]);
//                                taskswitch286(0,segdat);
                                flags&=~I_FLAG;
                                eflags&=~VM_FLAG;
                                return;
                                case 0x900: /*386 Task gate*/
//                                case 0xB00: /*386 Busy Task gate*/
//                                if (optype==JMP) printf("Task switch!\n");
                                loadcscall(segdat[1]);
//                                taskswitch286(0,segdat);
                                flags&=~I_FLAG;
                                eflags&=~VM_FLAG;
                                return;

                case 0xE00: /*386 Interrupt gate*/
                case 0xF00: /*386 Trap gate*/
//                printf("32-bit interrupt gate  %02X  %i %i  %i %04X\n",_cs.access,CPL,oldcs,v86int,segdat[2]);
                temp[0]=eflags; temp[1]=flags; temp[2]=CS; temp[3]=pc>>16; temp[4]=pc;
                if ((segdat[2]&0xF00)==0xE00) flags&=~I_FLAG;
                eflags&=~VM_FLAG;
                CS=0;
                loadseg(segdat[1],&_cs);
                pc=segdat[0]|(segdat[3]<<16);
                if (!(_cs.access&4) && (CPL<oldcs) && !v86int)
                {
/*                        printf("Shit, need to load a new stack!\n");
                        dumpregs();
                        exit(-1);*/
                        oldss=SS;
                        oldsp=ESP;

                        addr=4+((CS&3)<<3)+tr.base;
                        loadseg(readmemw(0,addr+4),&_ss);
                        ESP=readmeml(0,addr);

                        if (stack32)
                        {
                                writememl(ss,ESP-4,oldss); //if (output) printf("Write SS %08X to %08X\n",ESP-4,oldss);
                                writememl(ss,ESP-8,oldsp); //if (output) printf("Write SP %08X to %08X\n",ESP-8,oldsp);
                                ESP-=8;
                        }
                        else
                        {
                                writememl(ss,((SP-4)&0xFFFF),oldss);
                                writememl(ss,((SP-8)&0xFFFF),oldsp);
                                SP-=8;
                        }
                }
                if (stack32)
                {
                        writememw(ss,ESP-2,temp[0]); //if (output) printf("Write %08X to %08X\n",ESP-2,temp[0]);
                        writememw(ss,ESP-4,temp[1]); //if (output) printf("Write %08X to %08X\n",ESP-4,temp[1]);
                        writememw(ss,ESP-6,0);       //if (output) printf("Write %08X to %08X\n",ESP-6,0);
                        writememw(ss,ESP-8,temp[2]); //if (output) printf("Write %08X to %08X\n",ESP-8,temp[2]);
                        writememw(ss,ESP-10,temp[3]);//if (output) printf("Write %08X to %08X\n",ESP-10,temp[3]);
                        writememw(ss,ESP-12,temp[4]);//if (output) printf("Write %08X to %08X\n",ESP-12,temp[4]);
//                        if (output==3) printf("Write PC to %08X\n",ESP-12);
                        ESP-=12;
                }
                else
                {
                        writememw(ss,((SP-2)&0xFFFF),temp[0]);
                        writememw(ss,((SP-4)&0xFFFF),temp[1]);
                        writememw(ss,((SP-6)&0xFFFF),0);
                        writememw(ss,((SP-8)&0xFFFF),temp[2]);
                        writememw(ss,((SP-10)&0xFFFF),temp[3]);
                        writememw(ss,((SP-12)&0xFFFF),temp[4]);
                        SP-=12;
                }
//                if (output) printf("New PC %08X\n",pc);
//                if (output) printf("386 int over %06X\n",SP);
                intgatesize=32;
                return;

                case 0x000: /*Invalid*/
                pclog("INT - invalid gate\n");
                x86gpf(NULL,(num*8)+2);
                return;
//                dumpregs();
//                exit(-1);
                default:
                printf("Bad int gate %03X  %04X %04X %04X %04X  %02X %i\n",segdat[2]&0xF00,segdat[0],segdat[1],segdat[2],segdat[3],num,soft);
                dumpregs();
                exit(-1);
        }
        printf("PMODEINT - how did we get here?\n");
        dumpregs();
        exit(-1);
}
int inint;
void pmodeiret()
{
        unsigned short nss,nsp;
        unsigned short oldcs=CPL;
        unsigned short tempw,tempw2;
        unsigned short tempflags,flagmask;
        if (is386 && (eflags&VM_FLAG))
        {
                if (IOPL!=3)
                {
                        printf("V86 IRET! IOPL!=3\n");
                        x86gpf(NULL,0);
                        return;
                }
                oxpc=pc;
                if (stack32)
                {
                        pc=readmemw(ss,ESP);
                        tempw2=readmemw(ss,ESP+2);
                        tempw=readmemw(ss,ESP+4);
                        flags=(flags&0x3000)|(tempw&0xCFFF);
                        ESP+=6;
                }
                else
                {
                        pc=readmemw(ss,SP);
                        tempw2=readmemw(ss,(SP+2)&0xFFFF);
                        tempw=readmemw(ss,((SP+4)&0xFFFF));
                        flags=(flags&0x3000)|(tempw&0xCFFF);
                        SP+=6;
                }
                loadcs(tempw2);
//                if (flags==0xF000) printf("VM86IRET - flags now F000 %04X(%06X):%04X %08X %08X %08X\n",CS,cs,pc,old8,old82,old83);
                return;
        }
        flushmmucache();
//        printf("Pmode IRET %04X:%04X ",CS,pc);
        inint=0;
        oxpc=pc;
        flagmask=0xFFFF;
        if (CPL) flagmask&=~0x3000;
        if (IOPL<CPL) flagmask&=~0x200;
        //pclog("IRET %i %i %04X\n",CPL,IOPL,flagmask);
        if (stack32)
        {
                pc=readmemw(ss,ESP);
                tempw=readmemw(ss,ESP+2);
//                loadcs(readmemw(ss,ESP+2));
                tempflags=readmemw(ss,ESP+4);
                if (!is386) tempflags&=0xFFF;
                ESP+=6;
                flags=(flags&~flagmask)|(tempflags&flagmask);
        }
        else
        {
                pc=readmemw(ss,SP);
                tempw=readmemw(ss,((SP+2)&0xFFFF));
//                loadcs(readmemw(ss,((SP+2)&0xFFFF)));
                tempflags=readmemw(ss,((SP+4)&0xFFFF));
                if (!is386) tempflags&=0xFFF;
                SP+=6;
                flags=(flags&~flagmask)|(tempflags&flagmask);
        }
        //pclog("Returned to %04X:%08X %04X %04X\n",CS,pc,flags,tempflags);
        loadcs(tempw);
        if (CPL>oldcs) /*Return to outer level*/
        {
                if (stack32)
                {
                        printf("IRET to outer level! %04X stack32\n",oldcs);
                        dumpregs();
                        exit(-1);
                }
                nsp=readmemw(ss,SP);
                nss=readmemw(ss,((SP+2)&0xFFFF));
//                if (!nss) printf("SP NULL when IRET\n");
//                printf("SS %04X SP %04X\n",nss,nsp);
                loadseg(nss,&_ss);
                SP=nsp;
                if (CPL>((_ds.access>>5)&3))
                {
                        _ds.seg=0;
                        _ds.base=-1;
                }
                if (CPL>((_es.access>>5)&3))
                {
                        _es.seg=0;
                        _es.base=-1;
                }
//                dumpregs();
//                exit(-1);
        }
//        if (output) printf("16-bit CS %04X %06X\n",CS,cs);
//        printf("%04X:%04X %04X\n",CS,pc,flags);
}
void pmodeiretd()
{
        unsigned long nesp;
        unsigned short nss,nsp;
        unsigned short oldcs=CPL;
        unsigned short tempw,tempw2;
        unsigned short tempflags,flagmask;
        if (is386 && (eflags&VM_FLAG))
        {
                if (IOPL!=3)
                {
                        printf("V86 IRETD - IOPL!=3\n");
                        x86gpf(NULL,0);
                        return;
                }
                printf("V86 IRETD!\n");
                dumpregs();
                exit(-1);
        }
//        printf("Pmode IRET %04X:%04X ",CS,pc);
        inint=0;
        oxpc=pc;
        flagmask=0xFFFF;
        if (CPL) flagmask&=~0x3000;
        if (IOPL<CPL) flagmask&=~0x200;
        if (stack32)
        {
//                if (output==3) printf("PC reading from %08X\n",ESP);
                pc=readmeml(ss,ESP);
                tempw=readmemw(ss,ESP+4);
//                loadcs(readmemw(ss,ESP+4));
                tempflags=readmemw(ss,ESP+8);
                eflags=readmemw(ss,ESP+10)&3;
                ESP+=12;
        }
        else
        {
                pc=readmeml(ss,SP);
                tempw=readmemw(ss,((SP+4)&0xFFFF));
//                loadcs(readmemw(ss,((SP+4)&0xFFFF)));
                tempflags=readmemw(ss,((SP+8)&0xFFFF));
                eflags=readmemw(ss,((SP+10)&0xFFFF))&3;
                SP+=12;
        }
        flags=(flags&~flagmask)|(tempflags&flagmask);
//        pclog("DReturned to %04X:%08X %04X %04X\n",CS,pc,flags,tempflags);
        loadcs(tempw);
        if (is386 && (eflags&VM_FLAG))
        {
//                printf("V86 iretd! %04X %06X\n",oldcs,oldpc);
                //output=1;
//                timetolive=1500;
                if (stack32)
                {
                        nesp=readmeml(ss,ESP);
                        nss=readmeml(ss,ESP+4);
                        loadseg(readmemw(ss,ESP+8),&_es);
                        loadseg(readmemw(ss,ESP+12),&_ds);
                        loadseg(readmemw(ss,ESP+16),&_fs);
                        loadseg(readmemw(ss,ESP+20),&_gs);
                        ESP+=24;
//                        if (output==3) printf("Final ESP %08X\n",ESP);
                        ESP=nesp;
                        loadseg(nss,&_ss);
                }
                else
                {
                        nesp=readmeml(ss,SP);
                        nss=readmeml(ss,(SP+4)&0xFFFF);
                        loadseg(readmemw(ss,(SP+8)&0xFFFF),&_es);
                        loadseg(readmemw(ss,(SP+12)&0xFFFF),&_ds); //printf("Read DS from %04X\n",SP+12);
                        loadseg(readmemw(ss,(SP+16)&0xFFFF),&_fs);
                        loadseg(readmemw(ss,(SP+20)&0xFFFF),&_gs);
                        SP=nesp;
                        loadseg(nss,&_ss);
                }
                use32=0;
                return;
        }
        flushmmucache();
/*        else if (flags&NT_FLAG)
        {
                tempw=readmemw(0,tr.base);
                printf("Nested task return 32!\n");
                printf("Backlink %04X\n",tempw);
                dumpregs();
                exit(-1);
        }*/
//        if (output) printf("32-bit CS %04X %06X\n",CS,cs);
        if (CPL>oldcs) /*Return to outer level*/
        {
//                printf("IRETD to outer level! %04X\n",oldcs);
//                dumpregs();
//                exit(-1);
                if (stack32)
                {
                        nesp=readmeml(ss,ESP);
                        nss=readmemw(ss,ESP+4);
                }
                else
                {
                        nesp=readmeml(ss,SP);
                        nss=readmemw(ss,((SP+4)&0xFFFF));
                }
                loadseg(nss,&_ss);
                ESP=nesp;
                if (CPL>((_ds.access>>5)&3))
                {
                        _ds.seg=0;
                        _ds.base=-1;
                }
                if (CPL>((_es.access>>5)&3))
                {
                        _es.seg=0;
                        _es.base=-1;
                }
        }
//        printf("%04X:%04X %04X\n",CS,pc,flags);
}

void taskswitch286(unsigned short seg, unsigned short *segdat)
{
        unsigned long base;
        unsigned long limit;
        int x386;
        unsigned long templ;
        int c;

	unsigned long new_cr3=0;
	unsigned short new_ax,new_bx,new_cx,new_dx,new_sp,new_bp,new_si,new_di;
	unsigned short new_es,new_cs,new_ss,new_ds;
	unsigned short new_ldt,new_ip,new_flags;

	unsigned short oldflags;

        base=segdat[1]|((segdat[2]&0xFF)<<16)|((segdat[3]>>8)<<24);
        limit=segdat[0]|((segdat[3]&0xF)<<16);
        printf("286 Task switch!\n");
        printf("TSS %04X base %08X limit %04X\n",seg,base,limit);
        printf("%04X %04X %04X %04X\n",segdat[0],segdat[1],segdat[2],segdat[3]);

/*        for (c=0;c<0xEC;c+=4)
        {
                printf("%08X : %08X\n",base+c,readmeml(base,c));
        }

        printf("\nBefore :\n");
        dumpregs();*/

                new_ip=readmemw(base,14);
                new_flags=readmemw(base,16);
                new_ax=readmemw(base,18);
                new_cx=readmemw(base,20);
                new_dx=readmemw(base,22);
                new_bx=readmemw(base,24);
                new_sp=readmemw(base,26);
                new_bp=readmemw(base,28);
                new_si=readmemw(base,30);
                new_di=readmemw(base,32);

                new_es=readmemw(base,34);
                new_cs=readmemw(base,36);
                new_ss=readmemw(base,38);
                new_ds=readmemw(base,40);
                new_ldt=readmemw(base,42);
                printf("New stack - %04X:%04X\n",new_ss,new_sp);

        if (optype==JMP || optype==IRET)
        {
                tr.access&=~2; /*Clear busy*/
//                printf("Cleared busy bit\n");
                writememb((tr.seg&~7)+gdt.base+5,tr.access);
        }

        oldflags=flags;
        if (optype==IRET) oldflags&=~NT_FLAG;

                writememw(tr.base,14,oxpc);
                writememw(tr.base,16,oldflags);
                writememw(tr.base,18,AX);
                writememw(tr.base,20,CX);
                writememw(tr.base,22,DX);
                writememw(tr.base,24,BX);
                writememw(tr.base,26,SP);
                writememw(tr.base,28,BP);
                writememw(tr.base,30,SI);
                writememw(tr.base,32,DI);

                writememw(tr.base,34,ES);
                writememw(tr.base,36,CS);
                writememw(tr.base,38,SS);
                writememw(tr.base,40,DS);
                writememw(tr.base,42,ldt.seg);

        if (optype==CALL)
           writememw(base,0,tr.seg);

        if (optype==JMP || optype==CALL)
        {
                segdat[2]|=0x200; /*Set busy*/
//                printf("Set busy bit\n");
                writememw(gdt.base,(seg&~7)+4,segdat[2]);
        }

        if ((seg&~7)==(tr.seg&~7))
        {
                printf("Crap TS\n");
                dumpregs();
                exit(-1);
/*                new_eip=pc;
                new_cs=CS;
                new_ds=DS;
                new_es=ES;
                new_fs=FS;
                new_gs=GS;
                new_ss=SS;*/
        }
        else
        {
//                printf("Good TS\n");
                pc=new_ip;
                flags=new_flags;
                AX=new_ax;
                BX=new_bx;
                CX=new_cx;
                DX=new_dx;
                BP=new_bp;
                SP=new_sp;
                SI=new_si;
                DI=new_di;
                ldt.seg=new_ldt;
//                printf("LDT %04X\n",new_ldt);
                if (new_ldt&~7)
                {
                        templ=(new_ldt&~7)+gdt.base;
                        ldt.limit=readmemw(0,templ);
                        ldt.base=(readmemw(0,templ+2))|(readmemb(templ+4)<<16)|(readmemb(templ+7)<<24);
//                        printf("LDT limit %04X base %08X\n",ldt.limit,ldt.base);
                }
        }

//        printf("CS %04X\n",new_cs);
        loadseg(new_cs,&_cs);
//        printf("DS %04X\n",new_ds);
        loadseg(new_ds,&_ds);
//        printf("ES %04X\n",new_es);
        loadseg(new_es,&_es);
//        printf("SS %04X\n",new_ss);
        loadseg(new_ss,&_ss);

        tr.seg=seg;
        tr.base=base;
        tr.limit=limit;
        tr.access=segdat[2]>>8;

/*        printf("\nAfter :\n");
        dumpregs();
        exit(-1);*/
}

void taskswitch386(unsigned short seg, unsigned short *segdat)
{
        unsigned long base;
        unsigned long limit;
        int x386;
        unsigned long templ;
        int c;

	unsigned long new_cr3=0;
	unsigned long new_eax,new_ebx,new_ecx,new_edx,new_esp,new_ebp,new_esi,new_edi;
	unsigned long new_es,new_cs,new_ss,new_ds,new_fs,new_gs;
	unsigned long new_ldt,new_eip,new_eflags;
	
	unsigned long oldeflags;

        base=segdat[1]|((segdat[2]&0xFF)<<16)|((segdat[3]>>8)<<24);
        limit=segdat[0]|((segdat[3]&0xF)<<16);
        x386=segdat[2]&0x800;
//        printf("386 Task switch!\n");
//        printf("TSS %04X base %08X limit %04X %s\n",seg,base,limit,(x386)?"386":"286");
        
/*        for (c=0;c<0xEC;c+=4)
        {
                printf("%08X : %08X\n",base+c,readmeml(base,c));
        }
        
        printf("\nBefore :\n");
        dumpregs();*/
        
        if (x386)
        {
                new_cr3=readmeml(base,0x1C);
                new_eip=readmeml(base,0x20);
                new_eflags=readmeml(base,0x24);
                new_eax=readmeml(base,0x28);
                new_ecx=readmeml(base,0x2C);
                new_edx=readmeml(base,0x30);
                new_ebx=readmeml(base,0x34);
                new_esp=readmeml(base,0x38);
                new_ebp=readmeml(base,0x3C);
                new_esi=readmeml(base,0x40);
                new_edi=readmeml(base,0x44);

                new_es=readmemw(base,0x48);
                new_cs=readmemw(base,0x4C);
//                printf("New CS %04X %08X+4C %08X\n",new_cs,base,base+0x4C);
                new_ss=readmemw(base,0x50);
                new_ds=readmemw(base,0x54);
                new_fs=readmemw(base,0x58);
                new_gs=readmemw(base,0x5C);
                new_ldt=readmemw(base,0x60);
//                printf("New stack - %04X:%08X %08X %08X\n",new_ss,new_esp,base+0x50,base+0x38);
        }
        else
        {
                printf("286 TSS!\n");
                dumpregs();
                exit(-1);
        }
        
        if (optype==JMP || optype==IRET)
        {
                tr.access&=~2; /*Clear busy*/
//                printf("Cleared busy bit\n");
                writememb((tr.seg&~7)+gdt.base+5,tr.access);
        }
        
        oldeflags=flags|(eflags<<16);
        if (optype==IRET) oldeflags&=~NT_FLAG;
        
        if (x386)
        {
                writememl(tr.base,0x1C,cr3);
                writememl(tr.base,0x20,oxpc);
                writememl(tr.base,0x24,oldeflags);
                writememl(tr.base,0x28,EAX);
                writememl(tr.base,0x2C,ECX);
                writememl(tr.base,0x30,EDX);
                writememl(tr.base,0x34,EBX);
                writememl(tr.base,0x38,ESP);
                writememl(tr.base,0x3C,EBP);
                writememl(tr.base,0x40,ESI);
                writememl(tr.base,0x44,EDI);

                writememl(tr.base,0x48,ES);
                writememl(tr.base,0x4C,CS);
                writememl(tr.base,0x50,SS);
                writememl(tr.base,0x54,DS);
                writememl(tr.base,0x58,FS);
                writememl(tr.base,0x5C,GS);
                writememl(tr.base,0x60,ldt.seg);
//                printf("Old stack - %04X:%08X %08X %08X\n",SS,ESP,tr.base+0x50,tr.base+0x38);
        }
        
        if (optype==CALL)
           writememl(base,0,tr.seg);

        if (optype==JMP || optype==CALL)
        {
                segdat[2]|=0x200; /*Set busy*/
//                printf("Set busy bit\n");
                writememw(gdt.base,(seg&~7)+4,segdat[2]);
        }
        
        if ((seg&~7)==(tr.seg&~7))
        {
//                printf("Crap TS\n");
                new_eip=pc;
                new_cs=CS;
                new_ds=DS;
                new_es=ES;
                new_fs=FS;
                new_gs=GS;
                new_ss=SS;
        }
        else
        {
//                printf("Good TS\n");
                cr3=new_cr3&~0xFFF;
                flushmmucache();
                pc=new_eip;
                flags=new_eflags&0xFFFF;
                eflags=new_eflags>>16;
                EAX=new_eax;
                EBX=new_ebx;
                ECX=new_ecx;
                EDX=new_edx;
                EBP=new_ebp;
                ESP=new_esp;
                ESI=new_esi;
                EDI=new_edi;
                ldt.seg=new_ldt;
//                printf("LDT %04X\n",new_ldt);
                if (new_ldt&~7)
                {
                        templ=(new_ldt&~7)+gdt.base;
                        ldt.limit=readmemw(0,templ);
                        ldt.base=(readmemw(0,templ+2))|(readmemb(templ+4)<<16)|(readmemb(templ+7)<<24);
//                        printf("LDT limit %04X base %08X\n",ldt.limit,ldt.base);
                }
        }
        
//        printf("CS %04X\n",new_cs);
        loadseg(new_cs,&_cs);
//        printf("DS %04X\n",new_ds);
        loadseg(new_ds,&_ds);
//        printf("ES %04X\n",new_es);
        loadseg(new_es,&_es);
//        printf("FS %04X\n",new_fs);
        loadseg(new_fs,&_fs);
//        printf("GS %04X\n",new_gs);
        loadseg(new_gs,&_gs);
//        printf("SS %04X\n",new_ss);
        loadseg(new_ss,&_ss);

        tr.seg=seg;
        tr.base=base;
        tr.limit=limit;
        tr.access=segdat[2]>>8;
        
/*        printf("\nAfter :\n");
        dumpregs();
        exit(-1);*/
}
