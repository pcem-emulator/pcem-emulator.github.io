#include <stdio.h>
#include <allegro.h>
#include "ibm.h"

BITMAP *buffer,*vbuf;//,*vbuf2;
BITMAP *buffer32;
int speshul=0;

unsigned char fontdat[256][8];
unsigned char fontdatm[256][16];

float dispontime,dispofftime,disptime;
int svgaon;
unsigned char cgamode=1,cgastat,cgacol=7,ocgamode;
int linepos=0;
int frames=0;
int output;
unsigned char *vram,*ram;

int cgadispon=0;
int cgablink;

unsigned char port3de,port3dd,port3df;

unsigned char crtc[64],crtcreg;
unsigned char crtcmask[64]={0xFF,0xFF,0xFF,0xFF,0x7F,0x1F,0x7F,0x7F,0xF3,0x1F,0x7F,0x1F,0x3F,0xFF,0x3F,0xFF,0xFF,0xFF};
unsigned char charbuffer[256];
int crtcams[64]={0,0,0,0,0,0,0,0,0,1,1,1,1,1,1,1,1,1};
int nmi=0;

/*Amstrad PC1512*/
unsigned char amswrite=0xF,amsread=0;

void recalccgatimings()
{
        if (MDA) return;
        if (cgamode&1)
        {
                disptime=crtc[0]+1;
                dispontime=crtc[1];
        }
        else
        {
                disptime=(crtc[0]+1)<<1;
                dispontime=crtc[1]<<1;
        }
        dispofftime=disptime-dispontime;
//        printf("%i %f %f %f  %i %i\n",cgamode&1,disptime,dispontime,dispofftime,crtc[0],crtc[1]);
        dispontime*=CGACONST;
        dispofftime*=CGACONST;
//        printf("Timings - on %f off %f frame %f second %f\n",dispontime,dispofftime,(dispontime+dispofftime)*262.0,(dispontime+dispofftime)*262.0*59.92);
}

int xsize=656,ysize=200;
int vc,sc,vadj;
unsigned short ma,maback;
int vsynctime;
int displine=0;
int firstline=1000,lastline=0;
int con,coff,cursoron;

void pollcga()
{
        unsigned short ca=(crtc[15]|(crtc[14]<<8))&0x3FFF;
        int drawcursor;
        int x,c;
        int oldvc;
        unsigned char chr,attr;
        unsigned short dat,dat2,dat3,dat4;
        int cols[4];
        int col;
        int oldsc;
        if (!linepos)
        {
//                printf("Firstline %i Lastline %i Displine %i\n",firstline,lastline,displine);
                vidtime+=dispofftime;
                cgastat|=1;
                linepos=1;
                oldsc=sc;
                if ((crtc[8]&3)==3) sc=(sc<<1)&7;
                if (cgadispon)
                {
                        if (displine<firstline)
                        {
                                firstline=displine;
//                                printf("Firstline %i\n",firstline);
                        }
                        lastline=displine;
                        for (c=0;c<8;c++)
                        {
                                if ((cgamode&0x12)==0x12)
                                {
                                        buffer->line[displine][c]=0;
                                        if (cgamode&1) buffer->line[displine][c+(crtc[1]<<3)+8]=0;
                                        else           buffer->line[displine][c+(crtc[1]<<4)+8]=0;
                                }
                                else
                                {
                                        buffer->line[displine][c]=(cgacol&15)+16;
                                        if (cgamode&1) buffer->line[displine][c+(crtc[1]<<3)+8]=(cgacol&15)+16;
                                        else           buffer->line[displine][c+(crtc[1]<<4)+8]=(cgacol&15)+16;
                                }
                        }
//                        printf("X %i %i\n",c+(crtc[1]<<4)+8,c+(crtc[1]<<3)+8);
//                        printf("Drawing %i %i %i\n",displine,vc,sc);
                        if (cgamode&1)
                        {
                                for (x=0;x<crtc[1];x++)
                                {
                                        chr=charbuffer[x<<1];
                                        attr=charbuffer[(x<<1)+1];
                                        drawcursor=((ma==ca) && con && cursoron);
                                        if (cgamode&0x20)
                                        {
                                                cols[1]=(attr&15)+16;
                                                cols[0]=((attr>>4)&7)+16;
                                                if ((cgablink&16) && (attr&0x80) && !drawcursor) cols[1]=cols[0];
                                        }
                                        else
                                        {
                                                cols[1]=(attr&15)+16;
                                                cols[0]=(attr>>4)+16;
                                        }
                                        for (c=0;c<8;c++)
                                            buffer->line[displine][(x<<3)+c+8]=cols[(fontdat[chr][sc&7]&(1<<(c^7)))?1:0];
//                                        if (!((ma^(crtc[15]|(crtc[14]<<8)))&0x3FFF)) printf("Cursor match! %04X\n",ma);
                                        if (drawcursor)
                                        {
                                                for (c=0;c<8;c++)
                                                    buffer->line[displine][(x<<3)+c+8]^=15;
                                        }
                                        ma++;
                                }
                        }
                        else if (!(cgamode&2))
                        {
                                for (x=0;x<crtc[1];x++)
                                {
                                        chr=vram[((ma<<1)&0x3FFF)];
                                        attr=vram[(((ma<<1)+1)&0x3FFF)];
                                        drawcursor=((ma==ca) && con && cursoron);
                                        if (cgamode&0x20)
                                        {
                                                cols[1]=(attr&15)+16;
                                                cols[0]=((attr>>4)&7)+16;
                                                if ((cgablink&16) && (attr&0x80)) cols[1]=cols[0];
                                        }
                                        else
                                        {
                                                cols[1]=(attr&15)+16;
                                                cols[0]=(attr>>4)+16;
                                        }
                                        ma++;
                                        for (c=0;c<8;c++)
                                            buffer->line[displine][(x<<4)+(c<<1)+8]=buffer->line[displine][(x<<4)+(c<<1)+1+8]=cols[(fontdat[chr][sc&7]&(1<<(c^7)))?1:0];
                                        if (drawcursor)
                                        {
                                                for (c=0;c<16;c++)
                                                    buffer->line[displine][(x<<4)+c+8]^=15;
                                        }
                                }
                        }
                        else if (!(cgamode&16))
                        {
                                if (cgacol&32) col=4;
                                else           col=0;
                                if (cgacol&16) col|=8;
                                if (cgamode&4) col|=0x30;
                                cols[0]=(cgacol&15)|16;
                                cols[1]=col|1;
                                cols[2]=col|2;
                                cols[3]=col|3;
                                for (x=0;x<crtc[1];x++)
                                {
                                        dat=(vram[((ma<<1)&0x1FFF)+((sc&1)*0x2000)]<<8)|vram[((ma<<1)&0x1FFF)+((sc&1)*0x2000)+1];
                                        ma++;
                                        for (c=0;c<8;c++)
                                        {
                                                buffer->line[displine][(x<<4)+(c<<1)+8]=
                                                  buffer->line[displine][(x<<4)+(c<<1)+1+8]=cols[dat>>14];
                                                dat<<=2;
                                        }
                                }
                        }
                        else
                        {
                                if (AMSTRAD)
                                {
//                                        printf("AMSTRAD display! %02X %i\n",cgacol,crtc[1]);
                                        for (x=0;x<crtc[1];x++)
                                        {
                                                ca=((ma<<1)&0x1FFF)+((sc&1)*0x2000);
                                                dat=(vram[ca]<<8)|vram[ca+1];
                                                dat2=(vram[ca+0x10000]<<8)|vram[ca+0x10001];
                                                dat3=(vram[ca+0x20000]<<8)|vram[ca+0x20001];
                                                dat4=(vram[ca+0x30000]<<8)|vram[ca+0x30001];
//                                                printf("%04X %04X %04X %04X %04X\n",ca,dat,dat2,dat3,dat4);
                                                ma++;
                                                for (c=0;c<16;c++)
                                                {
                                                        buffer->line[displine][(x<<4)+c+8]=(((dat>>15)|((dat2>>15)<<1)|((dat3>>15)<<2)|((dat4>>15)<<3))&(cgacol&15))+16;
                                                        dat<<=1;
                                                        dat2<<=1;
                                                        dat3<<=1;
                                                        dat4<<=1;
                                                }
                                        }
                                }
                                else
                                {
                                        cols[0]=0; cols[1]=(cgacol&15)+16;
                                        for (x=0;x<crtc[1];x++)
                                        {
                                                dat=(vram[((ma<<1)&0x1FFF)+((sc&1)*0x2000)]<<8)|vram[((ma<<1)&0x1FFF)+((sc&1)*0x2000)+1];
                                                ma++;
                                                for (c=0;c<16;c++)
                                                {
                                                        buffer->line[displine][(x<<4)+c+8]=cols[dat>>15];
                                                        dat<<=1;
                                                }
                                        }
                                }
                        }
                }
                else
                {
                        cols[0]=((cgamode&0x12)==0x12)?0:(cgacol&15)+16;
                        if (cgamode&1) hline(buffer,0,displine,(crtc[1]<<3)+16,cols[0]);
                        else           hline(buffer,0,displine,(crtc[1]<<4)+16,cols[0]);
                }
                sc=oldsc;
                if ((vc==crtc[7] && !sc) || (AMSTRAD && vsynctime))
                {
                        cgastat|=8;
//                        printf("VSYNC on %i %i\n",vc,sc);
                }
                displine++;
                if (displine>=360) displine=0;
        }
        else
        {
                vidtime+=dispontime;
                if (AMSTRAD && (lastline-firstline)==199) cgadispon=0; /*Amstrad PC1512 always displays 200 lines, regardless of CRTC settings*/
                if (cgadispon) cgastat&=~1;
                linepos=0;
                if (vsynctime)
                {
                        vsynctime--;
                        if (!vsynctime)
                        {
                                cgastat&=~8;
//                                printf("VSYNC off %i %i\n",vc,sc);
                        }
                }
                if (sc==(crtc[11]&31) || ((crtc[8]&3)==3 && sc==((crtc[11]&31)>>1))) { con=0; coff=1; }
                if (vadj)
                {
                        sc++;
                        sc&=31;
                        ma=maback;
                        vadj--;
                        if (!vadj)
                        {
                                cgadispon=1;
                                ma=maback=(crtc[13]|(crtc[12]<<8))&0x3FFF;
                                sc=0;
//                                printf("Display on!\n");
                        }
                }
                else if (sc==crtc[9] || ((crtc[8]&3)==3 && sc==(crtc[9]>>1)))
                {
                        maback=ma;
//                        con=0;
//                        coff=0;
                        sc=0;
                        oldvc=vc;
                        vc++;
                        vc&=127;
//                        printf("VC %i %i %i %i  %i\n",vc,crtc[4],crtc[6],crtc[7],cgadispon);
                        if (vc==crtc[6] && !AMSTRAD) cgadispon=0; /*PC1512 ignores R6*/
//                        if (AMSTRAD && (lastline-firstline)==200) cgadispon=0; /*Amstrad PC1512 always displays 200 lines, regardless of CRTC settings*/
                        if ((oldvc==crtc[4] && !AMSTRAD) || (AMSTRAD && displine==32))
                        {
//                                printf("Display over at %i\n",displine);
                                vc=0;
                                vadj=crtc[5];
                                if (!vadj) cgadispon=1;
                                if (!vadj) ma=maback=(crtc[13]|(crtc[12]<<8))&0x3FFF;
                                if ((crtc[10]&0x60)==0x20) cursoron=0;
                                else                       cursoron=cgablink&16;
//                                printf("CRTC10 %02X %i\n",crtc[10],cursoron);
                        }
//                        if (AMSTRAD) printf("Line %i %i\n",displine,cgadispon);
                        if ((vc==crtc[7] && !AMSTRAD) || (AMSTRAD && displine>=262))
                        {
                                cgadispon=0;
                                displine=0;
                                vsynctime=(AMSTRAD)?46:(crtc[3]>>4)+1;
//                                printf("Vsynctime %i %02X\n",vsynctime,crtc[3]);
//                                cgastat|=8;
                                if (crtc[7])
                                {
//                                        printf("Lastline %i Firstline %i  %i\n",lastline,firstline,lastline-firstline);
                                        if (cgamode&1) x=(crtc[1]<<3)+16;
                                        else           x=(crtc[1]<<4)+16;
                                        if (x!=xsize || (lastline-firstline)!=ysize)
                                        {
                                                xsize=x;
                                                ysize=lastline-firstline;
//                                                printf("Resize to %i,%i - R1 %i\n",xsize,ysize,crtc[1]);
                                                if (xsize<64) xsize=656;
                                                if (ysize<32) ysize=200;
                                                updatewindowsize(xsize,(ysize<<1)+16);
                                        }
//                                        printf("Blit %i %i\n",firstline,lastline);
startblit();
                                        blit(buffer,vbuf,0,firstline-4,0,0,xsize,(lastline-firstline)+8+1);
                                        stretch_blit(vbuf,screen,0,0,xsize,(lastline-firstline)+8+1,0,0,xsize,((lastline-firstline)<<1)+16+2);
        if (readflash) rectfill(screen,600,8,632,14,0xFFFFFFFF);
        readflash=0;
endblit();
                                }
                                firstline=1000;
                                lastline=0;
                                cgablink++;
                        }
                }
                else
                {
                        sc++;
                        sc&=31;
                        ma=maback;
                }
                if ((sc==(crtc[10]&31) || ((crtc[8]&3)==3 && sc==((crtc[10]&31)>>1)))) con=1;
                if (cgadispon && (cgamode&1))
                {
                        for (x=0;x<(crtc[1]<<1);x++)
                            charbuffer[x]=vram[(((ma<<1)+x)&0x3FFF)];
                }
        }
}

extern int fullchange;
extern int changeframecount;
extern unsigned long vrammask;
void writecrtc(unsigned short addr, unsigned char val)
{
        unsigned char old;
        if (!(addr&1)) crtcreg=val&((VGA)?63:31);
        else
        {
                old=crtc[crtcreg];

                if (romset==ROM_PC200 && !(port3de&0x40) && crtcreg<=11) { if (port3de&0x80) {nmi=1;} port3dd=0x20|(crtcreg&0x1F); port3df=val; }
                else if (EGA)
                {
                        crtc[crtcreg]=val;
//                        pclog("Write CRTC R%02X %02X\n",crtcreg,val);
                }
                else if (!AMSTRADIO || crtcams[crtcreg])                crtc[crtcreg]=val&crtcmask[crtcreg];
                if (crtcreg==0x17 && SVGA) vrammask=(val&8)?0xFFFFF:0x3FFFF;
                if (crtcreg==0x1E && TRIDENT) vrammask=(val&0x80)?0x1FFFFF:0x3FFFF;
//                /*if (crtcreg>=0x30) */printf("CRTC R%02X %02X\n",crtcreg,val);
//                printf("Write CRTC %i %02X %02X %04X:%04X %02X\n",crtcreg,val,cgastat,cs>>4,pc,port3de);
                if (old!=val)
                {
                        if (crtcreg<0xE || crtcreg>0x10)
                        {
                                fullchange=changeframecount;
                                if (EGA) recalcegatimings();
                                else     recalccgatimings();
                        }
                }
//                if (crtcreg==0x1F) printf("Write CRTC 1F %02X %04X:%04X\n",val,CS,pc);
        }
}

unsigned char readcrtc(unsigned short addr)
{
//        printf("Read %03X %04X:%04X\n",addr,CS,pc);
        if (!(addr&1)) return crtcreg;
        else           return crtc[crtcreg];
}

unsigned char read3d8()
{
//        printf("Read 3D8 %02X\n",cgamode);
        return cgamode;
}

unsigned char read3dd()
{
        unsigned char temp=port3dd;
        port3dd&=0x1F;
//        printf("Read 3DD %02X\n",temp);
        return temp;
}

unsigned char read3de()
{
//        printf("Read 3DE %02X\n",(port3de&0xC7)|8);
        return (port3de&0xC7)|8; /*External CGA*/
}

unsigned char read3df()
{
        return port3df;
}

void write3de(unsigned char val)
{
//        printf("Write 3DE %02X\n",val);
        port3de=val;
        port3dd=0x1F;
        if (val&0x80) port3dd|=0x40;
}

void writecgamode(unsigned char val)
{
//        printf("Write CGAMODE %02X\n",val);
        if ((cgamode&0x12)!=0x12 && (val&0x12)==0x12) amswrite=15;
        cgamode=val;
        if (romset==ROM_PC200) port3dd|=0x80;
        if (AMSTRADIO)
        {
                crtc[0]=(cgamode&1)?0x71:0x38;
                crtc[1]=(cgamode&1)?80:40;
                crtc[4]=(cgamode&2)?127:31;
                crtc[5]=6;
                crtc[6]=(cgamode&2)?100:25;
                crtc[7]=(cgamode&2)?112:28;
                recalccgatimings();
        }
}


/*MDA/Hercules*/
unsigned char crtcm[32],crtcmreg;

void recalcmdatimings()
{
        if (!MDA) return;
        disptime=crtc[0]+1;
        dispontime=crtc[1];
        dispofftime=disptime-dispontime;
//        printf("%i %f %f %f  %i %i\n",cgamode&1,disptime,dispontime,dispofftime,crtc[0],crtc[1]);
        dispontime*=MDACONST;
        dispofftime*=MDACONST;
//        printf("Timings - on %f off %f frame %f second %f\n",dispontime,dispofftime,(dispontime+dispofftime)*262.0,(dispontime+dispofftime)*370.0*50);
}

void writecrtcm(unsigned short addr, unsigned char val)
{
        if (!(addr&1)) crtcmreg=val&31;
        else
        {
                crtcm[crtcmreg]=val;
                //printf("Write CRTC %i %02X\n",crtcmreg,val);
                recalcmdatimings();
                if (crtcm[10]==6 && crtcm[11]==7) /*Fix for Generic Turbo XT BIOS, which sets up cursor registers wrong*/
                {
                        crtcm[10]=0xB;
                        crtcm[11]=0xC;
                }
        }
}

unsigned char readcrtcm(unsigned short addr)
{
        if (!(addr&1)) return crtcmreg;
        else           return crtcm[crtcmreg];
}

unsigned char mdactrl,hercctrl;
int hercgfx=0;
void writemda(unsigned short addr, unsigned char val)
{
        if (addr==0x3BF) hercctrl=val;
        if (addr==0x3B8) mdactrl=val;
        hercgfx=(hercctrl&1)&&(mdactrl&2);
}

int mdacols[256][2][2];
void pollmda()
{
        unsigned short ca=(crtcm[15]|(crtcm[14]<<8))&0x3FFF;
        int drawcursor;
        int x,c;
        int oldvc;
        unsigned char chr,attr;
        unsigned short dat,dat2,dat3,dat4;
        int cols[4];
        int col;
        int oldsc;
        int blink;
        if (!linepos)
        {
                vidtime+=dispofftime;
                cgastat|=1;
                linepos=1;
                oldsc=sc;
                if ((crtcm[8]&3)==3) sc=(sc<<1)&7;
                if (cgadispon)
                {
                        if (displine<firstline)
                        {
                                firstline=displine;
                        }
                        lastline=displine;
                        cols[0]=0;
                        cols[1]=7;
                        if (hercgfx && HERCULES)
                        {
                                ca=(sc&3)*0x2000;
                                if (mdactrl&0x80) ca+=0x8000;
//                                printf("Draw herc %04X\n",ca);
                                for (x=0;x<crtcm[1];x++)
                                {
                                        dat=(vram[((ma<<1)&0x1FFF)+ca]<<8)|vram[((ma<<1)&0x1FFF)+ca+1];
                                        ma++;
                                        for (c=0;c<16;c++)
                                            buffer->line[displine][(x<<4)+c]=(dat&(32768>>c))?7:0;
                                }
                        }
                        else
                        {
                                for (x=0;x<crtcm[1];x++)
                                {
                                        chr=vram[(ma<<1)&0x3FFF];
                                        attr=vram[((ma<<1)+1)&0x3FFF];
                                        drawcursor=((ma==ca) && con && cursoron);
                                        blink=((cgablink&16) && (mdactrl&0x20) && (attr&0x80) && !drawcursor);
                                        if (sc==12 && ((attr&7)==1))
                                        {
                                                for (c=0;c<9;c++)
                                                    buffer->line[displine][(x*9)+c]=mdacols[attr][blink][1];
                                        }
                                        else
                                        {
                                                for (c=0;c<8;c++)
                                                    buffer->line[displine][(x*9)+c]=mdacols[attr][blink][(fontdatm[chr][sc]&(1<<(c^7)))?1:0];
                                                if ((chr&~0x1F)==0xC0) buffer->line[displine][(x*9)+8]=mdacols[attr][blink][fontdatm[chr][sc]&1];
                                                else                   buffer->line[displine][(x*9)+8]=mdacols[attr][blink][0];
                                        }
                                        ma++;
                                        if (drawcursor)
                                        {
                                                for (c=0;c<9;c++)
                                                    buffer->line[displine][(x*9)+c]^=mdacols[attr][0][1];
                                        }
                                }
                        }
                }
                sc=oldsc;
                if (vc==crtcm[7] && !sc)
                {
                        cgastat|=8;
//                        printf("VSYNC on %i %i\n",vc,sc);
                }
                displine++;
                if (displine>=500) displine=0;
        }
        else
        {
                vidtime+=dispontime;
                if (cgadispon) cgastat&=~1;
                linepos=0;
                if (vsynctime)
                {
                        vsynctime--;
                        if (!vsynctime)
                        {
                                cgastat&=~8;
//                                printf("VSYNC off %i %i\n",vc,sc);
                        }
                }
                if (sc==(crtcm[11]&31) || ((crtcm[8]&3)==3 && sc==((crtcm[11]&31)>>1))) { con=0; coff=1; }
                if (vadj)
                {
                        sc++;
                        sc&=31;
                        ma=maback;
                        vadj--;
                        if (!vadj)
                        {
                                cgadispon=1;
                                ma=maback=(crtcm[13]|(crtcm[12]<<8))&0x3FFF;
                                sc=0;
                        }
                }
                else if (sc==crtcm[9] || ((crtcm[8]&3)==3 && sc==(crtcm[9]>>1)))
                {
                        maback=ma;
                        sc=0;
                        oldvc=vc;
                        vc++;
                        vc&=127;
                        if (vc==crtcm[6]) cgadispon=0;
                        if (oldvc==crtcm[4])
                        {
//                                printf("Display over at %i\n",displine);
                                vc=0;
                                vadj=crtcm[5];
                                if (!vadj) cgadispon=1;
                                if (!vadj) ma=maback=(crtcm[13]|(crtcm[12]<<8))&0x3FFF;
                                if ((crtcm[10]&0x60)==0x20) cursoron=0;
                                else                        cursoron=cgablink&16;
                        }
                        if (vc==crtcm[7])
                        {
                                cgadispon=0;
                                displine=0;
                                vsynctime=16;//(crtcm[3]>>4)+1;
                                if (crtcm[7])
                                {
//                                        printf("Lastline %i Firstline %i  %i\n",lastline,firstline,lastline-firstline);
                                        if (hercgfx && HERCULES) x=crtcm[1]<<4;
                                        else                     x=crtcm[1]*9;
                                        if (x!=xsize || (lastline-firstline)!=ysize)
                                        {
                                                xsize=x;
                                                ysize=lastline-firstline;
//                                                printf("Resize to %i,%i - R1 %i\n",xsize,ysize,crtcm[1]);
                                                if (xsize<64) xsize=656;
                                                if (ysize<32) ysize=200;
                                                updatewindowsize(xsize,ysize);
                                        }
                                startblit();
                                        blit(buffer,screen,0,firstline,0,0,xsize,(lastline-firstline)+1);
                                        if (readflash) rectfill(screen,600,8,632,14,0xFFFFFFFF);
                                        readflash=0;
                                endblit();
                                }
                                firstline=1000;
                                lastline=0;
                                cgablink++;
                        }
                }
                else
                {
                        sc++;
                        sc&=31;
                        ma=maback;
                }
                if ((sc==(crtcm[10]&31) || ((crtcm[8]&3)==3 && sc==((crtcm[10]&31)>>1))))
                {
                        con=1;
//                        printf("Cursor on - %02X %02X %02X\n",crtcm[8],crtcm[10],crtcm[11]);
                }
        }
}
unsigned char gdcreg[16];
void writevramgen(unsigned short addr, unsigned char val)
{
        cycles-=4;
        if (VGA && ((gdcreg[6]&0xC)!=0xC)) return;
        if (VGA) fullchange=2;
//        output=3;
//        if (addr==0x8000 && output) output=3;
//        /*if (addr>=0x8000 && addr<0x9000) */printf("Write VRAM gen %04X %02X %c %i %i\n",addr,val,(val>31)?val:'.',AMSTRAD,EGA);
/*        if (addr==0x821A && val=='X')
        {
                dumpregs();
                exit(-1);
        }*/
        if (addr&0x8000 && !MDA)
        {
                if (EGA) vram[(addr&0x7FFF)<<2]=val;
                else     vram[addr&0x7FFF]=val;
        }
        if (!(addr&0x8000) && MDA) vram[addr&0x7FFF]=val;
        if (romset<3)
        {
                if ((cgamode&1) && cgadispon && !linepos)
                {
                        charbuffer[((int)(((dispontime-vidtime)*2)/CGACONST))&255]=val;
                }
        }
}

void writevram(unsigned short addr, unsigned char val)
{
        cycles-=4;
        if (!(addr&0x8000)) return;
        addr&=0x7FFF;
//        printf("Write VRAM %04X %02X %02X %02X %02X\n",addr,val,cgamode,amswrite,cgacol);
        if ((cgamode&0x12)==0x12)
        {
//                printf("AMSWRITE\n");
                if (amswrite&1) vram[addr]=val;
                if (amswrite&2) vram[addr|0x10000]=val;
                if (amswrite&4) vram[addr|0x20000]=val;
                if (amswrite&8) vram[addr|0x30000]=val;
        }
        else
           vram[addr]=val;
}

unsigned char readvram(unsigned short addr)
{
        cycles-=4;
        if (!(addr&0x8000) && MDA) return vram[addr&0x7FFF];
        if (!(addr&0x8000)) return 0xFF;
        addr&=0x7FFF;
        if ((cgamode&0x12)==0x12 && AMSTRAD)
        {
//                printf("Amstrad read %04X %i %02X\n",addr,amsread,vram[addr|(amsread<<16)]);
                return vram[addr|(amsread<<16)];
        }
//        printf("Amstrad read %04X %02X\n",addr,vram[addr]);
        return vram[addr];
}

void writeams(unsigned short addr, unsigned char val)
{
//        printf("Amstrad write %04X %02X\n",addr,val);
        if (addr==0x3DD) amswrite=val;
        if (addr==0x3DE) amsread=val&3;
}

/*PCjr/Tandy*/
unsigned char array[32];
int arrayreg;
void writearray(unsigned short addr, unsigned char val)
{
//        printf("Write addr %04X %02X\n",addr,val);
        if (addr&4)
        {
                if (arrayreg&16) val&=0xF;
                array[arrayreg&31]=val;
//                if (arrayreg<16) printf("Register %i now %02X\n",arrayreg,val);
        }
        else
           arrayreg=val&31;
}

unsigned char *tandyvram,*tandyb8000;
int tandymemctrl=-1;
unsigned long tandybase=0;
void recalctandyaddress()
{
        if ((tandymemctrl&0xC0)==0xC0)
        {
                tandyvram=&ram[((tandymemctrl&0x6)<<14)+tandybase];
                tandyb8000=&ram[((tandymemctrl&0x30)<<11)+tandybase];
//                printf("VRAM at %05X B8000 at %05X\n",((tandymemctrl&0x6)<<14)+tandybase,((tandymemctrl&0x30)<<11)+tandybase);
        }
        else
        {
                tandyvram=&ram[((tandymemctrl&0x7)<<14)+tandybase];
                tandyb8000=&ram[((tandymemctrl&0x38)<<11)+tandybase];
//                printf("VRAM at %05X B8000 at %05X\n",((tandymemctrl&0x7)<<14)+tandybase,((tandymemctrl&0x38)<<11)+tandybase);
        }
}

void writetandy(unsigned short addr, unsigned char val)
{
        if (addr==0x3DA || addr==0x3DE) writearray(addr,val);
//        printf("Write Tandy %03X %02X\n",addr,val);
        if (addr==0x3DF)
        {
                tandymemctrl=val;
                recalctandyaddress();
        }
        if (addr==0xA0)
        {
                tandybase=((val>>1)&7)*128*1024;
                recalctandyaddress();
        }
}

void writetandyvram(unsigned short addr, unsigned char val)
{
//        if (tandybase==0xA0000) return;
        if (tandymemctrl==-1) return;
        if (addr&0x8000) tandyb8000[addr&0x7FFF]=val;
//        printf("Write tandy vram %04X,%02X %04X:%04X %04X %05X\n",addr,val,cs>>4,pc,ds>>4,((tandymemctrl&0x38)<<11)+0x80000+(addr&0x7FFF));
        //        if (addr==0xBE84) output=1;
}

unsigned char readtandyvram(unsigned short addr)
{
        if (tandymemctrl==-1) return 0xFF;
//        printf("Read tandy vram %04X %02X\n",addr&0x7FFF,tandyb8000[addr&0x7FFF]);
        if (addr&0x8000) return tandyb8000[addr&0x7FFF];
         return 0xFF;
}

int cga4pal[8][4]=
{
        {0,2,4,6},{0,3,5,7},{0,3,4,7},{0,3,4,7},
        {0,10,12,14},{0,11,13,15},{0,11,12,15},{0,11,12,15}
};

void polltandy()
{
        int *cgapal=cga4pal[((cgacol&0x10)>>2)|((cgamode&4)>>1)|((cgacol&0x20)>>5)];
        unsigned short ca=(crtc[15]|(crtc[14]<<8))&0x3FFF;
        int drawcursor;
        int x,c;
        int oldvc;
        unsigned char chr,attr;
        unsigned short dat,dat2,dat3,dat4;
        int cols[4];
        int col;
        int oldsc;
        if (!linepos)
        {
                cgapal[0]=cgacol&15;
//                printf("Firstline %i Lastline %i Displine %i\n",firstline,lastline,displine);
                vidtime+=dispofftime;
                cgastat|=1;
                linepos=1;
                oldsc=sc;
                if ((crtc[8]&3)==3) sc=(sc<<1)&7;
                if (cgadispon)
                {
                        if (displine<firstline)
                        {
                                firstline=displine;
//                                printf("Firstline %i\n",firstline);
                        }
                        lastline=displine;
                        cols[0]=(array[2]&0xF)+16;
                        for (c=0;c<8;c++)
                        {
                                if (array[3]&4)
                                {
                                        buffer->line[displine][c]=cols[0];
                                        if (cgamode&1) buffer->line[displine][c+(crtc[1]<<3)+8]=cols[0];
                                        else           buffer->line[displine][c+(crtc[1]<<4)+8]=cols[0];
                                }
                                else if ((cgamode&0x12)==0x12)
                                {
                                        buffer->line[displine][c]=0;
                                        if (cgamode&1) buffer->line[displine][c+(crtc[1]<<3)+8]=0;
                                        else           buffer->line[displine][c+(crtc[1]<<4)+8]=0;
                                }
                                else
                                {
                                        buffer->line[displine][c]=(cgacol&15)+16;
                                        if (cgamode&1) buffer->line[displine][c+(crtc[1]<<3)+8]=(cgacol&15)+16;
                                        else           buffer->line[displine][c+(crtc[1]<<4)+8]=(cgacol&15)+16;
                                }
                        }
//                        printf("X %i %i\n",c+(crtc[1]<<4)+8,c+(crtc[1]<<3)+8);
//                        printf("Drawing %i %i %i\n",displine,vc,sc);
                        if ((array[3]&0x10) && (cgamode&1)) /*320x200x16*/
                        {
                                for (x=0;x<crtc[1];x++)
                                {
                                        dat=(tandyvram[((ma<<1)&0x1FFF)+((sc&3)*0x2000)]<<8)|tandyvram[((ma<<1)&0x1FFF)+((sc&3)*0x2000)+1];
                                        ma++;
                                        buffer->line[displine][(x<<3)+8]=buffer->line[displine][(x<<3)+9]=array[((dat>>12)&array[1])+16]+16;
                                        buffer->line[displine][(x<<3)+10]=buffer->line[displine][(x<<3)+11]=array[((dat>>8)&array[1])+16]+16;
                                        buffer->line[displine][(x<<3)+12]=buffer->line[displine][(x<<3)+13]=array[((dat>>4)&array[1])+16]+16;
                                        buffer->line[displine][(x<<3)+14]=buffer->line[displine][(x<<3)+15]=array[(dat&array[1])+16]+16;
                                }
                        }
                        else if (array[3]&0x10) /*160x200x16*/
                        {
                                for (x=0;x<crtc[1];x++)
                                {
                                        dat=(tandyvram[((ma<<1)&0x1FFF)+((sc&3)*0x2000)]<<8)|tandyvram[((ma<<1)&0x1FFF)+((sc&3)*0x2000)+1];
                                        ma++;
                                        buffer->line[displine][(x<<4)+8]=buffer->line[displine][(x<<4)+9]=buffer->line[displine][(x<<4)+10]=buffer->line[displine][(x<<4)+11]=array[((dat>>12)&array[1])+16]+16;
                                        buffer->line[displine][(x<<4)+12]=buffer->line[displine][(x<<4)+13]=buffer->line[displine][(x<<4)+14]=buffer->line[displine][(x<<4)+15]=array[((dat>>8)&array[1])+16]+16;
                                        buffer->line[displine][(x<<4)+16]=buffer->line[displine][(x<<4)+17]=buffer->line[displine][(x<<4)+18]=buffer->line[displine][(x<<4)+19]=array[((dat>>4)&array[1])+16]+16;
                                        buffer->line[displine][(x<<4)+20]=buffer->line[displine][(x<<4)+21]=buffer->line[displine][(x<<4)+22]=buffer->line[displine][(x<<4)+23]=array[(dat&array[1])+16]+16;
                                }
                        }
                        else if (array[3]&0x08) /*640x200x4 - this implementation is a complete guess!*/
                        {
                                for (x=0;x<crtc[1];x++)
                                {
                                        dat=(tandyvram[((ma<<1)&0x1FFF)+((sc&3)*0x2000)]<<8)|tandyvram[((ma<<1)&0x1FFF)+((sc&3)*0x2000)+1];
                                        ma++;
                                        for (c=0;c<8;c++)
                                        {
                                                chr=(dat>>7)&1;
                                                chr|=((dat>>14)&2);
                                                buffer->line[displine][(x<<3)+8+c]=array[(chr&array[1])+16]+16;
                                                dat<<=1;
                                        }
/*                                        buffer->line[displine][(x<<3)+9]=array[((dat>>12)&array[1])+16]+16;
                                        buffer->line[displine][(x<<3)+10]=array[((dat>>10)&array[1])+16]+16;
                                        buffer->line[displine][(x<<3)+11]=array[((dat>>8)&array[1])+16]+16;
                                        buffer->line[displine][(x<<3)+12]=array[((dat>>6)&array[1])+16]+16;
                                        buffer->line[displine][(x<<3)+13]=array[((dat>>4)&array[1])+16]+16;
                                        buffer->line[displine][(x<<3)+14]=array[((dat>>2)&array[1])+16]+16;
                                        buffer->line[displine][(x<<3)+15]=array[(dat&array[1])+16]+16;*/
                                }
                        }
                        else if (cgamode&1)
                        {
                                for (x=0;x<crtc[1];x++)
                                {
                                        chr=tandyvram[(ma<<1)&0x3FFF];
                                        attr=tandyvram[((ma<<1)+1)&0x3FFF];
                                        drawcursor=((ma==ca) && con && cursoron);
                                        if (cgamode&0x20)
                                        {
                                                cols[1]=array[((attr&15)&array[1])+16]+16;
                                                cols[0]=array[(((attr>>4)&7)&array[1])+16]+16;
                                                if ((cgablink&16) && (attr&0x80) && !drawcursor) cols[1]=cols[0];
                                        }
                                        else
                                        {
                                                cols[1]=array[((attr&15)&array[1])+16]+16;
                                                cols[0]=array[((attr>>4)&array[1])+16]+16;
                                        }
                                        if (sc&8)
                                        {
                                                for (c=0;c<8;c++)
                                                    buffer->line[displine][(x<<3)+c+8]=cols[0];
                                        }
                                        else
                                        {
                                                for (c=0;c<8;c++)
                                                    buffer->line[displine][(x<<3)+c+8]=cols[(fontdat[chr][sc&7]&(1<<(c^7)))?1:0];
                                        }
//                                        if (!((ma^(crtc[15]|(crtc[14]<<8)))&0x3FFF)) printf("Cursor match! %04X\n",ma);
                                        if (drawcursor)
                                        {
                                                for (c=0;c<8;c++)
                                                    buffer->line[displine][(x<<3)+c+8]^=15;
                                        }
                                        ma++;
                                }
                        }
                        else if (!(cgamode&2))
                        {
                                for (x=0;x<crtc[1];x++)
                                {
                                        chr=tandyvram[(ma<<1)&0x3FFF];
                                        attr=tandyvram[((ma<<1)+1)&0x3FFF];
                                        drawcursor=((ma==ca) && con && cursoron);
                                        if (cgamode&0x20)
                                        {
                                                cols[1]=array[((attr&15)&array[1])+16]+16;
                                                cols[0]=array[(((attr>>4)&7)&array[1])+16]+16;
                                                if ((cgablink&16) && (attr&0x80) && !drawcursor) cols[1]=cols[0];
                                        }
                                        else
                                        {
                                                cols[1]=array[((attr&15)&array[1])+16]+16;
                                                cols[0]=array[((attr>>4)&array[1])+16]+16;
                                        }
                                        ma++;
                                        if (sc&8)
                                        {
                                                for (c=0;c<8;c++)
                                                    buffer->line[displine][(x<<4)+(c<<1)+8]=buffer->line[displine][(x<<4)+(c<<1)+1+8]=cols[0];
                                        }
                                        else
                                        {
                                                for (c=0;c<8;c++)
                                                    buffer->line[displine][(x<<4)+(c<<1)+8]=buffer->line[displine][(x<<4)+(c<<1)+1+8]=cols[(fontdat[chr][sc&7]&(1<<(c^7)))?1:0];
                                        }
                                        if (drawcursor)
                                        {
                                                for (c=0;c<16;c++)
                                                    buffer->line[displine][(x<<4)+c+8]^=15;
                                        }
                                }
                        }
                        else if (!(cgamode&16))
                        {
                                if (cgacol&32) col=4;
                                else           col=0;
                                if (cgacol&16) col|=8;
                                if (cgamode&4) col|=0x30;
                                cols[0]=(cgacol&15)|16;
                                cols[1]=col|1;
                                cols[2]=col|2;
                                cols[3]=col|3;
                                for (x=0;x<crtc[1];x++)
                                {
                                        dat=(tandyvram[((ma<<1)&0x1FFF)+((sc&1)*0x2000)]<<8)|tandyvram[((ma<<1)&0x1FFF)+((sc&1)*0x2000)+1];
                                        ma++;
                                        for (c=0;c<8;c++)
                                        {
                                                buffer->line[displine][(x<<4)+(c<<1)+8]=
                                                  buffer->line[displine][(x<<4)+(c<<1)+1+8]=cgapal[dat>>14]+16;
                                                dat<<=2;
                                        }
                                }
                        }
                        else
                        {
                                cols[0]=0; cols[1]=array[(cgacol&array[1])+16]+16;
                                for (x=0;x<crtc[1];x++)
                                {
                                        dat=(tandyvram[((ma<<1)&0x1FFF)+((sc&1)*0x2000)]<<8)|tandyvram[((ma<<1)&0x1FFF)+((sc&1)*0x2000)+1];
                                        ma++;
                                        for (c=0;c<16;c++)
                                        {
                                                buffer->line[displine][(x<<4)+c+8]=cols[dat>>15];
                                                dat<<=1;
                                        }
                                }
                        }
                }
                else
                {
                        if (array[3]&4)
                        {
                                if (cgamode&1) hline(buffer,0,displine,(crtc[1]<<3)+16,(array[2]&0xF)+16);
                                else           hline(buffer,0,displine,(crtc[1]<<4)+16,(array[2]&0xF)+16);
                        }
                        else
                        {
                                cols[0]=((cgamode&0x12)==0x12)?0:(cgacol&15)+16;
                                if (cgamode&1) hline(buffer,0,displine,(crtc[1]<<3)+16,cols[0]);
                                else           hline(buffer,0,displine,(crtc[1]<<4)+16,cols[0]);
                        }
                }
                sc=oldsc;
                if (vc==crtc[7] && !sc)
                {
                        cgastat|=8;
//                        printf("VSYNC on %i %i\n",vc,sc);
                }
                displine++;
                if (displine>=360) displine=0;
        }
        else
        {
                vidtime+=dispontime;
                if (cgadispon) cgastat&=~1;
                linepos=0;
                if (vsynctime)
                {
                        vsynctime--;
                        if (!vsynctime)
                        {
                                cgastat&=~8;
//                                printf("VSYNC off %i %i\n",vc,sc);
                        }
                }
                if (sc==(crtc[11]&31) || ((crtc[8]&3)==3 && sc==((crtc[11]&31)>>1))) { con=0; coff=1; }
                if (vadj)
                {
                        sc++;
                        sc&=31;
                        ma=maback;
                        vadj--;
                        if (!vadj)
                        {
                                cgadispon=1;
                                ma=maback=(crtc[13]|(crtc[12]<<8))&0x3FFF;
                                sc=0;
//                                printf("Display on!\n");
                        }
                }
                else if (sc==crtc[9] || ((crtc[8]&3)==3 && sc==(crtc[9]>>1)))
                {
                        maback=ma;
//                        con=0;
//                        coff=0;
                        sc=0;
                        oldvc=vc;
                        vc++;
                        vc&=127;
//                        printf("VC %i %i %i %i  %i\n",vc,crtc[4],crtc[6],crtc[7],cgadispon);
                        if (vc==crtc[6]) cgadispon=0;
                        if (oldvc==crtc[4])
                        {
//                                printf("Display over at %i\n",displine);
                                vc=0;
                                vadj=crtc[5];
                                if (!vadj) cgadispon=1;
                                if (!vadj) ma=maback=(crtc[13]|(crtc[12]<<8))&0x3FFF;
                                if ((crtc[10]&0x60)==0x20) cursoron=0;
                                else                       cursoron=cgablink&16;
//                                printf("CRTC10 %02X %i\n",crtc[10],cursoron);
                        }
                        if (vc==crtc[7])
                        {
                                cgadispon=0;
                                displine=0;
                                vsynctime=16;//(crtc[3]>>4)+1;
//                                printf("Vsynctime %i %02X\n",vsynctime,crtc[3]);
//                                cgastat|=8;
                                if (crtc[7])
                                {
//                                        printf("Lastline %i Firstline %i  %i   %i %i\n",lastline,firstline,lastline-firstline,crtc[1],xsize);
                                        if (cgamode&1) x=(crtc[1]<<3)+16;
                                        else           x=(crtc[1]<<4)+16;
                                        if (x!=xsize || (lastline-firstline)!=ysize)
                                        {
                                                xsize=x;
                                                ysize=lastline-firstline;
//                                                printf("Resize to %i,%i - R1 %i\n",xsize,ysize,crtc[1]);
                                                if (xsize<64) xsize=656;
                                                if (ysize<32) ysize=200;
                                                updatewindowsize(xsize,(ysize<<1)+16);
                                        }
//                                        printf("Blit %i %i\n",firstline,lastline);
//printf("Xsize is %i\n",xsize);
                                startblit();
                                        blit(buffer,vbuf,0,firstline-4,0,0,xsize,(lastline-firstline)+8+1);
                                        stretch_blit(vbuf,screen,0,0,xsize,(lastline-firstline)+8+1,0,0,xsize,((lastline-firstline)<<1)+16+2);
                                        if (readflash) rectfill(screen,600,8,632,14,0xFFFFFFFF);
                                        readflash=0;
                                endblit();
                                }
                                firstline=1000;
                                lastline=0;
                                cgablink++;
                        }
                }
                else
                {
                        sc++;
                        sc&=31;
                        ma=maback;
                }
                if ((sc==(crtc[10]&31) || ((crtc[8]&3)==3 && sc==((crtc[10]&31)>>1)))) con=1;
                if (cgadispon && (cgamode&1))
                {
                        for (x=0;x<(crtc[1]<<1);x++)
                            charbuffer[x]=vram[(((ma<<1)+x)&0x3FFF)+0x8000];
                }
        }
}

void drawscr()
{
//        printf("Mode %i\n",array[3]);
}

PALETTE cgapal=
{
        {0,0,0},{0,42,0},{42,0,0},{42,21,0},
        {0,0,0},{0,42,42},{42,0,42},{42,42,42},
        {0,0,0},{21,63,21},{63,21,21},{63,63,21},
        {0,0,0},{21,63,63},{63,21,63},{63,63,63},

        {0,0,0},{0,0,42},{0,42,0},{0,42,42},
        {42,0,0},{42,0,42},{42,21,00},{42,42,42},
        {21,21,21},{21,21,63},{21,63,21},{21,63,63},
        {63,21,21},{63,21,63},{63,63,21},{63,63,63},

        {0,0,0},{0,21,0},{0,0,42},{0,42,42},
        {42,0,21},{21,10,21},{42,0,42},{42,0,63},
        {21,21,21},{21,63,21},{42,21,42},{21,63,63},
        {63,0,0},{42,42,0},{63,21,42},{41,41,41},
        
        {0,0,0},{0,42,42},{42,0,0},{42,42,42},
        {0,0,0},{0,42,42},{42,0,0},{42,42,42},
        {0,0,0},{0,63,63},{63,0,0},{63,63,63},
        {0,0,0},{0,63,63},{63,0,0},{63,63,63},
};

void loadfont()
{
        FILE *f=fopen("mda.rom","rb");
        int c,d;
        for (c=0;c<256;c++)
        {
                for (d=0;d<8;d++)
                {
                        fontdatm[c][d]=getc(f);
                }
        }
        for (c=0;c<256;c++)
        {
                for (d=0;d<8;d++)
                {
                        fontdatm[c][d+8]=getc(f);
                }
        }
        fseek(f,4096+2048,SEEK_SET);
        for (c=0;c<256;c++)
        {
                for (d=0;d<8;d++)
                {
                        fontdat[c][d]=getc(f);
                }
        }
        fclose(f);
}


void drawscreen()
{
//        printf("Drawscreen %i %i %i %i\n",gfxcard,MDA,EGA,TANDY);
//        if (EGA) drawscreenega(buffer,vbuf);
/*        else if (MDA) {}//drawscreenmda();
        else if (TANDY)
        {
                if ((cgamode&3)==3 || array[3]&0x10) drawscreentandy(tandyvram);
                else                drawscreencga(tandyvram);
        }*/
//        else            drawscreencga(&vram[0x8000]);
        frames++;
}

void initvideo()
{
        int c,d;
        set_color_depth(desktop_color_depth());
        if (set_gfx_mode(GFX_AUTODETECT_WINDOWED,1280,1024,0,0))
           set_gfx_mode(GFX_AUTODETECT_WINDOWED,1024,768,0,0);
        vbuf=create_system_bitmap(1280+32,1024+32);
//        vbuf2=create_video_bitmap(160,200);
        set_color_depth(32);
        buffer32=create_bitmap(2048,2048);
        set_color_depth(8);
        buffer=create_bitmap(2048,2048);
        for (c=0;c<64;c++)
        {
                cgapal[c+64].r=(((c&4)?2:0)|((c&0x10)?1:0))*21;
                cgapal[c+64].g=(((c&2)?2:0)|((c&0x10)?1:0))*21;
                cgapal[c+64].b=(((c&1)?2:0)|((c&0x10)?1:0))*21;
                if ((c&0x17)==6) cgapal[c+64].g>>=1;
        }
        for (c=0;c<64;c++)
        {
                cgapal[c+128].r=(((c&4)?2:0)|((c&0x20)?1:0))*21;
                cgapal[c+128].g=(((c&2)?2:0)|((c&0x10)?1:0))*21;
                cgapal[c+128].b=(((c&1)?2:0)|((c&0x08)?1:0))*21;
        }
        set_palette(cgapal);
        if (MDA && !TANDY && !AMSTRAD && romset!=ROM_PC200) updatewindowsize(720,350);
        else                                                updatewindowsize(656,416);
        for (c=17;c<64;c++) crtcmask[c]=0xFF;
}

void resetvideo()
{
        int c;
        tandybase=0x80000;
        tandymemctrl=0x3F;
        recalctandyaddress();
        tandymemctrl=-1;
        if (MDA && !TANDY && !AMSTRAD && romset!=ROM_PC200) updatewindowsize(720,350);
        else                                                updatewindowsize(656,416);
        cgastat=0;
        set_palette(cgapal);
        vc=sc=vadj=0;
        for (c=18;c<64;c++) crtcmask[c]=0xFF;
        crtc[0]=0x38;
        crtc[1]=0x28;
//        crtc[3]=0xFA;
        crtc[4]=0x7F;
        crtc[5]=0x06;
        crtc[6]=0x64;
        crtc[7]=0x70;
        crtc[8]=0x02;
        crtc[9]=1;
        recalccgatimings();
        cgacol=7;
        for (c=0;c<256;c++)
        {
                mdacols[c][0][0]=mdacols[c][1][0]=mdacols[c][1][1]=16;
                if (c&8) mdacols[c][0][1]=15+16;
                else     mdacols[c][0][1]=7+16;
        }
        mdacols[0x70][0][1]=16;
        mdacols[0x70][0][0]=mdacols[0x70][1][0]=mdacols[0x70][1][1]=16+15;
        mdacols[0xF0][0][1]=16;
        mdacols[0xF0][0][0]=mdacols[0xF0][1][0]=mdacols[0xF0][1][1]=16+15;
        mdacols[0x78][0][1]=16+7;
        mdacols[0x78][0][0]=mdacols[0x78][1][0]=mdacols[0x78][1][1]=16+15;
        mdacols[0xF8][0][1]=16+7;
        mdacols[0xF8][0][0]=mdacols[0xF8][1][0]=mdacols[0xF8][1][1]=16+15;
        switch (gfxcard)
        {
                case GFX_CGA: pollvideo=pollcga; break;
                case GFX_MDA:
                case GFX_HERCULES: pollvideo=pollmda; break;
        }
        if (TANDY) pollvideo=polltandy;
        if (EGA) pollvideo=pollega;
        if (romset==ROM_PC1512 || romset==ROM_PC200) pollvideo=pollcga;
//        tandyvram=&ram[0x9C000];
//        printf("Tandy VRAM %08X\n",tandyvram);
//        tandyb8000=&ram[0x9C000];
}

void closevideo()
{
        destroy_bitmap(buffer);
        destroy_bitmap(vbuf);
}
